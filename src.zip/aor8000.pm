#!/usr/bin/perl -w
package aor8000;
require Exporter;
use constant FALSE => 0;
use constant TRUE => 1;
@ISA   = qw(Exporter);
@EXPORT = qw(aor_cmd) ;
use strict;
use Data::Dumper;
use Text::ParseWords;
use radioctl;
use constant AOR_TERMINATOR => pack("H4","0D0A");
use Scalar::Util qw(looks_like_number);
use Time::HiRes qw( time usleep ualarm gettimeofday tv_interval );
use autovivification;
no  autovivification;
my @mode2rc = ('FMw','FMn','AM ','USB','LSB','CW');
my %rc2mode = ('rtty' => 5,'rtty-r' => 5,'cw-r' => 5,'amn' => 2,'amw' => 2);
foreach my $ndx (0..$#mode2rc) {$rc2mode{lc(strip($mode2rc[$ndx]))} = $ndx;}
my @rssi2sig   = (4,5,8,12,15,17,20,22,24,28);
my @sig2meter = (0,1,2, 3, 4, 5, 6, 7, 7, 7);
my %aorchans = ();
my $alpha = 'ABCDEFGHIJabcdefghij';
my $rcchan = 0;
foreach my $char (split "",$alpha) {
foreach my $num (0..49) {
my $key = $char . sprintf("%02.2u",$num);
$aorchans{$key} = $rcchan;
$rcchan++;
}
}
my @rcchan2aor = ();
foreach my $key (keys %aorchans) {$rcchan2aor[$aorchans{$key}] = $key;}
my $model = 'AOR-8000';
my $warn = TRUE;
my $chanper = 50;
my %state_save = (
'state' => '',
'mode'  => '',
);
my $protoname = 'aor';
use constant PROTO_NUMBER => 5;
$radio_routine{$protoname} = \&aor_cmd;
$valid_protocols{$protoname} = TRUE;
return TRUE;
sub aor_cmd {
my $cmdcode = shift @_;
if (!$cmdcode) {LogIt(779,"AOR_CMD:No command code specified");}
my $parmref = shift @_;
if (!$parmref) {LogIt(782,"AOR_CMD:No parmref reference specified. Command=>$cmdcode");}
if (ref($parmref) ne 'HASH') {LogIt(783,"AOR_CMD:parmref is NOT a reference to a hash! CMD=$cmdcode");}
if (!$parmref->{'def'}) {LogIt(786,"AOR_CMD:No 'def' specified in parmref");}
my $defref    = $parmref->{'def'};
if (ref($defref) ne 'HASH') {LogIt(788,"AOR_CMD:defref is NOT a reference to a hash! CMD=$cmdcode");}
my $out  = $parmref->{'out'};
if (!$out) {LogIt(792,"AOR_CMD:No 'out' defined in parmref! Command=>$cmdcode");}
if (ref($out) ne 'HASH') {LogIt(793,"AOR_CMD:Out spec in parmref is NOT a hash reference! CMD=$cmdcode");}
my $outsave = $out;
if (!$parmref->{'portobj'} and ($cmdcode ne 'autobaud')) {LogIt(797,"AOR_CMD:No portobj in parmref! CMD=$cmdcode");}
my $portobj = $parmref->{'portobj'};
my $db = $parmref->{'database'};
if ($db) {
if (ref($db) ne 'HASH') {LogIt(584,"AOR_CMD:Database spec in parmref is NOT a hash reference! CMD=$cmdcode");}
}
else {$db = '';}
my $write = $parmref->{'write'};
if (!$write) {$write = FALSE;}
my $in   = $parmref->{'in'};
if ($in) {
if (ref($in) ne 'HASH') {LogIt(580,"IN spec in parmref is NOT a hash reference! CMD=$cmdcode");}
}
else {$in = '';}
my $insave = $in;
my $delay = 10000;
$parmref->{'rc'} = $GoodCode;
my $parmstr = '';
if ($debug1) {LogIt(0,"AOR_CMD:command=$cmdcode");}
my $countout = 0;
my $instr= "";
my $rc = 0 ;
my $data_in;
my $count_in;
my $hex_data;
my $gotit = FALSE;
my $radio_set = $out;
my $channel = 0;
if ($cmdcode eq 'init') {
$delay = 500;
$defref->{'dualchan'} = FALSE ;
$defref->{'noscan'} = TRUE;
$defref->{'sqlchange'} = FALSE;
$defref->{'minfreq'} = 500000;
$defref->{'maxfreq'} = 1900000000;
$defref->{'maxchan'} = 999;
$defref->{'sigdet'} = 2;
$defref->{'group'} = FALSE;
$chanper = 50;
$defref->{'origin'} = 0;
$parmref->{'write'} = FALSE;
if (aor_cmd('VA',$parmref)) {
LogIt(1,"AOR does not appear to be connected");
return ($parmref->{'rc'});
}
$parmref->{'in'} = $insave;
return $parmref->{'rc'};
}
elsif ($cmdcode eq 'autobaud') {
my $model_save = $defref->{'model'};
my @allports = ();
if ($in->{'noport'} and $defref->{'port'}) {push @allports,$defref->{'port'};}
else {
if (lc($defref->{'model'}) ne 'icr30') {push @allports,glob("/dev/ttyUSB*");}
}
my @allbauds = ();
if ($in->{'nobaud'}) {push @allbauds,$defref->{'baudrate'};}
else {
@allbauds = (9600);
}
@allbauds = sort {$b <=> $a} @allbauds;
@allports = sort {$b cmp $a} @allports;
PORTLOOP:
foreach my $port (@allports) {
my $portobj =  Device::SerialPort->new($port) ;
if (!$portobj) {next;}
$parmref->{'portobj'} = $portobj;
$portobj->user_msg("ON");
$portobj->databits(8);
$portobj->handshake('none');
$portobj->read_const_time(100);
$portobj->write_settings || undef $portobj;
$portobj->read_char_time(0);
foreach my $baud (@allbauds) {
$portobj->baudrate($baud);
$warn = FALSE;
$parmref->{'write'} = FALSE;
$out->{'frequency'} = 0;
$rc = aor_cmd('RX',$parmref);
$warn = TRUE;
if (!$rc and $out->{'frequency'}) {### command succeeded
$defref->{'baudrate'} = $baud;
$defref->{'port'} = $port;
$portobj->close;
$parmref->{'portobj'} = undef;
return ($parmref->{'rc'} = $GoodCode);
}
}
$portobj->close;
$parmref->{'portobj'} = undef;
}
return ($parmref->{'rc'} = 1);
}
elsif ($cmdcode eq 'vfoinit') {
aor_cmd('DD',$parmref);
return $parmref->{'rc'};
}
elsif ($cmdcode eq 'meminit') {
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmdcode eq 'scan') {
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmdcode eq 'poll') {
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmdcode eq 'getvfo') {
if (!$outsave) {LogIt(968,"No 'out' reference in parmref for GETVFO call!");}
if ($parmref->{'rc'} = aor_cmd('LM',$parmref)) {return $parmref->{'rc'};}
aor_cmd('RX',$parmref);
return $parmref->{'rc'};
}
elsif ($cmdcode eq 'getsig') {
$out->{'signal'} = 0;
$out->{'sql'} = FALSE;
if (aor_cmd('LM',$parmref)) {return $parmref->{'rc'};}
if ($out->{'sql'}) {
aor_cmd('RX',$parmref);
}
return $parmref->{'rc'};
}
elsif ($cmdcode eq 'setvfo') {
if (!$in->{'frequency'}) {
add_message("AOR_CMD_l891:VFO frequency = 0 or undefined not allowed");
return ($parmref->{'rc'} = $ParmErr);
}
my %out = ();
$parmref->{'out'} = \%out;
aor_cmd('RX',$parmref);
if (($out{'state'} eq 'SCN') or ($out{'state'} eq 'MEM')) {
aor_cmd('VF',$parmref);
}
elsif ($out{'state'} eq 'SRC') {
aor_cmd('DD',$parmref);
}
my $state = $out{'state'};
$parmref->{'out'} = $outsave;
$parmref->{'write'} = TRUE;
if ($state eq 'VFO') {aor_cmd('VA',$parmref);}
elsif ($state eq 'HLD') {aor_cmd('RF',$parmref);}
else {LogIt(909,"AOR_CMD:Cannot deal with state $state!");}
return $parmref->{'rc'};
}
elsif ($cmdcode eq 'selmem') {
my $channel = $in ->{'channel'};
if (!defined $channel) {
add_message("AOR_CMD_l1171:Memory channel undefined not allowed");
return ($parmref->{'rc'} = $ParmErr);
}
if (($channel < 0) or ($channel > $defref->{'maxchan'})) {
return ($parmref->{'rc'} = $ParmErr);
}
aor_cmd ('MR',$parmref);
$parmref->{'in'} = $insave;
return $parmref->{'rc'};
}
elsif ($cmdcode eq 'getmem') {
if ($debug2) {LogIt(0,"AOR_CMD l1262:got 'getmem'");}
if (!$in) {LogIt(1165,"AOR_CMD:No 'in' defined for GETMEM");}
if (!$db) {LogIt(1166,"AOR_CMD:No database reference for GETMEM");}
my $startstate = $progstate;
my $maxcount = 1999;
my $maxchan = $defref->{'maxchan'};
my $channel =  $defref->{'origin'};
my $comment = TRUE;
my $nodup = FALSE;
if ($in->{'count'}) {$maxcount = $in->{'count'};}
if ($in->{'firstchan'} and ($in->{'firstchan'} < $maxchan)) {
$channel = $in->{'firstchan'};
}
if ($in->{'firstchan'} and ($in->{'lastchan'} < $maxchan)) {
$maxchan = $in->{'lastchan'};
}
if ($in->{'nocomment'}) {$comment = FALSE;}
my $noskip = $in->{'noskip'};
if (!$noskip) {$noskip = FALSE;}
my %duplist = ();
if ($in->{'nodup'}) {
$nodup = TRUE;
foreach my $rec (@{$db->{'freq'}}) {
my $ch = $rec->{'channel'};
if ((defined $ch) and (looks_like_number($ch))) {
$ch = $ch + 0;
$duplist{$ch} = $rec->{'index'}
}### Found a channel number
}### Looking through the current database
}### NODUP specified
my $count = 0;
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = FALSE;
my $sysno = $db->{'system'}[1]{'index'};
if ($sysno and $nodup) {
}
else {
my %sysrec = ('systemtype' => 'CNV','service' => "AOR8000", 'valid' => TRUE);
$sysno = add_a_record($db,'system',\%sysrec,$parmref->{'gui'});
}
my $igrp = 0;
my $grpndx = 0;
CHANLOOP:
while ($channel <= $maxchan) {
if (!$grpndx) {
my %grouprec = ('sysno' =>$sysno,
'service' => "AOR8000 Group/Bank:$igrp",
'valid' => TRUE
);
$grpndx = add_a_record($db,'group',\%grouprec,$parmref->{'gui'});
$igrp++;
my %newfreq = ('frequency' => 0,
'groupno' => $grpndx,
'channel' => $channel,
'service' => "Freqs for group $grpndx",
'_noshow' => TRUE,
'linecomment' => "*\n* ### Channels for group $grpndx"
);
if ($comment) {my $ndx1 = add_a_record($db,'freq',\%newfreq,FALSE);}
}### New group creation
$vfo{'channel'} = $channel;
$vfo{'groupno'} = $grpndx;
threads->yield;
if ($progstate ne $startstate) {
print "Exited loop as progstate changed\n";
last CHANLOOP;
}
if (!$parmref->{'gui'}) {
print STDERR "\rReading channel:$Bold$Green" . sprintf("%02.2u",$channel) .$Reset ;
}
$myout{'valid'} = FALSE;
$myout{'mode'} = 'auto';
$myout{'frequency'} = 0;
$myout{'tone'} = '_off';
$myout{'tone_type'} = 'off';
$myout{'dlyrsm'} = 0;
$myout{'atten'} = 0;
$myout{'service'} = '';
$myout{'tgid_valid'} = FALSE;
$myout{'channel'} = $channel;
$myout{'groupno'} = $grpndx;
$myin{'channel'} = $channel;
if ($nodup and $duplist{$channel}) {
}
else {
my $rc = aor_cmd ('MR',$parmref);
if ($rc) {
print "AOR8000:line 1444: Return code $rc from 'MR'\n";
}
else {
my $freq = $myout{'frequency'} + 0;
if ($noskip or $freq) {
if (!$freq) {$myout{'valid'} = FALSE;}
my $recno = add_a_record($db,'freq',\%myout,$parmref->{'gui'});
$vfo{'index'} = $recno;
$count++;
if ($count >= $maxcount) {last CHANLOOP;}
}### Not skipping
}### good return code from memory read routine
}### Not skipping duplicates
$channel++;
if (!($channel % $chanper)) {
$grpndx = 0;
}
}### Channel loop
print STDERR "\n";
$parmref->{'out'} = $outsave;
$parmref->{'in'} = $insave;
$outsave->{'count'} = $count;
$out->{'sysno'} = $sysno;
return ($parmref->{'rc'} = $GoodCode);
}### 'GETMEM'
elsif ($cmdcode eq 'setmem') {
my $freq = $in->{'frequency'};
my $clear = FALSE;
if ($freq) {
if  (($freq > $defref->{'maxfreq'}) or ($freq < $defref->{'minfreq'}) ) {
print "AOR8000 l1627:Frequency $freq out of range of radio\n";
return $NotForModel;
}
}### Frequency not 0
else {$clear = TRUE;}
aor_cmd('MX',$parmref);
return $parmref->{'rc'};
}
elsif ($cmdcode eq 'sdcard') {
my $freq = $in->{'frequency'};
my $mode = $in->{'mode'};
my $channel = $in->{'channel'};
my $sd_hash = $parmref->{'sdcard'};
return $GoodCode;
}
elsif ($cmdcode eq 'getglob') {
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = FALSE;
$parmref->{'write'} = $writesave;
$parmref->{'in'} = $insave;
$parmref->{'out'} = $outsave;
return ($parmref->{'rc'});
}
elsif ($cmdcode eq 'setglob') {
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = TRUE;
$parmref->{'write'} = $writesave;
$parmref->{'in'} = $insave;
$parmref->{'out'} = $outsave;
return ($parmref->{'rc'});
}
elsif ($cmdcode eq 'getsrch') {
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
my $startstate = $progstate;
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = FALSE;
$parmref->{'write'} = $writesave;
$parmref->{'in'} = $insave;
$parmref->{'out'} = $outsave;
return ($parmref->{'rc'});
}
elsif ($cmdcode eq 'setsrch') {
my %myin = ();
my %myout = ();
my $startstate = $progstate;
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = TRUE;
$parmref->{'write'} = $writesave;
$parmref->{'in'} = $insave;
$parmref->{'out'} = $outsave;
return ($parmref->{'rc'});
}
elsif ($cmdcode eq 'getinfo') {
aor_cmd('init',$parmref);
$out->{'chan_count'} = $defref->{'maxchan'};
$out->{'model'} = $model;
return ($parmref->{'rc'});
}
elsif ($cmdcode eq 'test') {
}
elsif ($cmdcode eq 'setsquelch') {
return;
}
elsif ($cmdcode eq 'AT') {
if ($parmref->{'write'}) {
if (!$in) {LogIt(782,"AOR:Missing IN for AT  command!");}
if ($in->{'atten'}) {$parmstr = 1;}
else {$parmstr = 0;}
}
else { }
}
elsif ($cmdcode eq 'AU') {
if ($parmref->{'write'}) {
if (!$in) {LogIt(882,"AOR:Missing IN for AU  command!");}
if ($in->{'auto'}) {$parmstr = 1;}
else {$parmstr = 0;}
}
else {  }
}
elsif ($cmdcode eq 'BM') {
if ($parmref->{'write'}) {
if (!$in) {LogIt(823,"AOR:Missing IN for BM  command!");}
$parmstr = $in->{'link'};
}
else {  }
}
elsif ($cmdcode eq 'BS') {
if ($parmref->{'write'}) {
if (!$in) {LogIt(858,"AOR:Missing IN for BS  command!");}
$parmstr = $in->{'link'};
}
else {  }
}
elsif ($cmdcode eq 'DD') {
}
elsif ($cmdcode eq 'LM') {
}
elsif ($cmdcode eq 'MQ') {
}
elsif ($cmdcode eq 'MR') {
my $channel = $in->{'channel'};
if (defined $channel and $channel >= 0) {
if ($channel > $parmref->{'maxchan'}) {return $ParmErr;}
$parmstr = rc2aor($channel);
}### Channel specified
}## MR command Pre-Process
elsif ($cmdcode eq 'MX') {
my $channel = $in->{'channel'};
if (!defined $channel) {LogIt(2087,"'MX':Forgot to included channel spec");}
my $rcchan = '';
if (($channel < 0) or ($channel > $parmref->{'maxchan'})) {
return ($parmref->{'rc'} = $ParmErr);
}
my $freq =  $in->{'frequency'};
if (!$freq) {
print "AOR8000 l2102:Removing channel $channel\n";
aor_cmd('MR',$parmref);
if ($out->{'frequency'}) {aor_cmd('MQ',$parmref);}
else {LogIt(1,"channel $channel ($parmstr) already cleared!");}
return $parmref->{'rc'};
}
$freq = Strip($freq);
my $lockout = 1;
if ($in->{'valid'}) {$lockout = 0;}
my $service = '.      ';
if ($in->{'service'}) {$service = sprintf("%7.7s",$in->{'service'});}
$parmref->{'write'} = TRUE;
my $aor_chan = rc2aor($channel);
$parmstr = "$aor_chan " .
"RF$freq MP$lockout AU0 " . set_keys($in) . " TM$service";
}## MX command
elsif ($cmdcode eq 'RF') {
if ($parmref->{'write'}) {
if (!$in) {LogIt(1208,"AOR:Missing IN for RF  command!");}
my $freq = Strip($in->{'frequency'});
if (!$freq) {
add_message("AOR_CMD_l1217:VFO frequency = 0 or undefined not allowed");
return ($parmref->{'rc'} = $ParmErr);
}
$parmstr = $freq . ' ' . set_keys($in);
}
}
elsif ($cmdcode eq 'RX') {
}
elsif (($cmdcode eq 'VA') or ($cmdcode eq 'VB')){
if ($parmref->{'write'}) {
if (!$in) {LogIt(1268,"AOR:Missing IN for $cmdcode command!");}
$parmstr = $in->{'frequency'};
if (!$parmstr) {
add_message("AOR_CMD_l1272:VFO frequency = 0 or undefined not allowed");
return ($parmref->{'rc'} = $ParmErr);
}
$parmstr = "$parmstr " . set_keys($in);
}
}
my %sendparms = (
'portobj' => $parmref->{'portobj'},
'term' => CR,
'delay' => $delay,
'resend' => 0,
'debug' => 0,
'fails' => 1,
'wait' => 30,
);
RESEND:
my $outstr = $cmdcode;
if ($cmdcode eq 'test') {$outstr = $parmstr}
else {
$outstr = strip("$outstr$parmstr");
}
if ($debug3) {LogIt(0,"AOR_CMD l1208:sent =>$outstr");}
my $sent = $outstr;
$outstr = $outstr . AOR_TERMINATOR;
WAIT:
if ($debug3) {LogIt(0,"AOR_CMD l800:Waiting for Radio_Send..");}
if (radio_send(\%sendparms,$outstr)) {### send with retry
if ($rc eq '-2') {LogIt(1186,"AOR.PM:No open port detected!");}
if (!$outstr) {
$parmref->{'rsp'} = FALSE;
return ($parmref->{'rc'} = $GoodCode);
}
else {
if ($warn) {### Don't display for autobaud
LogIt(1,"no response to =>$outstr<=");
if (!$parmref->{'rsp'}) {add_message("AOR_CMD l1806:Radio is not responding...");}
}
$parmref->{'rsp'} = TRUE;
return ($parmref->{'rc'} = $CommErr);
}
}
$instr = $sendparms{'rcv'};
$instr =~ tr /\n//;
$instr =~ tr /\r//;
chomp $instr;
if ($debug3) {LogIt(0,"AOR_CMD l1266:Radio returned=>$instr command=>$cmdcode");}
if (!$instr) {
if ($debug3) {LogIt(0,"Command $sent produced no data");}
return ($parmref->{'rc'} = $GoodCode);
}
if ($parmref->{'rsp'}) {add_message("Radio is responding again...");}
$parmref->{'rsp'} = FALSE;
my @returns = split " ",$instr;
$instr = strip($instr);
my @parms = split " ",$instr;
my $rtcmd = substr($instr,0,2);
if ($debug3) {LogIt(0,"AOR_CMD:CMD=$cmdcode AOR returned =>$instr<=");}
$parmref->{'rc'} = $GoodCode;
if ($cmdcode eq 'test') {
$parmref->{'rsp'} = FALSE;
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmdcode eq 'AT') {
if ($instr) {$out->{'atten'} = substr($instr,2,1);}
}### AT post-process
elsif ($cmdcode eq 'AU') {
if ($instr) {$out->{'auto'} = substr($instr,2,1);}
}#### AU post process
elsif ($cmdcode eq 'BM') {
if ($instr) {$out->{'link'} = substr($instr,2);}
}#### BM post process
elsif ($cmdcode eq 'BS') {
if ($instr) {$out->{'link'} = substr($instr,2);}
}#### BS post process
elsif ($cmdcode eq 'DD') {
extract_keys($out,$instr,'DD');
}
elsif ($cmdcode eq 'LM') {
extract_keys($out,$instr,'LM');
}### LM process
elsif ($cmdcode eq 'MQ') {
}
elsif ($cmdcode eq 'MR') {
extract_keys($out,$instr,'MR');
}
elsif ($cmdcode eq 'MX') {
LogIt(1,"Got response of $instr for MX command!");
}
elsif ($cmdcode eq 'RF') {
if ($parmref->{'write'}) { }
else { extract_keys($out,$instr,'RF');}
$out->{'state'} = 'HLD';
}
elsif ($cmdcode eq 'RX') {
extract_keys($out,$instr,'RX');
}
elsif (($cmdcode eq 'VA') or ($cmdcode eq 'VB')) {
if ($parmref->{'write'}) { }
else {extract_keys($out,$instr,'VA')};
$out->{'state'} = 'VFO';
}
else {
if (!$instr) {
LogIt(1,"AOR did not like command $cmdcode");
return ($parmref->{'rc'} = $NotForModel);
}
}### No handler process
return ($parmref->{'rc'});
}
sub extract_keys{
my $hash = shift @_;
my $data = shift @_;
my $caller = shift @_;
$hash->{'frequency'} = 0;
$hash->{'mode'} = $mode2rc[0];
$hash->{'atten'} = FALSE;
$hash->{'step'} = 1;
$hash->{'channel'} = -1;
$hash->{'valid'} = FALSE;
my @fields = split " ",$data;
foreach my $parm (@fields) {
my $key = substr($parm,0,2);
if (substr($key,0,1) eq '-') {next;}
my $value = '';
if (length($parm) > 2) {$value = substr($parm,2);}
if ($key eq 'VA') {$hash->{'frequency'} = $value;}
elsif ($key eq 'RF') {$hash->{'frequency'} = $value;}
elsif ($key eq 'VB') {$hash->{'frequency'} = $value;}
elsif ($key eq 'MD') {
$hash->{'mode'} = $mode2rc[$value];
}
elsif ($key eq 'AT') {$hash->{'atten'} = $value;}
elsif ($key eq 'ST') {$hash->{'step'} = $value;}
elsif ($key eq 'AU') { }### TODO:Auto:What to do with this?
elsif ($key eq 'MX') {
my $ch  = substr($value,1);
my $bank = substr($value,0,1);
my $igrp = index($alpha,$bank);
my $rcchan = $ch + ($igrp * $chanper);
$hash->{'channel'} = $rcchan;
$hash->{'_bank'} = $bank;
$hash->{'_ch'} = $ch;
}
elsif ($key eq 'LM') {
my $signal = rssi_cvt(substr($parm,2),$hash);
}
elsif ($key eq 'MP') {
if ($parm eq 'MP0') {$hash->{'valid'} = TRUE;}
}
elsif ($key eq 'TM') {
($hash->{'service'}) = $data =~ /TM(.*)/; 
last;
}
elsif ($key eq 'MS') {$hash->{'state'} = 'SCN';}
elsif ($key eq 'MR') {$hash->{'state'} = 'MEM';}
elsif ($key eq 'VF') {$hash->{'state'} = 'VFO';}
elsif ($key eq 'DD') {$hash->{'state'} = 'HLD';}
elsif ($key eq 'SS') {$hash->{'state'} = 'SRC';}
else {
if ($warn) {LogIt(1,"AOR_EXTRACT_KEYS:Unprocessed extract key $key");}
}
}
}
sub set_keys{
my $hash = shift @_;
my $options = '';
my $mode = $hash->{'mode'};
my $step = $hash->{'step'};
my $att  = $hash->{'atten'};
my $freq = $hash->{'frequency'};
if (!$freq) {$freq = 0;}
if (defined $mode) {
my $mode = lc(strip($hash->{'mode'}));
if ($mode eq 'auto') {$mode = lc(AutoMode($freq));}
my $modecode = $rc2mode{$mode};
if (defined $modecode) {$options = "MD$modecode";}
else {LogIt(1,"AOR_CMD:Undefined modulation $mode");}
}
if (defined $step) {$options = "$options ST$step";}
if (defined $att) {
if ($att) {$att = 1;}
else {$att = 0;}
$options = "$options AT$att";
}
return $options
}
sub rssi_cvt {
my $value = shift @_;
my $out = shift @_;
if (!$out) {LogIt(2851,"RSSI_CVT: No OUT reference passed!");}
my $signal = 0;
my $rssi = 0;
my $sql = FALSE;
$out->{'dbmv'} = $value;
if (!$value) {$value = 0;}
$value = Strip($value);
my $ishex = $value =~ /^[[:xdigit:]]+\z/;   
if ($value and $ishex)  {
$rssi = hex($value);
if ($rssi < 128) {$sql = TRUE;}
else {$rssi = $rssi - 128;}
foreach my $cmp (@rssi2sig) {
if (($rssi <=  $cmp) or ($signal >= MAXSIGNAL)){last;}
$signal++;
}
}
if (!$ishex) {
LogIt(1,"Invalid hex value $value passed to RSSI_CVT");
}
$out->{'meter'} = $sig2meter[$signal];
if ($sql and (!$signal)) {$signal = 1;}
$out->{'signal'} = $signal;
$out->{'sql'} = $sql;
$out->{'rssi'} = $rssi;
return $signal;
}
sub rc2aor {
my $channel = shift @_;
my $bank = int($channel / $chanper);
my $ch = $channel % $chanper;
my $aorch =  substr($alpha,$bank,1) . sprintf("%02.2u",$ch);
return $aorch;
}
sub numerically {$a<=>$b;}
