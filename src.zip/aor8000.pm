#!/usr/bin/perl -w
package aor8000;
require Exporter;
use constant FALSE => 0;
use constant TRUE => 1;
@ISA   = qw(Exporter);
@EXPORT = qw(aor_cmd) ;
use strict;
use Data::Dumper;
use Text::ParseWords;
use radioctl;
use Useful;
use constant AOR_TERMINATOR => pack("H4","0D0A");
use Scalar::Util qw(looks_like_number);
use Time::HiRes qw( time usleep ualarm gettimeofday tv_interval );
use autovivification;
no  autovivification;
my @mode2rc = ('FMw','FMn','AM ','USB','LSB','CW');
my %rc2mode = ('rtty' => 5,'rtty-r' => 5,'cw-r' => 5,'amn' => 2,'amw' => 2);
foreach my $ndx (0..$#mode2rc) {$rc2mode{lc(strip($mode2rc[$ndx]))} = $ndx;}
my %aorchans = ();
my $alpha = 'ABCDEFGHIJabcdefghij';
my $rcchan = 0;
foreach my $char (split "",$alpha) {
foreach my $num (0..49) {
my $key = $char . sprintf("%02.2u",$num);
$aorchans{$key} = $rcchan;
$rcchan++;
}
}
my @rcchan2aor = ();
foreach my $key (keys %aorchans) {$rcchan2aor[$aorchans{$key}] = $key;}
my $model = 'AOR-8000';
my $warn = TRUE;
my %state_save = (
'state' => '',
'mode'  => '',
);
my $protoname = 'aor';
use constant PROTO_NUMBER => 5;
$radio_routine{$protoname} = \&aor_cmd;
my %extra_keys = ( 'freq' => [
],
'system' => [
],
'group' => [
],
'search' => [
],
);
add_protocol($protoname,\%extra_keys);
return TRUE;
sub aor_cmd {
my $cmdcode = shift @_;
if (!$cmdcode) {LogIt(779,"AOR_CMD:No command code specified");}
my $parmref = shift @_;
if (!$parmref) {LogIt(782,"AOR_CMD:No parmref reference specified. Command=>$cmdcode");}
if (ref($parmref) ne 'HASH') {LogIt(783,"AOR_CMD:parmref is NOT a reference to a hash! CMD=$cmdcode");}
if (!$parmref->{'def'}) {LogIt(786,"AOR_CMD:No 'def' specified in parmref");}
my $defref    = $parmref->{'def'};
if (ref($defref) ne 'HASH') {LogIt(788,"AOR_CMD:defref is NOT a reference to a hash! CMD=$cmdcode");}
my $out  = $parmref->{'out'};
if (!$out) {LogIt(792,"AOR_CMD:No 'out' defined in parmref! Command=>$cmdcode");}
if (ref($out) ne 'HASH') {LogIt(793,"AOR_CMD:Out spec in parmref is NOT a hash reference! CMD=$cmdcode");}
my $outsave = $out;
if (!$parmref->{'portobj'} and ($cmdcode ne 'autobaud')) {LogIt(797,"AOR_CMD:No portobj in parmref! CMD=$cmdcode");}
my $portobj = $parmref->{'portobj'};
my $db = $parmref->{'database'};
if ($db) {
if (ref($db) ne 'HASH') {LogIt(584,"AOR_CMD:Database spec in parmref is NOT a hash reference! CMD=$cmdcode");}
}
else {$db = '';}
my $write = $parmref->{'write'};
if (!$write) {$write = FALSE;}
my $in   = $parmref->{'in'};
if ($in) {
if (ref($in) ne 'HASH') {LogIt(580,"IN spec in parmref is NOT a hash reference! CMD=$cmdcode");}
}
else {$in = '';}
my $insave = $in;
my $delay = 10000;
$parmref->{'rc'} = $GoodCode;
my $parmstr = '';
if ($debug1) {LogIt(0,"AOR_CMD:command=$cmdcode");}
my $countout = 0;
my $instr= "";
my $rc = 0 ;
my $data_in;
my $count_in;
my $hex_data;
my $gotit = FALSE;
my $radio_set = $out;
my $channel = 0;
if ($cmdcode eq 'init') {
$delay = 500;
$defref->{'dualchan'} = FALSE ;
$defref->{'noscan'} = TRUE;
$defref->{'sqlchange'} = FALSE;
$defref->{'minfreq'} = 500000;
$defref->{'maxfreq'} = 1900000000;
$defref->{'maxchan'} = 49;
$defref->{'maxigrp'} = 19;
$defref->{'sigdet'} = 2;
$defref->{'group'} = TRUE;
$defref->{'chanper'} = 50;
$defref->{'origin'} = 0;
$parmref->{'write'} = FALSE;
if (aor_cmd('VA',$parmref)) {
LogIt(1,"AOR does not appear to be connected");
return ($parmref->{'rc'});
}
$parmref->{'in'} = $insave;
return $parmref->{'rc'};
}
elsif ($cmdcode eq 'autobaud') {
my $model_save = $defref->{'model'};
my @allports = ();
if ($in->{'noport'} and $defref->{'port'}) {push @allports,$defref->{'port'};}
else {
if (lc($defref->{'model'}) ne 'icr30') {push @allports,glob("/dev/ttyUSB*");}
}
my @allbauds = ();
if ($in->{'nobaud'}) {push @allbauds,$defref->{'baudrate'};}
else {
@allbauds = (9600);
}
@allbauds = sort {$b <=> $a} @allbauds;
@allports = sort {$b cmp $a} @allports;
PORTLOOP:
foreach my $port (@allports) {
my $portobj =  Device::SerialPort->new($port) ;
if (!$portobj) {next;}
$parmref->{'portobj'} = $portobj;
$portobj->user_msg("ON");
$portobj->databits(8);
$portobj->handshake('none');
$portobj->read_const_time(100);
$portobj->write_settings || undef $portobj;
$portobj->read_char_time(0);
foreach my $baud (@allbauds) {
$portobj->baudrate($baud);
$warn = FALSE;
$parmref->{'write'} = FALSE;
$out->{'frequency'} = 0;
$rc = aor_cmd('RX',$parmref);
$warn = TRUE;
if (!$rc and $out->{'frequency'}) {### command succeeded
$defref->{'baudrate'} = $baud;
$defref->{'port'} = $port;
$portobj->close;
$parmref->{'portobj'} = undef;
return ($parmref->{'rc'} = $GoodCode);
}
}
$portobj->close;
$parmref->{'portobj'} = undef;
}
return ($parmref->{'rc'} = 1);
}
elsif ($cmdcode eq 'vfoinit') {
aor_cmd('DD',$parmref);
return $parmref->{'rc'};
}
elsif ($cmdcode eq 'meminit') {
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmdcode eq 'scan') {
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmdcode eq 'poll') {
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmdcode eq 'getvfo') {
if (!$outsave) {LogIt(968,"No 'out' reference in parmref for GETVFO call!");}
if ($parmref->{'rc'} = aor_cmd('LM',$parmref)) {return $parmref->{'rc'};}
aor_cmd('RX',$parmref);
return $parmref->{'rc'};
}
elsif ($cmdcode eq 'getsig') {
$out->{'signal'} = 0;
$out->{'sql'} = FALSE;
if (aor_cmd('LM',$parmref)) {return $parmref->{'rc'};}
if ($out->{'sql'}) {
aor_cmd('RX',$parmref);
$out->{'_radiochan'} = $out->{'channel'};
$out->{'channel'} = $out->{'_rcchan'};
}
return $parmref->{'rc'};
}
elsif ($cmdcode eq 'setvfo') {
if (!$in->{'frequency'}) {
add_message("AOR_CMD_l891:VFO frequency = 0 or undefined not allowed");
return ($parmref->{'rc'} = $ParmErr);
}
my %out = ();
$parmref->{'out'} = \%out;
aor_cmd('RX',$parmref);
if (($out{'state'} eq 'SCN') or ($out{'state'} eq 'MEM')) {
aor_cmd('VF',$parmref);
}
elsif ($out{'state'} eq 'SRC') {
aor_cmd('DD',$parmref);
}
my $state = $out{'state'};
$parmref->{'out'} = $outsave;
$parmref->{'write'} = TRUE;
if ($state eq 'VFO') {aor_cmd('VA',$parmref);}
elsif ($state eq 'HLD') {aor_cmd('RF',$parmref);}
else {LogIt(909,"AOR_CMD:Cannot deal with state $state!");}
return $parmref->{'rc'};
}
elsif ($cmdcode eq 'selmem') {
my $rcchan = $in ->{'channel'};
if (!$rcchan) {
add_message("AOR_CMD_l1068:Memory channel undefined or 0 not allowed");
return ($parmref->{'rc'} = $ParmErr);
}
my $chanper = $defref->{'chanper'};
my $igrp = int($rcchan/($chanper)) ;
if ($igrp > $defref->{'maxigrp'}) {
my $msg = "AOR_CMD_l1069:Memory channel $rcchan out of range of the radio.";
print "$msg igrp=>$igrp\n";
add_message($msg);
return ($parmref->{'rc'} = $ParmErr);
}
my $channel = $rcchan - ($igrp * $chanper) - 1;
print "AOR SELMEM:rcchan=>$rcchan aor chan=>$channel igrp=>$igrp chanper=>$chanper\n";
my %myin = ();
$parmref->{'in'} = \%myin;
$myin{'channel'} = $channel;
$myin{'igrp'} = $igrp;
aor_cmd ('MR',$parmref);
$parmref->{'in'} = $insave;
return $parmref->{'rc'};
}
elsif ($cmdcode eq 'getmem') {
if ($debug2) {LogIt(0,"AOR_CMD l1122:got 'getmem'");}
if (!$in) {LogIt(1125,"AOR_CMD:No 'in' defined for GETMEM");}
if (!$db) {LogIt(1126,"AOR_CMD:No database reference for GETMEM");}
my $startstate = $progstate;
my $count = 0;
my $maxcount = 1000;
my $maxchan = $defref->{'maxchan'};
my $maxigrp = $defref->{'maxigrp'};
my $origin =  $defref->{'origin'};
my $chanper = $defref->{'chanper'};
my $hasgroups = $defref->{'group'};
my $firstigrp = 0;
my $channel = $origin - 1;
my $rc_channel = 0;
if ($in->{'count'}) {$maxcount = $in->{'count'};}
my $comment = TRUE;
if ($in->{'nocomment'}) {$comment = FALSE;}
my $skip = $in->{'skip'};
if (!$skip) {$skip = FALSE;}
my $firstchan = $in->{'firstnum'};
if (!$firstchan) {$firstchan = 0;}
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = FALSE;
my $bank_used = $hasgroups;
my %sysrec = ('systemtype' => 'CNV','service' => "AOR8000 all channels", 'valid' => TRUE,
'bank_used' => $bank_used,);
my $sysno = add_a_record($db,'system',\%sysrec,$parmref->{'gui'});
LogIt(0,"getting system $sysno data for $model...");
LogIt(0,"first=>$firstigrp last=>$maxigrp count=>$count maxcount=>$maxcount in{count}=>$in->{'count'}");
GROUPLOOP:
foreach my $igrp    ($firstigrp..$maxigrp) {
my $bank = substr($alpha,$igrp,1);
my %grouprec = ('sysno' =>$sysno,'service' => "$model Igrp/Bank:$igrp/$bank",
'valid' => TRUE,'igrp' => $igrp);
my $grpndx = add_a_record($db,'group',\%grouprec,$parmref->{'gui'});
my %newfreq = ('frequency' => 0,
'groupno' => $grpndx,
'channel' => $origin,
'service' => "Freqs for group/bank $grpndx/$bank",
'_noshow' => TRUE,
'linecomment' => "*\n* ### Channels for group $grpndx ($igrp/$bank).",
);
if ($comment) {my $ndx1 = add_a_record($db,'freq',\%newfreq,FALSE);}
if ($hasgroups) {$channel = $origin - 1;}
my $grpchcnt = 0;
CHANLOOP:
while ($channel <  $maxchan) {
$channel++;
$rc_channel++;
if ($rc_channel < $firstchan) {next;}
$vfo{'channel'} = $rc_channel;
$vfo{'group'} = $igrp;
threads->yield;
if ($progstate ne $startstate) {
LogIt(0,"AOR8000 l1241: GUI Interrupted the Channel loop. progstate=>$progstate");
last GROUPLOOP;
}
if (!$parmref->{'gui'}) {
print STDERR "\rreading group:$Bold$Yellow" . sprintf("%02.2u",$igrp) . $Reset;
print STDERR " channel:$Bold$Green" . sprintf("%02.2u",$channel) .$Reset ;
}
$myout{'channel'} = $channel;
$myout{'valid'} = FALSE;
$myout{'mode'} = 'auto';
$myout{'frequency'} = 0;
$myout{'tone'} = '_off';
$myout{'tone_type'} = 'off';
$myout{'dlyrsm'} = 0     ;
$myout{'atten'} = 0;
$myout{'service'} = '';
$myout{'tgid_valid'} = FALSE;
$myout{'groupno'} = $grpndx;
$myout{'_rcchan'} = $rc_channel;
$myout{'_radio_chan'} = $channel;
$myin{'channel'} = $channel;
$myin{'igrp'} = $igrp;
aor_cmd ('MR',$parmref);
my $freq = $myout{'frequency'} + 0;
if (!$skip or $freq) {
if (!$freq) {$myout{'valid'} = FALSE;}
my $recno = add_a_record($db,'freq',\%myout,$parmref->{'gui'});
$count++;
if ($count > $maxcount) {last GROUPLOOP;}
}
$grpchcnt++;
if ($grpchcnt >= $chanper) {next GROUPLOOP;}
if ($channel > $defref->{'maxchan'}) {
last;}
}### Channel loop
}### Bank loop
$parmref->{'out'} = $outsave;
$parmref->{'in'} = $insave;
$outsave->{'count'} = $count;
$out->{'sysno'} = $sysno;
print "\n";
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmdcode eq 'setmem') {
if (!$in) {LogIt(1236,"AOR_CMD:No 'in' defined for SETMEM");}
if (!$db) {LogIt(1237,"AOR_CMD:No database reference for SETMEM");}
if ($debug1) {LogIt(0,"Processing AOR SETMEM command");}
my $startstate = $progstate;
my %chans = ();
if (setmem_sub($parmref,\%chans)) {return ($parmref->{'rc'});}
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = TRUE;
my @chlist = sort numerically keys %chans;
my $storecount = 0;
WRTLP1:
foreach my $ch (@chlist) {
foreach my $key (keys %{$chans{$ch}}) {$myin{$key} = $chans{$ch}{$key};}
my $freq =   $chans{$ch}{'frequency'};
my $channel =  $chans{$ch}{'channel'};
my $igrp   = $chans{$ch}{'igrp'};
if ($parmref->{'gui'}) {
$vfo{'channel'} = $chans{$ch}{'channel'};
$vfo{'group'} = $chans{$ch}{'igrp'};
threads->yield;
if ($progstate ne $startstate) {last WRTLP1;}
%scan_request = ('_cmd' =>'vfodply','_dbn' => 'vfo');
$parmref->{'gui'}->('ICOM_l1685');
my $recno = $chans{$ch}{'_recno'};
%scan_request = ('_cmd' => 'sync','_dbn' => 'freq', '_seq'=> $recno,
'channel' => $ch);
$parmref->{'gui'}->('ICOM_l2539');
threads->yield;
}
else {
print STDERR "\rAOR8000 l1482:Writing channel " . sprintf("%2.2u",$channel) .
" group " . sprintf("%2.2u",$igrp) .
" freq=>" . rc_to_freq($freq) . "  mode=>$myin{'mode'}";
}
aor_cmd('MX',$parmref);
$storecount++;
usleep 500;
}### For every channel
$out->{'count'} = $storecount;
LogIt(0,"$storecount records were stored in the radio");
$parmref->{'in'} = $insave;
$parmref->{'write'} = $writesave;
return $parmref->{'rc'};
}
elsif ($cmdcode eq 'getglob') {
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = FALSE;
$parmref->{'write'} = $writesave;
$parmref->{'in'} = $insave;
$parmref->{'out'} = $outsave;
return ($parmref->{'rc'});
}
elsif ($cmdcode eq 'setglob') {
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = TRUE;
$parmref->{'write'} = $writesave;
$parmref->{'in'} = $insave;
$parmref->{'out'} = $outsave;
return ($parmref->{'rc'});
}
elsif ($cmdcode eq 'getsrch') {
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
my $startstate = $progstate;
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = FALSE;
$parmref->{'write'} = $writesave;
$parmref->{'in'} = $insave;
$parmref->{'out'} = $outsave;
return ($parmref->{'rc'});
}
elsif ($cmdcode eq 'setsrch') {
my %myin = ();
my %myout = ();
my $startstate = $progstate;
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = TRUE;
$parmref->{'write'} = $writesave;
$parmref->{'in'} = $insave;
$parmref->{'out'} = $outsave;
return ($parmref->{'rc'});
}
elsif ($cmdcode eq 'getinfo') {
aor_cmd('init',$parmref);
$out->{'chan_count'} = $defref->{'maxchan'};
$out->{'model'} = $model;
return ($parmref->{'rc'});
}
elsif ($cmdcode eq 'test') {
}
elsif ($cmdcode eq 'setsquelch') {
return;
}
elsif ($cmdcode eq 'AT') {
if ($parmref->{'write'}) {
if (!$in) {LogIt(782,"AOR:Missing IN for AT  command!");}
if ($in->{'atten'}) {$parmstr = 1;}
else {$parmstr = 0;}
}
else { }
}
elsif ($cmdcode eq 'AU') {
if ($parmref->{'write'}) {
if (!$in) {LogIt(882,"AOR:Missing IN for AU  command!");}
if ($in->{'auto'}) {$parmstr = 1;}
else {$parmstr = 0;}
}
else {  }
}
elsif ($cmdcode eq 'BM') {
if ($parmref->{'write'}) {
if (!$in) {LogIt(823,"AOR:Missing IN for BM  command!");}
$parmstr = $in->{'link'};
}
else {  }
}
elsif ($cmdcode eq 'BS') {
if ($parmref->{'write'}) {
if (!$in) {LogIt(858,"AOR:Missing IN for BS  command!");}
$parmstr = $in->{'link'};
}
else {  }
}
elsif ($cmdcode eq 'DD') {
}
elsif ($cmdcode eq 'LM') {
}
elsif ($cmdcode eq 'MQ') {
}
elsif ($cmdcode eq 'MR') {
my $channel = $in->{'channel'};
if (!defined $channel) {$channel = -1;}
my $bank = $in->{'igrp'};
if (!defined $bank) {$bank = -1;}
if ($channel >= 0) {
if ($channel > 49) {
LogIt(1,"AOR_CMD l1727:Channel $channel is out of range of the radio");
return ($parmref->{'rc'} = $ParmErr);
}
if (($bank < 0) or ($bank > 19)) {
LogIt(1,"AOR_CMD l1735:IGRP $bank is out of range or not specfied");
return ($parmref->{'rc'} = $ParmErr);
}
$parmstr = substr($alpha,$bank,1) . sprintf("%02.2u",$channel);
}### Channel specified
}## MR command
elsif ($cmdcode eq 'MX') {
my $channel = $in->{'channel'};
if (!defined $channel) {LogIt(1747,"'MX':Forgot to included channel spec");}
my $bank = $in->{'igrp'};
if (!defined $bank) {LogIt(1749,"'MX':Forgot to included channel spec");}
my $rcchan = '';
if ($in->{'_rcchan'}) {$rcchan = "(RadioCtl channel $in->{'_rcchan'})";}
if (($channel < 0) or ($channel > 49)) {
LogIt(1,"AOR_CMD l1755:Channel $channel $rcchan is out of range");
return ($parmref->{'rc'} = $ParmErr);
}
if (($bank < 0) or ($bank > 19)) {
LogIt(1,"AOR_CMD l1768:Bank $bank is out of range for channel $channel $rcchan");
return ($parmref->{'rc'} = $ParmErr);
}
my $freq =  $in->{'frequency'};
if (!$freq) {
LogIt(1,"Got 0 freq for channel $channel ");
aor_cmd('MR',$parmref);
if ($out->{'frequency'}) {aor_cmd('MQ',$parmref);}
else {LogIt(1,"channel $channel ($parmstr) already cleared!");}
return $parmref->{'rc'};
}
$freq = Strip($freq);
my $lockout = 1;
if ($in->{'valid'}) {$lockout = 0;}
my $service = '.      ';
if ($in->{'service'}) {$service = sprintf("%7.7s",$in->{'service'});}
$parmref->{'write'} = TRUE;
my $char = substr($alpha,$bank,1);
my $num = sprintf("%02.2u",$channel);
$parmstr = "$char$num " .
"RF$freq MP$lockout AU0 " . set_keys($in) . " TM$service";
}## MX command
elsif ($cmdcode eq 'RF') {
if ($parmref->{'write'}) {
if (!$in) {LogIt(1208,"AOR:Missing IN for RF  command!");}
my $freq = Strip($in->{'frequency'});
if (!$freq) {
add_message("AOR_CMD_l1217:VFO frequency = 0 or undefined not allowed");
return ($parmref->{'rc'} = $ParmErr);
}
$parmstr = $freq . ' ' . set_keys($in);
}
}
elsif ($cmdcode eq 'RX') {
}
elsif (($cmdcode eq 'VA') or ($cmdcode eq 'VB')){
if ($parmref->{'write'}) {
if (!$in) {LogIt(1268,"AOR:Missing IN for $cmdcode command!");}
$parmstr = $in->{'frequency'};
if (!$parmstr) {
add_message("AOR_CMD_l1272:VFO frequency = 0 or undefined not allowed");
return ($parmref->{'rc'} = $ParmErr);
}
$parmstr = "$parmstr " . set_keys($in);
}
}
my %sendparms = (
'portobj' => $parmref->{'portobj'},
'term' => CR,
'delay' => $delay,
'resend' => 0,
'debug' => 0,
'fails' => 1,
'wait' => 30,
);
RESEND:
my $outstr = $cmdcode;
if ($cmdcode eq 'test') {$outstr = $parmstr}
else {
$outstr = strip("$outstr$parmstr");
}
if ($debug3) {LogIt(0,"AOR_CMD l1208:sent =>$outstr");}
my $sent = $outstr;
$outstr = $outstr . AOR_TERMINATOR;
WAIT:
if ($debug3) {LogIt(0,"AOR_CMD l800:Waiting for Radio_Send..");}
if (radio_send(\%sendparms,$outstr)) {### send with retry
if ($rc eq '-2') {LogIt(1186,"AOR.PM:No open port detected!");}
if (!$outstr) {
$parmref->{'rsp'} = FALSE;
return ($parmref->{'rc'} = $GoodCode);
}
else {
if ($warn) {### Don't display for autobaud
LogIt(1,"no response to =>$outstr<=");
if (!$parmref->{'rsp'}) {add_message("AOR_CMD l1806:Radio is not responding...");}
}
$parmref->{'rsp'} = TRUE;
return ($parmref->{'rc'} = $CommErr);
}
}
$instr = $sendparms{'rcv'};
$instr =~ tr /\n//;
$instr =~ tr /\r//;
chomp $instr;
if ($debug3) {LogIt(0,"AOR_CMD l1266:Radio returned=>$instr command=>$cmdcode");}
if (!$instr) {
if ($debug3) {LogIt(0,"Command $sent produced no data");}
return ($parmref->{'rc'} = $GoodCode);
}
if ($parmref->{'rsp'}) {add_message("Radio is responding again...");}
$parmref->{'rsp'} = FALSE;
my @returns = split " ",$instr;
$instr = strip($instr);
my @parms = split " ",$instr;
my $rtcmd = substr($instr,0,2);
if ($debug3) {LogIt(0,"AOR_CMD:CMD=$cmdcode AOR returned =>$instr<=");}
$parmref->{'rc'} = $GoodCode;
if ($cmdcode eq 'test') {
$parmref->{'rsp'} = FALSE;
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmdcode eq 'AT') {
if ($instr) {$out->{'atten'} = substr($instr,2,1);}
}### AT post-process
elsif ($cmdcode eq 'AU') {
if ($instr) {$out->{'auto'} = substr($instr,2,1);}
}#### AU post process
elsif ($cmdcode eq 'BM') {
if ($instr) {$out->{'link'} = substr($instr,2);}
}#### BM post process
elsif ($cmdcode eq 'BS') {
if ($instr) {$out->{'link'} = substr($instr,2);}
}#### BS post process
elsif ($cmdcode eq 'DD') {
extract_keys($out,$instr);
}
elsif ($cmdcode eq 'LM') {
$out->{'signal'} = 0;
$out->{'sql'} = 0;
if ($instr) {
my $value = substr($instr,2);
if ($value) {$value = hex($value)}
if ($value < 128) {
$out->{'signal'} = 1;
my @smeter = (1,4,8,10,11,12,13,15,17);
foreach my $signal (@smeter) {
if ($value > $signal) {$out->{'signal'} = $signal;}
else {last;}
}
if ($out->{'signal'} > MAXSIGNAL) {$out->{'signal'} = MAXSIGNAL;}
$out->{'sql'} = 1;
}
}
}### LM process
elsif ($cmdcode eq 'MQ') {
LogIt(1,"Got response of $instr for MQ command!");
}
elsif ($cmdcode eq 'MR') {
extract_keys($out,$instr);
}
elsif ($cmdcode eq 'MX') {
LogIt(1,"Got response of $instr for MX command!");
}
elsif ($cmdcode eq 'RF') {
if ($parmref->{'write'}) { }
else { extract_keys($out,$instr);}
$out->{'state'} = 'HLD';
}
elsif ($cmdcode eq 'RX') {
extract_keys($out,$instr);
}
elsif (($cmdcode eq 'VA') or ($cmdcode eq 'VB')) {
if ($parmref->{'write'}) { }
else {extract_keys($out,$instr)};
$out->{'state'} = 'VFO';
}
else {
if (!$instr) {
LogIt(1,"AOR did not like command $cmdcode");
return ($parmref->{'rc'} = $NotForModel);
}
}### No handler process
return ($parmref->{'rc'});
}
sub extract_keys{
my $hash = shift @_;
my $data = shift @_;
$hash->{'frequency'} = 0;
$hash->{'mode'} = $mode2rc[0];
$hash->{'atten'} = FALSE;
$hash->{'step'} = 1;
$hash->{'channel'} = -1;
$hash->{'valid'} = FALSE;
$hash->{'igrp'} = -1;
$hash->{'_rcchan'} = -1;
$hash->{'_bank'} = ' ';
my @fields = split " ",$data;
foreach my $parm (@fields) {
my $key = substr($parm,0,2);
if (substr($key,0,1) eq '-') {next;}
my $value = '';
if (length($parm) > 2) {$value = substr($parm,2);}
if ($key eq 'VA') {$hash->{'frequency'} = $value;}
elsif ($key eq 'RF') {$hash->{'frequency'} = $value;}
elsif ($key eq 'VB') {$hash->{'frequency'} = $value;}
elsif ($key eq 'MD') {
$hash->{'mode'} = $mode2rc[$value];
}
elsif ($key eq 'AT') {$hash->{'atten'} = $value;}
elsif ($key eq 'ST') {$hash->{'step'} = $value;}
elsif ($key eq 'AU') { }### TODO:Auto:What to do with this?
elsif ($key eq 'MX') {
my $ch  = substr($value,1);
my $bank = substr($value,0,1);
my $igrp = index($alpha,$bank);
my $rcchan = $ch + ($igrp * 50) + 1;
$hash->{'channel'} = $ch;
$hash->{'_bank'} = $bank;
$hash->{'igrp'} = $igrp;
$hash->{'_rcchan'} = $rcchan;
}
elsif ($key eq 'MP') {
if ($parm eq 'MP0') {$hash->{'valid'} = TRUE;}
}
elsif ($key eq 'TM') {
($hash->{'service'}) = $data =~ /TM(.*)/; 
last;
}
elsif ($key eq 'MS') {$hash->{'state'} = 'SCN';}
elsif ($key eq 'MR') {$hash->{'state'} = 'MEM';}
elsif ($key eq 'VF') {$hash->{'state'} = 'VFO';}
elsif ($key eq 'DD') {$hash->{'state'} = 'HLD';}
elsif ($key eq 'SS') {$hash->{'state'} = 'SRC';}
else {
if ($warn) {LogIt(1,"AOR_EXTRACT_KEYS:Unprocessed extract key $key");}
}
}
}
sub set_keys{
my $hash = shift @_;
my $options = '';
my $mode = $hash->{'mode'};
my $step = $hash->{'step'};
my $att  = $hash->{'atten'};
my $freq = $hash->{'frequency'};
if (!$freq) {$freq = 0;}
if (defined $mode) {
my $mode = lc(strip($hash->{'mode'}));
if ($mode eq 'auto') {$mode = lc(AutoMode($freq));}
my $modecode = $rc2mode{$mode};
if (defined $modecode) {$options = "MD$modecode";}
else {LogIt(1,"AOR_CMD:Undefined modulation $mode");}
}
if (defined $step) {$options = "$options ST$step";}
if (defined $att) {
if ($att) {$att = 1;}
else {$att = 0;}
$options = "$options AT$att";
}
return $options
}
sub get_bank {
my $ch = shift @_;
my $groups = 'ABCDEFGHIJabcdefghij';
my $chpergrp = 50;
my $banklet = substr($groups,int(($ch-1)/$chpergrp),1);
return $banklet;
}
sub Radio_Send {
my ($parms,$outstr) = @_;
if (!$parms) {LogIt(993,"RADIO_SEND:No $parms for call!");}
my $portobj = $parms->{'portobj'};
if (!$portobj) {
print STDERR "## Radio_Send called without a portobj!\n";
return -2;
}
my $term = '';
my $clear = FALSE;
if (defined $parms->{'term'}) {$term = $parms->{'term'};}
if (defined $parms->{'clear'}) {$clear = $parms->{'clear'};}
$parms->{'rcv'} = '';
$parms->{'sent'} = $outstr;
while ($clear) {
my ($count_in, $data_in) = $portobj->read(1);
if ($count_in) {
if ($debug3) {
my $dplybyte = "$data_in";
if ($parms->{'binary'}) {$dplybyte = hexdply($data_in);}
LogIt(0,"RADIO_SEND:Clearing byte=$dplybyte");
}
}
else {$clear = FALSE;}
}
my $countout = 0;
my $startflag = TRUE;
if ($outstr ne '') {
$countout = $portobj->write($outstr);
if ($debug3) {
my $dply = $outstr;
LogIt(0, "RADIO_WRITE:Sent=>$dply<=\n count=$countout");
}
}
if ($term eq '') {return 0 ;}
my $instr = '';
my $bytecnt = 0;
my $wait_count = 10;
my $resend = 0;
if ($parms->{'resend'}) {$resend = $parms->{'resend'};}
my $delay = 10;
if ($parms->{'delay'}) {$delay = $parms->{'delay'};}
while (TRUE) {
my ($count_in, $data_in) = $portobj->read(1);
if ($count_in) {
if ($data_in eq $term) {
$parms->{'rcv'} = $instr;
return 0;
}
else {
if (ord($data_in) eq 254) {$startflag = TRUE;}
if (ord($data_in) eq 252) {### ICOM Jamming code
$instr = '';
next;
}
if ($startflag) {$instr = $instr . $data_in;}
}
$bytecnt++;
if (TRUE) {
my $dplybyte = "$data_in";
my $dplyhex = hexdply($data_in);
LogIt(0,"RADIO_SEND:Got byte=$dplybyte ($dplyhex)");
}
$wait_count = 3;
}
else {
--$wait_count;
if ($wait_count < 1) {
if ($debug3) {
my $what = unpack "H*",$term;
LogIt(0,"RADIO_SEND:$Bold Got timeout waiting for response $Yellow$what" . "x");
LogIt(0,"RADIO_SEND:   Sent->$outstr");
}
if (!$resend) {
if ($debug3) {LogIt(0,"RADIO_SEND:Re-sent too many times. Giving up!");}
return 1;
}
else {
if ($outstr ne '') {$countout = $portobj->write($outstr);}
$resend--;
$wait_count = 3;
if ($debug3) {LogIt(0,"RADIO_WRITE:resending...");}
}
}
threads->yield;
if ($debug3) {LogIt(0,"RADIO_WRITE:delaying for $delay us. Wait count=$wait_count");}
usleep($delay);
}
}
}
sub numerically {$a<=>$b;}
