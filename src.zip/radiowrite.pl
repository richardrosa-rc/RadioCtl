#!/usr/bin/perl -w
use strict;
###############################################################################
#    RadioCtl Write/Read deta   (No GUI)                                      #
#                                                                             #
#  Function: Process Radio memories, SD cards, and RadioCtl CSV files.        #
#                                                                             #
#  syntax: radiowrite.pl {parms} {options}                                    #
#      parms:   Command  {filespec} {filespec} ..{filespec}  {options)}       #
#        Unless otherwise indicated by the command, multiple files can be     #
#         processed for a single command.                                     #
#       'filespec' can be a single .csv file or a file with lists of .csv     #
#         files (one filespec per record).                                    #
#   valid commands:                                                           #
#                                                                             #
#   CSV2ICOM - Convert  RadioCtl CSV file(s) to an ICOM SD format file for    #
#              radios that support SD cards.                                  #
#             These files work in the ICR30, IC-705 amd R8600.                #
#             Output files are generated on /tmp/radioctl, and are named      #
#                  named ICOM-xx, where 'xx' is the group number or 'ALL'     #
#             If the 'use_banks' flag is present in each system record, the   #
#              channel numbers for that system will be honored.               #
#             Otherwise, channels will be renumbered.                         #
#                                                                             #
#                                                                             #
#             Input:name of file(s) to read.                                  #
#             Options:                                                        #
#              --dir directory  Override for default directory                #
#                              Default is specified 'sdir' in $radio_def or   #
#                                 $settings{'tempdir'}                        #
#              --radio       Radio model to process. Must be IC705,ICR30 or   #
#                              R8600. Defaults to all of these.               #
#                              Multiple --radio specs can be given.           #
#              --renum       Renumber channels regardless of the 'use_banks'  #
#                             flag.                                           #
#                                                                             #
#             Status:Functional                                               #
#                                                                             #
#                                                                             #
#   CSV2SDS   Convert  RadioCtl csv files to a SDS-x00 format file for the    #
#              SD card for those radios.                                      #
#             Output files are stored in the directory specified by           #
#             the 'sdir' setting for the radio definition, or the             #
#             'tempdir' setting in the CONF file.                             #
#             If neither is set, the output will be placed on ~/radioctl      #
#             Default Filenames are f_000001.hpd and f_list.cfg               #
#             Input:RadioCtl file(s) to read                                  #
#                                                                             #
#             Options:                                                        #
#               --dir directory  Override for default directory               #
#                              Default is specified 'sdir' in $radio_def or   #
#                                 $settings{'tempdir'}                        #
#               --hpd n    Index for hpd file. 'n' must be 0-999999           #
#                          default is '1'.                                    #
#                          The number will be used for the filename for       #
#                          the .hpd file.                                     #
#                                                                             #
#             Status:Mostly Functional                                        #
#                                                                             #
#                                                                             #
#       CVT   Reprocess one or more RadioCtl files.                           #
#             Output: files are stored in the directory specified by          #
#             'tempdir' in the CONF file (default is ~/radioctl).             #
#             Files are name the same as the input file(s).                   #
#                                                                             #
#             Input:List of filenames to read.                                #
#             Options:                                                        #
#               --append         Append data to existing file instead of      #
#                                  overwrite                                  #
#               --dir directory  Override for default directory               #
#                                 will be specified in ~radioctl.conf or      #
#                                   ~/radioctl                                #
#               --keyformat      Store records as KEYWORD=VALUE fields.       #
#               --nohdr          Don't generate header records.               #
#                                 Forced if --append option specified.        #
#               -o|overwrite     Overwrite existing files without prompt      #
#               --origin ch      First channel number for renumber            #
#               -q key           Change system quickkey (0-99)                #
#                                  will also update ':QUICKKEY:' tag          #
#                                 If this option is not specified, the        #
#                                 quickkeys will remain unchanged on the      #
#                                  system or site records.                    #
#                                 NOTE:If multiple files are specified, or    #
#                                  there are multiple 'system' or 'site'      #
#                                  records, ALL of these will have the same   #
#                                  quickkey assigned!                         #
#               --renum          Renumber the channels                        #
#               -s|sort          Sort FREQ records by frequency or TGID       #
#               -z|--hz          Store frequencies in Hz (default is MHz)     #
#             Status:Functional                                               #
#                                                                             #
#                                                                             #
#                                                                             #
#   READSYS  Extract all the radio's memories and settings, and create a file #
#             Input:Name of radio.                                            #
#             Output: file 'temp.csv' is stored in the directory specified by #
#             'tempdir' in the CONF file (default is ~/radioctl)              #
#             Options:                                                        #
#               --append         Append data to existing file instead of      #
#                                  overwrite                                  #
#               --count          Count of systems or channels to read         #
#               --dir directory  Override for default directory               #
#                                 will be specified in ~radioctl.conf or      #
#                                   ~/radioctl                                #
#          -f|--filename name    Filename to create (excluding path & ext)    #
#               --first  ch      First channel number to read.                #
#                                Channel number is a RadioCtl channel         #
#                                 (1 origin).                                 #
#                                 If not specified, defaults to the first     #
#                                 channel in the radio.                       #
#               --globals        Get Global settings from the radio as well.  #
#               --keyformat      Store records as KEYWORD=VALUE fields.       #
#               --nocomment      Do not generate FREQ record comments         #
#                                 Normally, a comment will be generated       #
#                                 Between the start of each GROUP's FREQ      #
#                                  records.                                   #
#               --nohdr          Don't generate header records.               #
#                                 Forced if --append option specified.        #
#               --skip           Skip empty channels.                         #
#               --nosys          Do NOT read system data. Used with --globals #
#                                 and/or --search when ONLY Search/Global     #
#                                 records are desired.                        #
#               --notrunk        Do NOT fetch trunked system records          #
#                                 (dynamic radios only)                       #
#               -o               Overwrite existing files without prompt      #
#               --origin         Starting channel for --renum option          #
#                                 (default is 1)                              #
#                                Ignored for Dynamic radios.                  #
#               -q key           Change system quickkey (0-99)                #
#                                  will also update ':QUICKKEY:' tag          #
#                                 If this option is not specified, the        #
#                                 quickkeys will remain unchanged on the      #
#                                  system or site records.                    #
#                                 NOTE:If multiple files are specified, or    #
#                                  there are multiple 'system' or 'site'      #
#                                  records, ALL of these will have the same   #
#                                  quickkey assigned!                         #
#               --renum          Renumber the channels. Renumbering will use  #
#                                 RadioCtl channel numbers, ignoring any      #
#                                 group assignments.                          #
#                                 Renumbering begins with 1, unless --origin  #
#                                  specified.                                 #
#                                ignored for dynamic radios.                  #
#               --search         Get search records as well                   #
#               -s|--sort        Sort FREQ records by frequency               #
#               -z|--hz          Store frequencies in Hz (default is MHz)     #
#                                                                             #
#               --port /dev/ttyxxx   serial port to use (defaults to device   #
#                                specified in the .CONF file.                 #
#                                                                             #
#             Status:Functional                                               #
#                                                                             #
#  WRITESYS   Read one or more RadioCtl file and store all the systems read   #
#               in the radio.                                                 #
#             Input:Name of Radio                                             #
#                   File(s) to process                                        #
#             Options:                                                        #
#               --count count    Count of channels to write                   #
#                                 Non-dynamic radios only.                    #
#                                 Not used by UNIDEN routine                  #
#               --erase          Clear data before storing new values.        #
#                                For the BCD325P2 the system name is          #
#                                  compared for erase.                        #
#                                For all other radios, channels between the   #
#                                 first and last channel number specified will#
#                                 be cleared.                                 #
#                                                                             #
#                                When storing Search, IF Exchange freqs and   #
#                                 lockout freqs any existing data will be     #
#                                 removed from the radio before the store     #
#                                 operation proceeds.                         #
#               --first index    First FREQ or GROUP database index to use.   #
#                                 If not specified, defaults to 1.            #
#                                 Non-dynamic radios only.                    #
#                                 Not used by UNIDEN routine                  #
#               --globals        Set Global settings to the radio as well     #
#                                 (if any specified in the file)              #
#               --nodie          Don't terminate the write if any single      #
#                                 record is in error.                         #
#                                NOTE:Bad records (and their children) will   #
#                                 NEVER be stored in the radio.               #
#               --nosys          Do NOT write system data records.            #
#                                 Used with --globals and/or --search when    #
#                                 ONLY Search/Global records are desired.     #
#               --origin x       First channel number for renumber.           #
#                                 Defaults to 1.                              #
#                                 NOTE:This is a RadioCtl index (1 is first)  #
#                                  If the radio's first channel is 0, any     #
#                                  origin specified will be adjusted.         #
#                                 ex: --origin 2 will start with the radio's  #
#                                   channel 1 (2nd channel number)            #
#                                 Non-dynamic radios only.                    #
#                                 Not used by UNIDEN routine                  #
#               --port /dev/ttyxxx   serial port to use.                      #
#                                Only needed if AUTOBAUD fails to locate the  #
#                                 radio.                                      #
#               --renum          If specified, renumber the channels, ignoring#
#                                 the channel number in the records.          #
#                                 Non-dynamic radios only.                    #
#                                 Not used by UNIDEN routine                  #
#               --search         Get search records as well                   #
#               --test           Read the file(s) but don't write to radio    #
#                                                                             #
#        NOTE:Some radios (such as the ICOM R30) do NOT support the ability   #
#          to store information using this command.                           #
#                                                                             #                                                                             #
#    Status:Functional                                                        #
#                                                                             #
#                                                                             #
#                                                                             #
#   REWRITE   Read one or more RadioCtl CSV files and store into a single     #
#              new file.                                                      #
#             Input:List of filenames to read.                                #
#             Output: file 'temp.csv' is stored in the directory specified by #
#             'tempdir' in the CONF file (default is ~/radioctl)              #
#             Options:                                                        #
#               -f|filename filename - Name of file. Defaults to 'temp'       #
#               --append         Append data to existing file instead of      #
#                                  overwrite                                  #
#               --dir directory  Override for default directory               #
#                                 will be specified in ~radioctl.conf or      #
#                                   ~/radioctl                                #
#               --keyformat      Store records as KEYWORD=VALUE fields.       #
#               --nohdr          Don't generate header records.               #
#                                 Forced if --append option specified.        #
#               -o|overwrite     Overwrite existing files without prompt      #
#               --origin ch      First channel number for renumber            #
#               -q key           Change system quickkey (0-99)                #
#                                  will also update ':QUICKKEY:' tag          #
#                                 If this option is not specified, the        #
#                                 quickkeys will remain unchanged on the      #
#                                  system or site records.                    #
#                                 NOTE:If multiple files are specified, or    #
#                                  there are multiple 'system' or 'site'      #
#                                  records, ALL of these will have the same   #
#                                  quickkey assigned!                         #
#               --renum          Renumber the channels                        #
#               -s|sort          Sort FREQ records by frequency or TGID       #
#               -z|--hz          Store frequencies in Hz (default is MHz)     #
#             Status:Functional                                               #
#                                                                             #
#                                                                             #
#                                                                             #
#   SDS2CSV   Convert Uniden .hpd & .cfg files to RadioCtl .csv files         #
#              Input:Single file to read.                                     #
#              Output: /tmp/temp.csv                                          #
#                                                                             #
#             Options:                                                        #
#               --append         Append data to existing file instead of      #
#                                  overwrite                                  #
#               --dir directory  Override for default directory               #
#                                 will be specified in ~radioctl.conf or      #
#                                   ~/radioctl                                #
#               -f|filename filename - Name of file. Defaults to 'temp'       #
#               --nohdr          Don't generate header records.               #
#                                 Forced if --append option specified.        #
#               --keyformat      Store records as KEYWORD=VALUE fields.       #
#               -s               Sort FREQ records by frequency               #
#               -z|--hz          Store frequencies in Hz (default is MHz)     #
#               --sysonly        Only output systems                          #
#               --gps            Restrict output to sites/groups in range     #
#               --lat            Latitude for GPS. Default is 41.603858       #
#               --lon            Longitude for GPS. Default is -73.976428     #
#               --radius         Radius in miles for GPS. Default is 25.      #
#               --renum          Renumber the channels                        #
#               --origin num     First channel number for renumber            #
#                                                                             #
#             Status:Mostly Functional                                        #
#                                                                             #
#                                                                             #
#  BLOCKS     Display block structure of a BCD radio                          #
#             Input:Name of radio.                                            #
#             Output: file 'blocks.txt' is stored in the directory specified  #
#              by 'tempdir' in the CONF file (default is ~/radioctl)          #
#             Options:                                                        #
#               --dir directory  Override for default directory               #
#                                 will be specified in ~radioctl.conf or      #
#                                   ~/radioctl                                #
#             Status:Functional                                               #
#                                                                             #
#   SHOWALL   Display all systems in the radio.                               #
#             Only valid for Uniden Dynamic Radios                            #
#             No data is modified in the radio.                               #
#             Input: (none)                                                   #
#             Options:                                                        #
#               -p /dev/ttyxxx   Specify a different serial port              #
#               -r name          Select radio by name                         #
#             Status:Functional                                               #
#                                                                             #
#    Required files/routines:                                                 #
#    these files MUST be available in the same directory as this tool         #
#      radioctl.pm    - Common routines for RadioCtl module                   #
#      scanner.pm     - Scanner thread routines                               #
#      icom.pm        - ICOM unique procedures                                #
#      kenwood.pm     - Kenwood unique procedures                             #
#      bearcat.pm     - Bearcat unique procedures                             #
#      uniden.pm      - Uniden Dynamic Radio procedures                       #
#      aor8000.pm     - AR-8000 procedures                                    #
#                                                                             #
#                                                                             #
#     Required PERL modules (available from CPAN)                             #
#      Device::SerialPort      - serial port support                          #
#      Text::ParseWords        - text parsing                                 #
#      Text::CSV               - CSV file functions                           #
#      File::Basename          - filename parsing                             #
#      threads                 - MultiThreading                               #
#      Thread::Queue           - likewise                                     #
#      Config                  - additional Thread Support                    #
#      Data::Dumper            - Debug tool                                   #
#      Time::HiRes             - HiRes timer                                  #
#      Fcntl::flock            - Locking                                      #
#                                                                             #
###############################################################################
my $rev = "0.4.4";
$rev = "0.4.5";
my $author = 'Lydia And Richard';
my $office_prog = 'libreoffice --view';
use constant TRUE  => 1;
use constant FALSE => 0;
use autovivification;
no  autovivification;
use Scalar::Util qw(looks_like_number);
my $debug = FALSE;
my $doit = TRUE;
use Device::SerialPort qw ( :PARAM :STAT 0.07 );
use Text::ParseWords;
use Text::CSV;
use File::Basename;
use Term::Sk;
use XML::Hash::LX;
use Scalar::Util qw(looks_like_number);
use threads;
use threads::shared;
use Thread::Queue;
use Config;
$Config{useithreads} or die "Perl Thread Support missing!";
use Data::Dumper;
use Encode;
use Time::HiRes qw( usleep ualarm gettimeofday tv_interval );
my $os = $^O;
my $linux;
my $homedir;
use FindBin qw($Bin);
use lib "$Bin";
my $callpath = "$Bin/";
print STDERR "callpath = $callpath\n";
if (substr($os,0,3) eq 'MSW') {
$os = 'WINDOWS';
$homedir = $ENV{"USERPROFILE"};
$linux = FALSE;
}
else {
$os = 'LINUX';
$homedir = $ENV{"HOME"};
$linux = TRUE;
}
use radioctl;
use scanner;
use uniden;
use icom;
use kenwood;
use aor8000;
use bearcat;
use Useful;
my $help =
"    $Bold RadioCtl Non-GUI write and read routines.                        $Eol" .
"                                                                             \n" .
"  Function: Read/Write various radios and data files.                        \n" .
"                                                                             \n" .
"  syntax: $Bold radiowrite.pl $Green command $Yellow input(s) $Magenta {options}$Eol" .
"        An 'input' is a filespec or a radio name.                            $Eol" .
"        For filespecs, most commands (unless otherwise indicated) allow for  $Eol" .
"         multiple inputs.                                                    $Eol" .
"       Filenames with imbedded blanks need to be enclosed with quotes.      $Eol" .
"       RadioCtl data files must have '*RadioCtl' as the first record.        $Eol" .
"       Unless the file resides in the current directory, the full path of    $Eol" .
"        each file is required.                                               $Eol" .
"       Output files are usually placed in the default directory.             $Eol" .
"       This default is specified in the configuration file key 'tempdir'     $Eol" .
"        and can be overridden using the $Yellow--dir$White option.           $Eol" .
"       If no default directory defined, the output is placed in ~/radioctl.  $Eol" .
"                                                                             \n" .
"   valid commands:                                                           \n" .
"   $Bold BLOCKS  $Reset   Generate block structure of a BCD radio            $Eol" .
"       Inputs:Name of radio to process. Must be a BCD type of radio.         \n" .
"       Output:blocks.txt  in the default directory (usually /tmp/radioctl)   $Eol" .
"       Options:                                                              \n" .
"             --dir$Yellow dir$Reset  Directory for output                  $Eol" .
"                                                                             \n" .
"   $Bold CSV2ICOM $Reset   Convert RadioCtl csv file(s) to an ICOM           $Eol" .
"                           format file for the Radio's SD card.              $Eol" .
"       Inputs:RadioCtl File(s) to process.                                    \n" .
"       Output:model-xx.csv in the directory specified by the 'sdir' directory $Eol" .
"              in the radio's spec, or the 'tempdir' directory in the         $Eol" .
"              configuration file.                                 .          $Eol" .
"              If neither set, defaults to '~/radioctl'                       $Eol" .
"              'xx' is 00 to 99 based on the group number assigned to each    $Eol" .
"               'freq' record.                                                $Eol" .
"              'model' is ICR30 or IC705                                      $Eol" .
"                                                                             \n" .
"       Options:                                                              \n" .
"             --dir$Yellow dir$Reset  Directory for output                  $Eol" .
"             --renum    Renumber the channels.                             $Eol" .
"                                                                             \n" .
"                                                                             \n" .
"   $Bold CSV2SDS $Reset   Convert RadioCtl csv file(s) to an SDS-x00         $Eol" .
"                           format file for the Radio's SD card.              $Eol" .
"       Inputs:RadioCtl File(s) to process.                                    \n" .
"       Output:f_0000001.hpd and f_list.cfg  in the directory specified       $Eol" .
"              by the 'sdir' directory in the radio spec,                     $Eol" .
"              or the 'tempdir' directory in the configuration file.          $Eol" .
"              If neither set, defaults to '~/radioctl'                       $Eol" .
"                                                                             \n" .
"       Options:                                                              \n" .
"             --dir$Yellow dir$Reset  Directory for output                  $Eol" .
"             --hpd n    Index for hpd file. 'n' must be 0-999999.            \n" .
"                        default is '1'.                                      \n" .
"                                                                             \n" .
"   $Bold CVT $Reset       Reprocess RadiocCtl .csv file(s).                  \n" .
"       Inputs:RadioCtl Files(s) to read.                                      \n" .
"       Output:Regenerated files(s) in the default directory. Files will be   \n" .
"              the same name as the input file.                               \n" .
"       Options:                                                              \n" .
"             --append    Append data to existing file instead of overwrite \n" .
"             --dir$Yellow dir$Reset   Directory for output                  $Eol" .
"             --keyformat Store records as KEYWORD=VALUE fields             $Eol" .
"             --nohdr     Don't generate header records                     $Eol" .
"             -o          Overwrite any existing file without prompt        $Eol" .
"             --origin$Yellow n$Reset  First channel number for the --RENUM option $Eol" .
"             -q$Yellow key$Reset      Change system quickkey (0-99).       $Eol" .
"                          This option will also update ':QUICKKEY:' tag.     \n" .
"                          If this option is not specified, the quickkeys     \n" .
"                            will remain unchanged on the SYSTEM or SITE      \n" .
"                            records.                                         \n" .
"                         NOTE:If multiple files are specified, or there are  \n" .
"                            multiple SYSTEM or SITE records, ALL of these    \n" .
"                            will be assigned the same quickkey with this     \n" .
"                            option.                                          \n" .
"             --renum     Renumber the channels                               \n" .
"             -s          Sort FREQ records by frequency                      \n" .
"             -z|--hz     Store frequencies in Hz (default is MHz)            \n" .
"                                                                             \n" .
"                                                                             \n" .
"   $Bold READSYS $Reset   Extract all a radio's memories and write to a file.\n" .
"             Input:Name of radio to read.                                    \n" .
"             Output:'temp.csv' saved in the default directory.               \n" .
"             Options:                                                        \n" .
"             --append    Append data to existing file instead of overwrite \n" .
"             --count$Yellow n$Reset  Only process 'n' systems or channels. $Eol" .
"                             For Uniden radios, this will be systems.      $Eol" .
"                             For all other radios, this will be channels.  $Eol" .
"             --dir$Yellow dir$Reset   Directory for output                 $Eol" .
"             -f|--filename$Yellow name$Reset Filename to create.           $Eol" .
"                                 Do NOT specify the path or ext.           $Eol" .
"                                  Ext will be '.csv'                       $Eol" .
"             --first$Yellow ch$Reset First channel number to read.         $Eol" .
"             --globals    get global settings from the radio               $Eol" .
"             --keyformat  Store records as KEYWORD=VALUE fields            $Eol" .
"             --nocomment  Do not generate FREQ comment records.            $Eol" .
"             -o           Overwrite any existing file without prompt       $Eol" .
"             --origin$Yellow n$Reset  First channel number for renumber.     \n" .
"             --port$Yellow /dev/ttyxxx$Reset  Override for default device. $Eol" .
"             -q$Yellow key$Reset    Change system quickkey (0-99).         $Eol" .
"                          This option will also update ':QUICKKEY:' tag.     \n" .
"                          If this option is not specified, the quickkeys     \n" .
"                            will remain unchanged on the SYSTEM or SITE      \n" .
"                            records.                                         \n" .
"                          NOTE:If multiple files are specified, or there are  \n" .
"                            multiple SYSTEM or SITE records, ALL of these    \n" .
"                            will be assigned the same quickkey with this     \n" .
"                            option.                                          \n" .
"             --renum      Renumber the channels.                             \n" .
"             -s|--sort    Sort FREQ records by frequency                     \n" .
"             --search     Get Search records from the radio                  $Eol" .
"             --skip       Skip over empty channels.                        $Eol" .
"             -z|--hz     Store frequencies in Hz (default is MHz)            \n" .
"                                                                             $Eol" .
"                                                                             $Eol" .
"   $Bold REWRITE$Reset    Read RadioCtl file(s) and merge all files read into$Eol" .
"                  a single new file.                               $Eol" .
"       Inputs:RadioCtl Files(s) to read.                                      \n" .
"       Output:'temp.csv' saved in the default directory.                     \n" .
"       Options:                                                              \n" .
"             --append    Append data to existing file instead of overwrite \n" .
"             --dir$Yellow dir$Reset   Directory for output                 $Eol" .
"             -f|--filename$Yellow name$Reset Filename to create.           $Eol" .
"                                 Do NOT specify the path or ext.           $Eol" .
"                                  Ext will be '.csv'                       $Eol" .
"             --keyformat  Store records as KEYWORD=VALUE fields            $Eol" .
"             -o           Overwrite any existing file without prompt       $Eol" .
"             --origin$Yellow n$Reset  First channel number for the --RENUM option  \n" .
"             -q$Yellow key$Reset    Change system quickkey (0-99).         $Eol" .
"                          This option will also update ':QUICKKEY:' tag.     \n" .
"                          If this option is not specified, the quickkeys     \n" .
"                            will remain unchanged on the SYSTEM or SITE      \n" .
"                            records.                                         \n" .
"                          NOTE:If multiple files are specified, or there are  \n" .
"                            multiple SYSTEM or SITE records, ALL of these    \n" .
"                            will be assigned the same quickkey with this     \n" .
"                            option.                                          \n" .
"             --renum      Renumber the channels                        \n" .
"             -s           Sort FREQ records by frequency               \n" .
"             -z|--hz     Store frequencies in Hz (default is MHz)     \n" .
"                                                                             $Eol" .
"   $Bold SDS2CSV $Reset   Convert Uniden .hpd & .cfg files to RadioCtl .csv files $Eol" .
"       Input:Single .hpd or .cfg file to read.                               \n" .
"       Output:'temp.csv' saved in the default directory.                     \n" .
"       Options:                                                              \n" .
"             --append    Append data to existing file instead of overwrite \n" .
"             --dir$Yellow dir$Reset   Directory for output                  $Eol" .
"             -f|--filename$Yellow name$Reset Filename to create.             $Eol" .
"                                 Do NOT specify the path or ext.             $Eol" .
"                                  Ext will be '.csv'                         $Eol" .
"             --keyformat  Store records as KEYWORD=VALUE fields              $Eol" .
"             -o           Overwrite any existing file without prompt         $Eol" .
"             -q$Yellow key$Reset    Change system quickkey (0-99).           $Eol" .
"                          This option will also update ':QUICKKEY:' tag,     \n" .
"                          If this option is not specified, the quickkeys     \n" .
"                            will remain unchanged on the SYSTEM or SITE      \n" .
"                            records.                                         \n" .
"                          NOTE:If multiple files are specified, or there are  \n" .
"                            multiple SYSTEM or SITE records, ALL of these    \n" .
"                            will be assigned the same quickkey with this     \n" .
"                            option.                                          \n" .
"             --renum     Renumber the channels                              \n" .
"             --origin$Yellow n$Reset  First channel number for the --RENUM option         \n" .
"             -s          Sort FREQ records by frequency                      \n" .
"             --sysonly   Only output systems                                 \n" .
"             --gps       Restrict output to sites/groups in range            \n" .
"             --lat       Latitude for GPS. Default is 41.603858              \n" .
"             --lon       Longitude for GPS. Default is -73.976428            \n" .
"             --radius    Radius in miles for GPS. Default is 25.             \n" .
"             -z|--hz     Store frequencies in Hz (default is MHz)            \n" .
"                                                                             \n" .
"                                                                             \n" .
"  $Bold WRITESYS $Reset  Read one or more RadioCtl file and store the data   \n" .
"               in the selected radio's memory.                               \n" .
"             Input:Name of radio to write (must be specified first)          \n" .
"                   Filespec(s) to store into radio                           $Eol" .
"             Options:                                                        \n" .
"              --count$Green n$Reset  Store only 'n' channels (non-dynamic radios only) $Eol" .
"              --renum    Renumber channels (non-dynamic radios only)        $Eol" .
"              --origin$Green n$Reset First channel number for --renum option (non-dynamic radios only) $Eol" .
"              --port$Yellow /dev/ttyxxx$Reset  Override for default device. $Eol" .
"              --erase    Clear any existing systems/channels. (dynamic radios only)  $Eol" .
"              --test     Only read the file. Do not write to the radio.     $Eol" .
"\n";
our $deffile = "$homedir/radioctl.conf";
if (!-e $deffile) {LogIt(320,"Cannot locate configuration file $deffile");}
my %radiodb = ();
my %out = ();
my %in = ();
my %parmref = ('out' => \%out,'in' => \%in,'database' => \%radiodb, 'def' =>\%radio_def);
my %radio_parms = ();
my %bench = ();
my %radmaxno = ();
foreach my $key (keys %structure) {$radmaxno{$key} = 0;}
my %create = ('sin' => 'CSY',
'sif' => 'AST',
'tfq' => 'ACC',
'cin' => 'ACC',
'gin' => 'AGC',
'tin' => 'ACT',
);
my %changekey = ('service' => 1,
'qkey'    => 1,
'mot_type' => 1,
'edacs_type' => 1,
'frequency' => 1,
);
my %new = ();
my $debug_addr = '9000';
my %systypes = (
'ltr'   => 'Ltr',
'dmr'   => 'DmrOneFrequency',
'nxdn'  => 'Nxdn',
'nxdn1' => 'NxdnOneFrequency',
'eds'   => 'Scat',
'edw'   => 'Edacs',
'edn'   => 'Edacs',
'p25s'  => 'P25Standard',
'p25f'  => 'P25OneFrequency',
'p25x'  => 'P25X2_TDMA',
'trbo'  => 'MotoTrbo',
'turbo' => 'MotoTrbo',
'mots'  => 'Motorola',
'motp'  => 'Motorola',
'motc'  => 'Motorola',
'cnv'   => 'Conventional',
);
my %syskeys = ();
my %grpkeys = ();
my $sitecnt = 0;
my $freqcnt = 0;
my $tfqcnt = 0;
my $grpcnt = 0;
my $gidcnt = 0;
my $sgidcnt = 0;
my $altport = '';
my $append = FALSE;
my $count = 0;
my $default_dir = $settings{'tempdir'};
my $dir = "";
my $erase = FALSE;
my $firstnum   = 0;
my $freqsort = FALSE;
my $globals = FALSE;
my $gps = FALSE;
my $hotkey = -1;
my $hpd = 1;
my $keyformat = FALSE;
my $lat =  41.603858;
my $lon =  -73.976428;### Default longitude for GPS (Marlboro)                    SDS2CSV
my $nocomment = FALSE;### Do not include FREQ comment records                     READSYS
my $nohdr = FALSE;
my $notrunk = FALSE;
my $nodie = FALSE;
my $noigrp = FALSE;
my $skip = FALSE;
my $nosys = FALSE;
my $radius = 25;
my $origin = 1;
my $overwrite = FALSE;### Overwrite without prompting                            *CVT REWRITE SDS2CSV RR2CSV READSYS
my @radio = ();
my $renum = FALSE;
my $search = FALSE;
my $showhz  = FALSE;
my $stype = '';
my $testing = FALSE;
my $user_filename = 'temp';
my $dupcheck = FALSE;
my $gidsort  = FALSE;
my $sitesort = FALSE;
my $freqserv = FALSE;
my $gidserv  = FALSE;
my $keep     = FALSE;
my $firstsitenum = '';
my $firstgidnum = '';
my $siteprepend = '';
my $refsite = FALSE;
my $output = "/$default_dir/temp.csv";
my $default_output = $output;
my $firstsin  = -1;
my $sysonly = FALSE;
$Options{'append'}   = \$append;
$Options{'count=n'}  = \$count;
$Options{'dir=s'}    = \$dir;
$Options{'erase'}    = \$erase;
$Options{'f|filename=s'} = \$user_filename;
$Options{'first=n'} = \$firstnum;
$Options{'globals'} = \$globals;
$Options{'gps'}      = \$gps;
$Options{'hpd=n'}    = \$hpd;
$Options{'h|help'}   = \&help;
$Options{'k'}        = \$keep;
$Options{'keyformat'} = \$keyformat;
$Options{'lat=n'}    = \$lat;
$Options{'lon=n'}    = \$lon;
$Options{'nocomment'} = \$nocomment;
$Options{'nodie'}    = \$nodie;
$Options{'noigrp'}   = \$noigrp;
$Options{'notrunk'}  = \$notrunk;
$Options{'nosys'}    = \$nosys;
$Options{'skip'}     = \$skip;
$Options{'nohdr'}    = \$nohdr;
$Options{'o|overwrite'} = \$overwrite;
$Options{'origin=n'} = \$origin;
$Options{'port=s'}   = \$altport;
$Options{'q=i'}      = \$hotkey;
$Options{'radio=s'} = \@radio;
$Options{'radius=n'} = \$radius;
$Options{'renum'}    = \$renum;
$Options{'search'}   = \$search;
$Options{'s|sort'}   = \$freqsort;
$Options{'sysonly'}  = \$sysonly;
$Options{'test'}     = \$testing;
$Options{'stype=s'}  = \$stype;
$Options{'z|hz'}     = \$showhz;
Parms_Parse();
my $cmd = shift @ARGV;
if (!$cmd) {$cmd = '?';}
$cmd = lc($cmd);
my $fs = '';
if ($ARGV[0]) {$fs = shift @ARGV;}
if (!$user_filename) {
LogIt(940,"Cannot specify a blank for the output filename!");
}
if ($stype) {
my $sysvalid = FALSE;
$stype = lc($stype);
foreach my $str (@system_type) {
if ($stype eq $str) {
$sysvalid = TRUE;
last;
}
}
if (!$sysvalid) {LogIt(983,"System type $stype is NOT a valid radioctl system type!");}
}
if ($altport) {
if (! -e $altport) {LogIt(988,"Serial/USB port $altport does NOT exist!");}
}
spec_read($deffile);
if ($cmd eq '?') {help();}
elsif ($cmd eq 'dplysignal') {
my @freqlist = (25,30,40,75,80,
120,140,150,160,170,
200,300,400,430,451,470,
500,584,602,700,770,
800,850,900,950,999,
);
my $ndx = 0;
my $freq = -1;
my $lastdply = '.';
my $first = TRUE;
if (!$fs) {LogIt(3898,"READSYS:No radio for command $cmd given!");}
$bench{'start_read'} = time();
my $radioname = $fs;
my $radiosel = lc($radioname);
select_radio($radiosel);
my $protocol = $radio_def{'protocol'};
my $routine = $radio_routine{$protocol};
if (!$routine) {LogIt(4155,"READSYS:Radio routine not set for protocol $protocol");}
$parmref{'out'} = \%out;
$parmref{'in'} = \%in;
%in = ('noport' => FALSE, 'nobaud' => FALSE);
if ($altport) {
$radio_def{'port'} = $altport;
$in{'noport'} = TRUE;
}
if (&$routine('autobaud',\%parmref) ) {
LogIt(4160,"READSYS:Failed to determine baud/port for radio: $radioname ");
}
LogIt(0,"$Bold Radio $Yellow$radiosel$White is on port " .
"$Magenta$radio_def{'port'}$White with baud $Green$radio_def{'baudrate'}");
$parmref{'portobj'} = open_serial();
$parmref{'database'} = \%radiodb;
%in = ();
if (&$routine('init',\%parmref) ) {
LogIt(3937,"READSYS:Failed to initialize radio: $radiosel ($protocol)");
}
open(TTY, "+</dev/tty") or die "no tty: $!";
system "stty -echo cbreak </dev/tty >/dev/tty 2>&1";
my $direction = 1;
while (TRUE) {
if ($freq < 0) {
$ndx = $ndx + $direction;
if ($ndx > $#freqlist) {$ndx = 0;}
elsif ($ndx < 0) {$ndx = $#freqlist;}
$freq = $freqlist[$ndx];
%in = ('frequency'=> ($freq * 1000000), 'mode' => 'fmn');
if (&$routine('setvfo',\%parmref)) {
LogIt(1,"Radio did NOT like frequency $Yellow$freq$White mhz");
$ndx = $ndx + $direction;
sleep 1;
$freq = -1;
next;
}
$lastdply = '.';
}### setting frequency
%out = ('sql'=> 0, 'signal'=> 0, 'rssi'=> 0);
if (&$routine('getsig',\%parmref)) {LogIt(1,"Radio is not responing");}
else {
my $sql = $out{'sql'};
my $signal = $out{'signal'};
my $rssi = $out{'rssi'};
my $dply = "freq=>$Bold$Yellow" . sprintf("%4.1f",$freq) .
" MHz$Reset squelch=>";
if ($sql) {$dply = "$dply$Bold";}
$dply = "$dply$sql$Reset $signal=>";
if ($signal) {$dply = "$dply$Bold";}
$dply = "$dply$Green$signal$Reset rssi=>";
if ($rssi) {$dply = "$dply$Bold";}
$dply = "$dply$Magenta" . sprintf("%3.3u",$rssi) . $Reset;
print STDERR "\r$dply   ";
my $rin;
vec($rin, fileno(TTY), 1) = 1;
if (select($rin,undef,undef,0)) {
my $key = getc();
if (lc($key) eq 'q') {
close TTY;
last;
}
elsif (lc($key) eq 'u') {
$freq = -1;
$direction = 1;
}
elsif (lc($key) eq 'd') {
$freq = -1;
$direction = -1;
}
else {
}
}
}
}
close TTY;
system "stty echo -cbreak </dev/tty >/dev/tty 2>&1";
print "\n";
exit 0;
}
elsif ($cmd eq 'dupcheck') {
my @filelist = ();
get_files(\@filelist);
my $filecount = scalar @filelist;
if ($filecount) {LogIt(0,"found $filecount  files to check");}
else {LogIt(1132,"No files found to process!");}
my %database = ();
foreach my $fs (@filelist) {
if (!-e $fs) {LogIt(497,"Unable to locate $fs!");}
read_radioctl(\%database,$fs);
}
my %freqs = ();
foreach my $freqrec (@{$database{'freq'}}) {
if (!$freqrec->{'index'}) {next;}
my $frequency = $freqrec->{'frequency'};
if (!$frequency) {next;}
my $oldref = $freqs{$frequency};
if ($oldref) {
print "Duplicate frequency:",rc_to_freq($frequency),"\n";
print "   First record number: $oldref->{'_recno'} Service: $oldref->{'service'}\n";
print "  Current record number:$freqrec->{'_recno'} Service:$freqrec->{'service'}\n";
}
else {$freqs{$frequency} = $freqrec;}
}
}
elsif ($cmd eq 'csv2icom') {
my %csv_struct = (
'all' => [
{'Group No'         => 'icomgroup'},
{'Group Name'       => 'groupname'},
{'CH No'            => 'channel'},
{'Name'             => 'service'},
{'Frequency'        => 'frequency'},
{'Mode'             => 'mode'},
{'Tone'             => 'tone_type'},
{'TSQL Frequency'   => 'ctcss'},
{'DTCS Code'        => 'dcs'},
{'DTCS Polarity'    => '',},
{'Offset'           => 'offset'},
{'DUP'              => 'dup'},
{'DV SQL'           => ''},
{'DV CSQL Code'     => ''},
],
&ICR30 => [
{'RF Gain'          => 'gain'},
{'SKIP'             => 'skip'},
{'P25 SQl'          => 'p25sql'},
{'P25 NAC'          => 'p25nac'},
],
&IC705 => [
{'Repeater Tone'    => 'rptrtone'},
{'filter'           => 'filter'},
{'SEL'              => 'select'},
{'split'            => 'split'},
{'Frequency(2)'     => 'sfrequency'},
{'Mode(2)'          => 'smode'},
{'Filter(2)'        => 'sfilter'},
{'TONE(2)'          => 'stone_type'},
{'Repeater Tone(2)' => 'srptrtone'},
{'TSQL Frequency(2)'=> 'sctcss'},
{'DTCS Code(2)'     => 'sdcs'},
{'DTCS Polarity(2)' => 'spolarity'},
{'DV SQL(2)'        => ''},
{'DV CSQL Code (2)' => ''},
],
&R8600 => [
{'SKIP'             => 'skip'},
{'SEL'              => 'select'},
],
);
my %valid_models = ('ICR30' => TRUE, 'IC705' => TRUE, 'R8600' => TRUE);
my @allmodels = ();
if (scalar @radio) {
foreach my $radio (@radio) {
if ($valid_models{uc($radio)}) {push @allmodels,uc($radio);}
else {LogIt(1,"$radio is not a valid model for CSV2ICOM");}
}
}
else {@allmodels = keys %valid_models;}
if (!scalar @allmodels) {LogIt(1251,"No valid radio models selected for process!");}
my %outdir = ('IC705' => 'IC-705',
'ICR30' => 'IC-R30',
'R8600' => 'IC-R8600',
);
my $tdir = get_directory($radio_def{'sdir'});
my @filelist = ();
get_files(\@filelist);
my $filecount = scalar @filelist;
if ($filecount) {LogIt(0,"found $filecount  files to convert");}
else {LogIt(1,"No files found to process!");}
my %database = ();
foreach my $fs (@filelist) {
if (!-e $fs) {LogIt(497,"Unable to locate $fs!");}
read_radioctl(\%database,$fs);
}
my %newrecords = ();
my $outcount = 0;
foreach my $sys (@{$database{'system'}}) {
my $sysno = $sys->{'index'};
if (!$sysno) {next;}
if (lc($sys->{'systemtype'}) ne 'cnv') {next;}
my $file_renum = $renum;
my $bank_used = FALSE;
if ($sys->{'bank_used'}) {$bank_used = TRUE;}
else {
LogIt(1,"Missing 'bank_used in $sys->{'service'}. Renumber forced");
$file_renum = TRUE;
}
my $sysgroupno = $sys->{'index'};
my $sysgroupsvc  = $sys->{'service'};
foreach my $key ('igrp','qkey') {
my $test = Strip($sys->{$key});
if (($test ne '') and  ($test !~ /\./) and ($test !~ /\-/) and (looks_like_number($test) )) {
$sysgroupno = $test;
last;
}
}
foreach my $grp (@{$database{'group'}}) {
my $grpno = $grp->{'index'};
if (!$grpno) {next;}
if ($grp->{'sysno'} != $sysno) {next;}
my $icomgroup = $sysgroupno;
my $icomsvc = $sysgroupsvc;
my $test = Strip($grp->{'igrp'});
if (($test ne '') and  ($test !~ /\./) and ($test !~ /\-/) and (looks_like_number($test) )) {
$icomgroup = $test;
$icomsvc = $grp->{'service'};
$icomgroup = $icomgroup + 0;
}
if (!defined $newrecords{$icomgroup}{'service'}) {
$newrecords{$icomgroup}{'service'} = $icomsvc;
}
else {
if (defined $newrecords{$icomgroup}{'rcds'} and  (scalar @{$newrecords{$icomgroup}{'rcds'}} > 99)) {
LogIt(1,"ICOM ICOM group $icomgroup is full");
$icomgroup = 'overflow';
$icomsvc = 'Overflow Frequencies';
if (!defined $newrecords{$icomgroup}{'service'}) {
$newrecords{$icomgroup}{'service'} = $icomsvc;
}
}### service is full
}### Not the first time this group has been defined
my $newchannel = 0;
foreach my $frq (@{$database{'freq'}}) {
my $frqno = $frq->{'index'};
if (!$frqno) {next;}
if ($frq->{'groupno'} ne $grpno) {next;}
if ($frq->{'tgid_valid'}) {next;}
if ($icomgroup ne 'overflow') {
if ((defined $newrecords{$icomgroup}{'rcds'}) and (scalar @{$newrecords{$icomgroup}{'rcds'}} > 98)) {
LogIt(1,"RadioWrite l1581: ICOM group $icomgroup is full");
$icomgroup = 'overflow';
}
}
if ($file_renum) {$frq->{'channel'} = $newchannel;}
else {
if (!defined $frq->{'channel'}) {
LogIt(1341,"Channel number $frq->{'channel'} in record $frqno is not defined. Skipped");
}
my $ch = $frq->{'channel'};
if (!looks_like_number($ch)) {
LogIt(1,"Channel not defined in record $frqno. Skipped.");
next;
}
if  (($ch > 99) or ($ch < 0)) {
LogIt(0,"Channel $ch for freqno $frqno Skipped due to out of bounds (recno=$frq->{'_recno'})");
next;
}
}
my $scangrp = icomscangrp($frq->{'scangrp'},$grp->{'scangrp'},);
$frq->{'scangrp'} = $scangrp;
push @{$newrecords{$icomgroup}{'rcds'}},$frq;
$newchannel++;
if ($newchannel > 99) {
LogIt(1,"Too many channels for group $icomgroup");
last;
}
}### Run through the frequencies
}### For each defined group
}### For each system
foreach my $model (@allmodels) {
my $header = '';
foreach my $md ('all',$model) {
my $array = $csv_struct{$md};
foreach my $rcd (@{$array}) {
foreach my $key (keys %{$rcd}) {
if ($rcd->{$key}) {$header = "$header$key,";}
}
}
}
my @allgroups = ($header);
foreach my $ndx (sort keys %newrecords) {
my $groupndx = $ndx;
my $groupname =  Strip(substr($newrecords{$ndx}{'service'},0,16));
if ($ndx ne 'overflow') {
$groupndx = sprintf("%02.2u",$groupndx);
}
else {$groupndx = '99';}
my @outrecs = ($header);
foreach my $frq (@{$newrecords{$ndx}{'rcds'}}) {
my %outdata = ('icomgroup' => $groupndx,
'groupname' => $groupname,
'channel'   => sprintf("%02d",$frq->{'channel'}),
'service'   => Strip(substr($frq->{'service'},0,16)),
'tone_type' => 'OFF',
'rptrtone' => '88.5Hz',
'ctcss'    => '88.5Hz',
'dcs'      => '023',
'polarity' => 'BOTH N',
'split'    => 'OFF',
'gain'     => 'RFG MAX',
'skip'     => 'OFF',
'filter'   => 1,
'select'   => 'OFF',
'dup'      => 'OFF',
'offset'   => '0.000000',
'sfrequency' => '',
'smode'     => '',
'sfilter'  => '',
'srptrtone' => '',
'sctcss'   => '',
'sdcs'     => '',
'stone_type' => '',
'sdcs'   => '',
'spolarity' => '',
'p25nac'  => '',
'p25sql'  => '',
);
my $freqhz = $frq->{'frequency'};
if (!$freqhz) {next;}
$outdata{'frequency'} =  rc_to_freq($freqhz);
if (!$frq->{'valid'}) {
$outdata{'skip'} = 'SKIP';
$outdata{'select'} = 'OFF';
}
else {
if ($frq->{'scangrp'}) {
my $selscan = $frq->{'scangrp'};
if (($model eq IC705) and ($selscan > 3)) {$selscan = 3;}
$outdata{'select'} = 'SEL' . $selscan;
}
else {$outdata{'select'} = 'SEL1';}
}
foreach my $pass (0,1) {
my $pre = '';
if ($pass) {$pre = 's';}
my $inmode = $frq->{$pre . 'mode'};
if ($pre and (!$inmode)) {$inmode = $frq->{'mode'};}
if ((!$inmode) or ($inmode eq '-') or ($inmode eq '.')) {
if (!$pass) {### Only warn if this is NOT the split frequency
LogIt(1,"Missing modulation in record $frq->{'_recno'}. Set to FMn");
}
$inmode = 'FMn';
}
my ($code,$mode) = rcmode2icom($inmode,ICR30);
if (!$mode) {
LogIt(1453,"RADIOWRITE l1453:rcmode2icom did NOT return a valid modulation for SD CARD! " .
" Mode passed ($pre" . "mode)=>" . $frq->{$pre . 'mode'});
}
$outdata{$pre . 'mode'} = $mode;
my $filter = substr($code,-1,1);
$outdata{$pre . 'filter'} = $filter;
my $tone = $frq->{$pre . 'tone'};
if (!$tone) {$tone = 'Off';}
my $tone_type = $frq->{$pre . 'tone_type'};
if (!$tone_type) {$tone_type = 'Off';}
$tone = Strip($tone);
$tone_type = lc($tone_type);
if ($mode !~ /fm/i) { 
$tone = '';
$tone_type = 'off';
}
else {
if (($tone_type eq 'rptr') and ($model eq IC705)) {
$tone_type = 'TONE';
$tone = $tone . 'Hz';
}
elsif ($tone_type eq 'ctcss') {
$tone_type  = 'TSQL';
$tone = $tone . 'Hz'
}
elsif ($tone_type eq 'dcs') {
$tone_type = 'DTCS';
}
else {
$tone_type = 'off';
$tone = '67.0Hz';
}
}### FM modulation discovered
$outdata{$pre .'tone_type'} = $tone_type;
$outdata{$pre . 'tone'} = $tone;
}
if ($frq->{'sfrequency'}) {
if ($frq->{'ominus'}) {
$outdata{'dup'} = 'DUP-';
$outdata{'offset'} = rc_to_freq($frq->{'sfrequency'});
}
elsif ($frq->{'oplus'}) {
$outdata{'dup'} = 'DUP+';
$outdata{'offset'} = rc_to_freq($frq->{'sfrequency'});
}
else {
$outdata{'sfrequency'} = $frq->{'sfrequency'};
$outdata{'split'} = 'ON';
}
}
$outdata{'gain'} = 'RFG MAX';
if ($frq->{'rfgain'} and $frq->{'rfgain'} < 10) {
$outdata{'gain'} = 'RFG' . strip($frq->{'rfgain'});
}
elsif ($frq->{'atten'} or $frq->{'r30att'}) {
$outdata{'gain'} = 'RFG5';
}
my $out = '';
foreach my $md ('all',$model) {
my $array = $csv_struct{$md};
foreach my $rcd (@{$array}) {
foreach my $key (keys %{$rcd}) {
if ($rcd->{$key}) {
my $rckey = $rcd->{$key};
my $value = '';
if (defined $outdata{$rckey}) {
$value = $outdata{$rckey};
}
else {LogIt(1,"Missing field $rckey from outdata hash!");}
if (!defined $value) {$value = '';}
$out = "$out$value,";
}### The key will be used
}
}### Each element
}### For each model
push @outrecs,$out;
push @allgroups,$out;
}### for each frequency defined for this group
if ((scalar @outrecs) > 1) {
my $outdir = "$tdir/$outdir{$model}/Csv/MemoryCh";
if (!-e $outdir) {system "mkdir -p $outdir";}
if (!-e $outdir) {LogIt(1662,"Cannot create directory $outdir");}
my $outfile = "$outdir/$model-group-$groupndx.csv";
if (open OUTFILE,">$outfile") {
foreach my $rec (@outrecs) {print OUTFILE "$rec\n";}
close OUTFILE;
$outcount++;
LogIt(0,"$Bold Created $outfile");
}
else {LogIt(1355,"Cannot open $outfile for writing! Error is $!");}
}
}### For each Group
if (scalar @allgroups > 1) {
my $outdir = "$tdir/$outdir{$model}/Csv/MemoryCh";
if (!-e $outdir)  {system "mkdir -p $outdir";}
if (!-e $outdir) {LogIt(1684,"Cannot create directory $outdir");}
my $outfile = "$outdir/$model-all.csv";
if (open OUTFILE,">$outfile") {
foreach my $rec (@allgroups) {print OUTFILE "$rec\n";}
close OUTFILE;
$outcount++;
LogIt(0,"$Bold Created $outfile");
}
else {LogIt(1327,"Cannot open $outfile for writing! Error is=>$!");}
}### Created ALL.CSV
}### For each model
LogIt(0,"$Bold Built $Green$outcount$White ICOM SD-Card files in directory $dir");
exit;
}
elsif ($cmd eq 'autobaud') {
my $radioname = $fs;
my $radiosel = lc($radioname);
select_radio($radiosel);
my $protocol = $radio_def{'protocol'};
my $routine = $radio_routine{$protocol};
if ($routine) {
if (&$routine('autobaud',\%parmref) ) {
LogIt(1121,"AUTOBAUD:Failed to determine baud/port for radio: $radioname ");
}
LogIt(0,"$Bold Radio $Yellow$radiosel$White is on port " .
"$Magenta$radio_def{'port'}$White with baud $Green$radio_def{'baudrate'}");
}
}
elsif ($cmd eq 'merge') {
my @filelist = ();
get_files(\@filelist);
my %outdb = ();
my $records = 0;
my $sysno = 0;
foreach my $fs (@filelist) {
my %ctldb = ();
read_radioctl(\%ctldb,$fs);
if (!$outdb{'system'}[1]{'index'}) {
my %recdata = ('systemtype' => 'CNV','valid' => TRUE,
'service' => "Merged database",
);
if ($ctldb{'system'}[1]{'index'} and (lc($ctldb{'system'}[1]{'systemtype'}) eq 'cnv') ){
foreach my $key (keys %{$ctldb{'system'}[1]}) {
$recdata{$key} = $ctldb{'system'}[1]{$key};
}
}
$sysno = add_a_record(\%outdb,'system',\%recdata,FALSE);
foreach my $grprec (@{$ctldb{'group'}}) {
if (!$grprec->{'index'}) {next;}
my %recdata = ();
foreach my $key (keys %{$grprec}) {$recdata{$key} = $grprec->{$key};}
add_a_record(\%outdb,'group',\%recdata,FALSE);
}
my %tags = ('updated' => Time_Format() . " by RadioWrite:MERGE");
add_a_record(\%outdb,'tag',\%tags,FALSE);
foreach my $ndx (1..10) {
if ($ctldb{'tag'}[$ndx]{'index'}) {
add_a_record(\%outdb,'tag',$ctldb{'tag'}[$ndx],FALSE);
}
else {last;}
}
}### First file process
MRGRECLP:
foreach my $rec (@{$ctldb{'mergerec'}}) {
my $mgndx = $rec->{'index'};
if (!$mgndx) {next;}
add_a_record(\%outdb,"mergerec",$ctldb{'mergerec'}[$mgndx]);
my $infilename = $rec->{'infile'};
if (!$infilename) {$infilename = '.';}
$infilename =~ s/\"//g; 
my $ingrpno = $rec->{'ingrpno'};
my $chan = $rec->{'outfirst'};
my $lastchan = $rec->{'outlast'};
my $outgrpno = $rec->{'outgrpno'};
my $procfile = $fs;
my $dbref = \%ctldb;
my %tdb = ();
if ($infilename ne '.') {
$dbref = \%tdb;
read_radioctl($dbref,$infilename);
$procfile = $infilename;
}
print "Processing $procfile...\n";
my $foundcnt = 0;
foreach my $grprec (@{$dbref->{'group'}}) {
my $grpndx = $grprec->{'index'};
if (!$grpndx) {next;}
my $igrp = $grprec->{'igrp'};
if ($igrp != $ingrpno) {next;}
my $grpsysno = $grprec->{'sysno'};
my $grpsrv  = $grprec->{'service'};
print "   Found igroup number $igrp in $procfile\n";
if (lc($dbref->{'system'}[$grpsysno]{'systemtype'}) ne 'cnv') {
next;
}
if ($outdb{'group'}[$outgrpno]{'index'}) {
if (!$outdb{'group'}[$outgrpno]{'service'}) {
$outdb{'group'}[$outgrpno]{'service'} = $grpsrv;
$outdb{'group'}[$outgrpno]{'igrp'} = $igrp;
$outdb{'group'}[$outgrpno]{'valid'} = TRUE;
}
}
else {
my %newgrp = ('sysno' => $sysno);
foreach my $ndx (1..($outgrpno-1)) {
if (!$outdb{'group'}[$ndx]{'index'}) { add_a_record(\%outdb,'group',\%newgrp);}
}
foreach my $key (keys %{$grprec}) {$newgrp{$key} = $grprec->{$key};}
$newgrp{'sysno'} = $sysno;
my $newgrpno =  add_a_record(\%outdb,'group',\%newgrp);
}
my $linecomment = "*\n* ## $grpsrv  (file=>$infilename IGRP=>$igrp)\n";
foreach my $frecrec (@{$dbref->{'freq'}}) {
my $frqndx = $frecrec->{'index'};
if (!$frqndx) {next;}
if ($frecrec->{'groupno'} != $grpndx) {next;}
if (!$frecrec->{'frequency'}) {next;}
my %newfrq = ();
foreach my $key (keys %{$frecrec}) {$newfrq{$key} = $frecrec->{$key};}
$newfrq{'groupno'} = $outgrpno;
$newfrq{'channel'} = $chan;
if ($linecomment) {$newfrq{'linecomment'} = $linecomment;}
my $newfrqno =  add_a_record(\%outdb,'freq',\%newfrq,FALSE);
$linecomment = '';
$chan++;
$foundcnt++;
$records++;
if ($chan > $lastchan) {next MRGRECLP;}
}
if ($chan < $lastchan) {
my %newfreq = ('frequency' => 0,
'groupno' => $outgrpno,
'channel' => $chan,
'service' => "(reserved for the future)",
'_noshow' => TRUE,
'linecomment' => "* ### Channels $chan to $lastchan reserved for the future\n*"
);
add_a_record(\%outdb,'freq',\%newfreq,FALSE);
}
}### For each group record
if (!$foundcnt) {
LogIt(1,"No records found for mergerec line $Green$rec->{'_recno'}$White igrp=>$Magenta$ingrpno");
}
}
}
if (!$records) {
LogIt(1212,"No records were found matching specs");
}
my $tfile = '/tmp/newfile.csv';
if (write_radioctl(\%outdb,$tfile,'mhz','mergerec')) {
}
}
elsif ($cmd eq 'blocks') {
if (!$fs) {LogIt(1010,"No radio for command $cmd given!");}
$bench{'start_block'} = time();
my $radiosel = $fs;
select_radio($radiosel);
if ($altport) {$radio_def{'port'} = $altport;}
$parmref{'portobj'} = open_serial();
$parmref{'database'} = \%radiodb;
$parmref{'out'} = \%out;
$parmref{'in'} = \%in;
my $protocol = $radio_def{'protocol'};
%radiodb = ();
my $routine = $radio_routine{$protocol};
if ($routine) {
if (&$routine('init',\%parmref) ) {
LogIt(559,"Failed to initialize radio: $radiosel ($protocol)");
}
}
else {LogIt(1987,"RadioWrite-BLOCKS:Radio routine not set for protocol $protocol");}
if (substr(lc($radio_def{'model'}),0,3) ne 'bcd') {
LogIt(1089,"This command is only valid for BCD radios (selected model=>$radio_def{'model'})");
}
my @outrecs = ();
%out = ();
my $rc = &$routine('getinfo',\%parmref);
push @outrecs,"*** Current structure for $radiosel on " . Time_Format(time()) . "****\n" .
"** Model:$out{'model'}  (Battery status:$out{'bat_level'}v) \n" .
"** Total systems:$out{'sys_count'}\n" .
"** Total sites:$out{'site_count'}\n" .
"** Total frequencies:$out{'chan_count'}\n" .
"** Memory Used:$out{'mem_used'}" . '%'.  "\n" .
"** Memory Blocks Free:$out{'mem_free'}\n" .
"\n*** Record Format:  Block:Database_number:Block_addr  Service (Other info)\n";
$rc = &$routine('getmem',\%parmref);
my $syscount = 0;
my $totalgroups = 0;
foreach my $sysrec (@{$radiodb{'system'}}) {
my $sysno = $sysrec->{'index'};
if (!$sysno) {next;}
my $out = "\nSYSTEM " . sprintf("%3.3u",$sysno) . ':' .
sprintf("%5.5u",$sysrec->{'block_addr'}) . "  " .
sprintf("%-16.16s",$sysrec->{'service'}) .
" ($sysrec->{'systemtype'}) " .
" (qkey=>$sysrec->{'qkey'}) " .
"\n";
push @outrecs,$out;
$syscount++;
my $sitecount = 0;
my $freqcount = 0;
my $groupcount = 0;
foreach my $siterec (@{$radiodb{'site'}}) {
my $siteno = $siterec->{'index'};
if (!$siteno) {next;}
if ($siterec->{'sysno'} != $sysno) {next;}
$sitecount++;
my $tfreqcount = 0;
my $out = "          SITE:" . sprintf("%3.3u",$siteno) . ':' .
sprintf("%5.5u",$siterec->{'block_addr'}) . "  " .
sprintf("%-16.16s",$siterec->{'service'}) . "\n";
push @outrecs,$out;
foreach my $tfrec (@{$radiodb{'tfreq'}}) {
my $tfno = $tfrec->{'index'};
if (!$tfno) {next;}
if ($tfrec->{'siteno'} != $siteno) {next;}
my $out = "              TFREQ:" . sprintf("%3.3u",$tfno) . ':' .
sprintf("%5.5u",$tfrec->{'block_addr'}) .
"   " . rc_to_freq($tfrec->{'frequency'}) . "mhz \n";
push @outrecs,$out;
$freqcount++;
$tfreqcount++;
}
push @outrecs,"  --------$tfreqcount total TFREQs for site $siteno\n"
}
foreach my $grprec (@{$radiodb{'group'}}) {
my $grpno = $grprec->{'index'};
if (!$grpno) {next;}
if ($grprec->{'sysno'} != $sysno) {next;}
my $out = "          GROUP:" . sprintf("%3.3u",$grpno) . ':' .
sprintf("%5.5u",$grprec->{'block_addr'}) . "  " .
sprintf("%-16.16s",$grprec->{'service'}) .
" (qkey=>$grprec->{'gqkey'}) " .
"\n";
push @outrecs,$out;
$groupcount++;
my $frgrpcount = 0;
foreach my $frqrec (@{$radiodb{'freq'}}) {
my $frqno = $frqrec->{'index'};
if (!$frqno) {next;}
if ($frqrec->{'groupno'} != $grpno) {next;}
my $freq = '';
if ($frqrec->{'tgid_valid'}) {$freq = "TGID=$frqrec->{'tgid'}";}
else {$freq = rc_to_freq($frqrec->{'frequency'}) . "mhz";}
my $out = "                FREQ:" . sprintf("%3.3u",$frqno) . ':' .
sprintf("%5.5u",$frqrec->{'block_addr'}) . "  " .
sprintf("%-16.16s",$frqrec->{'service'}) .
" ($freq) " .
"\n";
push @outrecs,$out;
$frgrpcount++;
$freqcount++;
}
push @outrecs,"  --------$frgrpcount total FREQs for group $grpno\n";
}### For each group
push @outrecs,"  >>>$sitecount total SITES for system $sysno\n";
push @outrecs,"  >>>$groupcount total GROUP for system $sysno\n";
push @outrecs,"  >>>$freqcount total FREQS for system $sysno\n";
}
push @outrecs,"\n\n $syscount Total Systems defined\n";
push @outrecs,"\n\n $totalgroups Total Groups defined\n";
my $tdir = get_directory(FALSE);
my $outfile = "$tdir/blocks.txt";
if (open OUTFILE,">$outfile") {
print OUTFILE @outrecs;
close OUTFILE;
}
else {LogIt(1,"Could not create $outfile");}
$bench{'end_block'}  = time();
BenchMark(\%bench);
exit 0;
}
elsif ($cmd eq 'nullgroup') {
my %database = ();
read_radioctl(\%database,$fs);
foreach my $freq (@{$database{'freq'}}) {
if (!$freq->{'index'}) {next;}
if ($freq->{'groupno'}) {
my $groupno = $freq->{'groupno'};
if ($database{'group'}[$groupno]{"index"}) {
if ($database{'group'}[$groupno]{'_freqcnt'}) {
$database{'group'}[$groupno]{'_freqcnt'}++;
}
else {$database{'group'}[$groupno]{'_freqcnt'} = 1;}
}
}
}
foreach my $group (@{$database{'group'}}) {
if (!$group->{'index'}) {next;}
if ($group->{'_freqcnt'}) {next;}
else {
LogIt(0,"$Bold$Yellow$group->{'service'}$White Is not referenced by any FREQ record");
}
}
}
elsif ($cmd eq 'radios')  {
LogIt(0,"***$Green Available radio names (case sensitive)$White ***");
foreach my $name (sort keys %All_Radios) {
LogIt(0,"      $Bold$Yellow$name");
}
}
elsif ($cmd eq 'cvt') {
if (!$fs) {LogIt(1212,"$Yellow CVT$White Requires at least one file as input!");}
my @filelist = ();
get_files(\@filelist);
my $filecount = scalar @filelist;
if ($filecount) {LogIt(0,"found $Green$filecount$White  files to convert");}
else {LogIt(480,"No files found to rewrite!");}
foreach my $fs (@filelist) {
if (!-e $fs) {LogIt(497,"Unable to locate $fs!");}
my %database = ();
read_radioctl(\%database,$fs);
foreach my $rec (@{$database{'system'}}) {
if (!$rec->{'index'}) {next;}
if ($hotkey >= 0) {$rec->{'qkey'} = $hotkey;}
$rec->{'block_addr'} = '';
}### System records
foreach my $rec (@{$database{'site'}}) {
if (!$rec->{'index'}) {next;}
if ($hotkey >=0 ) {$rec->{'qkey'} = $hotkey;}
$rec->{'block_addr'} = '';
}### Site records
foreach my $rec (@{$database{'group'}}) {
if (!$rec->{'index'}) {next;}
my $gqkey = $rec->{'gqkey'};
if (!defined $gqkey or Strip($gqkey) eq '') {
$gqkey = $rec->{'index'};
if ($gqkey > 9) {$gqkey = 0;}
$rec->{'gqkey'}  = $gqkey;
}### Group quickkey process
$rec->{'block_addr'} = '';
}### Group process
my ($filename,$filepath,$fileext) = fileparse($fs,qr/\.[^.]*/);
write_data($filename,\%database);
}### For each file specified
exit $GoodCode;
}
elsif ($cmd eq 'edit') {
if (!$fs) {LogIt(1566,"No input file specified!");}
if (!-e $fs) {LogIt(1567,"Input file $fs does not exist!");}
my @inrecs = ();
if (open INFILE,$fs) {
@inrecs = <INFILE>;
close INFILE;
}
else {LogIt(1334,"Could not read $fs");}
if (!scalar @inrecs) {LogIt(1577,"No records were read from $fs");}
my @out = ();
my $fieldref = \$version1{'freq'};
my $index = 0;
my $recno = 0;
foreach my $linein (@inrecs) {
$recno++;
if (lc(substr($linein,0,4)) eq 'freq') {
my $line = $linein;
chomp $line;
my %outrec = ('_recno' => $recno, '_filespec' =>$fs);
if (read_line($line,\%outrec,\%version1)) {
push @out,$linein;
next;
}
$index++;
$outrec{'index'} = $index;
$outrec{'_rsvd'} = '';
my $lineout = write_format(\%outrec,'freq',$outrec{'protocol'},FALSE);
push @out,"$lineout\n";
}### FREQ record for editing
else {push @out,$linein;}
}
my $tdir = get_directory(FALSE);
my ($filename,$filepath,$fileext) = fileparse($fs,qr/\.[^.]*/);
my $outfile = "$tdir/$filename.csv";
if (-e $outfile) {
LogIt(1,"existing file $Yellow$outfile$White will be overwritten.");
if (!$overwrite) {
print "   OK (Y/N)=>";
my $answer = <STDIN>;
chomp($answer);
print STDERR "$Eol";
if (uc(substr($answer,0,1)) ne 'Y') {
LogIt(0,"$Bold Output file generation was bypassed!");
return 1;
}
}
}
if (open OUT,">$outfile") {
print OUT @out;
close OUT;
}
else {LogIt(1629,"Could not create $outfile!");}
LogIt(0,"$Bold $outfile created with changes....");
}
elsif ($cmd eq 'rewrite') {
my @filelist = ();
get_files(\@filelist);
my $filecount = scalar @filelist;
if ($filecount) {LogIt(0,"found $filecount  files to rewrite into $output");}
else {LogIt(480,"No files found to rewrite!");}
%radiodb = ();
foreach my $fs (@filelist) {
if ($fs eq $output) {LogIt(483,"Input $fs cannot be the same as output!");}
read_radioctl(\%radiodb,$fs);
}
write_data($user_filename,\%radiodb);
exit $GoodCode;
}
elsif ($cmd eq 'csv2sds') {
my $lat = 0;
my $lon = 0;
my $range = 50;
my @filelist = ();
get_files(\@filelist);
my @outrecs = ("TargetModel\tBCDx36HP\r\n","FormatVersion\t1.00\r\n");
my $filecount = scalar @filelist;
if ($filecount) {LogIt(0,"found $filecount  files to rewrite into $output");}
else {LogIt(480,"No files found to rewrite!");}
%radiodb = ();
foreach my $fs (@filelist) {
if ($fs eq $output) {LogIt(483,"Input $fs cannot be the same as output!");}
read_radioctl(\%radiodb,$fs);
}
if (defined $radiodb{'system'}[1]{'index'}) {
my %groupqk = ();
foreach my $rec (@{$radiodb{'group'}}) {
if ($rec->{'index'}) {
my $gqkey = $rec->{'gqkey'};
if (defined $gqkey and looks_like_number($gqkey)) {
my $gqkey = $gqkey + 0;
$groupqk{$gqkey} = TRUE;
}
}
}
my $dqk_status = "DQKs_Status\t";
foreach my $ndx (0..99) {
my $value = 'Off';
if ($groupqk{$ndx}) {$value = 'On';}
$dqk_status = "$dqk_status\t$value";
}
$dqk_status = "$dqk_status\t";
foreach my $sys (@{$radiodb{'system'}}) {
my $sysno = $sys->{'index'};
if (!$sysno) {next;}
my $systype = lc($sys->{'systemtype'});
my $qkey = $sys->{'qkey'};
if ($qkey and looks_like_number($qkey)) { }
else {$qkey = 'Off';}
my $hld = $sys->{'hld'};
if (!$hld) {$hld = '0';}
my $wait = $sys->{'p25wait'};
if (!$wait) {$wait = 0;}
else {
}
my $tag = $sys->{'systag'};
if (defined $tag and (looks_like_number($tag))){
$tag = $tag - 1;
if ($tag > 99) {$tag = 99;}
}
else {$tag = 'Off';}
my $service = $sys->{'service'};
if (!$service) {$service = '';}
my ($emgalt,$emglvl,$emgcol,$emgpat) = sds_alert($sys);
my $sys_p25mode = lc($sys->{'p25mode'});
my $p25_mode = 'Auto';
if (substr($sys_p25mode,0,1) eq 'm') {$p25_mode = 'Manual';}
elsif (substr($sys_p25mode,0,1) eq 'd') {$p25_mode = 'Default';}
my $p25_level = $sys->{'p25lvl'};
if (!$p25_level or ($p25_level < 5)) {$p25_level = 5;}
if ($p25_level > 13) {$p25_level = 13;}
my $motoend = 'Analog';
if ($systype =~ /p25/i) {$motoend = 'Ignore';}
if ($sys->{'end_code'} =~ /\+/) {$motoend = 'Analog+Digital';}
elsif (lc(substr($sys->{'end_code'},0,1)) eq 'i') {$motoend = 'Ignore';}
my $tgid_format = 'NEXEDGE';
my $agc_analog = 'Off';
if ($sys->{'agc_analog'}) {$agc_analog = 'On';}
my $agc_digital = 'Off';
if ($sys->{'agc_digital'}) {$agc_digital = 'On';}
my $priority = 'Off';
if ($sys->{'priority'}) {$priority = 'On';}
my $id_search = 'Off';
if ($sys->{'id_search'}) {$id_search = 'On';}
my $sbit = 'Ignore';
if ($sys->{'s_bit'}) {$sbit = 'Yes';}
my $edacs_width = 'Wide';
if ($systype eq 'edn') {$edacs_width = 'Narrow';}
my $moto_type = 'Standard';
if ($systype eq 'motp') {$moto_type = 'Sprinter';}
elsif ($systype eq 'motc') {$moto_type = 'Custom';}
my $syscode = $systypes{$systype};
if (!$syscode) {Logit(1598,"No translation for RadioCtl system code $syscode recno=$sys->{'recno'}");}
if ($systype eq 'cnv') {
my $rec = "Conventional" .
"\t\t" .
"\t$service" .
"\tOff" .
"\t" .
"\t$syscode" .
"\t$qkey\t$tag\t$hld\t$agc_analog\t$agc_digital\t$wait" .
"\t$p25_mode\t$p25_level";
push @outrecs,"$rec\r\n";
push @outrecs,"$dqk_status\r\n";
foreach my $grp (@{$radiodb{'group'}}) {
my $grpno = $grp->{'index'};
if (!$grpno) {next;}
if ($grp->{'sysno'} != $sysno) {next;}
my $service = $grp->{'service'};
my $gqkey = $grp->{'gqkey'};
if ((defined $gqkey) and looks_like_number($gqkey)) { }
else {$gqkey = 'Off';}
if (!$service) {$service = '';}
my $rf_filter = 'Off';
if ($grp->{'rf_filter'}) {$rf_filter = ucfirst($grp->{'rf_filter'});}
my $avoid = 'Off';
if (!$grp->{'valid'}) {$avoid = 'On';}
my $rec = "C-Group" .
"\t\t" .
"\t$service" .
"\t$avoid" .
"\t$lat\t$lon\t$range\tCircle" .
"\t$gqkey" .
"\t$rf_filter";
push @outrecs,"$rec\r\n";
foreach my $frq (@{$radiodb{'freq'}}) {
if (!$frq->{'index'}) {next;}
if ($frq->{'groupno'} ne $grpno) {next;}
my $frequency = $frq->{'frequency'};
if (!$frequency) {next;}
my $service = $frq->{'service'};
if (!$service) {$service = '';}
my $mode = "Auto";
my $rcmode = Strip(lc($frq->{'mode'}));
if ($rcmode) {
if ($rcmode eq 'am') {$mode = 'AM';}
elsif ($rcmode eq 'fmw') {$mode = 'FMB';}
elsif ($rcmode eq 'fmm') {$mode = 'WFM';}
elsif ($rcmode eq 'fmun') {$mode = 'NFM';}
elsif ($rcmode eq 'fmn') {$mode = 'FM'; }
}
my $avoid = 'Off';
if (!$frq->{'valid'}){$avoid = 'On';}
my $delay = 0;
if ($frq->{'dlyrsm'}) {
$delay = int($frq->{'dlyrsm'});
if ($delay < -8) {$delay = -10;}
elsif ($delay < 0) {$delay = -5;}
elsif ($delay < 6) { }
elsif ($delay < 20) {$delay = 10;}
else {$delay = 30;}
}
my $atten = 'Off';
if ($frq->{'atten'} or $frq->{'sdsatt'}) {$atten = 'On';}
my $tone_type = $frq->{'tone_type'};
if (!$tone_type) {$tone_type = 'off';}
$tone_type = Strip(lc($tone_type));
my $tone = $frq->{'tone'};
if (!defined $tone) {$tone = 'Off';}
$tone = Strip(lc($tone));
if (($tone eq 'off') or ($tone eq '')) {$tone = '';}
else {
$tone = Strip($tone);
if ($tone_type eq 'ctcss') {$tone = "TONE=C$tone";}
elsif ($tone_type eq 'dcs') {$tone = "TONE=D$tone";}
elsif ($tone_type eq 'nac') {$tone = "NAC=$tone";}
elsif ($tone_type eq 'ccode') {$tone = "ColorCode=$tone";}
elsif ($tone_type eq 'ran') {$tone = "RAN=$tone";}
else {$tone = '';}
}
my ($atone,$alevel,$acolor,$apattern) = sds_alert($frq);
my $offset = radctl2vol($frq->{'voloff'});
my $tag = 'Off';
if ($frq->{'bcdtag'} and looks_like_number($frq->{'bcdtag'})) {
$tag = $frq->{'bcdtag'} - 1;
if ($tag > 999) {$tag = 999;}
if ($tag < 0) {$tag = 'off';}
}
my $servtype = 3;
if ($frq->{'svcode'}) {
$servtype = $frq->{'svcode'};
}
elsif ($grp->{'svcode'}) {
$servtype = $grp->{'svcode'};
}
else {
}
my $priority = 'Off';
my $rec = "C-Freq" .
"\t\t" .
"\t$service\t$avoid" .
"\t$frequency\t$mode\t$tone\t$servtype\t$atten\t$delay\t$offset" .
"\t$atone\t$alevel\t$acolor\t$apattern" .
"\t$tag\t$priority";
push @outrecs,"$rec\r\n";
}### for all frequencies
}### For all Groups
}### Conventional system
else {
if (lc($qkey) eq 'off') {
foreach my $site (@{$radiodb{'site'}}) {
my $siteno = $site->{'index'};
if (!$siteno) {next;}
if ($site->{'sysno'} != $sysno) {next;}
if ($site->{'qkey'} and (looks_like_number($site->{'qkey'})) ) {
$qkey = $site-{'qkey'};
}
}
}
my $rec = "Trunk" .
"\t\t" .
"\t$service" .
"\tOff" .
"\t" .
"\t$syscode" .
"\t$id_search\t$emgalt\t$emglvl" .
"\t$sbit" .
"\t" .
"\t$qkey\t$tag\t$hld" .
"\t$agc_analog\t$agc_digital" .
"\t$motoend" .
"\t$priority" .
"\t$emgcol\t$emgpat" .
"\t$tgid_format";
push @outrecs,"$rec\r\n";
push @outrecs,"$dqk_status\r\n";
foreach my $site (@{$radiodb{'site'}}) {
my $siteno = $site->{'index'};
if (!$siteno) {next;}
if ($site->{'sysno'} != $sysno) {next;}
my $service = $site->{'service'};
if (!$service) {next;}
if (!$site->{'valid'}) {next;}
my $qkey = $site->{'qkey'};
if ($qkey and looks_like_number($qkey)) { }
else {
$qkey = 'Off';
}
my $atten = 'Off';
if ($site->{'atten'}) {$atten = 'On';}
my $mode = 'AUTO';
if (lc($site->{'mode'}) eq 'fmn') {$mode = 'FM';}
elsif (lc($site->{'mode'}) eq 'fmun') {$mode = 'NFM';}
my $p25wait = $site->{'p25wait'};
if (!$p25wait) {$p25wait = 0;}
my $site_p25mode = lc($site->{'p25mode'});
my $p25_mode = 'Auto';
if (substr($site_p25mode,0,1) eq 'm') {$p25_mode = 'Manual';}
elsif (substr($site_p25mode,0,1) eq 'd') {$p25_mode = 'Default';}
my $p25_level = $site->{'p25lvl'};
if (!$p25_level or ($p25_level < 5)) {$p25_level = 5;}
if ($p25_level > 13) {$p25_level = 13;}
my $nac = $site->{'p25nac'};
if (!$nac) {$nac = 'Srch';}
my $lat = $site->{'latitude'};
if (!$lat) {$lat = '-0.000000';}
if (!$lat) {$lat = 0;}
my $lon = $site->{'longitude'};
if (!$lon) {$lon = 0;}
my $range = $site->{'range'};
if (!$range) {$range = 0;}
my $rec = "Site" .
"\t\t" .
"\t$service" .
"\tOff" .
"\t$lat\t$lon\t$range" .
"\t$mode" .
"\t$moto_type" .
"\t$edacs_width" .
"\tCircle" .
"\t$atten" .
"\t$p25wait\t$p25_mode\t$p25_level" .
"\tOff" .
"\t$nac" .
"\tGlobal";
push @outrecs,"$rec\r\n";
foreach my $bplan (@{$radiodb{'bplan'}}) {
my $bpno = $bplan->{'index'};
if (!$bpno) {next;}
if ($bplan->{'siteno'} != $siteno) {next;}
my $rec = "BandPlan_mot";
foreach my $ndx (1..6) {
foreach my $keybase ('frequency_l','frequency_u','spacing_','offset_') {
my $key = $keybase . $ndx;
$rec = $rec . "\t" . $bplan->{$key};
}
}
push @outrecs,"$rec\r\n";
}### Bandplan process
my $freqcount = 0;
foreach my $frq (@{$radiodb{'tfreq'}}) {
my $frqno = $frq->{'index'};
if (!$frqno) {next;}
if (!$frq->{'siteno'}) {next;}
if ($frq->{'siteno'} != $siteno) { next;}
my $frequency = $frq->{'frequency'};
if (!$frequency) {next;}
my $lcn = $frq->{'lcn'};
if ($lcn and looks_like_number($lcn)) { }
else {$lcn = '0';}
my $ccode = 'Srch';
$freqcount++;
my $rec = "T-Freq" .
"\t\t" .
"\t"    .
"\tOff" .
"\t$frequency" .
"\t$lcn" .
"\t$ccode";
push @outrecs,"$rec\r\n";
}### All freqs for this site
if (!$freqcount) {LogIt(1,"RadioWrite l1361:No frequencies found for site $siteno!");}
}### All The sites
foreach my $grp (@{$radiodb{'group'}}) {
my $grpno = $grp->{'index'};
if (!$grpno) {next;}
if ($grp->{'sysno'} ne $sysno) {next;}
my $service = $grp->{'service'};
if (!$service) {$service = '';}
my $avoid = 'Off';
if (!$grp->{'valid'}) {$avoid = 'On';}
my $gqkey = $grp->{'gqkey'};
if ((defined $gqkey) and looks_like_number($gqkey)) { }
else {
LogIt(1,"No quickkey assigned for group $service ($grpno). Group cannot be selected!");
$gqkey = 'Off';}
my $rec = "T-Group" .
"\t\t" .
"\t$service" .
"\t$avoid" .
"\t$lat\t$lon\t$range\tCircle" .
"\t$gqkey";
push @outrecs,"$rec\r\n";
my $tgid_cnt = 0;
foreach my $frq (@{$radiodb{'freq'}}) {
if (!$frq->{'index'}) {next;}
if (!$frq->{'tgid_valid'}) {next}
if ($frq->{'groupno'} ne $grpno) {next;}
if ($frq->{'siteno'}) {next;}
my $tgid = $frq->{'tgid'};
my $service = $frq->{'service'};
if (!$service) {$service = '';}
my $avoid = 'Off';
if (!$frq->{'valid'}){$avoid = 'On';}
my $delay = 0;
if ($frq->{'dlyrsm'}) {
$delay = int($frq->{'dlyrsm'});
if ($delay < -8) {$delay = -10;}
elsif ($delay < 0) {$delay = -5;}
elsif ($delay < 6) { }
elsif ($delay < 20) {$delay = 10;}
else {$delay = 30;}
}
my $audiotype = 'ALL';
if ($frq->{'adtype'} and looks_like_number($frq->{'adtype'})) {
if ($frq->{'adtype'} == 1) {$audiotype = 'ANALOG';}
else {$audiotype = 'DIGITAL';}
}
my $atten = 'Off';
if ($frq->{'atten'} or $frq->{'sdsatt'}) {$atten = 'On';}
my ($atone,$alevel,$acolor,$apattern) = sds_alert($frq);
my $offset = radctl2vol($frq->{'voloff'});
my $tag = 'Off';
if ($frq->{'bcdtag'} and looks_like_number($frq->{'bcdtag'})) {
$tag = $frq->{'bcdtag'} - 1;
if ($tag > 999) {$tag = 999;}
if ($tag < 0) {$tag = 'off';}
}
my $servtype = 3;
if ($frq->{'svcode'}) {
$servtype = $frq->{'svcode'};
}
elsif ($grp->{'svcode'}) {
$servtype = $grp->{'svcode'};
}
else {
LogIt(0,"RadioWrite l3371:No servtype for record $frq->{'_recno'}. Set servtype to $servtype as default");
}
my $priority = 'Off';
my $tdmaslot = 'Any';
my $rec = "TGID" .
"\t\t" .
"\t$service" .
"\t$avoid\t$tgid" .
"\t$audiotype" .
"\t$servtype\t$delay\t$offset" .
"\t$atone\t$alevel\t$acolor\t$apattern" .
"\t$tag\t$priority" .
"\t$tdmaslot";
push @outrecs,"$rec\r\n";
$tgid_cnt++;
}### For each TGID
}### For Each Grp
}### Trunked system process
}### For all systems
}### system records are available
my $tdir = get_directory($radio_def{'sdir'});
$tdir = "$tdir/BCDx36HP/favorites_lists";
if (!-e $tdir) {system "mkdir -p $tdir";}
if (!-e $tdir) {LogIt(3164,"Unable to create output directory $tdir");}
if (scalar @outrecs > 2) {
my $outfile = "$tdir/f_" . sprintf("%06.6u",$hpd) . '.hpd';
if (open OUTFILE, ">$outfile") {
print OUTFILE @outrecs;
close OUTFILE;
LogIt(0,"$Bold$outfile created...");
}
else {Logit(1,"Could not create $outfile");}
}
else {LogIt(1,"No Favorites records were found for this conversion!");}
@outrecs = ("TargetModel\tBCDx36HP\r\n","FormatVersion\t1.00\r\n");
foreach my $rec (@{$radiodb{'flist'}}){
if (!$rec->{'index'}) {next;}
my $filename = $rec->{'filename'};
my $name = $rec->{'service'};
my $monitor = 'Off';
if ($rec->{'monitor'}) {$monitor = 'On';}
my $useloc = 'Off';
if ($rec->{'useloc'}) {$useloc = 'On';}
my $qkey = $rec->{'qkey'};
my $tag = $rec->{'systag'};
if ($tag and looks_like_number($tag)) {$tag = $tag - 1;}
else {$tag = 'Off';}
my $keys_on = $rec->{'keys_on'};
my @keys = split " ",$keys_on;
my %qkeys = ();
foreach my $qk (@keys) {
$qk = Strip($qk);
if (looks_like_number($qk) and $qk < 100) {$qkeys{$qk} = TRUE;}
}
my $outrec = "F-List\t$name\t$filename\t$useloc\t$monitor\t$qkey\t$tag";
foreach my $ndx (0..9) {$outrec = "$outrec\tOff";}
foreach my $ndx (0..99) {
my $value = 'Off';
if ($qkeys{$ndx}) {$value = 'On';}
$outrec = "$outrec\t$value";
}
push @outrecs,"$outrec\r\n";
}
if (scalar @outrecs > 2) {
my $flist = "$tdir/f_list.cfg";
if (open OUTFILE, ">$flist") {
print OUTFILE @outrecs;
close OUTFILE;
LogIt(0,"$Bold$flist created...");
}
else {Logit(1,"Could not create $flist");}
}
else {LogIt(1,"No FLIST records were found for this conversion!");}
exit $GoodCode;
}
elsif ($cmd eq 'sds2csv') {
if (!$fs) {LogIt(1327,"No input file specified!");}
if (!-e $fs) {LogIt(1328,"Input file $fs does not exist!");}
my @inrecs = ();
if (open INFILE,$fs) {
@inrecs = <INFILE>;
close INFILE;
}
else {LogIt(1334,"Could not read $fs");}
if (!scalar @inrecs) {LogIt(1335,"No records were read from $fs");}
my $londelta = ($radius * .0166);
my $latdelta = ($radius * .01923);
%radiodb = ();
my $recno = 0;
my $sysno = 0;
my $siteno = 0;
my $groupno = 0;
my %sysinfo = ();
RECPROC:
foreach my $rec (@inrecs) {
$recno++;
chomp $rec;
if (!$rec) {next;}
my %recdata = ('valid' => TRUE);
my @fields = split "\t",$rec;
my $rectype = lc(shift @fields);
if ($rectype eq 'targetmodel') {next;}
elsif ($rectype eq 'formatversion') {next;}
elsif ($rectype eq 'conventional') {
if ($sysno) {
sds_validate(\%sysinfo,\%radiodb);
}
%sysinfo = ('trunked' => FALSE,
'sites' => { },
'groupcnt' => 0,
'freqcnt' => 0,
);
foreach my $key ('myid','parentid','service','avoid','_rsvd','systemtype',
'qkey','systag','hld','a_agc','d_agc','p25wait',
'p25mode','p25lvl') {
if (scalar @fields) {$recdata{$key} = shift @fields;}
else {$recdata{$key} = '';}
}
if (lc($recdata{'avoid'}) eq 'on') {$recdata{'valid'} = FALSE;}
$recdata{'systemtype'} = 'cnv';
$recdata{'agc_analog'} = FALSE;
if (lc($recdata{'a_agc'}) eq 'on') {$recdata{'agc_analog'} = TRUE;}
$recdata{'agc_digital'} = FALSE;
if (lc($recdata{'d_agc'}) eq 'on') {$recdata{'agc_digital'} = TRUE;}
if (looks_like_number($recdata{'systag'})) {
$recdata{'systag'} = $recdata{'systag'} + 1;
if ($recdata{'systag'} > 100) {$recdata{'systag'} = 100;}
}
else {$recdata{'systag'} = 0;}
$sysno = add_a_record(\%radiodb,'system',\%recdata);
$sysinfo{'sysno'} = $sysno;
$sysinfo{'sysname'} = $recdata{'service'};
}### Conventional record process
elsif ($rectype eq 'trunk') {
if ($sysno) {
sds_validate(\%sysinfo,\%radiodb);
}
%sysinfo = ('trunked' => TRUE,
'sites' => { },
'groupcnt' => 0,
'freqcnt' => 0,
);
$siteno = 0;
foreach my $key ('myid','parentid','service','avoid','_rsvd','systemtype',
'idsrch','emgalt','emglvl','status_bit','p25nac','qkey','systag','hld',
'a_agc','d_agc','end_code','pscan','emgcol','emgpat','tgid_format') {
if (scalar @fields) {$recdata{$key} = shift @fields;}
else {$recdata{$key} = '';}
}
if (lc($recdata{'avoid'}) eq 'on') {$recdata{'valid'} = FALSE;}
$recdata{'agc_analog'} = FALSE;
if (lc($recdata{'a_agc'}) eq 'on') {$recdata{'agc_analog'} = TRUE;}
$recdata{'agc_digital'} = FALSE;
if (lc($recdata{'d_agc'}) eq 'on') {$recdata{'agc_digital'} = TRUE;}
my %sds2rctype = (
'edacs' => 'edw',
'scat'  => 'eds',
'ltr'   => 'ltr',
'motorola' => 'mots',
'p25standard' => 'p25s',
'mototrbo'   => 'trbo',
'dmronefrequency' => 'dmr',
'nxdn'  => 'nxdn',
'nxdnonefrequency' => 'nxdn1',
);
my $systemtype = $sds2rctype{lc($recdata{'systemtype'})};
if (!$systemtype) {LogIt(1199,"No RadioCtl xref for system type $recdata{'systemtype'}");}
$recdata{'systemtype'} = $systemtype;
if (looks_like_number($recdata{'systag'})) {
$recdata{'systag'} = $recdata{'systag'} + 1;
if ($recdata{'systag'} > 100) {$recdata{'systag'} = 100;}
}
else {$recdata{'systag'} = 0;}
alert_sds(\%recdata);
$sysno = add_a_record(\%radiodb,'system',\%recdata);
$sysinfo{'sysno'} = $sysno;
$sysinfo{'sysname'} = $recdata{'service'};
}### Trunk record process
elsif ($rectype eq 'site') {
foreach my $key ('myid','parentid','service','avoid','latitude','longitude',
'range','mode','mot_band_type','edacs_band_type',
'location_type','at','p25wait','p25type','p25lvl','qkey','nac','rf_filter',
) {
if (scalar @fields) {$recdata{$key} = shift @fields;}
else {$recdata{$key} = '';}
}
$recdata{'sysno'} = $sysno;
if (lc($recdata{'avoid'}) eq 'on') {$recdata{'valid'} = FALSE;}
$recdata{'atten'} = FALSE;
$recdata{'sdsatt'} = FALSE;
if (lc($recdata{'at'}) eq 'on') {$recdata{'sdsatt'} = TRUE;}
$recdata{'mode'} = Strip(lc($recdata{'mode'}));
if ($recdata{'mode'} eq 'nfm')    {$recdata{'mode'} =  'FMun';}
elsif ($recdata{'mode'} eq 'fm')  {$recdata{'mode'} =  'FMn';}
elsif ($recdata{'mode'} eq 'fmb') {$recdata{'mode'} =  'FMw';}
elsif ($recdata{'mode'} eq 'wfm') {$recdata{'mode'} =  'FMm';}
elsif ($recdata{'mode'} eq 'auto')  {$recdata{'mode'} = 'auto';}
else {
print Dumper(%recdata),"\n";
print "record=$rec\n";
LogIt(1332,"Bad decode for 'mode' field =>$recdata{'mode'}");
}
my $bt = lc($recdata{'mot_band_type'});
my $ew = lc($recdata{'edacs_band_type'});
if (!$bt) {$bt = '-';}
if (!$ew) {$ew = '-';}
my $systemtype = $radiodb{'system'}[$sysno]{'systemtype'};
if ($systemtype eq 'mots') {
if ($bt eq 'sprinter') {$radiodb{'system'}[$sysno]{'systemtype'} = 'mots';}
elsif ($bt eq 'custom') {$radiodb{'system'}[$sysno]{'systemtype'} = 'motc';}
}
elsif (($systemtype eq 'edw') and ($ew eq 'narrow')) {
$radiodb{'system'}[$sysno]{'systemtype'} = 'edn';
}
my $keep = TRUE;
if ($gps) {
if (!$recdata{'latitude'} or !$recdata{'longitude'} ) {
LogIt(1,"Bad Longitude or Latitude data for site $recdata{'service'}");
}
else {
my $dif1 = abs($recdata{'latitude'} - $lat);
my $dif2 = abs($recdata{'longitude'} - $lon);
if (($dif1 > $latdelta) or ($dif2 > $londelta)) {
$keep = FALSE;
$siteno = 0;
}
}
}### GPS process
if ($keep) {
$siteno = add_a_record(\%radiodb,'site',\%recdata);
$sysinfo{'sites'}{$siteno} = 0;
}
}
elsif ($rectype eq 't-freq') {
if (!$siteno) {next RECPROC;}
foreach my $key ('myid','parentid','_rsvd','avoid','frequency','lcn',
'ccode',
) {
if (scalar @fields) {$recdata{$key} = shift @fields;}
else {$recdata{$key} = '';}
}
if (!$sysno) {
LogIt(1285,"Got a 0 sysno for t-freq record $recno!");
}
if (!$siteno) {
LogIt(1288,"Got a 0 siteno for t-freq record $recno!");
}
$recdata{'siteno'} = $siteno;
$recdata{'flags'} = '';
$recdata{'mode'} = 'FMn';
if (lc($recdata{'avoid'}) eq 'on') {$recdata{'valid'} = FALSE;}
my $freqno = add_a_record(\%radiodb,'tfreq',\%recdata);
$sysinfo{'sites'}{$siteno}++;
}
elsif (($rectype eq 'c-group') or ($rectype eq 't-group')) {
foreach my $key ('myid','parentid','service','avoid','latitude',
'longitude','range','location_type','qkey','rf_filter') {
if (scalar @fields) {$recdata{$key} = shift @fields;}
else {$recdata{$key} = '';}
}
$recdata{'sysno'} = $sysno;
if (lc($recdata{'avoid'}) eq 'on') {$recdata{'valid'} = FALSE;}
my $svccode = 21;
my $service = $recdata{'service'};
if ($service =~ /amateur/i) {$svccode = 13;}
elsif ($service =~ /ems/i) {$svccode = 4;}
elsif ($service =~ /school/i) {$svccode = 32;}
elsif ($service =~ /air/i) {$svccode = 15;}
elsif ($service =~ /911/i) {$svccode = 2;}
elsif ($service =~ /sheriff/i) {$svccode = 23;}
elsif ($service =~ /fire/i) {$svccode = 3;}
$recdata{'svcode'} = $svccode;
if ($gps) {
if (!$recdata{'latitude'} or !$recdata{'longitude'} ) {
LogIt(1,"Bad Longitude or Latitude data for group $recdata{'service'}");
}
else {
my $dif1 = abs($recdata{'latitude'} - $lat);
my $dif2 = abs($recdata{'longitude'} - $lon);
if (($dif1 > $latdelta) or ($dif2 > $londelta)) {
$recdata{'valid'} = FALSE;
}
}
}### GPS process
$groupno = add_a_record(\%radiodb,'group',\%recdata);
if ($recdata{'valid'}) {$sysinfo{'groupcnt'}++;}
}
elsif ($rectype eq 'c-freq') {
foreach my $key ('myid','parentid','service','avoid',
'frequency','mode','audio_opt','svcode','at','dlyrsm',
'voloff','emgalt','emglvl','emgcol','emgpat','bcdtag','pri_chan') {
if (scalar @fields) {$recdata{$key} = shift @fields;}
else {$recdata{$key} = '';}
}
if (lc($recdata{'avoid'}) eq 'on') {$recdata{'valid'} = FALSE;}
$recdata{'sysno'} = $sysno;
$recdata{'groupno'} = $groupno;
$recdata{'atten'} = FALSE;
$recdata{'sdsatt'} = FALSE;
if (lc($recdata{'at'}) eq 'on') {$recdata{'sdsatt'} = TRUE;}
$recdata{'mode'} = Strip(lc($recdata{'mode'}));
if ($recdata{'mode'} eq 'nfm')    {$recdata{'mode'} = 'FMun';}
elsif ($recdata{'mode'} eq 'fm')  {$recdata{'mode'} = 'FMn';}
elsif ($recdata{'mode'} eq 'fmb') {$recdata{'mode'} = 'FMw';}
elsif ($recdata{'mode'} eq 'wfm') {$recdata{'mode'} = 'FMm';}
elsif ($recdata{'mode'} eq 'am')  {$recdata{'mode'} = 'am';}
elsif ($recdata{'mode'} eq 'auto')  {$recdata{'mode'} = 'auto';}
else {
print Dumper(%recdata),"\n";
LogIt(1332,"Bad decode for 'mode' field =>$recdata{'mode'}");
}
alert_sds(\%recdata);
if (looks_like_number($recdata{'bcdtag'})) {
$recdata{'bcdtag'} = $recdata{'bcdtag'} + 1;
if ($recdata{'bcdtag'} > 100) {$recdata{'bcdtag'} = 100;}
}
else {$recdata{'bcdtag'} = 0;}
$recdata{'voloff'} = vol2radctl($recdata{'voloff'});
my $freqno = add_a_record(\%radiodb,'freq',\%recdata);
$sysinfo{'freqcnt'}++;
}
elsif ($rectype eq 'tgid') {
foreach my $key ('myid','parentid','service','avoid','tgid',
'audio_type','service_code','dlyrsm',
'voloff','emgalt','emglvl','emgcol','emgpat',
'bcdtag','pri_chan','tdma_slot',
) {
if (scalar @fields) {$recdata{$key} = shift @fields;}
else {$recdata{$key} = '';}
}
$recdata{'sysno'} = $sysno;
$recdata{'groupno'} = $groupno;
if (lc($recdata{'avoid'}) eq 'on') {$recdata{'valid'} = FALSE;}
$recdata{'tgid_valid'} = TRUE;
$recdata{'frequency'} = 0;
alert_sds(\%recdata);
if (looks_like_number($recdata{'bcdtag'})) {
$recdata{'bcdtag'} = $recdata{'bcdtag'} + 1;
if ($recdata{'bcdtag'} > 100) {$recdata{'bcdtag'} = 100;}
}
else {$recdata{'bcdtag'} = 0;}
$recdata{'voloff'} = vol2radctl($recdata{'voloff'});
$recdata{'adtype'} = 0;
if ($recdata{'audio_type'}) {
if ($recdata{'audio_type'} =~ /analog/i) {$recdata{'adtype'} = 1;}
elsif ($recdata{'audio_type'} =~ /digital/i) {$recdata{'adtype'} = 2;}
}
my $freqno = add_a_record(\%radiodb,'freq',\%recdata);
$sysinfo{'freqcnt'}++;
}
elsif ($rectype eq 'bandplan_mot') {
foreach my $key ('myid','frequency_l1','frequency_u1','spacing_1','offset_1',
'frequency_l2','frequency_u2','spacing_2','offset_2',
'frequency_l3','frequency_u3','spacing_3','offset_3',
'frequency_l4','frequency_u4','spacing_4','offset_4',
'frequency_l5','frequency_u5','spacing_5','offset_5',
'frequency_l6','frequency_u6','spacing_6','offset_6',
) {
if (scalar @fields) {$recdata{$key} = shift @fields;}
else {$recdata{$key} = '';}
}
$recdata{'siteno'} = $siteno;
$recdata{'flags'} = '';
my $bpno = add_a_record(\%radiodb,'bplan',\%recdata);
}
elsif ($rectype eq 'f-list') {
foreach my $key ('myid','parentid','service','avoid',
) {
if (scalar @fields) {$recdata{$key} = shift @fields;}
else {$recdata{$key} = '';}
}
if (lc($recdata{'avoid'}) eq 'on') {$recdata{'valid'} = FALSE;}
}
elsif ($rectype eq 'areacounty') {
}
elsif ($rectype eq 'areastate') {
}
elsif ($rectype eq 'fleetmap') {
LogIt(1,"System $sysno ($radiodb{'system'}[$sysno]{'service'}) needs Fleetmap");
}
elsif ($rectype eq 'rectangle') {
}
else {
LogIt(0,"No processing defined for rectype $Green$rectype");
next;
}
}
if ($sysno) {
sds_validate(\%sysinfo,\%radiodb);
}
if (defined $radiodb{'system'}[1]{'index'}) {
LogIt(0,"All input records processed. Generating output file...");
write_data($user_filename,\%radiodb);
exit $GoodCode;
}
else {LogIt(1,"No input records were processed! No file created.");}
}
elsif ($cmd eq 'rrd2csv') {
if (!$fs) {LogIt(1025,"No filespec for command $cmd given!");}
if (!-e $fs) {LogIt(1026,"Cannot locate $fs for process!");}
$bench{'start_rref'} = time();
my @groups = (
'Fire',
'State_Police',
'Local_Police',
'Police',
'Transportation',### group 5
'Public_Works',
'Business',
'Utilities',
'EMS',
'Other',
);
my $sysno = 1;
my $edacs = FALSE;
my $p25 = FALSE;
my $sysname = '(unknown)';
my $filedate = '?';
my($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,
$atime,$mtime,$ctime,$blksize,$blocks)
= stat($fs);
if ($ctime) {$filedate = Time_Format($ctime);}
open IN,$fs or die "Cannot open $fs";
my @inrecs = <IN>;
close IN;
my $system_info = '';
my $systype = '';
foreach my $rec (@inrecs) {
chomp $rec;
if (!$rec) {next;}
if ($rec =~ /system name\:/i) {
($sysname) =  $rec =~ /system name\:(.*)/i;
$sysname =~ s/\t//g;  
$sysname = Strip(remove_codes($sysname));
}
elsif  ($rec =~ /system type\:/i) {
my $notfound = FALSE;
($system_info) = $rec =~ /system type\:(.*)/i;
$system_info =~ s/\t//g;  
$system_info = Strip(remove_codes($system_info));
if ($system_info =~ /dmr/i) {
$systype = 'TRBO';}
elsif ($system_info =~ /trbo/i) {$systype = 'TRBO';}
elsif ($system_info =~ /edacs/i) {
$systype = 'EDC';
$edacs = TRUE;
}
elsif ($system_info =~ /project 25/i) {
$systype = 'P25S';
$p25 = TRUE;
}
elsif ($system_info =~ /motorola/i) {$systype = 'MOT';}
else {
$notfound = TRUE;
}
if ($notfound) {
if ($stype) {$systype = UC($stype);}
else {$systype = 'CNV';}
LogIt(1,"Could not determine System type from $rec.$Eol Set system to $Green$systype");
}
else {LogIt(0,"Set system to $Green$systype");}
last;
}### System type
}
my ($filename,$path,$ext) = fileparse($fs,qr/\.[^.]*/);
if (!$sysname) {$sysname = $filename;}
my %sysrec = ('service' => $sysname, 'valid'=>TRUE,'systemtype' => $systype);
my $sysndx = add_a_record(\%radiodb,'system',\%sysrec,FALSE);
my %tags = ('system' => $sysname,
'RRDB source file' => "$fs ($filedate)",
'system_type' => $system_info);
add_a_record(\%radiodb,'tag',\%tags,FALSE);
my %groupndx = ();
my %groupcount = ();
my $gqkey = 1;
foreach my $grp (@groups) {
if ($gqkey > 9) {$gqkey = 0;}
my %grouprec = ('valid'=>TRUE,'service'=>$grp,'sysno'=>$sysno);
$groupndx{$grp} = add_a_record(\%radiodb,'group',\%grouprec,FALSE);
$gqkey++;
$groupcount{$groupndx{$grp}} = 0;
}
my $recno = 0;
my $freqno = 0;
my $siteno = 0;
my $channel = 1;
my $talkcount = 0;
my $siteproc = FALSE;
my $talkproc = FALSE;
my $freqproc = FALSE;
my $rfss = FALSE;
my $sysid = FALSE;
my $region = FALSE;
my @tgheader = ();
REC:
while (scalar @inrecs) {
my $rec = shift @inrecs;
$recno++;
chomp $rec;
if (!$rec) {
$siteproc = FALSE;
$talkproc = FALSE;
$freqproc = FALSE;
next REC;
}
$rec = Strip($rec);
if (substr($rec,0,1) eq '*') {next;}
if (substr($rec,0,1) eq '#') {next;}
if ($rec =~ /system name:/i) {next REC;}    
elsif ($rec =~ /^system type:/i) {next REC;}
elsif ($rec =~ /^location:/i) {next REC;}  
elsif ($rec =~ /^county:/i) {next REC;}  
elsif ($rec =~ /^system voice:/i) {next REC;}  
elsif ($rec =~ /^last updated:/i) {next REC;}  
elsif ($rec =~ /^system frequencies/i) {next REC;}  
elsif ($rec =~ /^red/i) {next REC;}  
elsif ($rec =~ /^site/i) { 
$siteproc = TRUE;
next REC;
}
elsif ($rec =~ /^rfss/i) { 
$siteproc = TRUE;
$rfss = TRUE;
next;
}
elsif ($rec =~ /^sysid/i) { 
$siteproc = TRUE;
$sysid = TRUE;
next;
}
elsif ($rec =~ /^region/i) { 
$siteproc = TRUE;
$region = TRUE;
next;
}
elsif ($rec =~ /^dec/i) {
$talkproc = TRUE;
@tgheader = split /\t/,$rec;
next;
}
elsif ($rec =~ /^frequency/i) {
$freqproc = TRUE;
next;
}
elsif ($siteproc) {
my @words = split /\t/,$rec;
my $first = '';
if ($sysid) {$first = shift @words;}
elsif ($rfss) {$first = shift @words;}
elsif ($region) {$first = shift @words;}
if (!$words[0]) {
$siteproc = FALSE;
next REC;
}
if ($words[0] =~ /\(\d*/ ) {### looking for '(n'
my $siteinfo = shift @words;
my ($dec) = $siteinfo =~ /(\d*) \(/;
if (!$dec) {$dec = '';}
my $service = Strip(shift @words) . " ($dec)";
my $valid = TRUE;
if ($sysname =~ /onevoice/i) {
$service = "1V $service";
$valid = FALSE;
if ($service =~ /beacon/i) {$valid = TRUE;}
elsif ($service =~ /highland/i) {$valid = TRUE;}
elsif ($service =~ /schunn/i) {$valid = TRUE;}  
}
my $county = shift @words;
my $qkey = 1;
if ($hotkey >= 0) {$qkey = $hotkey;}
my %siterec = ('valid' => $valid,'sysno'=>$sysno,'service' =>$service,'qkey' =>$qkey, 'site_number'=> $dec);
$siteno = add_a_record(\%radiodb,'site',\%siterec,FALSE);
}
while (scalar @words) {
my %freqrec = ('valid' => TRUE,'siteno' => $siteno,'sysno'=>$sysno,'lcn' => 0,'mode'=>'FMn', 'ccode' => 'Srch' );
my ($lcn,$freq) = split " ",Strip(shift @words);
my $freqsave = $freq;
my $lcnsave = $lcn;
if ($lcn =~ /\./) {    
$freq = $lcn;
$lcn = '';
}
if ($lcn) {$freqrec{'lcn'} = $lcn;}
$freq =~ s/c$//;
$freq =~ s/a$//;
if ($freq) {$freq = lc(Strip($freq));}
else {$freq = 0;}
if ($freq eq 'n/a') {$freq = 0;}
if ($freq == 0) {LogIt(1,"Record $recno has a 0 frequency!");}
$freqrec{'frequency'} = $freq;
my $freqndx = add_a_record(\%radiodb,"tfreq",\%freqrec,FALSE);
}
}### SITE state process
elsif ($talkproc) {
my @words = split /\t/,$rec;
my $tgid = shift @words;
my $hdr = lc(Strip($tgheader[1]));
if ($hdr eq 'hex') {shift @words;}
elsif ($hdr eq 'afs') {$tgid = shift @words;}
my $mode = shift @words;
my $alpha = shift @words;
my $descript = shift @words;
my $tag = shift @words;
my $grp = shift @words;
if (!$descript) {next;}
if (!$tag) {$tag = '';}
if (!$grp) {$grp = '';}
if (!$mode) {$mode = '';}
my $grpkey = set_group("$tag $descript");
my $grpno = $groupndx{$grpkey};
if (!$grpno) {$grpno = 0;}
$groupcount{$grpno}++;
my %freqrec = ('valid' => TRUE,
'channel' => 0,
'siteno' => 0,
'sysno' => $sysno,
'frequency' => 0,
'mode' => '',
'tgid' => Strip($tgid),
'service' => Strip($alpha),
'groupno' => $grpno,
'svcode' => 0,
);
if ($mode =~ /E/) {$freqrec{'valid'} = FALSE;}   
my $freqno = add_a_record(\%radiodb,'freq',\%freqrec,FALSE);
$talkcount++;
}### Talkgroup process
elsif ($freqproc) {
my @words = split /\t/,$rec;
my $freq = shift @words;
if ($freq !~ /\./ ) {
LogIt(1,"line $recno first field is NOT a frequency. Cannot process");
next REC;
}
my $call = shift @words;
my $type = shift @words;
my $tone = shift @words;
my $service = shift @words;
if (!$service) {
LogIt(1,"line $recno Service is missing. Not processed.");
next REC;
}
my $description = shift @words;
my $mode = shift @words;
if ($mode =~ /fm/i) {$mode = 'FMn';}
my $tag = shift @words;
my $grpno = 0;
if ($tag) {
my $grpkey = set_group("$tag");
$grpno = $groupndx{$grpkey};
}
if (!$grpno) {$grpno = 0;}
my %freqrec = ('valid' => TRUE,
'channel' => $channel,
'siteno' => 0,
'sysno' => $sysno,
'tgid' => '',
'service' => Strip($service),
'mode' => Strip($mode),
'frequency' => $freq,
'groupno' => $grpno,
);
if ($tone) {
if ($tone =~ /dpl/i) {
$tone =~ s/dpl//i;
$freqrec{'tone'} = Strip($tone);
$freqrec{'tone_type'} = 'DCS';
}
elsif ($tone =~ /pl/i) {
$tone =~ s/pl//i;
$freqrec{'tone'} = Strip($tone);
$freqrec{'tone_type'} = 'CTCSS';
}
}
my $freqno = add_a_record(\%radiodb,'freq',\%freqrec,FALSE);
$channel ++;
}### frequency process
else {
}
}### process all records
if (defined $radiodb{'system'}[1]{'index'}) {
LogIt(0,"All input records processed. Generating output file $output");
write_data($user_filename,\%radiodb);
}
else {LogIt(1,"No input records were processed! No file created.");}
$bench{'end_rref'}  = time();
BenchMark(\%bench);
exit $GoodCode;
}### RRD2CSV command
elsif ($cmd eq 'readsys') {
if (!$fs) {LogIt(3898,"READSYS:No radio for command $cmd given!");}
$bench{'start_read'} = time();
my $radioname = $fs;
my $radiosel = lc($radioname);
select_radio($radiosel);
my $protocol = $radio_def{'protocol'};
my $routine = $radio_routine{$protocol};
if (!$routine) {LogIt(4155,"READSYS:Radio routine not set for protocol $protocol");}
$parmref{'out'} = \%out;
$parmref{'in'} = \%in;
%in = ('noport' => FALSE, 'nobaud' => FALSE);
if ($altport) {
$radio_def{'port'} = $altport;
$in{'noport'} = TRUE;
}
if (&$routine('autobaud',\%parmref) ) {
LogIt(4160,"READSYS:Failed to determine baud/port for radio: $radioname ");
}
LogIt(0,"$Bold Radio $Yellow$radiosel$White is on port " .
"$Magenta$radio_def{'port'}$White with baud $Green$radio_def{'baudrate'}");
$parmref{'portobj'} = open_serial();
$parmref{'database'} = \%radiodb;
%in = ('count'     => $count,
'firstnum'    => $firstnum,
'skip'      => $skip,
'nocomment' => $nocomment,
'notrunk'   => $notrunk,
);
%radiodb = ();
if (&$routine('init',\%parmref) ) {
LogIt(3937,"READSYS:Failed to initialize radio: $radiosel ($protocol)");
}
if (!$nosys)  {
my $rc = &$routine('getmem',\%parmref);
if ($rc) {
LogIt(1,"READSYS l3881:$Bold GETMEM routine from radio returned code $rc");
}
}
if ($globals) {
my $rc = &$routine('getglob',\%parmref);
if ($rc) {
LogIt(1,"READSYS l3888:$Bold GETGLOB routine from radio returned code $rc");
}
}
if ($search) {
my $rc = &$routine('getsrch',\%parmref);
if ($rc) {
LogIt(0,"READSYS l3894:$Bold GETSRCH routine from radio returned code $rc");
}
}
my %tagrec = ('system' => "All memory data from $radiosel");
add_a_record(\%radiodb,"tag",\%tagrec,FALSE);
my $found = FALSE;
foreach my $rectype (keys %radiodb) {
if (defined $radiodb{$rectype}[1]{'index'}) {
$found = TRUE;
last;
}
}
if ($found) {
LogIt(0,"All input records processed. Generating output file $user_filename");
write_data($user_filename,\%radiodb);
}
else {LogIt(1,"No data was processed from radio! No file created.");}
$bench{'end_read'}  = time();
BenchMark(\%bench);
exit $GoodCode;
}
elsif ($cmd eq 'showall') {
my $protocol = $radio_def{'protocol'};
if ($protocol ne 'uniden') {LogIt(487,"SHOWALL is NOT valid for protocol $protocol!");}
$parmref{'portobj'} = open_serial();
$parmref{'database'} = \%radiodb;
$parmref{'out'} = \%out;
$parmref{'in'} = \%in;
%radiodb = ();
if (uniden_cmd('_getall',\%parmref)) {LogIt(492,"Could not get systems!");}
shift @{$radiodb{'system'}};
if (scalar @{$radiodb{'system'}}) {
LogIt(0,"\n\n");
foreach my $rcd (@{$radiodb{'system'}}) {
my $name = $rcd->{'service'};
my $addr = sprintf("%6.6u",$rcd->{'block_addr'});
my $type = sprintf("%-7.7s",$rcd->{'systemtype'});
my $qkey = sprintf("%3.3s",$rcd->{'qkey'});
my $sysno = sprintf("%3u",$rcd->{'index'});
LogIt(0,"$Bold System:$Green$sysno"  .
"$White type:$Yellow$type$White" .
" addr:$Blue$addr$White  key:$Magenta$qkey$White  name:$Red$name");
}
LogIt(0,"\n");
}
else {LogIt(1,"No systems found in connected radio!");}
exit 0;
}
elsif ($cmd eq 'writesys') {
if (!$fs) {LogIt(4360,"No radio for command $cmd given!");}
$bench{'start_write'} = time();
my $radioname = $fs;
my $radiosel = lc($radioname);
select_radio($radiosel);
my $protocol = $radio_def{'protocol'};
my $routine = $radio_routine{$protocol};
if (!$routine) {LogIt(4370,"WRITESYS:Radio routine not set for protocol $protocol");}
$fs = shift @ARGV;
if (!$fs) {LogIt(3752,"Need to specify at least one input file!");}
my @filelist = ();
get_files(\@filelist);
my $filecount = scalar @filelist;
if ($filecount) {LogIt(0,"found $filecount  files to store into radio");}
else {LogIt(3757,"No files specified or found to store into radio!");}
$parmref{'out'} = \%out;
$parmref{'in'} = \%in;
%in = ('noport' => FALSE, 'nobaud' => FALSE);
if ($altport) {
$radio_def{'port'} = $altport;
$in{'noport'} = TRUE;
}
if (&$routine('autobaud',\%parmref) ) {
LogIt(4160,"READSYS:Failed to determine baud/port for radio: $radioname ");
}
LogIt(0,"$Bold Radio $Yellow$radiosel$White is on port " .
"$Magenta$radio_def{'port'}$White with baud $Green$radio_def{'baudrate'}");
$parmref{'portobj'} = open_serial();
$parmref{'database'} = \%radiodb;
if (&$routine('init',\%parmref)) {
LogIt(4045,"WRITESYS:Cannot initialize the selected radio=>$radiosel");
}
%radiodb = ();
foreach my $fs (@filelist) {
read_radioctl(\%radiodb,$fs);
}
if ($firstnum == -1) {$firstnum  = $radio_def{'origin'};}
%in = (
'count' => $count,
'erase' => $erase,
'firstnum' => $firstnum,
'nodie' => $nodie,
'renum' => $renum,
'noigrp' => $noigrp,
'origin' => $origin,
);
if (!$radiodb{'system'}[1]{'index'}) {$nosys = TRUE;}
my $rc = 0;
if (!$testing) {
if (!$nosys) {
$rc = &$routine('setmem',\%parmref);
if ($rc) {
LogIt(1,"WRITESYS l4077:$Bold SETMEM routine from radio returned code $rc");
}
}
if ($globals  and (!$rc)) {
$rc =  &$routine('setglob',\%parmref);
if ($rc) {
LogIt(1,"WRITESYS l4083:$Bold SETGLOB routine from radio returned code $rc");
}
}
if ($search and (!$rc)) {
my $rc =  &$routine('setsrch',\%parmref);
if ($rc) {
LogIt(1,"WRITESYS l4089:$Bold SETSRCH routine from radio returned code $rc");
}
}
}
$bench{'end_write'}  = time();
BenchMark(\%bench);
exit $rc;
}
elsif ($cmd eq 'decrypt') {
my $radioselect = 'ICR30';
select_radio($radioselect);
$parmref{'portobj'} = open_serial();
if (!$parmref{'portobj'}) {LogIt(1484,"Could not open serial port");}
$parmref{'out'} = \%out;
$parmref{'in'} = \%in;
icom_cmd('init',\%parmref);
my $code = 0;
my $count = 0;
while (TRUE) {
icom_cmd('getsig',\%parmref);
if ($out{'signal'}) {
my $signal = $out{'signal'};
my $raw = $out{'raw'};
my $sql = $out{'sql'};
my $time = time();
$parmref{'write'} = FALSE;
icom_cmd('_nxdn_ran',\%parmref);
my $timestamp = Time_Format($time);
my $nxdnran = $out{'nxdnran'};
icom_cmd('_get_nxdn_rx_id',\%parmref);
my $nxdnrxid =  $out{'nxdnrxid'};
icom_cmd('_get_nxdn_rx_status',\%parmref);
my $nxdnrxstatus =  $out{'nxdnrxstatus'};
if ($nxdnrxstatus eq '00') {next;}
$count = $count + 1;
$code++;
if ($code > 32000) {$code = 1;}
$parmref{'write'} = TRUE;
$in{'nxdnkey'} = $code;
icom_cmd('_nxdn_crypt_key',\%parmref);
LogIt(0,"$timestamp count=$count key=$code status=$nxdnrxstatus nxdnran=$nxdnran nxdnrxid=$nxdnrxid signal=$signal raw=$raw");
while ($signal & ($nxdnrxstatus ne '00')) {
icom_cmd('_get_nxdn_rx_status',\%parmref);
my $newstatus =  $out{'nxdnrxstatus'};
icom_cmd('getsig',\%parmref);
$signal = $out{'signal'};
$raw = $out{'raw'};
if ($signal and ($newstatus ne '00') and ($nxdnrxstatus ne $newstatus))  {
LogIt(0,"    NXDN status changed=>$newstatus ");
}
usleep 20000;
}
my $offtime = time();
$timestamp = Time_Format($time);
my $duration = int($offtime - $time);
LogIt(0,"   Signal off at $timestamp ($duration seconds) nxdnrxstatus=$nxdnrxstatus");
}
}
}### DECRYPT command
elsif ($cmd eq 'find') {
my @ports = glob("/dev/tty*");
foreach my $port (@ports) {
print "looking at port $port\n";
}
exit;
}
elsif ($cmd eq 'testgen') {
my $grpcount = 10;
my $frqcount = 1;
my @outrecs = ("*RadioCtl \n","** Data for testing memory limits\n");
my $frqno = 1;
my $sitecnt = 1;
my $tfreqcnt = 1000;
push @outrecs,"SYSTEM   ,    1,Test System                   ,    1,P25s  ,         ,     0,  99,  0,    ,    ,    ,    400,   Auto\n";
foreach my $site (1..$sitecnt) {
push @outrecs,"SITE ,$site,Site $site,1,1,99\n";
foreach my $tfrq (1..$tfreqcnt) {
push @outrecs,"TFREQ,$tfrq,1,$site,850.312500,$tfrq,FMn\n";
}
}
foreach my $grp (1..$grpcount) {
push @outrecs,"GROUP    ,   $grp,Group $grp                    ,    1,    1,         ,  20,    ,   uniden,   01,     20,Off\n";
foreach my $frq (1..$frqcount) {
push @outrecs,"FREQ     ,   $frqno,Freq $frq for grp $grp        ,    1,    $grp,         ,   1, 150.000000,FMn   ,\n";
$frqno++;
}
}
my $outfile = "/tmp/radioctl/test.csv";
if (open OUTFILE,">$outfile") {
print OUTFILE @outrecs;
close OUTFILE;
LogIt(0,"$Bold$Yellow$outfile created");
}
else {LogIt(1,"Could not create $outfile");}
}
elsif ($cmd eq 'test') {
my @array = ("23",
"00","50","47","62","01",
"41","42","43","44","45",
"00","10","00",
"09","75",
"03","01",
);
print "decode of BITS for '23'=>",packet_decode(\@array,'bits',1),"\n";
print "decode of FREQUENCY for '162475000' =>",packet_decode(\@array,'frequency',5),"\n";
print "decode of ASCII for '4143434445' =>",packet_decode(\@array,'ascii',5),"\n";
print "decode of TONE for '001000' =>",packet_decode(\@array,'tone',3),"\n";
print "decode of TONE for '0974'   =>",packet_decode(\@array,'tone',2),"\n";
print "decode of MODE for '0301' =>",packet_decode(\@array,'mode'),"\n";
exit;
foreach my $radio ('R7000','IC703','IC705','R8600','ICR30','ICNEW') {
print "\n## $radio\n";
foreach my $code (0..9) {
foreach my $filter ('','00','01','02','03') {
my $bytes = sprintf("%02u",$code) . $filter;
my ($rcmode,$filter) = icom2rcmode($bytes,$radio);
print "bytes=> $bytes  mode=>$rcmode  filter=>$filter\n";
}
}
}
exit;
foreach my $radio ('R7000','IC703','IC705','R8600','ICR30','ICNEW') {
print "\n## $radio\n";
foreach my $rcmode (@modestring) {
my ($modecode,$sdscode) =  rcmode2icom($rcmode,$radio);
print " ",sprintf("%-7s",$rcmode),': ',"$modecode  ($sdscode) \n";
}
}
exit;
my $radioname = 'BCD325P2';
$radioname = 'SDS200';
$radioname = 'ic705';
select_radio($radioname);
my $protocol = $radio_def{'protocol'};
my $routine = $radio_routine{$protocol};
if (!$routine) {LogIt(4370,"WRITESYS:Radio routine not set for protocol $protocol");}
$parmref{'out'} = \%out;
$parmref{'in'} = \%in;
%in = ('noport' => FALSE, 'nobaud' => FALSE);
if ($altport) {
$radio_def{'port'} = $altport;
$in{'noport'} = TRUE;
}
if (&$routine('autobaud',\%parmref) ) {
LogIt(4160,"READSYS:Failed to determine baud/port for radio: $radioname ");
}
LogIt(0,"$Bold Radio $Yellow$radioname$White is on port " .
"$Magenta$radio_def{'port'}$White with baud $Green$radio_def{'baudrate'}");
$parmref{'portobj'} = open_serial();
$parmref{'database'} = \%radiodb;
if (&$routine('init',\%parmref)) {
LogIt(4045,"WRITESYS:Cannot initialize the selected radio=>$radioname");
}
print STDERR "\n";
while (TRUE) {
&$routine('_get_signal',\%parmref);
print "\r raw=>",sprintf("%8.8u",$out{'raw'})," signal:$out{'signal'}   ";
}
exit;
$out{'state'} = '';
while (TRUE) {
&$routine('STS',\%parmref);
print STDERR "\r ";
print STDERR "sigmeter=>",sprintf("%8.8u",$out{'sigmeter'});
print STDERR "  Signal=>$out{'signal'} ";
print STDERR "  STATE=>$out{'state'}       ";
print STDERR hexdply($out{'lchar1'})," ";
print STDERR "   ";
}
exit;
my $radioselect = 'ICR30';
select_radio($radioselect);
$radio_def{'port'} = '/dev/ttyACM0';
$parmref{'portobj'} = open_serial();
icom_cmd('init',\%parmref);
print Dumper(%out),"\n";
exit;
$radioselect = 'bcd325p2';
select_radio($radioselect);
$radio_def{'port'} = '/dev/ttyACM0';
$parmref{'portobj'} = open_serial();
$parmref{'database'} = \%radiodb;
uniden_cmd('init',\%parmref);
uniden_cmd('_getall',\%parmref);
print Dumper($radiodb{'system'}[2]),"\n";
exit;
select_radio($radioselect);
$radio_def{'port'} = '/dev/ttyACM0';
$parmref{'portobj'} = open_serial();
$parmref{'database'} = \%radiodb;
$parmref{'test'} = TRUE;
my @msg = ();
$parmref{'unsolicited'} = \@msg;
my %sendparms = (
'portobj' => $parmref{'portobj'},
'term' => "\r",
'delay' => 0,
'resend' => 0,
'debug' => 0,
);
my $alpha = ' abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
my %bypass = ('M','MDL' );
my @combos = ();
my $a = '';
my $b = '';
my $c = '';
foreach my $first (split '',$alpha) {
$a = $first;
if ($first eq ' ') {$a = '';}
foreach my $second (split '',$alpha) {
$b = $second;
if ($second eq ' ') {$b = '';}
foreach my $third (split '',$alpha) {
$c = $third;
if ($third eq '') {$c = '';};
my $cmd = "$a$b$c";
if (length($cmd) < 1) {next;}
push @combos,$cmd;
}
}
}
print "Number of combos=>",scalar @combos,"\n";
my $first = 2900;
foreach my $ndx ($first..$#combos) {
$sendparms{'rcv'} = '';
my $cmd = Strip($combos[$ndx]);
if (length($cmd) < 2) {next;}
if ($bypass{$cmd}) {next;}
if (substr($cmd,0,1) eq 'd') {next;}
if (substr($cmd,0,1) eq 'h') {next;}
if (substr($cmd,0,1) eq 'l') {next;}
if (substr($cmd,0,1) eq 'm') {next;}
if (substr($cmd,0,1) eq 'o') {next;}
if (substr($cmd,0,1) eq 'q') {next;}
if (substr($cmd,0,1) eq 'r') {next;}
if (substr($cmd,0,1) eq 'w') {next;}
if (substr($cmd,0,1) eq 'z') {next;}
if (substr($cmd,0,1) eq 'M') {next;}
my $rc = radio_send(\%sendparms,$cmd);
my $rcv = $sendparms{'rcv'};
my $outstr = Time_Format(time) .":$ndx =>$ndx  cmd=>$cmd  rcv=>$rcv<= (" . hexdply($rcv) . ") rc=>$rc\n";
print $outstr;
if (open OUTFILE, ">>/tmp/testcmd.txt") {
print OUTFILE $outstr;
close OUTFILE;
}
}
exit;
Get_SDS_Status(\%parmref);
print Dumper(%out),"\n";
exit;
$radio_def{'port'} = '/dev/ttyACM0';
$parmref{'portobj'} = open_serial();
$parmref{'database'} = \%radiodb;
uniden_cmd('init',\%parmref);
uniden_cmd('getmem',\%parmref);
exit (write_radioctl(\%radiodb,"/tmp/testing.csv",'mhz','puniden'));
exit;
}#### Test code section
elsif ($cmd eq 'validate') {
LogIt(1759,"VALIDATE is not functional");
if (!$fs) {LogIt(239,"No filespec for command $cmd given!");}
my @filelist = ();
get_files(\@filelist);
my $filecount = scalar @filelist;
if ($filecount) {LogIt(0,"found $filecount  files to validate");}
else {LogIt(662,"No files found to validate!");}
%new = ();
my @warn = ();
my @dumps = ();
foreach my $fs (@filelist) {
LogIt(0,"Validating file $fs...");
read_radioctl(\%new,$fs);
my @systems = sort {$a <=> $b} keys %new;
my $syscount = scalar @systems;
LogIt(0,"  file contains $syscount systems");
foreach my $sysno (@systems) {
LogIt(0,"validating system $sysno..");
my $trunked = TRUE;
my $systype = $new{$sysno}{'system'}{$sysno}{'systemtype'};
my $recno = $new{$sysno}{'system'}{$sysno}{'recno'};
if (!$systype) {
push @warn,"missing SYSTYPE key for system=$sysno record=$recno. Set to 'CNV'";
$systype = 'cnv';
}
if (lc($systype) eq 'cnv') {$trunked = FALSE;}
my @sites =  keys %{$new{$sysno}{'site'}};
my @freqs = keys %{$new{$sysno}{'freq'}};
my @gids = keys %{$new{$sysno}{'gid'}};
my @groups = keys %{$new{$sysno}{'group'}};
my $sitecount = scalar @sites;
my $freqcount = scalar @freqs;
my $gidcount = scalar @gids;
my $groupcount = scalar @groups;
my %frequencies = ();
if ($trunked) {
LogIt(0,"   System $sysno is a TRUNKED $systype system");
LogIt(0,"     Containing $sitecount Sites and $gidcount GIDs");
}
else {LogIt(0,"   System $sysno is a CONVENTIONAL system");}
LogIt(0,"     There are $groupcount groups and $freqcount frequencies defined");
if ($sitecount)  {
}
if ($gidcount)  {
}
if ($freqcount)   {
foreach my $rcd (@freqs) {
my $flags = $new{$sysno}{'freq'}{$rcd}{'freq_flag'};
my $tone  = $new{$sysno}{'freq'}{$rcd}{'tone'};
my $dcs   =  $new{$sysno}{'freq'}{$rcd}{'dcs'};
my $freq  = $new{$sysno}{'freq'}{$rcd}{'frequency'};
my $recno  = $new{$sysno}{'freq'}{$rcd}{'recno'};
my $refno = $new{$sysno}{'freq'}{$rcd}{'refno'};
if (!$flags) {$flags = '';}
if (!$tone)  {$tone = '';}
if (!$dcs)   {$dcs = '';}
if (!$refno) {$refno = 0;}
if (!$freq)  {
if ($flags) {push @warn,"non-blank flags with 0 frequency in record $recno";}
next;
}
if ($flags =~ /t/i) {
if (lc($flags) ne 't') {
push @warn,"multiple flags=>$flags in a trunked freq in record $recno";
}
if ($tone) {push @warn,"'tone' value set in a trunked freq in record $recno";}
if ($dcs) {push @warn,"'dcs' value set in a trunked freq in record $recno";}
if (!$trunked) {push @warn,"Trunked frequency in a conventional system in record $recno";}
elsif (!$refno or (! defined $new{$sysno}{'site'}{$refno}{'siteno'})) {
push @warn,"REFNO for Trunked freq does not reference a valid site in record $recno";
}
}### trunked frequency process
else {
if ($tone) {### tone entered
if ($flags =~ /d/i) {push @warn,"DCS flag set with TONE frequency in record $recno";}
}
else {## no tone entered
if ($flags =~ /c/i) {push @warn,"CTCSS flag set with NO tone frequency in record $recno";}
}
if ($dcs) {### tone entered
if ($flags =~ /c/i) {push @warn,"CTCSS flag set with DCS frequency in record $recno";}
}
else {## no tone entered
if ($flags =~ /d/i) {push @warn,"DCS flag set with NO DCS frequency in record $recno";}
}
if ($flags =~ /s/i) {
if (!$refno or (! defined $new{$sysno}{'freq'}{$refno}{'frequency'})) {
push @warn,"REFNO for split record does not reference a valid record in record $recno";
}
if ($refno == $recno) {
push @warn,"REFNO for split record is self-referencing in record $recno";
}
}
else {
if (!$refno or (! defined $new{$sysno}{'group'}{$refno}{'recno'})) {
push @warn,"REFNO ($refno) does not reference a valid group in record $recno";
}
if ($frequencies{$freq}) {### is this frequency already defined
if ($dupcheck) {
push @warn,"Duplicate frequency $freq in $recno. with  $frequencies{$freq}";
}
$frequencies{$freq} = $frequencies{$freq} . ",rec=$recno";
}
else {$frequencies{$freq} = "rec=$recno";}
}
}### Non-Trunked frequency process
}### For each Freq record
}### Freq record checking
if ($groupcount) {
}
}### for each System in the fs
}### for each FS
if (scalar @warn) {
foreach my $msg (@warn) {
LogIt(1,$msg);
}
}
else {LogIt(0,"$Eol$Bold No inconsistancies found in any file$Eol");}
my $tfile = '/tmp/radiowrite_validate.csv';
if (write_radioctl(\%new,$tfile)) {
}
else {LogIt(0,"$Bold Created $Yellow$tfile$White for validation");}
}
elsif ($cmd eq 'clearall') {
LogIt(1959,"CLEARALL is not functional");
LogIt(1,"This will erase ALL programming and setting in the radio");
Get_Answer("Are you sure you wish to do this?");
open_serial();
LogIt(0,"$Eol$Bold Clearing all programming. Please wait!");
if( bcd396_cmd("PRG") ) {
LogIt(239,"Could not set radio into PRG mode!");
}
bcd396_cmd('CLR');
bcd396_cmd('EPG');
LogIt(0,"$Eol$Bold All programming is now erased!");
}
else {LogIt(627,"Unknown command $cmd!");}
exit;
sub sds_alert {
my $rec = shift @_;
my $atone = 'Off';
my $alevel = 'Auto';
my $acolor = 'Off';
my $apattern = "";
if  ($rec->{'emgalt'} and looks_like_number($rec->{'emgalt'})) {
$atone = $rec->{'emgalt'};
if ($atone > 8) {$atone = 8;}
if ($rec->{'emglvl'} and looks_like_number($rec->{'emglvl'})) {
$alevel = $rec->{'emglvl'};
}
if ($rec->{'emgpat'} and looks_like_number($rec->{'emgpat'})) {
if ($rec ->{'emgpat'} == 1) {$apattern = 'Slow Blink';}
else {$apattern = 'Fast Blink';}
}
if ($rec->{'emgcol'} and looks_like_number($rec->{'emgcol'})) {
$acolor = @xlate_color[$rec->{'emgcol'}];
if ($acolor) {$acolor = ucfirst($acolor);}
else {
LogIt(1,"RadioWrite l3041: Failed translation of $rec->{'emgcol'}");
$acolor = 'Off';
}
}
else { $acolor = 'Red';}
}### Alert is turned on
return ($atone,$alevel,$acolor,$apattern);
}
sub alert_sds {
my $inrec = shift @_;
my %outdata = ();
foreach my $key ('emgalt','emglvl','emgpat','emgcol') {
$outdata{$key} = 0;
if ($key eq 'emgalt') {
if (looks_like_number($inrec->{$key})) {$outdata{$key} = $inrec->{$key};}
}
elsif ($key eq 'emglvl') {
if (looks_like_number($inrec->{$key})) {$outdata{$key} = $inrec->{$key};}
}
elsif ($key eq 'emgpat') {
if ($inrec->{$key} =~ /slow/i) {$outdata{$key} = 1;}
elsif ($inrec->{$key} =~ /fast/i) {$outdata{$key} = 2;}
}
elsif ($key eq 'emgcol') {
$outdata{$key} = $color_xlate{$inrec->{$key}};
if (!$outdata{$key}) {$outdata{$key} = 0;}
}
}
if (!$outdata{'emgalt'}) {
$outdata{'emglvl'} = 0;
$outdata{'emgpat'} = 0;
$outdata{'emgcol'} = 0;
}
foreach my $key (keys %outdata) {$inrec->{$key} = $outdata{$key};}
return 0;
}
sub sds_validate {
my $sysinfo = shift @_;
my $db = shift @_;
my $sysno = $sysinfo->{'sysno'};
if (!$sysno) {LogIt(4683,"SDS_VALIDATE: No system number for $sysinfo!")}
if ($sysinfo->{'trunked'}) {
my @sites = keys %{$sysinfo->{'sites'}};
if (!scalar @sites) {
if ($gps) {
LogIt(0,"Not keeping system $db->{'system'}[$sysno]{'service'}. Out of range...");### debug
$db->{'system'}[$sysno]{'index'} = 0;}
else {
LogIt(1,"No sites defined for system $sysno ($db->{'system'}[$sysno]{'service'})");
$db->{'system'}[$sysno]{'valid'} = FALSE;
}
}
else {
foreach my $siteno (@sites) {
if (!$sysinfo->{'sites'}{$siteno}) {
LogIt(1,"No Frequencies defined for site $siteno ($db->{'site'}[$siteno]{'service'})");
}
}
}
}### Trunked system
else {
if (!$sysinfo->{'groupcnt'}) {
if ($gps) {
LogIt(0,"Not keeping system $db->{'system'}[$sysno]{'service'}. Out of range...");### debug
$db->{'system'}[$sysno]{'index'} = 0;
}
else {
LogIt(1,"No valid groups defined for system $sysno ($db->{'system'}[$sysno]{'service'})");
$db->{'system'}[$sysno]{'valid'} = FALSE;
}
}
}#### Conventional system
return 0;
}
sub icr30_cmd {
my $instr = substr($in{'test'},8);
$in{'test'} = lc($in{'test'});
if (       $in{'test'}       eq 'fefe9c0008')   {goto BYPASS;}
if (substr($in{'test'},0,10) eq 'fefe9c0011')   {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c0007d0') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c0007d1') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c000f11') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c000f12') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c0008a0') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001401') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001402') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001403') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001622') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001643') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001659') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001800') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001a00') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001a01') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001a02') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001a03') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001a04') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001a06') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001a07') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001a08') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001a09') {goto BYPASS;}
if (substr($in{'test'},0,14) eq 'fefe9c001a0a00') {goto BYPASS;}
if (substr($in{'test'},0,14) eq 'fefe9c001a0a01') {goto BYPASS;}
if (substr($in{'test'},0,14) eq 'fefe9c001a0a02') {goto BYPASS;}
if (substr($in{'test'},0,14) eq 'fefe9c001a0a03') {goto BYPASS;}
if (substr($in{'test'},0,14) eq 'fefe9c001a0a04') {goto BYPASS;}
if (substr($in{'test'},0,14) eq 'fefe9c001a0b00') {goto BYPASS;}
if (substr($in{'test'},0,14) eq 'fefe9c001a0b01') {goto BYPASS;}
if (substr($in{'test'},0,14) eq 'fefe9c001a0b02') {goto BYPASS;}
if (substr($in{'test'},0,14) eq 'fefe9c001a1000') {goto BYPASS;}
if (substr($in{'test'},0,14) eq 'fefe9c001a1001') {goto BYPASS;}
if (substr($in{'test'},0,14) eq 'fefe9c001a1002') {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001b07')   {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001b08')   {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001b09')   {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001b0a')   {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001b0b')   {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001b0c')   {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001b0d')   {goto BYPASS;}
if (substr($in{'test'},0,12) eq 'fefe9c001b0e')   {goto BYPASS;}
if (substr($in{'test'},0,10) eq 'fefe9c0020')   {goto BYPASS;}
icom_cmd('test',\%parmref);
my $rsp = '';
my $code = '';
my $outstr = '(none)';
my $stdpl =  'VFO';
if ($in{'state'}) {$stdpl = 'Memory';}
if ($out{'test'}) {
if (length($out{'test'}) > 8) {
$outstr = substr($out{'test'},8);
$code = substr($outstr,0,2);
if (lc($code) eq 'fa') {$rsp = '(bad)';}
}
}
if (!$rsp) {
print "   $instr => $outstr   $stdpl\n";
}
return 0;
BYPASS:
return 1;
}
sub get_files {
my $array = shift @_;
my @filespecs = ($fs);
while (scalar @ARGV)  {push @filespecs,shift @ARGV};
my $errors = 0;
foreach my $fs (@filespecs) {
if (!-e $fs) {
LogIt(1,"GET_FILES l3740:Cannot locate $fs to process!");
$errors++;
next;
}
LogIt(0,"Checking file $fs");
open IN,$fs or LogIt(639,"Cannot open $fs!");
my @records = <IN>;
close IN;
my $ver = $records[0];
if (!$ver) {$ver = '**';}
if (($ver =~ /^\*radioctl/i) or ($ver =~ /^\*3/) ) {
push @{$array},$fs;
}
else {
LogIt(0,"$fs was NOT a radioctl type file. It will be treated as a list of files");
my $recno = 0;
foreach my $rcd (@records) {
$recno++;
chomp $rcd;
if (!$rcd) {next;}
$rcd = Strip($rcd);
if (substr($rcd,0,1) eq '*') {next;}
if (substr($rcd,0,1) eq '#') {next;}
if (!-e $rcd) {
LogIt(1,"Cannot locate file $rcd in record $recno of $fs");
$errors++
}
else {push @{$array},$rcd;}
}
}
}### For all the files specified on the command line
if ($errors) {LogIt(806,"$errors missing files in input file. Please repair before restarting!");}
return 0;
}
sub write_data {
my $fs  = shift @_;
my $database = shift @_;
my $channel = $origin;
if ($renum ) {
foreach my $sysrec (@{$database->{'system'}}) {
my $sysno = $sysrec->{'index'};
if (!$sysno) {next;}
$sysrec->{'bank_used'} = FALSE;
foreach my $grprec (@{$database->{'group'}}) {
my $grpndx = $grprec->{'index'};
if (!$grpndx) {next;}
if ($grprec->{'sysno'} ne $sysno) {next;}
foreach my $freqrec (@{$database->{'freq'}}) {
my $frqndx = $freqrec->{'index'};
if (!$frqndx) {next;}
if ($freqrec->{'groupno'} ne $grpndx) {next;}
if (!$freqrec->{'_noshow'}) {
$freqrec->{'channel'} = $channel;
$channel++;
}
$freqrec->{'_notorphan'} = TRUE;
}
}
}
foreach my $freqrec (@{$database->{'freq'}}) {
my $frqndx = $freqrec->{'index'};
if (!$frqndx) {next;}
if ($freqrec->{'_notorphan'}) {next;}
$freqrec->{'channel'} = $channel;
$channel++;
}### Orphan process
}### Renumber process
my @opt = ();
if ($append) {$nohdr = TRUE;}
if ($keyformat) {push @opt,'keyformat';}
if (!$showhz) {push @opt,'mhz'};
if ($freqsort) {push @opt,'sort';}
if ($append)   {push @opt,'append';}
if ($nohdr) {push @opt,'nohdr';}
my $tdir = get_directory(FALSE);
my $outfile = "$tdir/$fs.csv";
if (-e $outfile) {
if ($append) {
LogIt(1,"Data will be appended to existing file $Yellow$outfile");
}
else {
LogIt(1,"existing file $Yellow$outfile$White will be overwritten.");
if (!$overwrite) {
print "   OK (Y/N)=>";
my $answer = <STDIN>;
chomp($answer);
print STDERR "$Eol";
if (uc(substr($answer,0,1)) ne 'Y') {
LogIt(0,"$Bold Output file generation was bypassed!");
return 1;
}
}
}
}
return (write_radioctl($database,$outfile,@opt));
}
sub key_proc {
my $keyword = shift @_;
my $sysno = shift @_;
my $newno = shift @_;
my $radsysno = shift @_;
my $type = lc(shift @_);
my $radionum = 0;
my $new_index = 0;
if ($new_index) {
LogIt(0,"checking for existing $keyword block at $new_index");
my @keylist = ();
if ($radsysno) {
@keylist = keys %{$radiodb{$radsysno}{$keyword}};
}
else {
@keylist = keys %radiodb;
}
foreach my $rndx (@keylist) {
my $rno = $radsysno;
if (!$rno) {$rno = $rndx;};
my $radio_addr = $radiodb{$rno}{$keyword}{$rndx}{'block_addr'};
if ($radio_addr and ($new_index eq $radio_addr)) {
$radionum = $rndx;
if (!$radsysno) {$radsysno = $rndx;}
last;
}
}
}
my $changed = FALSE;
if (!$radionum) {
if ($new_index) {LogIt(1,"Did NOT find $new_index for $keyword");exit}
$parmref{'out'} = \%{$new{$sysno}{$keyword}{$newno}};
my $cmd = $create{$type};
my $tflag = $new{$sysno}{$keyword}{$newno}{'trunked'};
if (!$tflag) {$tflag = '';}
if ((lc($tflag) eq 't') and ($type eq 'gin')) {
$cmd = 'AGT';
}
$parmref{'out'} = \%{$new{$sysno}{$keyword}{$newno}};
$parmref{'write'} = TRUE;
if ($doit) {
if( bcd396_cmd($cmd) ){
print "Failed create of $type call\n",
print "'out'->",
Dumper($parmref{'out'}),"\n";
print "cmd=$cmd sysno=$sysno keyword=$keyword newno=$newno ",
"sitecnt=$sitecnt freqcnt=$freqcnt ",
"tfqcnt=$tfqcnt grpcnt=$grpcnt gidcnt=$gidcnt sysgidcnt=$sgidcnt\n";
LogIt(1519,"Could not create new $type block");}
}
else {
LogIt(0," Would have issued BCD396 command $cmd for $type");
$new{$sysno}{$keyword}{$newno}{'block_addr'} = $debug_addr++;
print Dumper($new{$sysno}{$keyword}{$newno}),"\n";
exit;
}
$changed = TRUE;
$radionum = (++$radmaxno{$keyword});
if (defined $radiodb{$radsysno}{$keyword}{$radionum}) {
LogIt(1,"$radionum for $keyword is NOT unique!");
print Dumper(%radmaxno),"\n";
print "radsysno=$radsysno keyword=$keyword radionum=$radionum \n",
Dumper($radiodb{$radsysno}{$keyword}{$radionum}),"\n";
exit;
}
foreach my $key (keys %{$new{$sysno}{$keyword}{$newno}}) {
$radiodb{$radsysno}{$keyword}{$radionum}{$key} =
$new{$sysno}{$keyword}{$newno}{$key};
}
}
else {
LogIt(0, "Found existing $keyword (radio's index=$radionum. Checking for changes\n");
foreach my $key (keys %{$radiodb{$radsysno}{$keyword}{$radionum}}) {
if ($changekey{$key}) {
if ($radiodb{$radsysno}{$keyword}{$radionum}{$key} ne
$new{$sysno}{$keyword}{$newno}{$key}) {
LogIt(0,"$Bold $keyword $key is being changed");
$radiodb{$radsysno}{$keyword}{$radionum}{$key} =
$new{$sysno}{$keyword}{$newno}{$key};
$changed = TRUE;
}
}
else {$new{$sysno}{$keyword}{$newno}{$key} =
$radiodb{$radsysno}{$keyword}{$radionum}{$key};}
}
}
if ($changed) {
$parmref{'out'} = \%{$new{$sysno}{$keyword}{$newno}};
$parmref{'write'} = TRUE;
my $cmd = uc($type);
if ($doit) {
if( bcd396_cmd($cmd) ){LogIt(608,"Could not update $type for system $sysno");}
}
else {
LogIt(0," Would issue bcd396 update command $cmd for $type");
print Dumper($new{$sysno}{$keyword}{$newno}),"\n";
}
}
else {LogIt(0,"No changes needed for New $keyword $sysno\n");}
return $radionum;
}
sub set_group {
my $tag = shift @_;
my $key = 'Other';
if ($tag =~ /law/i) {$key = 'Police';}
elsif ($tag =~ /pd/i) {$key = 'Police';}
elsif ($tag =~ /fire/i) {$key = 'Fire';}
elsif ($tag =~ /fd/i) {$key = 'Fire';}
elsif ($tag =~ /utilit/i) {$key ='Utilities';}
elsif ($tag =~ /public works/i) {$key ='Public_Works';}
elsif ($tag =~ /business/i) {$key ='Business';}
elsif ($tag =~ /emergency/i) {$key ='Police';}
elsif ($tag =~ /interop/i) {$key ='Police';}
elsif ($tag =~ /hospital/i) {$key ='EMS';}
elsif ($tag =~ /ems/i) {$key ='EMS';}
elsif ($tag =~ /med/i) {$key ='EMS';}
elsif ($tag =~ /transport/i) {$key ='Transportation';}
elsif ($tag =~ /bus/i) {$key ='Transportation';}
else {$key = 'Other';}
return $key;
}
sub check_modulation {
my $mds = lc(Strip(shift @_));
if ($mds == '') {return -1;}
if (defined $rc_hash{$mds}) {
return $rc_hash{$mds};
}
else {return -1;}
}
sub write_one {
foreach my $sysno (sort numerically keys %new) {
if ($sysno == 0) {
next;
my %keysset = ();
foreach my $key (keys %{$new{0}{'global'}{'0'}}) {
$keysset{lc($key)} = TRUE;
}
if ($keysset{'msg1'}) {
$parmref{'write'} = TRUE;
bcd396_cmd('OMS');
}
if ($keysset{'beep'}) {
$parmref{'write'} = TRUE;
bcd396_cmd('KBP');
}
next;
}
if (!defined $new{$sysno}{'system'}) {
LogIt(472,"No SYSTEM record was found for this system");
}
LogIt(0,"  Storing SYSTEM $sysno for this file..");
my $dbsysno = key_proc('system',$sysno,$sysno,0,'sin');
my $sys_index = $new{$sysno}{'system'}{$sysno}{'block_addr'};
my @freqs = sort keys %{$new{$sysno}{'freq'}};
my $trunked = TRUE;
if (lc($new{$sysno}{'system'}{$sysno}{'sys_type'}) eq 'cnv') {
$trunked = FALSE;
my $qkey = $new{$sysno}{'system'}{$sysno}{'qkey'};
if ($qkey and looks_like_number($qkey)) {
if ($new{$sysno}{'system'}{$sysno}{'valid'}) {$syskeys{$qkey} = 1;}
else {$syskeys{$qkey} = 0;}
}
}
else {
LogIt(0,"   Setting SITES for this system...");
$sitecnt = 0;
$sgidcnt = 0;
foreach my $siteno (sort keys %{$new{$sysno}{'site'}}) {
$new{$sysno}{'site'}{$siteno}{'sys_index'} = $sys_index;
my $dbsiteno = key_proc('site',$sysno,$siteno,$dbsysno,'sif');
my $site_index = $new{$sysno}{'site'}{$siteno}{'block_addr'};
my $qkey = $new{$sysno}{'site'}{$siteno}{'qkey'};
if ($qkey and looks_like_number($qkey)) {
if ($new{$sysno}{'system'}{$sysno}{'valid'}) {$syskeys{$qkey} = 1;}
else {$syskeys{$qkey} = 0;}
}
$sitecnt++;
if (!scalar @freqs) {LogIt(1,"No frequencies found for trunked system!");}
$tfqcnt = 0;
foreach my $freqno (@freqs) {
if (lc($new{$sysno}{'freq'}{$freqno}{'trunked'}) eq 't') {
my $refno = $new{$sysno}{'freq'}{$freqno}{'refno'} ;
if ($refno != $siteno) {
next;
}
$new{$sysno}{'freq'}{$freqno}{'grp_index'} = $site_index;
$new{$sysno}{'freq'}{$freqno}{'valid'} = TRUE;
my $dbfreqno = key_proc('freq',$sysno,$freqno,$dbsysno,'tfq');
$tfqcnt++;
}
else {
LogIt(1,"$freqno is NOT a trunked frequency. flag => " .
$new{$sysno}{'freq'}{$freqno}{'trunked'});
}
}
if (!$tfqcnt) {
LogIt(1,"no Trunk frequencies were assigned to site $siteno");
}
}
}
%grpkeys = ();
LogIt(0,"    setting GROUP/GIDS/FREQS for this system...");
$grpcnt = 0;
my $firstgrp = -1;
foreach my $groupno (sort keys  %{$new{$sysno}{'group'}}) {
if ($trunked) {$new{$sysno}{'group'}{$groupno}{'trunked'} = 'T';}
else {$new{$sysno}{'group'}{$groupno}{'trunked'} = '0';}
$new{$sysno}{'group'}{$groupno}{'sys_index'} = $sys_index;
my $dbgrpno = key_proc('group',$sysno,$groupno,$dbsysno,'gin');
my $grp_index = $new{$sysno}{'group'}{$groupno}{'block_addr'};
my $qkey = $new{$sysno}{'group'}{$groupno}{'qkey'};
if ($qkey and looks_like_number($qkey)) {
if ($firstgrp < 0) {$firstgrp = $qkey;}
if ($new{$sysno}{'group'}{$groupno}{'valid'}) {$grpkeys{$qkey} = 1;}
else {$grpkeys{$qkey} = 0;}
}
$grpcnt++;
$freqcnt = 0;
$gidcnt = 0;
if ($trunked) {
foreach my $tgidno (keys %{$new{$sysno}{'gid'}}) {
if ($new{$sysno}{'gid'}{$tgidno}{'groupno'} ne $groupno) {next;}
$new{$sysno}{'gid'}{$tgidno}{'grp_index'} = $grp_index;
$gidcnt++;
$sgidcnt++;
my $dbtgidno = key_proc('gid',$sysno,$tgidno,$dbsysno,'tin');
}
}
else {
my @sort = sort {$a <=> $b} keys %{$new{$sysno}{'freq'}};
foreach my $freqno (@sort) {
if ($new{$sysno}{'freq'}{$freqno}{'refno'} ne $groupno) {next;}
if (lc($new{$sysno}{'freq'}{$freqno}{'trunked'}) eq 't') {next;}
$freqcnt++;
$new{$sysno}{'freq'}{$freqno}{'grp_index'} = $grp_index;
my $dbfreqno = key_proc('freq',$sysno,$freqno,$dbsysno,'cin');
}
}### Conventional frequencies
}
my $one = FALSE;
foreach my $key (keys %grpkeys) {
if ($grpkeys{$key}) {### got one
$one = TRUE;
last;
}
}
if (!$one and ($firstgrp > -1)) {$grpkeys{$firstgrp} = 1;}
$parmref{'write'} = TRUE;
$grpkeys{'block_base'} = $sys_index;
$parmref{'out'} = \%grpkeys;
bcd396_cmd('QGL');
}### System number loop
}### Write_One
sub select_radio {
my $radio = lc(shift @_);
if (defined $All_Radios{$radio}) {
foreach my $key (keys %{$All_Radios{$radio}}) {
$radio_def{$key} = $All_Radios{$radio}{$key};
}
}
else {LogIt(3169,"$Magenta$radio$White was not defined in $Yellow$deffile");}
return 0;
}
sub open_serial {
my $port = $radio_def{'port'};
my $portobj = '';
if (lc($port) ne 'none') {
$portobj = Device::SerialPort->new($port) ;
if (!$portobj) {
print STDERR "error=$?\n";
LogIt(7129,"Cannot connect to port $port");
}
else {LogIt(0,"connected to port $port");}
$portobj->user_msg("ON");
$portobj->databits(8);
$portobj->baudrate($radio_def{'baudrate'});
$portobj->read_const_time(100);
$portobj->read_char_time(0);
$portobj->write_settings || undef $portobj;
LogIt(0,"Radio's baudrate set to $radio_def{'baudrate'}");
}
else {
LogIt(0,"Selected radio does not have a serial connection");
}
return $portobj;
}
sub get_directory {
my $radiodir = shift @_;
my $tdir = "$homedir/radioctl";
if ($dir) {$tdir = $dir;}
elsif ($radiodir ) {
}
elsif ($settings{'tempdir'}) {$tdir = $settings{'tempdir'};}
if (!-d $tdir) {
my $umask = umask;
umask 0;
if (mkdir $tdir,0777) {### all is well
umask $umask;
}
else {
LogIt(7229,"Unable to create directory $tdir for output file");
}
}### Create directory
return $tdir;
}
sub help {print "$help\n";exit;}
