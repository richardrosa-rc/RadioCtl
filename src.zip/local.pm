#!/usr/bin/perl -w
package local;
require Exporter;
use constant FALSE => 0;
use constant TRUE => 1;
@ISA   = qw(Exporter);
@EXPORT = qw(local_cmd %local_vfo
) ;
use Data::Dumper;
use Text::ParseWords;
use threads;
use threads::shared;
use Thread::Queue;
use Time::HiRes qw(time usleep ualarm gettimeofday tv_interval );
use radioctl;
use Useful;
use strict;
use autovivification;
no  autovivification;
my %local = ();
my @grpno = ('','AM Radio','Ham Radio','Fire','FM Radio', 'Air','Police','Railroad');
my @freqsamp = (
{'gpno' => 1, 'frequency' => '   770000', 'mode' => 'AM', 'service' => 'WABC-AM',   'dlyrsm' => -3},
{'gpno' => 1, 'frequency' => '  1390000', 'mode' => 'AM', 'service' => 'WEOK-AM',   'dlyrsm' => 10},
{'gpno' => 2, 'frequency' => '  7019000', 'mode' => 'lsb','service' => '40 meters', 'dlyrsm' => -5},
{'gpno' => 2, 'frequency' => ' 28300000', 'mode' => 'AM ','service' => '10 meters', 'dlyrsm' =>  5},
{'gpno' => 3, 'frequency' => ' 46460000', 'mode' => 'FMn','service' => 'UC Fire  ', 'dlyrsm' => -1},
{'gpno' => 4, 'frequency' => '101500000', 'mode' => 'FMw','service' => 'WPDH-FM  ', 'dlyrsm' =>  1},
{'gpno' => 3, 'frequency' => '154205000', 'mode' => 'FMn','service' => 'OC Fire  ', 'dlyrsm' => -4},
{'gpno' => 8, 'frequency' => '160950000', 'mode' => 'FMn','service' => 'MetroNorth','dlyrsm' =>  4},
{'gpno' => 5, 'frequency' => '162475000', 'mode' => 'FMn','service' => 'NOAA     ', 'dlyrsm' => -2},
{'gpno' => 7, 'frequency' => '460187500', 'mode' => 'FMn','service' => 'DC-911   ', 'dlyrsm' =>  2},
);
my %sample = ('service' => 'Simulated System', 'systemtype' => 'cnv', 'valid' => TRUE);
my $locsysno = add_a_record(\%local,'system',\%sample);
foreach my $ndx (1..$#grpno) {
%sample = ('service' => $grpno[$ndx],"valid" => TRUE,"sysno" => $locsysno);
my $locgrpno =  add_a_record(\%local,'group',\%sample);
foreach my $frqrec (@freqsamp) {
if ($frqrec->{'gpno'} == $ndx) {
my %rec = %{$frqrec};
$rec{'groupno'} = $locgrpno;
add_a_record(\%local,'freq',\%rec);
}
}
}
share (our %local_vfo);
%local_vfo = ('frequency' => 30000000,
'mode'      => 'fmn',
'signal'    => 0,
'sql'       => 0,
'channel'   => 0,
);
my $channel = 0;
foreach my $rec (@{$local{'freq'}}) {
if (!$rec->{'frequency'}) {next;}
$rec->{'sysno'} = 1;
$rec->{'valid'} = TRUE;
$rec->{'channel'} = $channel;
$rec->{'groupname'} = '';
$rec->{'systemname'} = '';
$rec->{'count'} = 0;
$rec->{'duration'} = 0;
$rec->{'timestamp'} = '';
$rec->{'signal'} = 0;
if (!$rec->{'tone_type'}) {$rec->{'tone_type'} = 'off';}
if (!$rec->{'tone'}) {$rec->{'tone'} = 'off';}
if (!$rec->{'dlyrsm'}) {$rec->{'dlyrsm'} = 0;}
KeyVerify($rec,@{$structure{'freq'}});
$channel++;
}
my $protoname = 'local';
use constant PROTO_NUMBER => 0;
$radio_routine{$protoname} = \&local_cmd;
my %extra_keys = ( 'freq' => [
],
'system' => [
],
'group' => [
],
'search' => [
],
);
add_protocol($protoname,\%extra_keys);
TRUE;
sub local_cmd {
my $cmd = shift@_;
if (!$cmd) {LogIt(326,"LOCAL_CMD:No command specified!");}
my $parmref = shift @_;
if (!$parmref) {LogIt(435,"LOCAL_CMD:No parmref reference specified. CMD=$cmd");}
if (ref($parmref) ne 'HASH') {LogIt(4336,"LOCAL_CMD:parmref is NOT a reference to a hash! CMD=$cmd");}
if (!$parmref->{'def'}) {LogIt(439,"LOCAL_CMD:No 'def' specified in parmref");}
my $defref    = $parmref->{'def'};
if (ref($defref) ne 'HASH') {LogIt(441,"LOCAL_CMD:defref is NOT a reference to a hash! CMD=$cmd");}
my $in   = $parmref->{'in'};
if (!$in) {LogIt(445,"LOCAL_CMD:No 'in' defined in parmref! CMD=$cmd");}
if (ref($in) ne 'HASH') {LogIt(446,"LOCAL_CMD:'in' spec in parmref is NOT a hash reference! CMD=$cmd");}
my $out   = $parmref->{'out'};
if (!$out) {LogIt(450,"LOCAL_CMD:No 'out' defined in parmref! CMD=$cmd");}
if (ref($out) ne 'HASH') {LogIt(451,"LOCAL_CMD:Out spec in parmref is NOT a hash reference! CMD=$cmd");}
my $outsave = $out;
my $db = $parmref->{'database'};
my $rc = 0;
if ($cmd eq 'init') {
$defref->{'maxchan'} = MAXCHAN;
$defref->{'origin'} = 0;
$defref->{'minfreq'} = 1;
$defref->{'maxfreq'} = MAXFREQ;
$defref->{'radioscan'} = FALSE;
$defref->{'sigdet'} = 2;
$defref->{'delay'} = 3000;
$defref->{'speed'} = 20;
$local_vfo{'signal'} = 0;
return ($parmref->{'rc'} = $GoodCode);
}### Init
elsif ($cmd eq 'manual') {
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'vfoinit') {
$local_vfo{'signal'} = 0;
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'meminit') {
$local_vfo{'signal'} = 0;
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'poll') {
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'getvfo') {
foreach my $key ('frequency','mode') {$vfo{$key} = $local_vfo{$key};}
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'setvfo') {
$local_vfo{'signal'} = 0;
foreach my $key ('frequency','mode') {
if ($vfo{$key}) {$local_vfo{$key} = $vfo{$key};}
else {LogIt(1,"LOCAL l495:Attempted to set  local vfo $key to null");}
}
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'selmem') {
my $ch = $in->{'channel'};
$local_vfo{'channel'} = $ch;
if (defined $local{'freq'}[$ch]{'channel'}) {
foreach my $key (keys %{$local{'freq'}[$ch]}) {
$out->{$key} = $local{'freq'}[$ch]{$key};
}
$local_vfo{'signal'} = 0;
return ($parmref->{'rc'} = $GoodCode);
}
else {
return ($parmref->{'rc'} = $ParmErr);
}
}### selmem
elsif ($cmd eq 'getmem') {
if (!$db) {LogIt(621,"LOCAL_CMD:No 'database' defined in parmref! CMD=$cmd");}
if (ref($db) ne 'HASH') {LogIt(622,"LOCAL_CMD:DB spec in parmref is NOT a hash reference! CMD=$cmd");}
my $startstate = $progstate;
my $maxcount = 99999999;
my $syscount = 0;
my $notrunk = FALSE;
my $sysname = '';
my $sysnos = '';
if ($in->{'notrunk'}) {$notrunk = TRUE;}
my @syslist = ();
my $firstdbno = 0;
my $firstradiono = 0;
if ($in->{'num'}) {
foreach my $ndx (@{$in->{'num'}}) {
if ($local{'system'}[$ndx]{'index'}) {
if ($notrunk and $local{'system'}[$ndx]{'systemtype'} ne 'cnv') {next;}
push @syslist,$local{'system'}[$ndx];
$syscount++;
}### System specified is defined
}### For each system number requested
}### 'NUM' option specified
elsif ($in->{'nam'}) {### specific system names?
foreach my $nam (@{$in->{'nam'}}) {
foreach my $sysrec (@{$local{'system'}}) {
if (!$sysrec->{'index'}) {next;}
if ($notrunk and $sysrec->{'systemtype'} ne 'cnv') {next;}
if (lc($sysrec->{'service'}) eq lc($nam)) {
push @syslist,$sysrec;
$syscount++;
}
}### for each system record
}### for each system name requested
}### 'NAM' option specified
else {
print "Local l694:Non-specific request maxcount=>$maxcount\n";
foreach my $sysrec (@{$local{'system'}}) {
if (!$sysrec->{'index'}) {next;}
if ($notrunk and $sysrec->{'systemtype'} ne 'cnv') {next;}
if ($syscount > $maxcount) {last;}
push @syslist,$sysrec;
$syscount++;
}### add all the systems to process
}
foreach my $sysrec (@syslist) {
my $systype = lc($sysrec->{'systemtype'});
my $locsysno = $sysrec->{'index'};
my $sysno = add_a_record($db,'system',$sysrec,$parmref->{'gui'});
if (!$firstdbno) {$firstdbno = $sysno;}
if (!$firstradiono) {$firstradiono = $locsysno;}
if ($systype ne 'cnv') {
foreach my $siterec (@{$local{'site'}}) {
my $locsiteno = $siterec->{'index'};
if (!$locsiteno->{'index'}) {next;}
if ($siterec->{'sysno'} != $locsysno) {next;}
my %site = %{$siterec};
$site{'sysno'} = $sysno;
my $siteno = add_a_record($db,'site',\%site,$parmref->{'gui'});
foreach my $tfreqrec (@{$local{'tfreq'}}) {
if (!$tfreqrec->{'index'}) {next;}
if ($tfreqrec->{'siteno'} != $locsiteno) {next;}
my %tfreq = %{$tfreqrec};
$tfreq{'siteno'} = $siteno;
add_a_record($db,'tfreq',\%tfreq,$parmref->{'gui'});
}### Tfreqs
}### Sites
}### Non-conventional system
foreach my $grouprec (@{$local{'group'}}) {
my $locgroupno = $grouprec->{'index'};
if (!$locgroupno) {next;}
if ($grouprec->{'sysno'} != $locsysno) {next;}
my %grprec = %{$grouprec};
$grprec{'sysno'} = $sysno;
my $grpno = add_a_record($db,'group',\%grprec,$parmref->{'gui'});
foreach my $freqrec (@{$local{'freq'}}) {
my $locfreqno = $freqrec->{'index'};
if (!$locfreqno) {next;}
if ($freqrec->{'groupno'} != $locgroupno) {next;}
my %newrec = %{$freqrec};
$newrec{'groupno'} = $grpno;
add_a_record($db,'freq',\%newrec,$parmref->{'gui'});
threads->yield;
if ($progstate ne $startstate) {
goto GETDONE;
}
}#### FREQ record process
}### group process
}### System record
GETDONE:
$out->{'firstnum'} = $firstradiono;
$out->{'sysno'} = $firstdbno;
$out->{'count'} = $syscount;
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'setmem') {
if (!$db) {LogIt(887,"LOCAL_CMD:No 'database' defined in parmref! CMD=$cmd");}
if (ref($db) ne 'HASH') {LogIt(888,"LOCAL_CMD:DB spec in parmref is NOT a hash reference! CMD=$cmd");}
if ($debug1) {LogIt(0,"Processing LOCAL SETMEM command");}
my $erase = FALSE;
my $dumpit = TRUE;
if ($in->{'erase'}) {$erase = TRUE;}
if ($in->{'dump'}) {$dumpit = TRUE;}
my @systems = @{$db->{'system'}};
my $retcode = 0;
SYSPROC:
foreach my $sysrec (@systems) {
if ($sysrec->{'_bypass'}) {next;}
my $sysno = $sysrec->{'index'};
if (!$sysno) {next;}
my $systype = $sysrec->{'systemtype'};
if (!$systype) {
LogIt(1,"SETMEM:No 'systemtype' key set in $sysno! Cannot process!");
$retcode = $ParmErr;
$sysrec->{'_bypass'} = TRUE;
next SYSPROC;
}
$systype = lc(Strip($systype));
if (!$system_type_valid{$systype}) {
LogIt(1,"SETMEM:System $Yellow$sysrec->{'service'}$White ($Green$sysno$White) " .
"type $Magenta$systype$White is NOT a valid RadioCtl system type");
$retcode = $ParmErr;
$sysrec->{'_bypass'} = TRUE;
next SYSPROC;
}
if ($sysrec->{'systemtype'} ne 'cnv') {
my $sitecount = 0;
SITEPROC:   foreach my $siterec (@{$db->{'site'}}) {
if ($siterec->{'_bypass'}) {next;}
my $siteno = $siterec->{'index'};
if (!$siteno) {next;}
if ($siterec->{'sysno'} ne $sysno) {next;}
my $tfcnt = 0;
foreach my $tfrec (@{$db->{'tfreq'}}) {
if ($tfrec->{'_bypass'}) {next;}
if (!$tfrec->{'index'}) {next;}
if ($tfrec->{'siteno'} != $siteno) {next;}
$tfcnt++;
}
if (!$tfcnt) {
LogIt(1,"SETMEM:No valid tfreq found for site $siterec->{'service'} Cannot process.");
$siterec->{'_bypass'} = TRUE;
$retcode = $EmptyChan;
next SITEPROC;
}
$sitecount++;
}### looking at all sites
if (!$sitecount) {
LogIt(1,"SETMEM:No valid sites found for system $sysno. Cannot process.");
$retcode = $EmptyChan;
$sysrec->{'_bypass'} = TRUE;
next SYSPROC;
}
}### trunked system
my $groupcnt = 0;
foreach my $grprec (@{$db->{'group'}}) {
if ($grprec->{'_bypass'}) {next;}
my $grpno = $grprec->{'index'};
if (!$grpno) {next;}
if ($grprec->{'sysno'} != $sysno) {next;}
my $freqcnt = 0;
foreach my $frqrec (@{$db->{'freq'}}) {
if ($frqrec->{'bypass'}) {next;}
if (!$frqrec->{'index'}) {next;}
if ($frqrec->{'groupno'} != $grpno) {next;}
$freqcnt++;
last;
}
if ($freqcnt) {$groupcnt++;}
else {
LogIt(1,"SETMEM:No valid frequencies for group $grprec->{'service'}. Cannot process.");
$grprec->{'_bypass'} = TRUE;
$retcode = $EmptyChan;
next;
}
}
if (!$groupcnt) {
LogIt(1,"SETMEM:No valid groups for system $sysrec->{'service'}. Cannot process.");
$sysrec->{'_bypass'} = TRUE;
$retcode = $EmptyChan;
next SYSPROC;
}
}### System check
if ($erase) {
foreach my $sysrec (@systems) {
if (!$sysrec->{'index'}) {next;}
foreach my $locsysrec (@{$local{'system'}}) {
if (!$locsysrec->{'index'}) {next;}
if ($locsysrec->{'service'} eq $sysrec->{'service'}) {
}
}
}
}
foreach my $sysrec (@systems) {
if ($sysrec->{'_bypass'}) {next;}
my $sysno = $sysrec->{'index'};
if (!$sysno) {next;}
my $newsysno = add_a_record(\%local,'system',$sysrec,$parmref->{'gui'});
foreach my $siterec (@{$db->{'site'}}) {
if ($siterec->{'_bypass'}) {next;}
my $siteno = $siterec->{'index'};
if (!$siteno) {next;}
if ($siteno != $sysno) {next;}
my %site = %{$siterec};
$site{'sysno'} = $newsysno;
my $newsiteno = add_a_record(\%local,'site',\%site,$parmref->{'gui'});
foreach my $tfrqrec (@{$db->{'tfreq'}}) {
if ($tfrqrec->{'_bypass'}){next;}
if (!$tfrqrec->{'index'}) {next;}
if ($tfrqrec->{'siteno'} != $siteno) {next;}
my %tfreq = %{$tfrqrec};
$tfreq{'siteno'} = $newsiteno;
my $newtfqeno = add_a_record(\%local,'tfreq',\%tfreq,$parmref->{'gui'});
}
}
foreach my $grprec (@{$db->{'group'}}) {
if ($grprec->{'_bypass'}) {next;}
my $groupno = $grprec->{'index'};
if (!$groupno) {next;}
if ($grprec->{'sysno'} != $sysno) {next;}
my %group = %{$grprec};
$group{'sysno'} = $newsysno;
my $newgrpno = add_a_record(\%local,'group',\%group,$parmref->{'gui'});
foreach my $frqrec (@{$db->{'freq'}}) {
if ($frqrec->{'_bypass'}) {next;}
my $freqno = $frqrec->{'index'};
if (!$freqno) {next;}
if ($frqrec->{'groupno'} != $groupno) {next;}
my %freq = %{$frqrec};
$freq{'groupno'} = $newgrpno;
my $newfrqno = add_a_record(\%local,'freq',\%freq,$parmref->{'gui'});
}
}
}
if ($dumpit) {write_radioctl(\%local,"/tmp/radioctl/local.csv",'sort');}
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'getglob') {
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'setglob') {
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'getsrch') {
foreach my $rec (@{$local{'search'}}) {
add_a_record($db,'search',$rec,$parmref->{'gui'});
}
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'setsrch') {
foreach my $rec (@{$db->{'search'}}) {
if (!$rec->{'index'}) {next;}
add_a_record(\%local,'search',$rec,$parmref->{'gui'});
}
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'getinfo') {
bearcat_cmd('init',$parmref);
$out->{'chan_count'} = (scalar @{$local{'freq'}}) - 1;
$out->{'model'} = 'Local';
return ($parmref->{'rc'});
}
elsif ($cmd eq 'getsig') {
$out->{'signal'} = $local_vfo{'signal'};
$out->{'frequency'} = $local_vfo{'frequency'};
$out->{'mode'} = $local_vfo{'mode'};
if ($local_vfo{'signal'}) {
$out->{'sql'} = TRUE;
$out->{'service'} = $local_vfo{'service'};
}
if ($out->{'sql'}) {### simulated signal
if (!$local_vfo{'channel'}) {
$local_vfo{'channel'} = int(rand($#{$local{'freq'}})); 
}
}
else {
if ($progstate eq 'radioscan') {$local_vfo{'channel'} = 0;}
}
if ($out->{'sql'}) {
if (($progstate eq 'radioscan') or ($progstate eq 'channelscan')) {
my $ch = $local_vfo{'channel'};
$out->{'frequency'} = 0;
$out->{'mode'} = 'FMn';
if ($ch) {
if ($local{'freq'}[$ch]{'frequency'}) {
$out->{'frequency'} = $local{'freq'}[$ch]{'frequency'};
$out->{'mode'} = $local{'freq'}[$ch]{'mode'};
$out->{'channel'} = $ch;
}
}### CH defined
else {
$out->{'channel'} = 0;
}
}### channel oriented scan
else {
$out->{'frequency'} = $local_vfo{'frequency'};
$out->{'mode'} = $local_vfo{'mode'};
$out->{'channel'} = $local_vfo{'channel'};
}
}### squelch break
else {
if ($progstate eq 'radioscan') {$local_vfo{'channel'} = 0;}
}
return ($parmref->{'rc'} = $GoodCode);
}### GetSig
else {LogIt(4522,"LOCAL_CMD:Unhandled command $cmd");}
return ($parmref->{'rc'} = $rc);
}
