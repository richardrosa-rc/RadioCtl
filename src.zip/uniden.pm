#!/usr/bin/perl -w
package uniden;
require Exporter;
@ISA   = qw(Exporter);
@EXPORT = qw(uniden_cmd Get_XML Get_SDS_Status
);
use Data::Dumper;
use Text::ParseWords;
use threads;
use threads::shared;
use Thread::Queue;
use Time::HiRes qw( usleep ualarm gettimeofday tv_interval );
use autovivification;
no  autovivification;
use Scalar::Util qw(looks_like_number);
use radioctl;
use constant FALSE => 0;
use constant TRUE => 1;
use strict;
my $protoname = 'uniden';
use constant PROTO_NUMBER => 1;
$radio_routine{$protoname} = \&uniden_cmd;
$valid_protocols{'uniden'} = TRUE;
my $ready = TRUE;
my %rc_to_uniden = ();
foreach my $mode (@modestring) {
my $key = Strip(lc($mode));
if ($key eq 'fmw') {$rc_to_uniden{$key} = 'FMB';}
elsif ($key eq 'fmn') {$rc_to_uniden{$key} = 'FM';}
elsif ($key eq 'fmm') {$rc_to_uniden{$key} = 'WFM';}
elsif ($key eq 'fmun') {$rc_to_uniden{$key} = 'NFM';}
elsif ($key eq 'am') {$rc_to_uniden{$key} = 'AM';}
elsif ($key eq 'amn') {$rc_to_uniden{$key} = 'AM';}
elsif ($key eq 'amw') {$rc_to_uniden{$key} = 'AM';}
else {$rc_to_uniden{$key} = 'AUTO';}
}
my %uniden_to_rc = (
'WFM' => 'FMm',
'AM'  => 'AM',
'NFM' => 'FMun',
'FM'  => 'FMn',
'FMB' => 'FMw',
'AUTO' => 'Auto',
);
my %service_search = ( 1 => 'Public Safety',
2 => "News",
3 => "HAM Radio",
4 => "Marine",
5 => "Railroad",
6 => "Air",
7 => "CB Radio",
8 => "FRS/GMRS/MURS",
9 => "Racing",
11 => "FM Broadcast",
12 => "Special",
15 => "Military Air",
);
my $queue_head  = -1;
my $queue_tail  = -1;
my %blocks = (
SIN => [
{'block_addr'   => 'q'},
{'systemtype'   => 'r'},
{'service'      => 'b'},
{'qkey'         => 'b'},
{'hld'          => 'b'},
{'lout'         => 'b'},
{'dlyrsm'       => 'b'},
{'skip'         => 'b'},
{'mode'         => 'b'},
{'atten'        => 'b'},
{'p25mode'      => 'b'},
{'p25lvl'    => 'b'},
{'rev_index'    => 'r'},
{'fwd_index'    => 'r'},
{'chn_head'     => 'r'},
{'chn_tail'     => 'r'},
{'seq_no'       => 'r'},
{'start_key'    => '3'},
{'rsvd'         => '3'},
{'rsvd'         => '3'},
{'rsvd'         => '3'},
{'rsvd'         => '3'},
{'rsvd'         => '3'},
{'rsvd'         => 'x'},
{'systag'       => '3'},
{'agc_analog'   => '3'},
{'agc_digital'  => '3'},
{'p25wait'      => '3'},
{'protect'      => 's'},
{'rsvd'         => 's'},
],
SIF => [
{'block_addr'   => 'q'},
{'rsvd'         => 'r'},
{'service'      => 'b'},
{'qkey'         => 'b'},
{'hld'          => 'b'},
{'lout'         => 'b'},
{'mode'         => 'b'},
{'atten'        => 'b'},
{'c_ch'         => 'b'},
{'rsvd'         => 'b'},
{'rsvd'         => 'b'},
{'rev_index'    => 'r'},
{'fwd_index'    => 'r'},
{'sys_index'    => 'r'},
{'chn_head'     => 'r'},
{'chn_tail'     => 'r'},
{'seq_no'       => 'r'},
{'start_key'    => 'b'},
{'lat',         => 'b'},
{'lon',         => 'b'},
{'radius'       => 'b'},
{'gps_enable'   => 'b'},
{'rsvd'         => 'b'},
{'mot_type'     => 'b'},
{'edacs_type'   => 'b'},
{'p25wait'      => 'b'},
{'rsvd'         => 'b'},
],
TRN => [
{'block_addr'   => 'q'},
{'id_search'    => 'b'},
{'s_bit'        => 'b'},
{'end_code'     => 'b'},
{'afs'          => 'b'},
{'i_call'       => 'b'},
{'c_ch'         => 'b'},
{'emgalt'       => 'b'},
{'emglvl'       => 'b'},
{'fleetmap'     => 'b'},
{'custmap'      => 'b'},
{'frequency_l1' => 'b'},
{'spacing_1'    => 'b'},
{'offset_1'     => 'b'},
{'frequency_l2' => 'b'},
{'spacing_2'    => 'b'},
{'offset_2'     => 'b'},
{'frequency_l3' => 'b'},
{'spacing_3'    => 'b'},
{'offset_3'     => 'b'},
{'mfid'         => 'b'},
{'chn_head'     => 'r'},
{'chn_tail'     => 'r'},
{'lo_head'      => 'r'},
{'lo_tail'      => 'r'},
{'moto_id'      => '3'},
{'emgcol'       => '3'},
{'emgpat'       => '3'},
{'p25nac'       => '3'},
{'priority'     => '3'},
],
TFQ  => [
{'block_addr'   => 'q'},
{'frequency'    => 'b'},
{'lcn'          => 'b'},
{'lout'         => 'b'},
{'rev_index'    => 'r'},
{'fwd_index'    => 'r'},
{'sys_index'    => 'r'},
{'site_index'   => 'r'},
{'rsvd'         => '3'},
{'bcdtag'       => '3'},
{'voloff'       => '3'},
{'rsvd'         => '3'},
{'ccode'        => '3'},
],
GIN => [
{'block_addr'   => 'q'},
{'grp_type'     => 'r'},
{'service'      => 'b'},
{'gqkey'        => 'b'},
{'lout'         => 'b'},
{'rev_index'    => 'r'},
{'fwd_index'    => 'r'},
{'sys_index'    => 'r'},
{'chn_head'     => 'r'},
{'chn_tail'     => 'r'},
{'seq_no'       => 'r'},
{'lat',              => '3'},
{'lon',               => '3'},
{'radius',      => '3'},
{'gps_enable'   => '3'},
],
MCP => [
{'block_addr'   => 'q'},
{'frequency_l1' => 'b'},
{'frequency_u1' => 'b'},
{'spacing_1'    => 'b'},
{'offset_1'     => 'b'},
{'frequency_l2' => 'b'},
{'frequency_u2' => 'b'},
{'spacing_2'    => 'b'},
{'offset_2'     => 'b'},
{'frequency_l3' => 'b'},
{'frequency_u3' => 'b'},
{'spacing_3'    => 'b'},
{'offset_3'     => 'b'},
{'frequency_l4' => 'b'},
{'frequency_u4' => 'b'},
{'spacing_4'    => 'b'},
{'offset_4'     => 'b'},
{'frequency_l5' => 'b'},
{'frequency_u5' => 'b'},
{'spacing_5'    => 'b'},
{'offset_5'     => 'b'},
{'frequency_l6' => 'b'},
{'frequency_u6' => 'b'},
{'spacing_6'    => 'b'},
{'offset_6'     => 'b'},
],
TIN =>[
{'block_addr'   => 'q'},
{'service'      => 'b'},
{'tgid'         => 'b'},
{'lout'         => 'b'},
{'priority'     => 'b'},
{'emgalt'       => 'b'},
{'emglvl'       => 'b'},
{'rev_index'    => 'r'},
{'fwd_index'    => 'r'},
{'sys_index'    => 'r'},
{'grp_index'    => 'r'},
{'rsvd'         => '3'},
{'adtype'       => '3'},
{'bcdtag'       => '3'},
{'emgcol'       => '3'},
{'emgpat'       => '3'},
{'voloff'       => '3'},
{'t_slot'       => '3'},
],
CIN =>[
{'block_addr'   => 'q'},
{'service'      => 'b'},
{'frequency'    => 'b'},
{'mode'         => 'b'},
{'ctcsdcs'      => 'b'},
{'tonelock'     => 'b'},
{'lout'         => 'b'},
{'priority'     => 'b'},
{'atten'        => 'b'},
{'emgalt'       => 'b'},
{'emglvl'       => 'b'},
{'rev_index'    => 'r'},
{'fwd_index'    => 'r'},
{'sys_index'    => 'r'},
{'grp_index'    => 'r'},
{'rsvd'         => '3'},
{'adtype'       => '3'},
{'p25nac'       => '3'},
{'bcdtag'          => '3'},
{'emgcol'       => '3'},
{'emgpat'       => '3'},
{'voloff'       => '3'},
],
ACC =>[
{'block_base'   => 'q'},
{'block_addr'   => 'r'},
],
ACT =>[
{'block_base'   => 'q'},
{'block_addr'   => 'r'},
],
AGC =>[
{'block_base'   => 'q'},
{'block_addr'   => 'r'},
],
AGT =>[
{'block_base'   => 'q'},
{'block_addr'   => 'r'},
],
AST =>[
{'block_base'   => 'q'},
{'rsvd'         => 'w'},
{'block_addr'   => 'r'},
],
REV =>[
{'block_base'   => 'q'},
{'block_addr'   => 'r'},
],
FWD =>[
{'block_base'   => 'q'},
{'block_addr'   => 'r'},
],
DSY => [
{'block_addr'   => 'q'},
],
DGR => [
{'block_addr'   => 'q'},
],
AGV => [
{'rsvd'        => 'b'},
{'rsvd'        => 'b'},
{'a_response'  => 'b'},
{'a_reference' => 'b'},
{'a_gain'      => 'b'},
{'d_response'  => 'b'},
{'d-gain'      => 'b'},
{'rsvd'        => 'b'},
],
BAV => [{'bat_level'  => 'r'}],
BLT => [
{'event'       => 'b'},
{'rsvd'        => '3'},
{'bright'      => '3'},
],
BSV => [
{'bat_save'    => 'b'},
{'charge_time' => 'b'},
],
DBC => [
{'band_no'      => 'q'},
{'step'         => 'b'},
{'mode'         => 'b'},
],
CIE => [
{'frequency'    => 'q'},
],
CLC => [
{'cc_mode'      => 'b'},
{'cc_ovrd'      => 'b'},
{'rsvd'         => 'b'},
{'emgalt'       => 'b'},
{'al_lvl'       => 'b'},
{'pause'        => 'b'},
{'cc_band'      => 'b'},
{'lout'         => 'b'},
{'hld'          => 'b'},
{'qkey'         => 'b'},
{'bcdtag'       => 'b'},
{'emgcol'       => 'b'},
{'elgpat'       => 'b'},
],
CNT => [
{'contrast'     => 'b'},
],
CSP => [
{'channel'     => 'q'},
{'service'     => 'b'},
{'lowfreq'     => 'b'},
{'highfreq'    => 'b'},
{'step'        => 'b'},
{'mode'        => 'b'},
{'atten'       => 'b'},
{'dlyrsm'      => 'b'},
{'skp'         => 'b'},
{'hld'         => 'b'},
{'lout'        => 'b'},
{'c_ch'        => 'b'},
{'p25mode'     => 'b'},
{'p25lvl'      => 'b'},
{'qkey'         => '3'},
{'start_key'    => '3'},
{'rsvd'         => '3'},
{'bcdtag'       => '3'},
{'agc_analog'   => '3'},
{'agc_digital'  => '3'},
],
CSY => [
{'systemtype'   => 'q'},
{'protect'     => 'x'},
{'block_addr'  => 'r'},
],
GID => [
{'systemtype'  => 'r'},
{'tgid'        => 'r'},
{'id_srch'     => 'r'},
{'sitename'    => 'r'},
{'groupname'   => 'r'},
{'service'     => 'r'},
],
GIE => [
{'frequency'    => 'r'},
],
GLF => [
{'frequency'    => 'r'},
],
GLG => [
{'frq_tgid'    => 'r'},
{'mode'        => 'r'},
{'atten'       => 'r'},
{'ctcsdcs'     => 'r'},
{'systemname'  => 'r'},
{'groupname'   => 'r'},
{'service'     => 'r'},
{'sql'         => 'r'},
{'mute'        => 'r'},
{'sys_tag'     => 'r'},
{'ch_tag'      => 'r'},
{'p25nac'      => 'r'},
],
JPM => [
{'jmp_mode'    => 'q'},
{'jmp_index'   => 'w'},
],
JNT => [
{'sys_tag'     => 'w'},
{'ch_tag'      => 'w'},
],
KEY => [
{'key_code'    => 'q'},
{'key_mode'    => 'q'},
],
KBP => [
{'beep'        => 'b'},
{'lock'        => '3'},
{'safe'        => '3'},
],
LOF => [
{'frequency'    => 'q'},
],
MEM => [
{'mem_used'    => 'r'},
{'sys_count'   => 'r'},
{'site_count'  => 'r'},
{'chan_count'  => 'r'},
{'loc_count'   => 'r'},
],
MDL => [{'model'      => 'r'}],
MNU => [{'menu_ndx'   => 'q'}],
OMS => [
{'msg1'        => 'b'},
{'msg2'        => 'b'},
{'msg3'        => 'b'},
{'msg4'        => 'b'},
],
P25 => [
{'rsvd'        => 'r'},
{'rsvd'        => 'r'},
{'err_rate'    => 'r'},
],
PRI => [
{'pri_mode'    => 'b'},
{'max_chan'    => 'b'},
{'interval'    => 'b'},
],
PWR => [
{'rssi'        => 'r'},
{'frequency'   => 'r'},
],
QSH => [
{'frequency'    => 'q'},
{'rsvd'         => 'w'},
{'mode'         => 'w'},
{'atten'        => 'w'},
{'dlyrsm'       => 'w'},
{'rsvd'         => 'w'},
{'code_srch'    => 'w'},
{'bsc'          => 'w'},
{'rep'          => 'w'},
{'rsvd'         => 'xy'},
{'agc_analog'   => 'xy'},
{'agc_digital'  => 'xy'},
{'p25wait'   => 'xy'},
],
QSC =>[
{'frequency'    => 'q'},
{'rsvd'         => 'w'},
{'mode'         => 'w'},
{'atten'        => 'w'},
{'dlyrsm'       => 'w'},
{'rsvd'         => 'w'},
{'code_srch'    => 'w'},
{'bsc'          => 'w'},
{'rep'          => 'w'},
{'rsvd'         => 'w'},
{'agc_analog'   => 'w'},
{'agc_digital'  => 'w'},
{'p25wait'      => 'w'},
{'rssi'         => 'r'},
{'frequency'    => 'r'},
{'sql'          => 'r'},
],
RIE => [
{'frequency'    => 'q'},
],
RMB => [### Number of free blocks
{'mem_free'    => 'r'},
],
SCN => [
{'disp_mode'   => 'b'},
{'rsvd'        => 'b'},
{'cc_logging'  => 'b'},
{'atten'       => 'b'},
{'rsvd'        => 'b'},
{'p25_lpf'     => 'b'},
{'disp_uid'    => 'b'},
{'rsvd'        => 'b'},
{'rsvd'        => 'b'},
{'rsvd'        => 'b'},
{'rsvd'        => 'b'},
{'rsvd'        => 'b'},
{'rsvd'        => 'b'},
{'rsvd'        => 'b'},
{'rsvd'        => 'b'},
{'rsvd'        => 'b'},
{'rsvd'        => 'b'},
{'rsvd'        => 'b'},
{'rsvd'        => 'b'},
{'rsvd'        => 'b'},
{'rsvd'        => 'b'},
],
SCT => [{'system_cnt' => 'r'}],
SIH => [{'block_addr' => 'r'}],
SIT => [{'block_addr' => 'r'}],
SQL => [{'squelch'    => 'b'}],
SSP =>[
{'channel'     => 'q'},
{'dlyrsm'      => 'b'},
{'atten'       => 'b'},
{'hld'         => 'b'},
{'lout'        => 'b'},
{'qkey'         => '3'},
{'start_key'    => '3'},
{'rsvd'         => '3'},
{'bcdtag'       => '3'},
{'agc_analog'   => '3'},
{'agc_digital'  => '3'},
],
ULF => [
{'frequency'    => 'q'},
],
VER => [{'version'    => 'r'}],
VOL => [{'vol_level'  => 'b'}],
WIN => [{'w_voltage'  => 'r'}],
);
my %nodata = (
'CLR'=>TRUE,
'EPG'=>TRUE,
'POF'=>TRUE,
'PRG'=>TRUE,
'nop'=>TRUE,
);
my %special = ('CLR' => {'delay' => 10000,'wait' => 200 },
'PRG' => {'delay' => 1000,'wait' => 50, 'resend' => 1, 'fails'=> 1},
'EPG' => {'delay' => 1000,'wait' => 50, 'resend' => 1, 'fails'=> 1},
'DSY' => {'delay' => 5000,'wait' => 50, },
'MDL' => {'delay' =>  100,'wait' =>  5, 'fails'=> 1},
);
my %unsolicited = ('DMR' => TRUE,'EDW'=> TRUE,'CSC'=> TRUE);
$struct_fields{'rev_index'}    = ['i', 5,0,    -1,-1,'.'     ,0,];
$struct_fields{'fwd_index'}    = ['i', 5,0,    -1,-1,'.'     ,0,];
$struct_fields{'sys_index'}    = ['i', 5,0,    -1,-1,'.'     ,0,];
$struct_fields{'site_index'}   = ['i', 5,0,    -1,-1,'.'     ,0,];
$struct_fields{'grp_index'}    = ['i', 5,0,    -1,-1,'.'     ,0,];
$struct_fields{'chn_head'}     = ['i', 5,0,    -1,-1,'.'     ,0,];
$struct_fields{'chn_tail'}     = ['i', 5,0,    -1,-1,'.'     ,0,];
$struct_fields{'lo_head'}      = ['i', 5,0,    -1,-1,'.'     ,0,];
$struct_fields{'lo_tail'}      = ['i', 5,0,    -1,-1,'.'     ,0,];
$struct_fields{'system_cnt'}   = ['i', 5,0,     0,0,'.'     ,0,];
$struct_fields{'grp_type'}     = ['c', 1,'a',  '', 0,0       ,0,];
$struct_fields{'block_type'}     = ['c', 1,'a',  '', 0,0       ,0,];
$struct_fields{'ctcsdcs'}      = ['i', 2,0,    '', 0,239     ,0,];
$struct_fields{'seq_no'}       = ['i', 5,0,    -1,-1,'.'     ,0,];
$struct_fields{'lout'}         = ['b', 1,0,     0,0,1        ,0,];
$struct_fields{'c_ch'}         = ['b', 1,0,     0,0,1        ,0,];
$struct_fields{'tonelock'}       = ['b', 1,0,     0,0,1      ,0,];
$struct_fields{'color_code'}   = ['i', 2,0,     0,0,15       ,0,'SRCH'];
$struct_fields{'base1'}        = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'base2'}        = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'base3'}        = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'step1'}        = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'step2'}        = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'step3'}        = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'offset1'}      = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'offset2'}      = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'offset3'}      = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'mfid'}         = ['n', 1,'a',  '',0,2        ,0];
$struct_fields{'lock'}         = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'safe'}         = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'start_key'}    = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'gps_enable'}   = ['b', 1,0,     0,0,1        ,0,];
$struct_fields{'protect'}      = ['b', 1,0,     0,0,1        ,0,];
$struct_fields{'rep'}          = ['b', 1,0,     0,0,1        ,0,];
$struct_fields{'bsc'}          = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'frq_tgid'}    = ['c', 10,'a',  '',0,0        ,0];
$struct_fields{'ch_name'}     = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'mute'   }     = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'ch_tag' }     = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'sys_tag'}     = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'cconly'}      = ['b', 1,0,     0,0,1        ,0,];
$struct_fields{'block_base'}  = ['i', 5,0,    -1,-1,'.'     ,0,];
$struct_fields{'rssi'}        = ['i', 5,0,     0,0,1047     ,0,];
$struct_fields{'code_srch'}   = ['i', 1,0,     0,0,2        ,0,];
$struct_fields{'key_code'}    = ['c', 1,'a',  '',0,0        ,0];
$struct_fields{'key_mode'}    = ['c', 1,'a',  '',0,0        ,0];
push @{$struct_fields{'systemtype'}},'edc';
my %state_save = (
'state' => '',
);
my $last_tgid = '';
my $setit = FALSE;
my $dbgfile = "/tmp/radioctl.log";
my $bcd325p2 = FALSE;
my $model = '';
my $warn = TRUE;
my @rssi2sig = (134,320,350,375,400,425,450,475,500,522);
my %rssi2sig = ('sds' => [-200,-120,-112,-107,-105,-102,-100,-97,-94],
'bcd' => [134,320,350,375,400,425,450,475,500,522],
);
my %system_qkeys = ();
my %bcd396_systypes = (
'cnv' => 'CNV',
'ltr' => 'LTR',
'eds' => 'EDS',
'edw' => 'EDW',
'edn' => 'EDN',
'mots' => 'M82S',
'motp' => 'M82P',
'motc' => 'M92',
'p25s' => 'MP25',
'p25f' => 'MP25',
);
my %systypes_bcd396 = (
'm82s' => 'mots',
'm82p' => 'motp',
'm92'  => 'motc',
'mp25' => 'p25s',
'm81p' => 'motp',
'mv2'  => 'mots',
'mu2'  => 'mots',
'm81s' => 'mots',
);
my %bcd325p2_systypes = (
'eds' => 'EDC',
'edw' => 'EDC',
'edn' => 'EDC',
'mots' => 'MOT',
'motp' => 'MOT',
'motc' => 'MOT',
);
my %systypes_bcd325p2 = (
'edc' => 'edw',
'mot' => 'mots',
);
TRUE;
sub uniden_cmd {
my $cmdcode = shift @_;
if (!$cmdcode) {
my ($package,$filename,$line) = caller();
LogIt(1434,"UNIDEN_CMD:No command code specified. Caller=$filename at line $line");
}
my $parmref = shift @_;
if (!$parmref) {LogIt(1736,"UNIDEN_CMD:No parmref reference specified");}
if (ref($parmref) ne 'HASH') {LogIt(1437,"UNIDEN_CMD:parmref is NOT a reference to a hash! CMD=$cmdcode");}
if (!$parmref->{'def'}) {LogIt(1740,"UNIDEN_CMD:No 'def' specified in parmref");}
my $defref    = $parmref->{'def'};
if (ref($defref) ne 'HASH') {LogIt(1448,"UNIDEN_CMD:defref is NOT a reference to a hash! CMD=$cmdcode");}
my $out  = $parmref->{'out'};
if (!$out) {LogIt(1747,"UNIDEN_CMD:No 'out' defined in parmref! Command=>$cmdcode");}
if (ref($out) ne 'HASH') {LogIt(1453,"UNIDEN_CMD:Out spec in parmref is NOT a hash reference! CMD=$cmdcode");}
my $outsave = $out;
my $in   = $parmref->{'in'};
if (!$in) {LogIt(1753,"UNIDEN_CMD:No 'in' defined in parmref! Command=>$cmdcode");}
if (ref($in) ne 'HASH') {LogIt(580,"IN spec in parmref is NOT a hash reference! CMD=$cmdcode");}
my $insave = $in;
if (!$parmref->{'portobj'} and ($cmdcode ne 'autobaud')) {LogIt(1758,"UNIDEN_CMD:No portobj in parmref! CMD=$cmdcode");}
my $portobj = $parmref->{'portobj'};
my $db = $parmref->{'database'};
if ($db) {
if (ref($db) ne 'HASH') {LogIt(1463,"UNIDEN_CMD:Database spec in parmref is NOT a hash reference! CMD=$cmdcode");}
}
my $write = $parmref->{'write'};
if (!$write) {$write = FALSE;}
my $retcode = 0;
my $cmd_parms = '';
my $noprocess = FALSE;
$parmref->{'term'} = CR;
my $delay = 100;
if (!defined $radio_def{'model'}) {
LogIt(1,"No Model number was defined for this radio!");
$radio_def{'model'} = '';
}
if ($radio_def{'model'} ne 'BCD325P2') {$delay = 400;}
my @send_validate = ();
my @rcv_validate = ();
my $blockname = $cmdcode;
if ($cmdcode eq 'init') {
my %myout = ();
$parmref->{'out'} = \%myout;
if (uniden_cmd('MDL',$parmref)) {return $parmref->{'rc'};}
if ($model eq 'BCD325P2') {
$bcd325p2 = TRUE;
print "Model returned $model\n";
}
if ($model ne 'SDS200') {
if (uniden_cmd('STS',$parmref)) {return  $parmref->{'rc'};}
if ($myout{'state'} eq 'prg')  {
uniden_cmd('EPG',$parmref);
}
if ($myout{'state'} eq 'mnu') {
%myout = ('key_code' => 'H','key_mode' => 'P');
$parmref->{'out'} = \%myout;
uniden_cmd('KEY',$parmref);
uniden_cmd('STS',$parmref);
}
}
$parmref->{'out'} = $outsave;
$out = $outsave;
$out->{'model'} = $model;
$defref->{'maxfreq'} = 960000000;
$defref->{'minfreq'} = 25000000;
$defref->{'radioscan'} = 2;
$defref->{'memory'} = 'dy';
$defref->{'model'} = $model;
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmdcode eq 'autobaud') {
if (!$defref->{'model'}) {
LogIt(1,"Model number not specified in .CONF file. " .
" Cannot automatically determine port/baud");
return ($parmref->{'rc'} = 1);
}
my $model_save = $defref->{'model'};
my @allports = ();
if ($in->{'noport'} and $defref->{'port'}) {push @allports,$defref->{'port'};}
else {
if (lc($model_save) ne 'bcd396t') {@allports = glob("/dev/ttyACM*");}
else {push @allports,glob("/dev/ttyUSB*");}
}
my @allbauds = ();
if ($in->{'nobaud'}) {push @allbauds,$defref->{'baudrate'};}
else {push @allbauds,115200;}
@allbauds = sort {$b <=> $a} @allbauds;
@allports = sort {$b cmp $a} @allports;
PORTLOOP:
foreach my $port (@allports) {
my $portobj =  Device::SerialPort->new($port) ;
if (!$portobj) {next;}
$parmref->{'portobj'} = $portobj;
$portobj->user_msg("ON");
$portobj->databits(8);
$portobj->handshake('none');
$portobj->read_const_time(100);
$portobj->write_settings || undef $portobj;
$portobj->read_char_time(0);
foreach my $baud (@allbauds) {
$portobj->baudrate($baud);
$warn = FALSE;
my $rc = uniden_cmd('MDL',$parmref);
$warn = TRUE;
if (!$rc) {### command succeeded
if ($model and ($model eq $model_save)) {
$defref->{'baudrate'} = $baud;
$defref->{'port'} = $port;
$portobj->close;
$parmref->{'portobj'} = undef;
return ($parmref->{'rc'} = $GoodCode);
}
else {
$defref->{'model'} = $model_save;
$model = $model_save;
next PORTLOOP;
}
}
}
$portobj->close;
$parmref->{'portobj'} = undef;
}
return ($parmref->{'rc'} = 1);
}
if ($cmdcode eq 'manual') {
my %myout = ('jpm_mode' => 'SCN_MODE');
$parmref->{'out'} = \%myout;
uniden_cmd('JPM',$parmref);
$parmref->{'out'} = \%myout;
%myout = ('key_code' => 'H','key_mode' => 'P');
if ($model eq 'SDS200') {
$myout{'key_code'} = 'C';
}
uniden_cmd('KEY',$parmref);
if ($model ne 'SDS200') {
uniden_cmd('GLG',$parmref);
}
uniden_cmd('getsig',$parmref);
return ($parmref->{'rc'} = $GoodCode);
}
if ($cmdcode eq 'vfoinit') {
my %myout = ('jpm_mode' => 'QSH_MODE');
$parmref->{'out'} = \%myout;
uniden_cmd('JPM',$parmref);
return ($parmref->{'rc'});
}
if ($cmdcode eq 'meminit') {
if ($state_save{'state'} ne "sch") {
if ($state_save{'state'} =~ /sc/i) { 
my %myout = ('key_code' => 'S','key_mode' => 'P');
$parmref->{'out'} = \%myout;
uniden_cmd('KEY',$parmref);
uniden_cmd('STS',$parmref);
$parmref->{'out'} = $outsave;
$out = $outsave;
}
if ($state_save{'state'} eq "scn") {
my %myout = ('key_code' => 'H','key_mode' => 'P');
$parmref->{'out'} = \%myout;
uniden_cmd('KEY',$parmref);
uniden_cmd('STS',$parmref);
$parmref->{'out'} = $outsave;
$out = $outsave;
}
}
}
if ($cmdcode eq 'scan'   ) {
my %myout = ('jpm_mode' => 'SCN_MODE');
$parmref->{'out'} = \%myout;
uniden_cmd('JPM',$parmref);
uniden_cmd('STS',$parmref);
$parmref->{'out'} = $outsave;
$out = $outsave;
return ($parmref->{'rc'});
}
if ($cmdcode eq 'selmem') {
return ($parmref->{'rc'} = $NotForModel);
}
elsif ($cmdcode eq '_getall') {
if (lc($model) eq 'sds200') {
LogIt(1,"Cannot issue _getall for SDS200");
return ($parmref->{'rc'} = 11);
}
$retcode = 0;
if (!$parmref->{'database'}) {LogIt(1573,"No database reference for GET_SYSTEMS");}
my $db = $parmref->{'database'};
$parmref->{'write'} = FALSE;
if (uniden_cmd('PRG',$parmref)) {
add_message("_GETALL: command failed to get Uniden into program state!");
return $parmref->{'rc'};
}
my %work_blk = ();
$parmref->{'out'} = \%work_blk;
%system_qkeys = ();
if (uniden_cmd('QSL',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg("GETMEM:Could not fetch SYSTEM quick-keys!", $parmref);
}
foreach my $qk (sort keys %system_qkeys) {
my %rcd = ($qk => $system_qkeys{$qk});
add_a_record($db,'sysqk',\%rcd);
}
my %used_qkeys = ();
if (uniden_cmd('SIH',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg("_GETALL:Could not fetch Uniden System Head (SIH)!",$parmref);
}
my $sin_index = $work_blk{'block_addr'};
while ($sin_index ne '-1') {
%work_blk = ('block_addr' => $sin_index);
if (uniden_cmd('SIN',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg("_GETALL:Could not fetch Uniden System Info block (SIN) =$sin_index!",$parmref);
}
$work_blk{'valid'} = !$work_blk{'lout'};
my $systemname = $work_blk{'service'};
my $systemtype = lc($work_blk{'systemtype'});
if (!$systemtype) {
print Dumper(%work_blk),"\n";
print Dumper($parmref),"\n";
LogIt(2366,"Uniden l2265:Bad SYSTEMTYPE in SIN");
}
my $qkey = $work_blk{'qkey'};
if (($qkey ne '.') and (looks_like_number($qkey))) {
if ($used_qkeys{$qkey}) {### warn about multiple assignments
$used_qkeys{$qkey} = "$used_qkeys{$qkey},$systemname";
LogIt(1,"Uniden l2106:Multiple systems assigned to system quickkey $qkey:$used_qkeys{$qkey}");
}
else {$used_qkeys{$qkey} = $systemname;}
if (!$system_qkeys{$qkey}) {
LogIt(2106,"Uniden l2114:Quickkey set in SYSTEM $work_blk{'service'} ($sin_index) but Not returned by 'QSL'!");
}
if ($system_qkeys{$qkey} eq 'on') {$work_blk{'qkeyon'} = TRUE;}
else {$work_blk{'qkeyon'} = FALSE;}
}
else {
if ($systemtype eq 'cnv') {
LogIt(1,"Uniden l2153:No quick key assigned to system $work_blk{'service'} ($sin_index)" .
" systemtype=>$work_blk{'systemtype'}");
}
}
my $sysno = add_a_record($db,'system',\%work_blk);
$sin_index = $work_blk{'fwd_index'};
}
$parmref->{'out'} = $outsave;
uniden_cmd('EPG',$parmref);
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmdcode eq 'getinfo') {
if (uniden_cmd('MDL',$parmref)) {
add_message("GETINFO:Could not get Uniden model number!");
return $parmref->{'rc'};
}
if (substr(lc($model),0,3)  eq 'bcd') {
if (uniden_cmd('PRG',$parmref)) {
add_message("_GETALL: command failed to get Uniden into program state!");
return $parmref->{'rc'};
}
uniden_cmd('MEM',$parmref);
uniden_cmd('RMB',$parmref);
uniden_cmd('EPG',$parmref);
uniden_cmd('BAV',$parmref);
if (!$out->{'bat_level'}) {$out->{'bat_level'} = 0;}
$out->{'bat_level'} = sprintf("%.2f",(3.2 * $out->{'bat_level'} * 2)/1023);
}
else {
}
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmdcode eq 'getsrch') {
LogIt(0,"Getting search records");
$parmref->{'write'} = FALSE;
if (uniden_cmd('PRG',$parmref)) {
add_message("GETMEM: command failed to get Uniden into program mode!");
return $parmref->{'rc'};
}
my %work_blk = ();
$parmref->{'out'} = \%work_blk;
foreach my $channel (0..9) {
$parmref->{'write'} = FALSE;
%work_blk = ('channel' => $channel);
if (uniden_cmd('CSP',$parmref)) {
add_message("GETSRCH:Command failed CSP!");
$retcode = $parmref->{'rc'};
last;
}
my $recno =  add_a_record($db,'search',\%work_blk,$parmref->{'gui'});
}
$parmref->{'out'} = $outsave;
uniden_cmd('EPG',$parmref);
return ($parmref->{'rc'});
}
elsif ($cmdcode eq 'setsrch') {
$parmref->{'write'} = FALSE;
if (uniden_cmd('PRG',$parmref)) {
add_message("GETMEM: command failed to get Uniden into program mode!");
return $parmref->{'rc'};
}
my %work_blk = ();
$parmref->{'out'} = \%work_blk;
LogIt(0,"setting SEARCH records into the radio...");
my $channel = 1;
foreach my $recno (1..10) {
if ($db->{'search'}[$recno]{'index'}) {
$parmref->{'write'} = TRUE;
%work_blk = ('channel' => $channel);
foreach my $key (keys %{$db->{'search'}[$recno]}) {
$work_blk{$key} = $db->{'search'}[$recno]{$key};
}
if (uniden_cmd('CSP',$parmref)) {
add_message("GETGLOB:Command failed CSP!");
$retcode = $parmref->{'rc'};
last;
}
$channel++;
if ($channel > 9) {$channel = 0;}
}
else {last;}
}
$parmref->{'out'} = $outsave;
uniden_cmd('EPG',$parmref);
return ($parmref->{'rc'});
}
elsif ($cmdcode eq 'getmem') {
if (!$in) {LogIt(1630,"UNIDEN_CMD:No 'in' defined in parmref for GETMEM");}
if (!$db) {LogIt(1631,"UNIDEN_CMD:No 'database' defined in parmref for GETMEM");}
$retcode = 0;
if (!$model) {
if (uniden_cmd('MDL',$parmref)) {
add_message("GETMEM:Could not get Uniden model number!");
return $parmref->{'rc'};
}
}
if (lc($model) eq 'sds200') {
LogIt(0,"UNIDEN GetMem l2216:Calling SDSx00 routine");
Get_All_SDS($parmref);
LogIt(0,"UNIDEN GetMem l2218:SDSx00 routine Finished");
return $parmref->{'rc'};
}
my $startstate = $progstate;
my %allsys = ();
my @systems = ();
$parmref->{'database'} = \%allsys;
my $rc = uniden_cmd('_getall',$parmref);
$parmref->{'database'} = $db;
if ($rc) {
add_message("UNIDEN:GETMEM-Could not get systems in this Uniden radio!");
return $rc;
}
my $syscount = scalar @{$allsys{'system'}};
if (!$syscount) {
add_message("UNIDEN:GETMEM-Could not get systems in this Uniden radio!");
return ($parmref->{'rc'} = $EmptyChan);
}
if ($in->{'blk'} or $in->{'num'} or $in->{'nam'}) {
if ($in->{'clear'}) {$in->{'clear'} = FALSE;}
select_systems($in,\%allsys,\@systems);
}### Requesting specific systems
else {
my $firstnum = 1;
if ($in->{'firstnum'}) {
if (!looks_like_number($in->{'firstnum'})) {
add_message("UNIDEN:GETMEM - Bad 'firstnum' =>$in->{'firstnum'}!");
return ($parmref->{'rc'} = $ParmErr);
}
if ($in->{'firstnum'} > $syscount) {
LogIt(1,"UNIDEN:GETMEM - Specified firstnum $in->{'firstnum'} > systems ($syscount). Changed to 1");
}
else {$firstnum = $in->{'firstnum'};}
}
my $maxcount = $syscount - $firstnum + 1;
if ($in->{'count'}) {
if (!looks_like_number($in->{'count'})) {
add_message("UNIDEN:GETMEM - Bad 'count' => $in->{'count'}!");
return ($parmref->{'rc'} = $ParmErr);
}
if ($in->{'count'} > $maxcount) {
LogIt(1,"UNIDEN:GETMEM - Count specified ($in->{'count'}) exceeds record count. Changed to $maxcount");
}
else {$maxcount = $in->{'count'};}
}
my $cnt = 0;
while ($cnt < $maxcount) {
if ($allsys{'system'}[$firstnum]) {push @systems,$allsys{'system'}[$firstnum];}
$cnt++;
$firstnum++;
}
}### Non specific request
if (!scalar @systems) {
add_message("UNIDEN:GETMEM-No systems found or selected in this Uniden radio!");
return ($parmref->{'rc'} = $EmptyChan);
}
my $notrunk = $in->{'notrunk'};
if (!$notrunk) {$notrunk = FALSE;}
my $firstdbsysno = 0;
my $count = 0;
my $p2 = FALSE;
if ($radio_def{'model'} eq 'BCD325P2') {$p2 = TRUE;}
$parmref->{'write'} = FALSE;
if (uniden_cmd('PRG',$parmref)) {
add_message("GETMEM: command failed to get Uniden into program mode!");
return $parmref->{'rc'};
}
my %work_blk = ();
$parmref->{'out'} = \%work_blk;
my @system_keys =  @{$structure{'system'}};
my @group_keys  =  @{$structure{'group'}};
my @site_keys   =  @{$structure{'site'}};
my @tfreq_keys   =  @{$structure{'tfreq'}};
my @freq_keys   =  @{$structure{'freq'}};
my @chan_keys   = @freq_keys;
my $outstr = '';
my $rcchan = 0;
SYSLP:# while (($count < $maxcount) and ($currentsys <= $maxsysno)) {
foreach my $rcd (@systems) {
threads->yield;
if ($progstate ne $startstate) {last SYSLP;}
my $sysndx = $rcd->{'index'};
if (!$parmref->{'gui'}) {
print STDERR "\rretrieving radio system $sysndx ";
}
my %sin_block = %{$rcd};
my $systype = lc($sin_block{'systemtype'});
if ($notrunk and ($systype ne 'cnv')) {
LogIt(0,"\nBypassing $sysndx type $systype");
next SYSLP;
}
my $sinndx = $sin_block{'block_addr'};
if ($debug3) {LogIt(0,"UNIDEN_CMD l1732:systype from SIN=$systype");}
if (($systype eq 'm82s') or ($systype eq 'm81s')) {$systype = 'mots';}
elsif (($systype eq 'm82p') or ($systype eq 'm81p')) {$systype = 'motp';}
elsif ( ($systype eq 'm92') or ($systype eq 'mv2') or ($systype eq 'mu2')) {$systype = 'motc';}
elsif ($systype eq 'mp25') {$systype = 'p25s';}
elsif ($systype eq 'turbo') {$systype = 'trbo';}
$sin_block{'systemtype'} = $systype;
KeyVerify(\%sin_block, @system_keys);
my $sysno = add_a_record($db,'system',\%sin_block,$parmref->{'gui'});
if (!$firstdbsysno) {$firstdbsysno = $sysno;}
$db->{'system'}[$sysno]{'end_code'} = 'Ignore';
if ($debug2) {LogIt(0,"UNIDEN_CMD l1738:finished getting SIN block");}
my $grpno  = 1;
my $channo = -1;
my $siteno = 1;
my $freqno = 1;
my $trnkno = 1;
my $grpndx = $sin_block{'chn_head'};
my $chncmd  = 'CIN';
if ($systype ne 'cnv') {
$chncmd = 'TIN';
my $sifndx = $grpndx;
%work_blk = ('block_addr' => $sinndx);
if (uniden_cmd('TRN',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg(
"GETMEM:Could not fetch Uniden Trunk Info Block (TRN) for index $sinndx!",
$parmref);
}
my @trunk_keys = ();
foreach my $key (keys %work_blk) {
my $value = $work_blk{$key};
if ($key eq 'block_addr') {next;}
elsif ($key eq 'rsvd') {next;}
push @trunk_keys,$key;
}
KeyVerify(\%work_blk,@trunk_keys);
foreach my $key (@trunk_keys) {
$db->{'system'}[$sysno]{$key} = $work_blk{$key};
}
if ($debug2) {LogIt(0,"UNIDEN l1511:finished getting TRN block $sinndx");}
$grpndx = $work_blk{'chn_head'};
my $firstsif = TRUE;
my $foundsite = FALSE;
my %site_keys = ();
if ( $db->{'system'}[$sysno]{'qkey'} ne '.') {
$site_keys{$db->{'system'}[$sysno]{'qkey'}} = TRUE;
}
SITE:    while ($sifndx != -1) {
if ($progstate ne $startstate) {last SYSLP;}
%work_blk = ('block_addr' => $sifndx);
if ($p2) {
if (uniden_cmd('SIF',$parmref)) {
add_message("GETMEM:Cannot read Uniden SIF block at $sifndx");
foreach my $key (keys %sin_block) {LogIt(0,"$key => $sin_block{$key}");}
LogIt(0,"sent =>$parmref->{'sent'} rcv=>$parmref->{'str'} rc=>$parmref->{'rc'}");
last SITE;
}### Error encountered
if ($firstsif) {
my $newsystype = '';
if ($systype eq 'edw') {
my $edwtype = lc($work_blk{'edacs_type'});
if ($edwtype eq 'wide') {$newsystype = 'edw';}
elsif ($edwtype eq 'narrow') {$newsystype = 'edn';}
else {add_message("GETMEM:unhandled EDACS type $edwtype");}
}
elsif ($systype eq 'mots') {
my $mottype = lc($work_blk{'mot_type'});
if ($mottype eq 'std') {$newsystype = 'mots';}
elsif ($mottype eq 'spl') {$newsystype = 'motp';}
elsif ($mottype eq 'custom') {$newsystype = 'motc';}
else {add_message("GETMEM:unhandled MOTO type $mottype");}
}
else { }
if ($newsystype) {
$db->{'system'}[$sysno]{'systemtype'} = uc($newsystype);
$systype = $newsystype;
if ($debug3) {LogIt(0,"Changed systype to $systype");}
}
my $sqk = $work_blk{'qkey'};
}### FIRST SIF process
}### BDC325P2
else {
if (uniden_cmd('GIN',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg(
"GETMEM:Could not Read Uniden Group Info Block (GIN) for index $sifndx!",
$parmref);
}### GIN error
$foundsite = TRUE;
}### Older radio
$work_blk{'sysno'} = $sysno;
$work_blk{'valid'} = !$work_blk{'lout'};
if ($work_blk{'valid'}) {$foundsite = TRUE;}
if ($p2 and $work_blk{'valid'}) {
my $qkey = $work_blk{'qkey'};
if (($qkey ne '.') and (looks_like_number($qkey))) {
$qkey = $qkey + 0;
my $sysqkey = $db->{'system'}[$sysno]{'qkey'};
if (!defined $sysqkey) {
print Dumper($db->{'system'}[$sysno]),"\n";
LogIt(2633,"Uniden l2633: 'qkey' key was not defaulted!");
}
if (($sysqkey eq '.')) { $db->{'system'}[$sysno]{'qkey'} = $qkey;}
$site_keys{$qkey} = TRUE;
}### quickkey defined
else {LogIt(1,"Uniden l2659:No quickkey assigned for site $siteno ($db->{'site'}[$siteno]{'service'} ) for system $sysno!");}
}### BDC325P2
KeyVerify(\%work_blk,@site_keys);
$siteno = add_a_record($db,'site',\%work_blk);
if ($debug2) {LogIt(0,"UNIDEN l1591:finished getting SIF/GIN block $sifndx");}
my $tfqndx = $work_blk{'chn_head'};
$sifndx = $work_blk{'fwd_index'};
if (lc($db->{'site'}[$siteno]{'mot_type'}) eq 'custom') {
%work_blk = ('block_addr' => $db->{'site'}[$siteno]{'block_addr'});
if (uniden_cmd('MCP',$parmref)) {
LogIt(1,"Could not retrieve Bandplan for Site $siteno");
}
else {
$work_blk{'siteno'} = $siteno;
$work_blk{'flags'} = '';
my $bplan = add_a_record($db,'bplan',\%work_blk);
}
}
while ($tfqndx ne '-1') {
if ($progstate ne $startstate) {last SYSLP;}
%work_blk = ('block_addr' => $tfqndx);
if (uniden_cmd('TFQ',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg(
"GETMEM:Could not Read Trunked Frequency (TFQ) for index $tfqndx!",
$parmref);
}### TFQ error encountered
$work_blk{'siteno'} = $siteno;
$work_blk{'valid'} = !$work_blk{'lout'};
$work_blk{'ccode'} = 'Srch';
$work_blk{'flags'} = '';
KeyVerify(\%work_blk,@tfreq_keys);
my $tfreqno = add_a_record($db,'tfreq',\%work_blk);
if ($debug2) {LogIt(0,"UNDEN l1615:finished getting TFQ block $tfqndx");}
$tfqndx = $work_blk{'fwd_index'};
}### all the TFQs
}### get all sites
if ($foundsite) {
my $sysqkey = $db->{'system'}[$sysno]{'qkey'};
if ($sysqkey ne '.') {
if ($system_qkeys{$sysqkey} eq 'on') {$db->{'system'}[$sysno]{'qkeyon'} = TRUE;}
else {$db->{'system'}[$sysno]{'qkeyon'} = FALSE;}
}
else {
LogIt(1,"Uniden 2761:No valid system quickkey was defined for $db->{'system'}[$sysno]{'service'}");
}
}
else {
LogIt(1,"Uniden l2761:No valid sites found for system $db->{'system'}[$sysno]{'service'}!");
$db->{'system'}[$sysno]{'valid'} = FALSE;
}
}### Trunked system unique process
if ($debug3) {LogIt(0,"UNIDEN 1610:Group index=$grpndx");}
my %group_qkeys = ();
print "\n Uniden l2736 system $sysno address=>$sinndx name=>$sin_block{'service'}\n";
%work_blk = ('block_addr' => $sinndx, 'grpkey' => \%group_qkeys);
if (uniden_cmd('QGL',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg(
"GETMEM:Could not fetch GROUP keys for index $sinndx!",
$parmref);
}
my %used_gkeys = ();
GRP:  while ($grpndx ne '-1') {
if ($progstate ne $startstate) {last SYSLP;}
%work_blk = ('block_addr' => $grpndx);
if (uniden_cmd('GIN',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg(
"GETMEM:Could not Read Uniden Group Info Block (GIN) for index $grpndx!",
$parmref);
}
$work_blk{'sysno'} = $sysno;
$work_blk{'valid'} = !$work_blk{'lout'};
my $gqkey = $work_blk{'gqkey'};
my $keymsg = '';
if (($gqkey ne '.')) {
if ($group_qkeys{$gqkey}) {
if ($group_qkeys{$gqkey} eq 'off') {$work_blk{'valid'} = FALSE;}
else {$work_blk{'valid'} = TRUE;}
}
else {
print "\n",Dumper(%group_qkeys),"\n";
LogIt(2887,"Uniden l2887:Group quickkey $gqkey was defined in group $work_blk{'service'} but not in QGL!\n" .
"   system=>$db->{'system'}[$sysno]{'service'}");
}
if ($used_gkeys{$gqkey}) {
$keymsg = "Other groups also have the same quickkey:$Green$gqkey$White";
}
else {$used_gkeys{$gqkey} = TRUE;}
}
else {$keymsg = "No quickkey assigned for this group";}
KeyVerify(\%work_blk,@group_keys);
$grpno = add_a_record($db,'group',\%work_blk,$parmref->{'gui'});
if ($keymsg) {LogRad(1,$db,'group',$grpno,$keymsg);}
if ($debug2) {LogIt(0,"UNIDEN l1648:finished getting GIN block $grpndx");}
my $chnndx = $work_blk{'chn_head'};
my %grpblk = %work_blk;
if ($chnndx eq '-1') {
my $msg = "No channels found for this group";
LogRad(1,$db,'group',$grpno,$msg);
}
$grpndx = $work_blk{'fwd_index'};
if ($debug2) {LogIt(0,"UNIDEN l1649: Next group address=$grpndx");}
$channo = 0;
CHN:     while ($chnndx ne '-1') {
if ($progstate ne $startstate) {last SYSLP;}
%work_blk = ('block_addr' => $chnndx);
if (uniden_cmd($chncmd,$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg(
"\n GETMEM:Could not Read Uniden $chncmd for index $chnndx!",
$parmref);
}### error encountered
$work_blk{'tone'} = 'off';
$work_blk{'tone_type'} = 'off';
$work_blk{'tone_search'} = FALSE;
if ($work_blk{'adtype'} and looks_like_number($work_blk{'adtype'})){
if ($work_blk{'adtype'} > 2 ) {$work_blk{'adtype'} = 2;}
}
else {$work_blk{'adtype'} = 0;}
$work_blk{'tone_type'} = 'off';
$work_blk{'tone'} = 'off';
if ($work_blk{'adtype'} == 2) {
if (!$work_blk{'p25nac'}) {$work_blk{'p25nac'} = 0;}
if (lc($work_blk{'p25nac'}) ne 'srch') {
my $tone = hex($work_blk{'p25nac'});
if ($tone > 4095) {
$work_blk{'tone_type'} = 'CCode';
$work_blk{'tone'} = $tone - 4096;
}
else {
$work_blk{'tone'} = $work_blk{'p25nac'};
$work_blk{'tone_type'} = 'NAC';
}
}## not SRCH for P25NAC
}### Digital mode
elsif ($work_blk{'adtype'} == 1) {
if ($work_blk{'ctcsdcs'}) {
my $ctcss = $work_blk{'ctcsdcs'};
if ($ctcss > 127) {
$work_blk{'tone_type'} = 'DCS';
$work_blk{'tone'} = $tonestring[$ctcss - 127];
}
elsif ($ctcss == 127) {$work_blk{'tone_search'} = TRUE;}
elsif ($ctcss > 113) {LogIt(1,"UNIDEN_CMD l1862:Unknown CTCSS Code => $ctcss!");}
elsif ($ctcss > 63) {
$work_blk{'tone_type'} = 'CTCSS';
$work_blk{'tone'} = $tonestring[$ctcss - 63];
}
else {LogIt(1,"UNIDEN_CMD l1869:Unknown CTCSS Code => $ctcss");}
}
}### Analog only tone process
$work_blk{'_rcchan'} = ++$rcchan;
if ($systype eq 'cnv') {
$work_blk{'lcn'} = '-';
$work_blk{'tgid'} = '-';
$work_blk{'tgid_valid'} = FALSE;
$work_blk{'channel'} = ++$channo;
$work_blk{'rec_type'} = 'f';
}
else {
$work_blk{'frequency'} = 0;
$work_blk{'mode'} = '-';
$work_blk{'tgid_valid'} = TRUE;
$work_blk{'channel'} = '-';
$work_blk{'rec_type'} = 'g';
}
$work_blk{'valid'} = TRUE;
if ($work_blk{'lout'}) {$work_blk{'valid'} = FALSE;}
$work_blk{'bcdatt'} = $work_blk{'atten'};
KeyVerify(\%work_blk,@freq_keys);
$work_blk{'groupno'} = $grpno;
$work_blk{'sysno'} = $sysno;
my $newrec = add_a_record($db,'freq',\%work_blk,$parmref->{'gui'});
if ($debug2) {LogIt(0,"UNIDEN l1681:finished getting $chncmd block $chnndx");}
$chnndx = $work_blk{'fwd_index'};
}### channel process
}### group process
$count++;
}#### while count
LogIt(0,"GETMEM complete");
uniden_cmd('EPG',$parmref);
$parmref->{'out'} = $outsave;
$out ->{'sysno'} = $firstdbsysno;
$out ->{'count'} = $count;
return ($parmref->{'rc'} = $GoodCode);
}### GETMEM
elsif ($cmdcode eq 'setmem') {
$ready = TRUE;
if (!$db) {LogIt(2160,"UNIDEN_CMD:No 'database' defined in parmref for SETMEM");}
if ($debug1) {LogIt(0,"Processing UNIDEN SETMEM command");}
my $erase = FALSE;
my $dumpit = TRUE;
my $nodie = FALSE;
if ($in->{'erase'}) {$erase = TRUE;}
if ($in->{'dump'}) {$dumpit = TRUE;}
if ($in->{'nodie'}) {$nodie = TRUE;}
if (!$model) {
if (uniden_cmd('MDL',$parmref)) {
add_message("SETMEM:Could not get Uniden model number!");
return $parmref->{'rc'};
}
}
if ((lc($model) eq 'sds200') or (lc($model) eq 'sds100'))  {
LogIt(0,"$Bold$Red" . "Error!$White Setmem cannot be used with model$Green $model");
return ($parmref->{'rc'} = $NotForModel);
}
my $p2 = FALSE;
if ($model eq 'BCD325P2') {$p2 = TRUE;}
my @systems = @{$db->{'system'}};
my $retcode = 0;
SYSPROC:
foreach my $sysrec (@systems) {
if ($sysrec->{'_bypass'}) {next;}
my $sysno = $sysrec->{'index'};
if (!$sysno) {next;}
my $systype = $sysrec->{'systemtype'};
if (!$systype) {
LogIt(1,"SETMEM l3486:No 'systemtype' key set in $sysno! Cannot process!");
$sysrec->{'_bypass'} = TRUE;
$retcode = $ParmErr;
next SYSPROC;
}
$systype = lc(Strip($systype));
if (!$system_type_valid{$systype}) {
LogIt(1,"SETMEM l3494:System $Yellow$sysrec->{'service'}$White ($Green$sysno$White) " .
"type $Magenta$systype$White is NOT a valid RadioCtl system type");
$retcode = $ParmErr;
$sysrec->{'_bypass'} = TRUE;
next SYSPROC;
}
if ((!$p2) and (!$bcd396_systypes{$systype})) {
LogIt(1,"SETMEM l3664:System $Yellow$sysrec->{'service'}$White ($Green$sysno$White) " .
"type $Magenta$systype$White is NOT a valid for model $model");
$retcode = $NotForModel;
$sysrec->{'_bypass'} = TRUE;
next SYSPROC;
}
my $sqkey = '.';
if ((!$p2) or ($systype eq 'cnv')) {
$sqkey = $sysrec->{'qkey'};
if (!$sqkey or ($sqkey eq '.') or  (!looks_like_number($sqkey)) or ($sqkey > 99)) {
LogIt(1,"SETMEM l3513:System number $sysno quickkey:$sqkey is NOT valid! Cannot process.");
$retcode = $ParmErr;
$sysrec->{'_bypass'} = TRUE;
next SYSPROC;
}
$sqkey = $sqkey + 0;
}
else {
my $sitecount = 0;
SITEPROC:   foreach my $siterec (@{$db->{'site'}}) {
if ($siterec->{'_bypass'}) {next;}
my $siteno = $siterec->{'index'};
if (!$siteno) {next;}
if ($siterec->{'sysno'} ne $sysno) {next;}
my $qkey = $siterec->{'qkey'};
if (!$qkey or ($qkey eq '.') or (!looks_like_number($qkey)) or ($qkey > 99)) {
LogIt(1,"SETMEM l3538:Site $Yellow$siterec->{'service'}$White " .
"($Green$siteno$White) quickkey is NOT valid! Cannot process.");
$retcode = $ParmErr;
$siterec->{'_bypass'} = TRUE;
next;
}
$qkey = $qkey + 0;
if (($sqkey ne '.') and ($qkey ne $sqkey)) {
LogIt(1,"Uniden 3548:Different quickkey on site $siteno (key=$qkey) than on system $sysno (key=$sqkey)");
}
my $tfcnt = 0;
foreach my $tfrec (@{$db->{'tfreq'}}) {
if ($tfrec->{'_bypass'}) {next;}
if (!$tfrec->{'index'}) {next;}
if ($tfrec->{'siteno'} != $siteno) {next;}
$tfcnt++;
}
if (!$tfcnt) {
LogIt(1,"SETMEM l3560 :No valid tfreq records found for site $siterec->{'service'} Cannot process.");
$siterec->{'_bypass'} = TRUE;
$retcode = $EmptyChan;
next SITEPROC;
}
$sitecount++;
}
if (!$sitecount) {
LogIt(1,"SETMEM l3570:No valid sites found for system $Yellow$sysrec->{'service'}$White" .
"($Green$sysno$White). Cannot process.");
$retcode = $EmptyChan;
$sysrec->{'_bypass'} = TRUE;
next;
}
}### trunked system
my $firstgrprec = 0;
my $groupcnt = 0;
my $validcnt = 0;
GRPPROC: foreach my $grprec (@{$db->{'group'}}) {
if ($grprec->{'_bypass'}) {next;}
my $grpno = $grprec->{'index'};
if (!$grpno) {next;}
if ($grprec->{'sysno'} ne $sysno) {next;}
my $qkey = $grprec->{'gqkey'};
if (!defined $qkey) {$qkey = '.';}
if (($qkey eq '.') or (!looks_like_number($qkey)) or ($qkey < 0) or ($qkey > 99) ) {
LogIt(1,"SETMEM l3671:Group quickkey $Magenta$qkey$White ".
"for group $Yellow$grprec->{'service'}$White ".
"($Green$grpno)$White is not valid. Cannot process!");
$retcode = $ParmErr;
$grprec->{'_bypass'} = TRUE;
next GRPPROC;
}
my $oldqkey = $qkey;
$qkey = $qkey % 10;
if ($oldqkey > 9) {LogIt(0,"Quickkey ($oldqkey) for group $grpno will be adjusted to $qkey for radio compatibility.");}
$qkey = $qkey + 0;
$grprec->{'qkey'} = $qkey;
$grprec->{'_oldqkey'} = $oldqkey;
my $chanfound = FALSE;
foreach my $freq (@{$db->{'freq'}}) {
if ($freq->{'_bypass'}) {next;}
if (!$freq->{'index'}) {next;}
if ($freq->{'groupno'} == $grpno) {
$chanfound = TRUE;
last;
}
}
if ($chanfound) {
if (!$firstgrprec) {$firstgrprec = $grprec;}
$groupcnt++;
if ($grprec->{'valid'}) {$validcnt++;}
}
else {
LogIt(1,"SETMEM l3612:No channels assigned to group " .
"$Yellow$grprec->{'service'}$White) ($Green$grpno$White). Group setting bypassed.");
$grprec->{'_bypass'} = TRUE;
next;
}
}### check for all groups
if ((!$groupcnt) and (!$retcode)) {
LogIt(1,"SETMEM l3659:No groups found for system  $Yellow$sysrec->{'service'}$White" .
"($Green$sysno$White). Cannot process.");
$retcode = $EmptyChan;
$sysrec->{'_bypass'} = TRUE;
next;
}
if (!$validcnt) {
LogIt(1,"SETMEM l3669:No groups with 'valid' set! " .
"Turning on first group to prevent problems!");
$firstgrprec->{'valid'} = TRUE;
}
if ($groupcnt > 20) {
LogIt(1,"SETMEM L3679: More than 20 groups defined. " .
"Group storage may get exhasted during writing...");
}
}### check of all systems
if ($retcode) {
if ($nodie) {
LogIt(1,"SETMEM will store only Database records NOT in error");
}
else {
LogIt(1,"Radio was NOT updated due to database errors! Retcode=$retcode");
return ($parmref->{'rc'} = $retcode);
}
}
my %allsys = ();
my @delsys = ();
if ($in->{'erase'}) {
$parmref->{'database'} = \%allsys;
my $rc = uniden_cmd('_getall',$parmref);
$parmref->{'database'} = $db;
foreach my $sysrec (@systems) {
if ($sysrec->{'_bypass'}) {next;}
my $name = Strip($sysrec->{'service'});
foreach my $radsys (@{$allsys{'system'}}) {
if (!$radsys ->{'index'}) {next;}
my $thisname = Strip($radsys->{'service'});
my $len = length($thisname);
if ($thisname eq substr($name,0,$len)) {
push @delsys,$radsys;
print "Uniden l3252:Scheduled system $name for removal\n";
}
}## for each system in the radio
}### Each database system
}### Removing systems
my $count = 0;
$parmref->{'write'} = FALSE;
if (uniden_cmd('PRG',$parmref)) {
add_message("SETMEM: command failed to get Uniden into program state!");
return $parmref->{'rc'};
}
my %work_blk = ();
$parmref->{'outsave'} = $outsave;
$parmref->{'out'} = \%work_blk;
my $startstate = $progstate;
%system_qkeys = ();
$parmref->{'write'} = FALSE;
if (uniden_cmd('QSL',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg("GETMEM:Could not fetch SYSTEM quick-keys!", $parmref);
}
foreach my $sin (@delsys) {
my $addr = $sin->{'block_addr'};
LogIt(0,"$Bold Deleting system $Yellow$sin->{'service'}$White (addr=>$Green$addr) ");
%work_blk = ('block_addr' => $addr);
my $system_cnt = 0;
if ($ready) {
if (uniden_cmd('DSY',$parmref)) {
add_message("SETMEM:unable to delete addr=$sin");
}
else {
$parmref->{'quiet'} = TRUE;
if (! uniden_cmd('SCT',$parmref)) {$system_cnt = $work_blk{'system_cnt'};}
if ($debug3) {LogIt(0,"SCT returned=>$parmref->{'rcv'}");}
while (uniden_cmd('SCT',$parmref)) {
if ($debug3) {LogIt(0,"Issued SCT waiting for system");}
sleep 1;
}
while (! uniden_cmd('nop',$parmref)) {
if ($debug3) {LogIt(0,"Waiting for bus to clear");}
}
$parmref->{'quiet'} = FALSE;
if ($debug3) {LogIt(0,"After delete number of systems=$system_cnt");}
}### delete successful
}### ready
else {LogIt(0,"  bypassed clear. block_addr=$sin");}
}
$retcode = 0;
my $firstpass = TRUE;
my $system_cnt = 0;
$parmref->{'write'} = TRUE;
SYSNO:foreach my $sysrec (@systems) {
if ($sysrec->{'_bypass'}) {next SYSNO;}
threads->yield;
if ($progstate ne $startstate) {last SYSNO;}
my $sysno = $sysrec->{'index'};
if (!$sysno) {next;}
my $qkey = $sysrec->{'qkey'};
if (defined $qkey and looks_like_number($qkey)) {
$qkey = $qkey + 0;
if ($sysrec->{'qkeyon'}) {
$system_qkeys{$qkey} = 'on';
}
}
my %group_qkeys = ();
my $sysndx = -1;
my $systype = lc(Strip($sysrec->{'systemtype'}));
my $radio_systype = uc($systype);
if ($p2) {
if ($bcd325p2_systypes{$systype}) {
$radio_systype = uc($bcd325p2_systypes{$systype});
}
}
else {
$radio_systype = uc($bcd396_systypes{$systype});
}
%work_blk = ('systemtype' => $radio_systype, 'block_addr' => 0);
if ($ready) {
if (uniden_cmd('CSY',$parmref)){
return exit_prg(
"SETMEM:Could not create new system $sysno of system type $systype!",
$parmref);
}### CSY failed
}### ready
$sysndx = $work_blk{'block_addr'};
LogIt(0,"Uniden l3927:Created new system block address=$sysndx");
if ($sysndx eq '-1') {
$parmref->{'rc'} = $OtherErr;
print Dumper(%work_blk),"\n";
return exit_prg("SETMEM l3931:Radio system capacity exceeded!",$parmref);
}
$db->{'system'}[$sysno]{'block_addr'} = $sysndx;
%work_blk = %{$db->{'system'}[$sysno]};
$work_blk{'lout'} = !$work_blk{'valid'};
$work_blk{'systemtype'} = $radio_systype;
$parmref->{'write'} = TRUE;
if ($ready) {
if (uniden_cmd('SIN',$parmref)){
return exit_prg("SETMEM l3945:Cannot update SIN for system $sysno ",$parmref);
}### failure
}### ready
my $grpcmd = 'AGC';
my $chncmd = 'ACC';
my $chantype = 'freq';
my $chnblk = 'CIN';
my %group_quickkeys = ();
threads->yield;
if ($progstate ne $startstate) {last SYSNO;}
if ($systype ne 'cnv') {
$grpcmd = 'AGT';
$chncmd = 'ACT';
$chnblk = 'TIN';
$chantype = 'tgid';
%work_blk = %{$db->{'system'}[$sysno]};
$parmref->{'write'} = TRUE;
if ($ready) {
if (uniden_cmd('TRN',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg("SETMEM l3988:Cannot update TRN for system $sysno ",$parmref);
}### failure
}
my $sitecount = 0;
foreach my $siterec (@{$db->{'site'}}) {
threads->yield;
if ($progstate ne $startstate) {last SYSNO;}
if ($siterec->{'_bypass'}) {next;}
my $siteno = $siterec->{'index'};
if (!$siteno) {next;}
if ($siterec->{'sysno'} ne $sysno) {next;}
if ($siterec->{'_bypass'}) {next;}
my $site_addr = -1;
my $chan_addr = -1;
if (!$siterec->{'lout'} and  $db->{'system'}[$sysno]{'qkeyon'})  {
my $qkey = $siterec->{'qkey'} + 0;
$system_qkeys{$qkey} = 'on';
}
if ($p2) {
%work_blk = ('block_base' => $sysndx, 'block_addr' => 0);
if ($ready) {
if (uniden_cmd('AST',$parmref)) {
return exit_prg("SETMEM l4041:Cannot create SIF for system $sysno ",$parmref);
}
}### ready
$site_addr = $work_blk{'block_addr'};
if ($site_addr eq '-1') {
my $msg = "Site capacity ($Green$sitecount$White) exceeded for this system!";
LogRad(1,$db,"system",$sysno,$msg);
last;
}
$sitecount++;
$siterec->{'block_addr'} = $site_addr;
%work_blk = %{$siterec};
$work_blk{'lout'} = !$siterec->{'valid'};
if ($systype eq 'edw') {$work_blk{'edacs_type'} = 'WIDE';}
elsif ($systype eq 'edn' ) {$work_blk{'edacs_type'} = 'NARROW';}
elsif ($systype eq 'mots') {$work_blk{'mot_type'} = 'STD';}
elsif ($systype eq 'motp') {$work_blk{'mot_type'} = 'SPL';}
elsif ($systype eq 'motc') {$work_blk{'mot_type'} = 'CUSTOM';}
$parmref->{'write'} = TRUE;
if ($ready) {
if (uniden_cmd('SIF',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg("SETMEM l4074:Cannot update SIF for system $sysno ",$parmref);
}
}### ready
if ($systype eq 'motc') {
my $found = TRUE;
foreach my $bp (@{$db->{'bplan'}}) {
if ($bp->{'_bypass'}) {next;}
if (!$bp->{'index'}) {next;}
if (!$bp->{'siteno'}) {
LogIt(1,"Bandplan $bp->{'index'} has no site index!");
next;
}
if ($bp->{'siteno'} == $siteno) {
$found = TRUE;
%work_blk = %{$bp};
$work_blk{'block_addr'} = $site_addr;
$parmref->{'write'} = TRUE;
foreach my $ndx (1..6) {
my $var = "spacing_$ndx";
my $value = $work_blk{$var};
if (!$value) {$value = '25000';}
if (!looks_like_number($value) or ($value < 0)) {
LogIt(1,"Unden l2721:Spacing value of $value is not valid. Set to 25000");
$value = '25000';
}
if ($value > 100000) {
LogIt(1,"Uniden l2721:$blockname MCP Spacing of $value is too large. Limited to 100khz");
$value = 100000;
}
$value = (substr(sprintf("%6.6ld",$value),0,-1)) + 0;
$work_blk{$var} = $value;
}
if (uniden_cmd('MCP',$parmref)) {
LogIt(1,"Could not write Bandplan for Site $siteno");
}
}### Looking for a bandplan
if (!$found) {LogIt(1,"No custom bandplan available for site $siteno!");}
}
}
}### BCD325P2 process
else {
%work_blk = ('block_addr' => $sysndx);
$parmref->{'write'} = FALSE;
if ($ready) {
if (uniden_cmd('SIN',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg("SETMEM l4153:Cannot get SIN for system $sysno ",$parmref);
}
}### ready
$site_addr = $work_blk{'chn_head'};
}#### BCD396 process
my $tfreqcnt = 0;
foreach my $freqrec (@{$db->{'tfreq'}}) {
threads->yield;
if ($progstate ne $startstate) {last SYSNO;}
if ($freqrec->{'_bypass'}) {next;}
if (!$freqrec->{'index'}) {next;}
if ($freqrec->{'siteno'} != $siteno) {next;}
if (!$freqrec->{'frequency'}) {
print Dumper($freqrec),"\n";
LogIt(1,"Unden 3704:SITE frequency for TFREQ index=>$freqrec->{'index'} cannot be '0'");
next;
}
%work_blk = ('block_base' => $site_addr, 'block_addr' => 0);
if ($ready) {### debug
if (uniden_cmd('ACC',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg("SETMEM:Cannot create TFQ for Siteno=$siteno addr=$site_addr system $sysno ",$parmref);
}### error
}### ready
my $tfq_addr = $work_blk{'block_addr'};
if ($tfq_addr eq '-1') {
LogIt(1,"Number of frequencies ($tfreqcnt) exceeded radio's capacity!");
last;
}
$freqrec->{'block_addr'} = $tfq_addr;
%work_blk = %{$freqrec};
$parmref->{'write'} = TRUE;
if ($ready) {
if (uniden_cmd('TFQ',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg("SETMEM:Cannot update TFQ for addr=$tfq_addr for system $sysno ",$parmref);
}### error
}### ready
$tfreqcnt++;
}### each frequency for this site
if (!$tfreqcnt) {
LogIt(1,"Uniden l3739:No frequencies assigned to site $siteno system=>$sysno");
exit;
}
}### for each SITE
}### Trunked system process
my %grpkey = ();
my $groupcount = 0;
foreach my $grprec (@{$db->{'group'}}) {
threads->yield;
if ($progstate ne $startstate) {last SYSNO;}
if ($grprec->{'_bypass'}) {next;}
my $groupno = $grprec->{'index'};
if (!$groupno) {next;}
if ($grprec->{'sysno'} != $sysno) {next;}
if ($grprec->{'_bypass'}) {next;}
%work_blk = ('block_base' => $sysndx, 'block_addr' => 0);
if ($ready) {
if (uniden_cmd($grpcmd,$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg("SETMEM l4264:Cannot create new group $grpcmd for system $sysno ",$parmref);
}
}### Ready
my $group_addr = $work_blk{'block_addr'};
if ($group_addr eq '-1') {
my $msg = "Group capacity ($Green$groupcount$White) exceeded for this system!";
LogRad(1,$db,"system",$sysno,$msg);
last;
}
$groupcount++;
$db->{'group'}[$groupno]{'block_addr'} = $group_addr;
%work_blk = %{$db->{'group'}[$groupno]};
$work_blk{'lout'} = FALSE;
my $qkey = $work_blk{'gqkey'};
if ($qkey ne '.') {
$qkey = $qkey + 0;
$grpkey{$qkey} = 'off';
if ($work_blk{'valid'}) {$grpkey{$qkey} = 'on';}
}
$parmref->{'write'} = TRUE;
if ($ready) {
if (uniden_cmd('GIN',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg("SETMEM l4301:Cannot update GIN for Group $groupno addr=$group_addr for system $sysno ",$parmref);
}### error
}### debug
my @recs = ();
my $chancount = 0;
foreach my $freqrec (@{$db->{'freq'}}) {
threads->yield;
if ($progstate ne $startstate) {last SYSNO;}
if ($freqrec->{'_bypass'}) {next;}
my $freqno = $freqrec->{'index'};
if (!$freqno) {next;}
if ($freqrec->{'groupno'} != $groupno) {next;}
if ($freqrec->{'siteno'}) {next;}
if (($freqrec->{'groupno'}) and ($freqrec->{'groupno'} == $groupno)) {
push @recs,$freqrec;
}
%work_blk = ('block_base' => $group_addr,'block_addr' => 0);
if ($ready) {
if (uniden_cmd($chncmd,$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg("SETMEM l4334:Cannot create new $chncmd  for system $sysno ",$parmref);
}### Error
}### Ready
my $chan_addr = $work_blk{'block_addr'};
if ($chan_addr eq '-1') {#### no more room at the inn
uniden_cmd('MEM',$parmref);
if (!$work_blk{'chan_count'}) {$work_blk{'chan_count'} = '?';}
my $msg = "Channel capacity exceeded.\n" .
"          $Green$chancount$White channels in group addr:$Magenta$group_addr$White " .
"(radio total:$Cyan$work_blk{'chan_count'}$White)";
LogRad(1,$db,"group",$groupno,$msg);
last;
}
$freqrec->{'block_addr'} = $chan_addr;
%work_blk = %{$freqrec};
$work_blk{'lout'} = !$work_blk{'valid'};
if ($work_blk{'bcdatt'}) {$work_blk{'atten'} = TRUE;}
if (!$work_blk{'adtype'}) {$work_blk{'adtype'} = 0;}
$work_blk{'tonelock'} = 0;
$work_blk{'ctcsdcs'} = 0;
my $tone_type = lc($freqrec->{'tone_type'});
my $tone = lc($freqrec->{'tone'});
if (($tone ne 'off') and ($tone_type ne 'off')) {
if (($tone_type eq 'ctcss')) {
$work_blk{'tonelock'} = 1;
$work_blk{'adtype'}  = 1;
$work_blk{'ctcsdcs'} = 127;
foreach my $ndx (1..$#tonestring) {
if ($tonestring[$ndx] eq $work_blk{'tone'}) {
$work_blk{'ctcsdcs'} = $ndx + 63;
last;
}
}
}### CTCSS tone type
elsif ($tone_type eq 'dcs') {
$work_blk{'adtype'}  = 1;
foreach my $ndx (1..$#dcsstring) {
if ($dcsstring[$ndx] eq $work_blk{'tone'}) {
$work_blk{'ctcsdcs'} = $ndx + 127;
last;
}
}
}### DCS tone type
else {
}
}## Tone is NOT off
$work_blk{'priority'} = FALSE;
$parmref->{'write'} = TRUE;
if ($ready) {
if (uniden_cmd($chnblk,$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg("SETMEM:Cannot update $chnblk for system $sysno ",$parmref);
}### error
}### ready
$chancount++;
}### Each record
}### Group process
%work_blk = ('block_addr' => $sysndx, 'grpkey' => \%grpkey);
$parmref->{'write'} = TRUE;
if ($ready) {
if (uniden_cmd('QGL',$parmref)) {
$parmref->{'out'} = $outsave;
return exit_prg("SETMEM l4464:Could not update Group QuickKeys for system $sysno ",$parmref);
}### error
}### Ready
$count++;
}### system process
$parmref->{'write'} = TRUE;
uniden_cmd('QSL',$parmref);
SETDONE:
uniden_cmd('EPG',$parmref);
$parmref->{'out'} = $outsave;
$outsave->{'count'} = $count;
LogIt(0,"System Write complete");
return ($parmref->{'rc'} = $retcode);
}###setmem
elsif ($cmdcode eq '_delete') {
if (!$in) {LogIt(2715,"UNIDEN_CMD:No 'in' defined in parmref for _DELETE");}
if (!$in->{'sysno'}) {LogIt(2716,"UNIDEN_CMD:No system number for _DELETE");}
my $sysno = $in->{'sysno'};
my %allsys = ();
$parmref->{'database'} = \%allsys;
my $rc = uniden_cmd('_getall',$parmref);
$parmref->{'database'} = $db;
if ($rc) {
add_message("_DELETE:Could not get systems in this Uniden radio!");
return $rc;
}
if (defined $allsys{'system'}[$sysno]{'block_addr'}) {
my $name = $allsys{$sysno}{'system'}{$sysno}{'service'};
my $addr = $allsys{$sysno}{'system'}{$sysno}{'block_addr'};
LogIt(0,"System $sysno (name=$name addr=$addr) is being removed");
$parmref->{'write'} = FALSE;
if (uniden_cmd('PRG',$parmref)) {
add_message("_DELETE: command failed to get Uniden into program mode!");
return $parmref->{'rc'};
}
$out->{'block_addr'}  = $addr;
if (uniden_cmd('DSY',$parmref)) {
return exit_prg("_DELETE:unable to delete system $sysno",$parmref);
}
print "DSY returned=>$parmref->{'rcv'}\n";
uniden_cmd('SCT',$parmref);
while (! uniden_cmd('nop',$parmref)) {
LogIt(0,"Waiting for bus to clear");
}
LogIt(0,"system $sysno removed!");
}
else {
LogIt(1,"$sysno does not exist in the connected radio. Cannot delete.");
return ($parmref->{'rc'} = $EmptyChan);
}
goto DONE;
}
elsif ($cmdcode eq 'getglob') {
if (!$db) {LogIt(2805,"UNIDEN_CMD:No 'database' defined in parmref for GETMEM");}
if (!$model) {
if (uniden_cmd('MDL',$parmref)) {
add_message("GETGLOG:Could not get Uniden model number!");
return $parmref->{'rc'};
}
}
if ($model eq 'SDS200') {return;}
my $p2 = FALSE;
if ($radio_def{'model'} eq 'BCD325P2') {$p2 = TRUE;}
$parmref->{'write'} = FALSE;
if (uniden_cmd('PRG',$parmref)) {
add_message("GETGLOB: command failed to get Uniden into program mode!");
return $parmref->{'rc'};
}
my %work_blk = ();
$parmref->{'out'} = \%work_blk;
$retcode = 0;
foreach my $cmd ('OMS','BLT','KBP') {
%work_blk = ();
$parmref->{'write'} = FALSE;
if (uniden_cmd($cmd,$parmref)) {
add_message("GETGLOB: command failed $cmd!");
$retcode = $parmref->{'rc'};
}
else {
foreach my $key (keys %work_blk) {
if ($key eq 'block_type') {next;}
if ($key eq 'rsvd') {next;}
my $value = Strip($work_blk{$key});
$radio_def{$key} = $value;
}
}
}
$db->{'powermsg'} = ();
my %newrec = ();
foreach my $key ('msg1','msg2','msg3','msg4') {$newrec{$key} = $radio_def{$key};}
my $pwndx = add_a_record($db,'powermsg',\%newrec);
$db->{'light'} = ();
my $event = $radio_def{'event'};
if (!$event) {
print "Unden l4594:Empty event!";
$event = '';}
$event = lc($event);
my $dimmer = $radio_def{'dimmer'};
if ($event eq 'if') {$event = 'on';}
%newrec = ('event' => $event, 'bright' => $dimmer);
my $lightdx = add_a_record($db,'light',\%newrec);
$db->{'beep'} = ();
my $level = $radio_def{'beep'};
if ($level == 0) {$level = 15;}
elsif ($level == 99) {$level = 0;}
%newrec = ('volume' => $level);
my $beepdx =  add_a_record($db,'beep',\%newrec);
if ($p2) {
$db ->{'ifxchng'} = ();
my $ifcount = 0;
my $lastfreq = '1';
while ($lastfreq > 0) {
%work_blk = ();
if (uniden_cmd('GIE',$parmref)) {
add_message("GETGLOB:Command failed GIE!");
$retcode = $parmref->{'rc'};
last;
}
$lastfreq = Strip($work_blk{'frequency'});
if ($lastfreq > 0) {
my %newrec = ('frequency' => $lastfreq);
my $newrec = add_a_record($db,'ifxchng',\%newrec);
$ifcount++;
}
}
LogIt(0,"found $ifcount IF Exchange records");
}
my $lastfreq = '1';
my $lockcount = 0;
LogIt(0,"Getting Lockout records");
$db ->{'lockfreq'} = ();
while ($lastfreq > 0) {
$parmref->{'write'} = FALSE;
%work_blk = ();
if (uniden_cmd('GLF',$parmref)) {
add_message("GETGLOB:Command failed GLF!");
$retcode = $parmref->{'rc'};
last;
}
$lastfreq = Strip($work_blk{'frequency'});
if ($lastfreq > 0) {
my %newrec = ('frequency' => $lastfreq);
my $newrec = add_a_record($db,'lockfreq',\%newrec);
$lockcount++;
}
if ($debug3) {LogIt(0,"lastfreq=$lastfreq");}
}
LogIt(0,"found $lockcount lockout records");
%work_blk = ();
uniden_cmd('EPG',$parmref);
$parmref->{'out'} = $outsave;
LogIt(0,"GET_GLOBALS is complete");
return ($parmref->{'rc'} = $retcode);
}
elsif ($cmdcode eq 'setglob') {
LogIt(0,"Called Uniden SETGLOB");
if (!$db) {LogIt(2805,"UNIDEN_CMD:No 'database' defined in parmref for GETMEM");}
if (!$model) {
if (uniden_cmd('MDL',$parmref)) {
add_message("SETGLOB:Could not get Uniden model number!");
return $parmref->{'rc'};
}
}
if (substr(lc($model),0,3) ne 'bcd') {
LogIt(1,"SETGLOB not valid for $model");
return $NotForModel;
}
my $p2 = FALSE;
if ($radio_def{'model'} eq 'BCD325P2') {$p2 = TRUE;}
my $clear = FALSE;
if ($in->{'erase'}) {$clear = TRUE;}
$parmref->{'write'} = FALSE;
if (uniden_cmd('PRG',$parmref)) {
add_message("SETGLOB: command failed to get Uniden into program mode!");
return $parmref->{'rc'};
}
my %work_blk = ();
$parmref->{'out'} = \%work_blk;
$retcode = $GoodCode;
if (defined $db->{'powermsg'}[1]) {
%work_blk = ();
foreach my $key ('msg1','msg2','msg3','msg4') {
my $msg = $db->{'powermsg'}[1]{$key};
if (!$msg) {$msg = '';}
$work_blk{$key} = $msg;
}
$parmref->{'write'} = TRUE;
if ($ready) {
if (uniden_cmd('OMS',$parmref)) {
add_message("SETGLOB:Command failed to set opening message!");
$retcode = $parmref->{'rc'};
}### failure
}### ready
}
if ($db->{'light'}[1]{'index'}) {
%work_blk = ('event' => '10','bright' => 3);
if ($db->{'light'}[1]{'event'}) {
my $event = uc($db->{'light'}[1]{'event'});
if ($event eq 'ON') {$event = 'IF';}
elsif ($event eq 'OFF') {$event = '10';}
elsif ($event eq 'KEY') {$event = 'KY';}
elsif (($event ne '30') and ($event ne '10')
and ($event ne 'KY') and ($event ne 'SQ') ) {
LogIt(1,"Unknown LIGHT event $Green$event$White. Changed to '10'");
$event = '10';
}
$work_blk{'event'} = $event;
}
if ($db->{'light'}[1]{'bright'}) {
my $bright = $db->{'light'}[1]{'bright'};
if (!$bright) {$bright = 0;}
if (!looks_like_number($bright) or ($bright < 1) or ($bright > 3)) {
LogIt(1,"Light bright level of $Green$bright$White not valid. Set to 3");
}
else {$work_blk{'bright'} = $bright;}
}
$parmref->{'write'} = TRUE;
if ($ready) {
if (uniden_cmd('BLT',$parmref)) {
add_message("SETGLOB:Command failed to set BackLight setting!");
$retcode = $parmref->{'rc'};
}### failure
}### ready
}### 'LIGHT' setting defined.
if (defined $db->{'beep'}[1]{'beep'}) {
%work_blk = ('beep' => 0,'lock' => 0,'safe' => 0);
my $beep = $db->{'beep'}[1]{'beep'};
if (looks_like_number($beep)) {
if ($beep < 1) {$beep = 99;}
elsif ($beep > 15) {$beep = 0;}
$work_blk{'beep'} = $beep;
}
else {LogIt(1,"Beep value of $Green$beep$White is not valid!. Set to default.")}
$parmref->{'write'} = TRUE;
if ($ready) {
if (uniden_cmd('KBP',$parmref)) {
add_message("SETGLOB:Command failed to set Keyboard Beep setting!");
$retcode = $parmref->{'rc'};
}### failure
}### ready
}### Keyboard beep
if ($p2 and $db->{'ifxchng'}[1]{'frequency'}) {
if ($clear) {
my @clrfreq = ();
my $lastfreq = '1';
while ($lastfreq > 0) {
%work_blk = ();
if (uniden_cmd('GIE',$parmref)) {
add_message("GETGLOB:Command failed GIE!");
$retcode = $parmref->{'rc'};
last;
}
$lastfreq = Strip($work_blk{'frequency'});
if ($lastfreq > 0) {push @clrfreq,$lastfreq;}
}
foreach my $freq (@clrfreq) {
print "l4876 Clearing IF Exchange Frequency $freq\n";
%work_blk = ('frequency' => $freq);
$parmref->{'write'} = TRUE;
if (uniden_cmd('CIE',$parmref)) {
add_message("GETGLOB:Command failed CIE!");
$retcode = $parmref->{'rc'};
last;
}
}
}
foreach my $rec (@{$db->{'ifxchng'}}) {
if (!$rec->{'index'}) {next;}
my $freq = $rec->{'frequency'};
if (!$freq) {next;}
%work_blk = ('frequency' => $freq);
$parmref->{'write'} = TRUE;
if ($ready) {
if (uniden_cmd('RIE',$parmref)) {
add_message("SETGLOB:Command failed RIE!");
$retcode = $parmref->{'rc'};
last;
}### error
}## Ready
}### ifxchng records
}### process IF exchange frequencies
if ($db->{'lockfreq'}[1]{'frequency'}) {
if ($clear) {
}
foreach my $rec (@{$db->{'lockfreq'}}) {
if (!$rec->{'index'}) {next;}
my $freq = $rec->{'frequency'};
if (!$freq) {next;}
%work_blk = ('frequency' => $freq);
$parmref->{'write'} = TRUE;
if ($ready) {
if (uniden_cmd('LOF',$parmref)) {
add_message("SETGLOB:Command failed LOF!");
$retcode = $parmref->{'rc'};
last;
}### Error
}### Debug
}### For each lockout record
}### Process lockfreq records
uniden_cmd('EPG',$parmref);
$parmref->{'out'} = $outsave;
LogIt(0,"SET_GLOBALS is complete");
return ($parmref->{'rc'} = $retcode);
}
elsif ($cmdcode eq 'getsig') {
if (uniden_cmd('GLG',$parmref)) {
add_message("GETSIG l4456:GLG Command failed!");
return ($parmref->{'rc'});
}### failure
if (($out->{'frq_tgid'}) and ($out->{'frq_tgid'} !~ /\./))  {
$out->{'tgid'} = $out->{'frq_tgid'};
$out->{'service'} = $out->{'groupname'} . ':' . $out->{'service'};
}
else {$out->{'tgid'} = '';}
if ($out->{'sql'}) {
if ($model =~ /sds/i) {
Get_SDS_Status($parmref);
}
elsif  ($model =~ /bcd325p2/i) {
if (uniden_cmd('PWR',$parmref)) {
add_message("GETSIG:PWR Command failed!");
return ($parmref->{'rc'});
}### failure
}
elsif ($model =~ /bcd396t/i) {
uniden_cmd('STS',$parmref);
}
else {
}
if (!$out->{'signal'}) {$out->{'signal'} = 1;}
}
else {
$last_tgid = '';
$out->{'sql'} = 0;
$out->{'signal'} = 0;
}
return ($parmref->{'rc'} = $retcode);
}
elsif ($cmdcode eq 'getvfo') {
if (uniden_cmd('GLG',$parmref)) {
add_message("SETGLOB:Command failed to set opening message!");
return ($parmref->{'rc'});
}### failure
if ($out->{'sql'}) {
if (uniden_cmd('PWR',$parmref)) {
add_message("SETGLOB:Command failed to set opening message!");
return ($parmref->{'rc'});
}### failure
}
else {
$out ->{'sql'} = 0;
$out ->{'frequency'} = $vfo{'frequency'};
$out ->{'mode'} = $vfo{'mode'};
}
return ($parmref->{'rc'} = $retcode);
}
elsif ($cmdcode eq 'setvfo') {
$parmref->{'write'} = TRUE;
foreach my $key ('frequency','mode','dlyrsm') {
$out->{$key} = $in->{$key};
}
if (uniden_cmd('QSH',$parmref)) {
add_message("SETVFI:QSH failure");
return ($parmref->{'rc'});
}### failure
return ($parmref->{'rc'});
}
elsif ($nodata{$cmdcode}) {
if ($blocks{$cmdcode}) {
LogIt(3153,"Missing 'out' for Uniden command $cmdcode");
}
}
elsif ($cmdcode eq 'QSL') {
$cmd_parms = '';
if ($parmref->{'write'}) {
foreach my $page (0..9) {
my $bitmap = '';
foreach my $no (1..9,0) {
my $keyno = ($page * 10) + $no;
my $value = '2';
if ($system_qkeys{$keyno} and ($system_qkeys{$keyno} eq 'on')) {
$value = 1;
}
$bitmap = "$bitmap$value";
}
$cmd_parms = "$cmd_parms,$bitmap";
}
}
}
elsif ($cmdcode eq 'QGL') {
if (!defined $out->{'block_addr'}) {LogIt(4744,"Uniden:No SIN block_addr for QGL");}
my $sinndx = $out->{'block_addr'};
my $grpkey = $out->{'grpkey'};
if (! defined $grpkey) {LogIt(4747,"Uniden:No GRPKEY for QGL");}
$cmd_parms = ",$sinndx";
if ($parmref->{'write'}) {
my $bitmap = '';
foreach my $keyno (1..9,0) {
my $value = 0;
if ($grpkey->{$keyno}) {
if (lc($grpkey->{$keyno}) eq 'on') {$value = 1;}
else {$value = 2;}
}
$bitmap = "$bitmap$value";
}
$cmd_parms = "$cmd_parms,$bitmap";
}
}
elsif ($cmdcode eq 'JPM') {
if ($model =~ 'SDS') {return;}
if ($model =~ '396') {return;}
my $scnmode = $out->{'jpm_mode'};
$cmd_parms = ",$scnmode";
}
elsif ($cmdcode eq 'ABP') {
}
elsif ($cmdcode eq 'STS') {
}
elsif ($cmdcode eq 'PRG') {
if ($model eq 'SDS200') {return;}
if ($model eq 'SDS100') {return;}
my $outsave = $parmref->{'out'};
my %out = ();
$parmref->{'out'} = \%out;
uniden_cmd('STS',$parmref);
$parmref->{'out'} = $outsave;
}
elsif ($cmdcode eq 'CSY') {
$cmd_parms = ",$out->{'systemtype'}";
if ($model =~ /bcd325/i) {$cmd_parms = "$cmd_parms,0";}
}
elsif ($cmdcode eq 'MEM') {
}
elsif ($cmdcode eq 'BLT') {
if ($parmref->{'write'}) {
$cmd_parms = ",$out->{'event'},,$out->{'bright'}";
}
else {$cmd_parms = '';}
}
elsif (defined $blocks{$blockname}) {
my @reflist = @{$blocks{$blockname}};
foreach my $ref (@reflist) {
my ($keyword) = keys %{$ref};
my $flag = lc($ref->{$keyword});
if ($flag =~ /q/i) {### required parameter for read and write
if (!defined $out->{$keyword}) {
print Dumper($out),"\n";
LogIt(3278,"Missing required $keyword for Uniden command $cmdcode");
}
push @send_validate,$keyword;
}
elsif (($flag =~ /r/i) or
(($flag =~ /s/i) and ($model =~ /bcd325p2/i)) or
(($flag =~ /t/i) and ($model =~ /sds/i)) or
(($flag =~ /u/i) and ($model =~ /bcd396t/i)) ) {
push @rcv_validate,$keyword;
}
elsif (($flag =~ /b/i) or
(($flag =~ /3/i) and ($model =~ /bcd325p2/i)) or
(($flag =~ /2/i) and ($model =~ /sds/i)) or
(($flag =~ /1/i) and ($model =~ /bcd396t/i)) ) {
if ($parmref->{'write'}) {push @send_validate,$keyword;}
else {push @rcv_validate,$keyword;}
}
elsif ($parmref->{'write'} and (
($flag =~ /w/i) or
(($flag =~ /x/i) and ($model =~ /bcd325p2/i)) or
(($flag =~ /y/i) and ($model =~ /sds/i)) or
(($flag =~ /z/i) and ($model =~ /bcd396t/i)) ) ) {
push @send_validate,$keyword;
}
}### Each key in the block
if (scalar @send_validate) {
KeyVerify($out,@send_validate);
my $parmcnt = 1;
foreach my $parm (@send_validate) {
my $value = '';
if ($parm ne 'rsvd') {$value = $out->{$parm};}
if (!defined $value) {
LogIt(1,"UNIDEN_CMD l3522:Undefined value for $parm");
$value = '';
}
if ($parm eq 'lout') {
}
elsif ($parm =~ /freq/)  {
if (looks_like_number($value) and ($value > 0)) {
$value = substr(sprintf("%011.11ld",$value),1,8);
}
}
elsif (($parm eq 'step')  ) {
if (!$value) {$value = 0;}
if (!looks_like_number($value)) {
LogIt(1,"Unden l5061:Step value of $value is not valid. Set to 100hz");
$value = '100';
}
if  ($value > 0) {
$value = substr(sprintf("%011.11ld",$value),1,9);
}
}
elsif ($parm eq 'beep') {
if (!$value) {$value = '99';}
elsif (lc($value) eq 'auto') {$value = 16;}
elsif (looks_like_number($value)) {
if ($value >15) {$value = 15;}
if ($value < 1) {$value = 1;}
}
else {$value = 99;}
}
elsif ($parm eq 'service') {
if (length($value) > 16) {$value = substr($value,0,16);}
}
elsif ($parm eq 'mode') {
$value = $rc_to_uniden{Strip(lc($value))};
if (!$value) {$value = 'AUTO';}
if (($value ne 'AUTO') and ($blockname eq 'SIF')) {
if (($value ne 'FM') and ($value ne 'NFM')) {$value = 'NFM';}
}
}
elsif ($parm eq 'emgalt') {
if ($value) {$out->{'emgcol'} = 'RED';}
else {$out->{'emgcol'} = 'OFF';}
}
elsif ($parm eq 'emgcol') {
}
elsif ($parm eq 'end_code') {
if (lc($value) eq 'a') {$value = 1;}
elsif (lc($value) eq 'd') {$value = 2;}
elsif (lc($value) eq 'a+d') {$value = 2;}
else {$value = 0;}
}
elsif ($parm eq 'p25wait') {
if (!$value) {$value = 0};
$value = (int($value/100)) * 100;
}
elsif ($parm eq 'audio') {
if (lc($value) eq 'analog') {$value = 1;}
elsif (lc($value) eq 'digital') {$value = 2;}
else {$value = 0;}
}
elsif ($parm eq 'voloff') {$value = radctl2vol($value);}
elsif ($parm eq 'dlyrsm') {
if ($value) {
if ($value < -8) {$value = -10;}
elsif ($value < -4) {$value = -5;}
elsif ($value < 0) {$value = -2;}
elsif ($value < 3) { }
elsif ($value < 7) {$value = 5;}
elsif ($value < 20) {$value = 10;}
else {$value = 30;}
}
}
elsif (($parm eq 'lat') or ($parm eq 'lon')) {
my ($dec,$dms) = Lat_Lon_Parse($value,$parm);
if ($dec) {
my ($dd,$mm,$sec,$dir) = $dms =~ /(.*?)\:(.*?)\:(.*?)\:(.*)/;
if ($parm eq 'lon') {$dd = substr('000' . $dd,-3,3);}
else {$dd = substr('00' . $dd,-2,2);}
$mm = substr('00' . $mm,-2,2);
$sec =~ s/\.//g;  
$sec = substr($sec . '0000',0,4);
$value = "$dd$mm$sec" . uc(Strip($dir));
}
else {
$value = '00000000N';
if ($parm eq 'lon') {$value = '000000000W';}
}
}
elsif (($parm eq 'bcdtag') or ($parm eq 'systag')) {
if ($value and looks_like_number($value)) {$value = $value - 1;}
else {$value = 'none';}
}
$cmd_parms = "$cmd_parms,$value";
}
}
}### Block pre-process
elsif (lc($cmdcode) eq 'glt') {
LogIt(1,"Uniden 4952:GLT Called. Cannot be processed here");
return 1;
$cmdcode = 'GLT';
$cmd_parms = "," . Strip($in->{'type'});
}
elsif (lc($cmdcode) eq 'poll') {
$cmdcode = lc($cmdcode);
$noprocess = TRUE;
$cmd_parms = '';
}
else {
LogIt(1,"UNIDEN:No pre-process defined for $cmdcode");
$noprocess = TRUE;
$cmd_parms = '';
}
my $sent = '';
my $outstr = '';
my $rc = '';
my %sendparms = (
'portobj' => $parmref->{'portobj'},
'term' => CR,
'delay' => $delay,
'resend' => 0,
'debug' => 0,
'fails' => 0,
'wait' => 30,
);
if ($noprocess or $parmref->{'test'} or ($cmdcode eq 'autobaud')) {
$sendparms{'wait'} = 1;
}
if (defined $special{$cmdcode}) {
foreach my $key (keys %{$special{$cmdcode}}) {
$sendparms{$key} = $special{$cmdcode}{$key};
}
}
my $wait_restore = $sendparms{'wait'};
RESEND:
$sent = Strip($cmdcode);
if ($cmd_parms) {$sent = $sent . $cmd_parms;}
$outstr = '';
if ((!$cmdcode) or ($cmdcode eq 'nop')) {$sent = '';}
else { $outstr = $sent . CR; }
$parmref->{'sent'} = $sent;
if ($debug2) {LogIt(0,"UNIDEN l2220:sent=$sent cmdcode=>$cmdcode");}
WAIT:
if ($rc = radio_send(\%sendparms,$outstr)) {
if ($rc eq '-2') {LogIt(2993,"UNIDEN.PM:No open port detected!");}
if ($debug2) {LogIt(0,"UNIDEN l2226:Radio_Send returned $sendparms{'rcv'} retcode=$rc");}
if ($sent) {
if ($sendparms{'wait'}--) {
$outstr = '';
usleep(100);
if ($warn) {print "Waiting...\n";}
else {
return ($parmref->{'rc'} = $CommErr);
}
goto WAIT;
}
if (!$parmref->{'rsp'} and $warn) {
my $msg = "Radio is not responding. Last command=>$sent.";
add_message($msg);
}
$parmref->{'rsp'} = TRUE;
return ($parmref->{'rc'} = $CommErr);
}### sent something
else {return( $parmref->{'rc'} = $EmptyChan);}
}
$parmref->{'rsp'} = FALSE;
my $instr = $sendparms{'rcv'};
if (!defined $instr) {$instr = ''}
if ($debug3) {LogIt(0,"UNIDEN_CMD:l3762- Received $instr");}
if (!$instr) {
if ($sendparms{'wait'}--) {
$outstr = '';
usleep(100);
goto WAIT;
}
add_message("Uniden l5134:radio returned empty response to $cmdcode");
return ($parmref->{'rc'} = $EmptyChan);
}
$parmref->{'rc'} = $GoodCode;
$parmref->{'rcv'} = $instr;
if ($noprocess) {
if (!$instr) {### Should NOT get here, but log it if we do
LogIt(1,"Nothing in the buffer, but got to NOPROCESS...");
$parmref->{'rc'} = $EmptyChan;
}
else {
my $queue = $parmref->{'unsolicited'};
if (!$queue) {LogIt(1,"UNIDEN l4318:Missing unsolicited queue reference in parmref!");}
else {
my %qe = ('uniden_msg' => $instr);
push @{$queue},{%qe};
}
}
return $parmref->{'rc'};
}
my @retvalues = split ',',$instr;
my $retcmd = shift @retvalues;
if (!$retcmd) {$retcmd = '';}
if ($retcmd eq 'ERR') {
if ($sendparms{'fails'}) {
$sendparms{'fails'}--;
$sendparms{'wait'} = $wait_restore;
LogIt(1,"$cmdcode got ERR, Retrying...");
sleep 1;
goto RESEND;
}
else {
if (! $parmref->{'quiet'}) {
LogIt(1,"Uniden gave 'ERR' for $parmref->{'sent'}");
}
return ($parmref->{'rc'} = $ParmErr);
}
}
elsif ($retcmd eq 'NG') {
if (! $parmref->{'quiet'}) {
LogIt(1,"Uniden gave 'NG' for $parmref->{'sent'}");
}
return ($parmref->{'rc'} = $ParmErr);
}
elsif ($retcmd eq 'FER') {
LogIt(1,"Uniden Communications error. ");
return ($parmref->{'rc'} = $CommErr);
}
elsif ($retcmd eq 'ORER') {
LogIt(1,"Uniden Overrun error. ");
return ($parmref->{'rc'} = $CommErr);
}
elsif ($retcmd ne $cmdcode) {
if ($unsolicited{$retcmd}) {
LogIt(1,"Uniden sent unsolicited $retcmd. Cannot issue commands!");
return ($parmref->{'rc'} = $OtherErr);
}
if (! $parmref->{'quiet'}) {
LogIt(1,"Uniden wrong response for $cmdcode! returned=>$instr");
}
if ($parmref->{'test'}) {
return ($parmref->{'rc'} = $OtherErr);
}
if (! $parmref->{'quiet'}) {LogIt(0,"$Bold...Waiting some more..");}
$outstr = '';
goto WAIT;
}
my $firstparm  = $retvalues[0];
if (!defined $firstparm) {$firstparm = '';}
$parmref->{'rc'} = $GoodCode;
if (lc($firstparm) eq 'ng') {
LogIt(1,"Uniden Returned NG. May be in wrong state. Sent=>$Green" . $parmref->{'sent'});
$parmref->{'rc'} = $ParmErr;
}
elsif (lc($firstparm) eq 'err') {
LogIt(1,"Uniden Returned ERR. Maybe bad parm. Sent=>$Green" . $parmref->{'sent'});
$parmref->{'rc'} = $ParmErr;
}
elsif (lc($firstparm) eq 'ok') {
if ($debug2) {LogIt(0,"UNIDEN l2418:Radio returned $instr");}
if ($cmdcode eq 'EPG') {
sleep 1;
my $outsave = $parmref->{'out'};
my %out = ('key_code' => 'P','key_mode' => 'P');
$parmref->{'out'} = \%out;
uniden_cmd('KEY',$parmref);
print "Last state before call to PRG was $state_save{'state'}\n";
if ($state_save{'state'} eq 'scn') {
%out =  ('key_code' => 'H','key_mode' => 'P');
uniden_cmd('KEY',$parmref);
}
$parmref->{'out'} = $outsave;
}
}
elsif ($retcmd eq 'STS') {
$out->{'dsp_form'} = Strip(shift @retvalues);
my $linecnt = length($out->{'dsp_form'});
my $menu = FALSE;
my $ndx = 1;
$out->{'raw'} = '';
$out->{'sigmeter'} = 0;
my $hold = FALSE;
my $lockout = FALSE;
while ($linecnt) {
my $cvar = 'lchar' . $ndx;
my $dvar = 'ldply' . $ndx;
$out->{$cvar} = '';
$out->{$dvar} = '';
my $line = shift @retvalues;
if (!$line) {$line = '';}
my $fmt = shift @retvalues;
if (!$fmt) {$fmt = '';}
$out->{$cvar} = $line;
$out->{$dvar} = $fmt;
if ($ndx == 1) {
if ($line) {
$out->{'raw'} = unpack("H32",$line);
my $sigoff = 10;
if ($model =~ /sds/i) {
$sigoff = 26;
}
else {
if (($line =~ /[a-zA-Z]/)) {
$state_save{'state'} = 'mnu';
$out->{'state'} = 'mnu' ;
$out->{'signal'} = 0;
return 0;
}
my $hex = unpack("H2",substr($line,1,1));
if (lc($hex) eq '8d') {$hold = TRUE;}
$hex = unpack("H2",substr($line,5,1));
if (lc($hex) eq '95') {$lockout = TRUE;}
}### Not the SDS200 process
my $sigmeter = hex(unpack("H4",substr($line,$sigoff,2)));
$out->{'sigmeter'} = $sigmeter;
my $signal = 0;
if ($sigmeter >= 44205) {$signal = 9;}
elsif ($sigmeter > 43691) {$signal = 7;}
elsif ($sigmeter > 43177) {$signal = 6;}
elsif ($sigmeter > 42784) {$signal = 4;}
elsif ($sigmeter > 42528) {$signal = 2;}
elsif ($sigmeter >8224)   {$signal = 1;}
$out->{'signal'} = $signal;
}### data on line one
}### Line one process
$ndx++;
$linecnt--;
}### For each linecount
my @keys = ('sql','mute','battery','wat');
my @extrakeys = ('rsvd1','rsvd2','sigl');
if ($model =~ /396/) {@extrakeys = ();}
foreach my $key (@keys,@extrakeys) {
if (scalar @retvalues) {$out ->{$key} = shift @retvalues;}
else {$out->{$key} = '';}
}
if (!$out->{'signal'}) {$out->{'signal'} = 0;}
my $state =  $state_save{'state'};
if ($out->{'lchar2'} =~ /remote/i) {$state = 'prg';}
else {
if ($model =~ /396/) {
if (substr($out->{'lchar5'},0,1) eq 'S') {### system quick-keys for scanning
if ($hold) {$state = 'sch';}
else {$state = 'scn';}
}
elsif ($out->{'lchar3'} =~ /yes/i) {### asking a question
$state = 'mnu';
}
elsif ($out->{'lchar2'} =~ /quick/i) {### Quick search
if ($hold) {$state = 'qsh';}
else {$state = 'qsr';}
}
elsif ($out->{'lchar5'} =~ /scr/i) {### Custom search
if ($hold) {$state = 'csh';}
else {$state = 'csr';}
}
else {
if ($hold) {$state = 'ssh';}
else {$state = 'ssr';}
}
}### Model BCD396T
elsif ($model =~ /325/) {
if (substr($out->{'lchar6'},0,3) eq 'GRP') {
$state = 'scn';
if ($hold) {$state = 'sch';}
}
elsif ($out->{'lchar3'} =~ /yes/i) {### asking a question
$state = 'mnu';
}
elsif ($out->{'lchar2'} =~ /quick/i) {### Quick search
if ($hold) {$state = 'qsh';}
else {$state = 'qsr';}
}
elsif ($out->{'lchar6'} =~ /[0-9]/) {
if ($hold) {$state = 'csh';}
else {$state = 'csr';}
}
else {
if ($hold) {$state = 'ssh';}
else {$state = 'ssr';}
}
}
elsif ($model =~ /sds/i) {
$state = 'scn';
}
else {
LogIt(1,"No state code for model $model");
}
}### Not in program mode
$out->{'state'} = $state;
$state_save{'state'} = $state;
}### STS
elsif ($cmdcode eq 'MDL') {
$model = $retvalues[0];
$out->{'model'} = $retvalues[0];
}
elsif ($cmdcode eq 'QSL') {
foreach my $pageno (0..9) {
my $page = shift @retvalues;
if (!defined $page) {last;}
my @bits = split "",$page;
foreach my $no (1..9,0) {
my $keyno = ($pageno * 10) + $no;
my $bit = shift @bits;
if ($bit eq '1') {$system_qkeys{$keyno} = 'on';}
else {$system_qkeys{$keyno} = 'off';}
}
}
}
elsif ($cmdcode eq 'QGL') {
my $grpkey = $out->{'grpkey'};
my @bits = split "",$retvalues[0];
foreach my $keyno (1..9,0) {
my $bit = shift @bits;
$grpkey->{$keyno} = 'off';
if ($bit eq '1') { $grpkey->{$keyno} = 'on';}
}
}
elsif ($cmdcode eq 'GID') {
if ($retvalues[1]) {
$out->{'tgid'} = $retvalues[1];
$last_tgid = $retvalues[1];
}
}
elsif ($cmdcode eq 'GLT') {
$out->{'xml'} = $instr;
}
elsif ($cmdcode eq 'CSY') {
$out->{'block_addr'} = shift @retvalues;
}
elsif ($cmdcode eq 'MEM') {
$out->{'block_type'} = $cmdcode;
foreach my $ref (@{$blocks{'MEM'}}) {
foreach my $key (keys %{$ref}) {$out->{$key} = shift @retvalues;}
}
}
elsif ($cmdcode eq 'BLT') {
foreach my $key ('event','rsvd','bright') {
my $value = shift @retvalues;
if (!$value) {$value = '';}
$out->{$key} = $value;
}
}
elsif ($blocks{$cmdcode}) {
$out->{'block_type'} = $cmdcode;
foreach my $key (@rcv_validate) {
my $value = shift @retvalues;
if (!defined $value) {last;}
if ($key eq 'lout') {
}
elsif ($key =~ /freq/) {
if (!$value) {$value = '0';}
if ($value > 0) {
$value = $value . '00';
}
}
elsif ($key eq 'frq_tgid') {
if (looks_like_number($value) and ($value > 99999) ) {
$out->{'frequency'} = $value . '00';
}
else {$out->{'tgid'} = $value;}
}
elsif ($key eq 'systemtype') {
$value = lc($value);
if ($model =~ /325/) {  
if ($systypes_bcd325p2{$value}) {$value = $systypes_bcd325p2{$value};}
}
else {
if ($systypes_bcd396{$value}) {$value = $systypes_bcd396{$value};}
}
}
elsif ($key =~ /spacing/) {
if (!$value) {$value = '0';}
else {$value = $value . '0';}
}
elsif ($key eq 'step') {### value MAY be 10hz or AUTO{
if (looks_like_number($value) and ($value > 0)) {
$value = $value . '0';
}
elsif (lc($value) eq 'auto') {
$value = 5000;
my $lf = $out->{'lowfreq'};
if ($lf) {
if (   $lf <=  27995000) {$value =   5000;}
elsif ($lf <=  29680000) {$value =  20000;}
elsif ($lf <=  49990000) {$value =  10000;}
elsif ($lf <=  53980000) {$value =  20000;}
elsif ($lf <=  71950000) {$value =  50000;}
elsif ($lf <=  75995000) {$value =   5000;}
elsif ($lf <=  87950000) {$value =  50000;}
elsif ($lf <= 107900000) {$value = 100000;}
elsif ($lf <= 136991600) {$value =   8330;}
elsif ($lf <= 143987500) {$value =  12500;}
elsif ($lf <= 147995000) {$value =   5000;}
elsif ($lf <= 150787500) {$value =  12500;}
elsif ($lf <= 161995000) {$value =   5000;}
elsif ($lf <= 173987500) {$value =  12500;}
elsif ($lf <= 215995000) {$value =  50000;}
elsif ($lf <= 224980000) {$value =  20000;}
elsif ($lf <= 379975000) {$value =  25000;}
elsif ($lf <= 757999500) {$value =  12500;}
elsif ($lf <= 805993750) {$value =   6250;}
else                     {$value =  12500;}
}### LF is specified
}
}
elsif ($key eq 'mode') {
$value = $uniden_to_rc{Strip(uc($value))};
if (!$value) {$value = 'Auto';}
}
elsif (($key eq 'qkey') or ($key eq 'gqkey')) {
if ($value eq '') {$value = '.';}
}
elsif ($key eq 'rssi') {
my $signal = rssi_cvt($value);
$out->{'signal'} = $signal;
}### rissi
elsif ($key eq 'beep') {### Need to convert BEEP value to RadioCtl
if ($value eq '99') { $value = 0;}
elsif ($value eq '0') {$value = 'AUTO';}
}
elsif ($key eq 'end_code') {
if ($value eq '2') {$value = 'Analog+Digital';}
elsif ($value eq  '1') {$value = 'Analog';}
else {$value = 'Ignore';}
}
elsif ($key eq 'emgcol') {
my $index = 'off';
if ($value) {$index = lc($value);}
if (defined $color_xlate{$index}) {$value = $color_xlate{$index};}
else {$value = 0;}
}
elsif ($key eq 'systag') {
if (looks_like_number($value)) {$value = $value + 1;}
else {$value = 0;}
if ($value > 100) {$value = 100;}
}
elsif ($key eq 'bcdtag') {
if (looks_like_number($value)) {$value = $value + 1;}
else {$value = 0;}
if ($value > 1000) {$value = 1000;}
}
elsif ($key eq 'voloff') {
if ($value) {$value = vol2radctl($value);}
else {$value = 0;}
}
elsif (($key eq 'lat') or ($key eq 'lon')) {
my ($dd,$mm,$ss,$dir) = $value =~ /(..)(..)(....)(.)/;
if ($key eq 'lon') {($dd,$mm,$ss,$dir) = $value =~ /(...)(..)(....)(.)/;}
$ss = $ss / 100;
my ($dec,$dms) = Lat_Lon_Parse("$dd:$mm:$ss:$dir",$key);
$value = $dec;
}
$out->{$key} = $value;
}### Validate each key
}### Block process
else {
LogIt(1,"No post processing defined for command $cmdcode");
}
return $parmref->{'rc'};
DONE:
if (($model ne 'SDS200') and ($model ne 'SDS100')) {
uniden_cmd('EPG',$parmref);
}
NOPRG:
if ($outsave) {$parmref->{'out'} = $outsave;}
$parmref->{'rc'} = $retcode;
return $retcode;
}
sub rssi_cvt {
my $rssi = shift @_;
my $signal = 0;
my @table = @{$rssi2sig{lc(substr($model,0,3))}};
if (!scalar @table) {
LogIt(1,"No RSSI_CVT process defined for model $model");
return $signal;
}
foreach my $value (@table) {
if ($rssi < $value) {return $signal;}
$signal++;
}
return $signal;
}
sub exit_prg {
my $msg = shift @_;
my $parmref = shift @_;
my $rc = $parmref->{'rc'};
add_message($msg);
uniden_cmd('EPG',$parmref);
if ($parmref->{'outsave'}) {$parmref->{'out'} = $parmref->{'outsave'};}
return ($parmref->{'rc'} = $rc);
}
sub select_systems {
my $in = shift @_;
my $allsys = shift @_;
my $system = shift @_;
if ($in->{'clear'} or $in->{'blk'} or $in->{'num'} or $in->{'nam'}) {
my $fld = '';
my $ref = '';
my %cmp = ();
if ($in->{'blk'}) {
$fld = 'block_addr';
$ref = $in->{'blk'};
if (ref($ref) ne 'ARRAY') {LogIt(4482,"UNIDEN_CMD:SELECT 'blk' is NOT a reference to an array!");}
}
elsif ($in->{'num'}) {
$fld = 'index';
$ref = $in->{'num'};
if (ref($ref) ne 'ARRAY') {LogIt(4487,"UNIDEN_CMD:SELECT 'num' is NOT a reference to an array!");}
}
elsif ($in->{'nam'}) {
$fld = 'service';
$ref = $in->{'nam'};
if (ref($ref) ne 'ARRAY') {LogIt(4492,"UNIDEN_CMD:SELECT 'nam' is NOT a reference to an array!");}
}
elsif ($in->{'clear'}) {
$ref = '*';
}
else {LogIt(4498,"UNIDEN:SELECT - Bad logic!");}
foreach my $rec (@{$allsys->{'system'}}) {
if (!$rec->{'index'}) {next;}
my $key = Strip($rec->{$fld});
if ($ref eq '*') {push @{$system},$rec;}
else {$cmp{$key} = $rec;}
}
if ($ref ne '*') {
foreach my $value (@{$ref}) {
my $key = Strip($value);
if ($cmp{$key}) {push @{$system},$cmp{$key};}
}
}
}### system search
return 0;
}
sub Get_All_SDS {
my $parmref = shift @_;
if (!$parmref) {LogIt(5973,"UNIDEN_Get_All_SDS:No parmref reference specified");}
if (ref($parmref) ne 'HASH') {LogIt(5974,"UNIDEN_Get_All_SDS:parmref is NOT a reference to a hash!");}
my $db = $parmref->{'database'};
if (!$db) {LogIt(5976,"UNIDEN_Get_All_SDS:Missing 'database' specification");}
if (ref($db) ne 'HASH') {LogIt(5977,"UNIDEN_Get_All_SDS:'database' is NOT a reference to a hash!");}
my $out  = $parmref->{'out'};
if (!$out) {LogIt(5976,"UNIDEN_Get_All_SDS:Missing 'out' specification");}
my $in = $parmref->{'in'};
if (!$in) {LogIt(5998,"UNIDEN_Get_All_SDS:Missing 'in' specification");}
LogIt(0,"Get_All_SDS l5996: Starting read of radio...");
my $notrunk = $in->{'notrunk'};
if (!$notrunk) {$notrunk = FALSE;}
my %fldb = ();
my $rc = Get_XML('FL',0,\%fldb,$parmref);
if ($rc) {
LogIt(1,"Get_All_SDS l5990:Bad return from Get_XML=>$rc");
return ($parmref->{'rc'} = $rc);
}
LogIt(0,"Get_All_SDS l6006: Got all Favorites...");
my $channel = 0;
foreach my $flndx (keys %fldb) {### for each favorites
if (   lc($fldb{$flndx}{'name'}) eq 'search with scan') {next;}
elsif (lc($fldb{$flndx}{'monitor'}) eq 'off') {next;}
print "Processing favorites index $flndx\n";
my %sysdb = ();
my $rc = Get_XML('SYS',$flndx,\%sysdb,$parmref);
if ($rc) {
LogIt(1,"Get_All_SDS l6004:Bad return from Get_XML=>$rc");
return ($parmref->{'rc'} = $rc);
}
SYSLP:foreach my $sysndx (keys %sysdb) {
my %rec = ('valid' => TRUE,'service'=>$sysdb{$sysndx}{'name'},
'qkey' => lc($sysdb{$sysndx}{'q_key'}),
'block_addr' => $sysndx,
);
if (lc($rec{'qkey'}) eq 'none') {$rec{'qkey'} = 'Off';}
my $ntag = $rec{'n_tag'};
if (looks_like_number($ntag)) {$rec{'systag'} = $ntag + 1;}
else {$rec{'systag'} = 0;}
if ($rec{'systag'} > 100) {$rec{'systag'} = 100;}
if (lc($sysdb{$sysndx}{'avoid'}) eq 'avoid') {$rec{'valid'} = FALSE;}
my $systype = Strip(lc($sysdb{$sysndx}{'type'}));
if ($systype eq 'conventional') {$rec{'systemtype'} = 'cnv';}
elsif ($systype eq 'edacs') {$rec{'systemtype'} = 'edw';}
elsif ($systype =~ /mototrbo/) {$rec{'systemtype'} = 'trbo';}
elsif ($systype eq 'ltr') {$rec{'systemtype'} = 'ltr';}
elsif ($systype eq 'p25 trunk') {$rec{'systemtype'} = 'p25s';}
elsif ($systype eq 'motorola') {$rec{'systemtype'} = 'mots';}
elsif ($systype eq 'nxdn trunk') {$rec{'systemtype'} = 'nxdn';}
elsif ($systype eq 'dmr one frequency') {$rec{'systemtype'} = 'dmr';}
else {
LogIt(1,"Get_All_SDS l6031:Don't have process for systemtype=>$systype");
next SYSLP;
}
if ($notrunk and ($rec{'systemtype'} ne 'cnv')) {next SYSLP;}
my $sysno = add_a_record($db,'system',\%rec,$parmref->{'gui'});
if ($systype eq 'conventional') {
my %deptdb = ();
my $rc = Get_XML('DEPT',$sysndx,\%deptdb,$parmref);
if ($rc) {
LogIt(1,"Get_All_SDS l6030:Bad return from Get_XML=>$rc");
return ($parmref->{'rc'} = $rc);
}
foreach my $grpndx (keys %deptdb) {
my %rec = ('valid' => TRUE,'service'=>$deptdb{$grpndx}{'name'},
'gqkey' => lc($deptdb{$grpndx}{'q_key'}),
'block_addr' => $grpndx,
'sysno' =>$sysno,
);
if ($rec{'gqkey'} eq 'none') {$rec{'gqkey'} = 'Off';}
if (lc($deptdb{$grpndx}{'avoid'}) eq 'avoid') {$rec{'valid'} = FALSE;}
my $grpno = add_a_record($db,'group',\%rec,$parmref->{'gui'});
my %freqdb = ();
my $rc = Get_XML('CFREQ',$grpndx,\%freqdb,$parmref);
if ($rc) {
LogIt(1,"Get_All_SDS l6051:Bad return from Get_XML=>$rc");
return ($parmref->{'rc'} = $rc);
}
$channel = 1;
foreach my $frqndx (keys %freqdb) {
my $freq = $freqdb{$frqndx}{'freq'};
$freq =~ s/mhz//i;   
my $mode = $freqdb{$frqndx}{'mod'};
$mode = Strip(uc($mode));
$mode = $uniden_to_rc{$mode};
if (!$mode) {$mode = 'Auto';}
my %rec = ('valid' => TRUE,'service' => $freqdb{$frqndx}{'name'},
'frequency' => $freq,
'block_addr' => $frqndx,
'mode' => $mode,
'channel' => $channel,
'audio' => $freqdb{$frqndx}{'sas'},
'tgid_valid' => FALSE,
'sysno' => $sysno,'groupno'=> $grpno,
);
my $ntag = $rec{'n_tag'};
if (looks_like_number($ntag)) {$rec{'bcdtag'} = $ntag + 1;}
else {$rec{'bcdtag'} = 0;}
$rec{'voloff'} = vol2radctl($rec{'lvl'});
if (lc($freqdb{$frqndx}{'avoid'}) eq 'avoid') {$rec{'valid'} = FALSE;}
my $freqno = add_a_record($db,'freq',\%rec,$parmref->{'gui'});
$channel++;
}
}### Group process
}
else {
LogIt(0,"Trunked system type is $systype");
my %sitedb = ();
my $rc = Get_XML('SITE',$sysndx,\%sitedb,$parmref);
if ($rc) {
LogIt(1,"Get_All_SDS l6095:Bad return from Get_XML=>$rc");
return ($parmref->{'rc'} = $rc);
}
foreach my $sitendx (keys %sitedb) {
my %rec = ('valid' => TRUE,'service' => $sitedb{$sitendx}{'name'},
'qkey' => lc($sitedb{$sitendx}{'q_key'}),
'block_addr' => $sitendx,
'sysno' => $sysno,
);
if ($rec{'qkey'} eq 'none') {$rec{'qkey'} = 'Off';}
if (lc($sitedb{$sitendx}{'avoid'}) eq 'avoid') {$rec{'valid'} = FALSE;}
my $siteno = add_a_record($db,'site',\%rec);
my %tfreq = ();
my $rc = Get_XML('SFREQ',$sitendx,\%tfreq,$parmref);
if ($rc) {
LogIt(1,"Get_All_SDS l6112:Bad return from Get_XML=>$rc");
return ($parmref->{'rc'} = $rc);
}
foreach my $tfqndx (keys %tfreq) {
my $freq = $tfreq{$tfqndx}{'freq'};
$freq =~ s/mhz//i;   
my %rec = ('valid' => TRUE,
'frequency' =>$freq,
'siteno' => $siteno,
);
my $tfreqno = add_a_record($db,'tfreq',\%rec);
}### For each tfreq
}### For each site
my %groupdb = ();
$rc = Get_XML('DEPT',$sysndx,\%groupdb,$parmref);
if ($rc) {
LogIt(1,"Get_All_SDS l6030:Bad return from Get_XML=>$rc");
return ($parmref->{'rc'} = $rc);
}
foreach my $grpndx (keys %groupdb) {
my %rec = ('valid' => TRUE,'service'=>$groupdb{$grpndx}{'name'},
'gqkey' => lc($groupdb{$grpndx}{'q_key'}),
'block_addr' => $grpndx,
'sysno' =>$sysno,
);
if ($rec{'gqkey'} eq 'none') {$rec{'gqkey'} = 'Off';}
if (lc($groupdb{$grpndx}{'avoid'}) eq 'avoid') {$rec{'valid'} = FALSE;}
my $grpno = add_a_record($db,'group',\%rec);
my %tgiddb = ();
my $rc = Get_XML('TGID',$grpndx,\%tgiddb,$parmref);
if ($rc) {
LogIt(1,"Get_All_SDS l6030:Bad return from Get_XML=>$rc");
return ($parmref->{'rc'} = $rc);
}
foreach my $tgidndx (keys %tgiddb) {
my %rec = ('valid' => TRUE,'service'=>$tgiddb{$tgidndx}{'name'},
'tgid' => $tgiddb{$tgidndx}{'tgid'},
'audio' => $tgiddb{$tgidndx}{'audiotype'},
'block_addr' => $tgidndx,
'frequency' => 0, 'mode' => '-',
'tgid_valid' => TRUE,
'groupno' => $grpno,
'sysno' =>$sysno,
);
if (lc($tgiddb{$tgidndx}{'avoid'}) eq 'avoid') {$rec{'valid'} = FALSE;}
my $freqno = add_a_record($db,'freq',\%rec);
}### TGID records
}### Groups for trunked system
}#### Trunked system process
}### All systems
}### For all favorites
return ($parmref->{'rc'} = $GoodCode);
}
sub Get_SDS_Status {
my $parmref = shift @_;
my $out  = $parmref->{'out'};
my %sendparms = (
'portobj' => $parmref->{'portobj'},
'term' => "</ScannerInfo>",
'delay' => 200,
'resend' => 0,
'debug' => 0,
);
my $outstr = "GSI\r";
my $rc = radio_send(\%sendparms,$outstr);
if ($rc) {
LogIt(1,"Get_SDS_Status l6288:Radio_Send failed! RC=$rc");
return ($parmref->{'rc'} = $rc);
}
my $xml = Strip($sendparms{'rcv'});
my %infotypes = ();
my @rcds = split "\n",$xml;
foreach my $rcd (@rcds) {
if (!$rcd) {next;}
if (lc(substr($rcd,0,3)) eq 'gsi') {next;}
if (lc(substr($rcd,0,3)) eq '<?x') {next;}
$rcd = Strip($rcd);
if (substr($rcd,0,2) eq '</') {next;}
my $rectype = '';
my $rest = '';
($rectype,$rest) = $rcd =~ /^\<(.*?) (.*?)\>/; 
if (!$rectype) {
next;
}
$rectype = Strip(lc($rectype));
if (!$rectype) {next;}
my @fields = quotewords(" ",FALSE,$rest);
foreach my $fld (@fields) {
my ($key,$value) = split '=',$fld,2;
$key = Strip(lc($key));
if ($key eq '/') {next;}
if (!defined $value) {
LogIt(1,"No value for key $key rectype=$rectype");
next;
}
$value = Strip($value);
$infotypes{$rectype}{$key} = $value;
}
}
$out->{'atten'} = FALSE;
if (lc($infotypes{'property'}{'att'}) eq 'on') {$out->{'atten'} = TRUE;}
$out->{'signal'} = $infotypes{'property'}{'sig'};
$out->{'rssi'} = $infotypes{'property'}{'rssi'};
$out->{'gqkey'} = $infotypes{'department'}{'q_key'};
$out->{'groupname'} = $infotypes{'department'}{'name'};
$out->{'qkey'} = $infotypes{'system'}{'q_key'};
$out->{'system_name'} = $infotypes{'system'}{'name'};
if (defined $infotypes{'convfrequency'}{'freq'}) {
$out->{'mode'} = $infotypes{'convfrequency'}{'mod'};
$out->{'frequency'} = $infotypes{'convfrequency'}{'freq'};
$out->{'channel_name'} = $infotypes{'convfrequency'}{'name'};
$out->{'tgid'} = '';
$out->{'tone'} = 'Off';
$out->{'tone_type'} = 'Off';
my $tone = $infotypes{'convfrequency'}{'sad'};
if (lc(substr($tone,0,5)) eq 'ctcss') {
$out->{'tone'} = substr($tone,5);
$out->{'tone_type'} = 'ctcss';
}
elsif (lc($tone) ne 'none') {LogIt(0,"Get_SDS_Status l6509:Tone $tone no process");}
}
if (defined $infotypes{'tgid'}{'tgid'}) {
$out->{'tgid'} = $infotypes{'tgid'}{'tgid'};
$out->{'channel_name'} = $infotypes{'tgid'}{'name'};
}
if (defined $infotypes{'sitefrequency'}{'freq'}) {
$out->{'frequency'} = $infotypes{'sitefrequency'}{'freq'};
}
if (defined $infotypes{'site'}{'name'}) {
$out->{'site_name'} = $infotypes{'site'}{'name'};
$out->{'mode'} = $infotypes{'site'}{'mod'};
}
if ($out->{'frequency'}) {
$out->{'frequency'} =~ s/MHz//i;  
$out->{'frequency'} = freq_to_rc($out->{'frequency'});
}
if ($out->{'mode'}) {
my $mode = Strip(uc($out->{'mode'}));
$out->{'mode'} = $uniden_to_rc{$mode};
if (!$out->{'mode'}) {$out->{'mode'} = 'Auto';}
}
if ($out->{'rssi'}) {
$out->{'signal'} = rssi_cvt($out->{'rssi'});
}
if ($out->{'tone'}) {
$out->{'tone'} =~ s/Hz//i;   
}
return 0;
}
sub Get_XML {
my $rtype = Strip(shift @_);
my $index = shift @_;
my $db = shift @_;
my $parmref = shift @_;
my %sendparms = (
'portobj' => $parmref->{'portobj'},
'term' => "</GLT>",
'delay' => 200,
'resend' => 0,
'debug' => 0,
);
my $outstr = "GLT,$rtype,$index\r";
my $eot = FALSE;
my $page = 0;
PAGEPROC:
while (!$eot) {
my $rc = radio_send(\%sendparms,$outstr);
if ($rc) {
LogIt(1,"Get_XML l5998:Radio_Send failed! RC=$rc page=$page");
if ($page > 0) {
LogIt(0,"May have lost the EOT");
return $GoodCode;
}
else {return $rc;}
}
$outstr = '';
my $xml = Strip(substr($sendparms{'rcv'},11));
my @lines = split "\n",$xml;
LINEPROC:
foreach my $line (@lines) {
$line = Strip($line);
if (substr($line,0,2) eq '<?') {next;}
if ($line eq '<GLT>') {next;}
if ($line eq '</GLT>') {next;}
if (substr($line,0,7) eq '<Footer') {
my ($procline) = $line =~ /\<Footer (.*)\/\>/;
my @fields = quotewords(' ',FALSE,$procline);
foreach my $fld (@fields) {
my ($key,$value) = split '=',$fld;
$key = lc(Strip($key));
if ($key eq 'eot') {
$eot = $value;
last LINEPROC;
}
elsif ($key eq 'no') {
$page = $value;
}
}
}
my ($procline) = $line =~ /\<$rtype (.*) \/\>/;
my @fields = quotewords(' ',FALSE,$procline);
my %rec = ();
foreach my $fld (@fields) {
my ($key,$value) = split '=',$fld;
$key = lc(Strip($key));
$rec{$key} = $value;
}
my $index = $rec{'index'};
if (!defined $index) {
LogIt(1,"GET_XML l6331:No index defined for $line");
next LINEPROC;
}
$db->{$index} = {%rec};
}### process all the lines
}
return $GoodCode
}
