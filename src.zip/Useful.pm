#!/usr/bin/perl -w
### Source file=>/data/source/perl/Useful.pm
package Useful;
require Exporter;
use constant FALSE => 0;
use constant TRUE => 1;
use Scalar::Util qw(looks_like_number);
use Getopt::Std;
use Getopt::Long;
use File::Basename;
use Data::Dumper;
use Sys::Syslog;
use Sys::Syslog qw(:standard :macros);
use XML::LibXML;
use XML::Simple qw(:strict);
use XBase;
use Cwd 'abs_path';
use Encode qw(decode encode);
use Text::CSV;
use Text::Capitalize;
@ISA   = qw(Exporter);
@EXPORT = qw(hexdply remove_codes CapWord Time_Format Help_Me Strip BuildSpread
LogIt @Warning_Log @Error_Log @Info_Log $LogHandle ReadSpread BenchMark
BuildDBF ReadDBF CopyBack List_Of_Files SpreadNuc ConfigFileProc
IsNumber WhereAmI Commify Parms_Parse Get_Answer MtabRead Os_Version Title_Format
$Red $Bold $Green $Blue $Magenta $Cyan $Yellow $White $Reset $Eol $Rev $Blink %OptDescript
KeyFormat MakeKey Get_Codec Read_Config Format_Hex LastFirst
Title_Unformat %MediaType %Catagory %Language %Quality %Rating
TrueFalse Dir_Glob NoDouble TVadapter DiskType
@Parms %Options $Debug );
our $Rev = '0.0';
$Red = "\e[31m";
$Bold = "\e[1m";
$Green = "\e[32m";
$Blue = "\e[34m";
$Magenta = "\e[35m";
$Cyan   =  "\e[36m";
$Yellow = "\e[33m";
$White  = "\e[37m";
$Blink  = "\e[5m";
$Reset =  "\e[0m";
$Eol = "$Reset\n";
our $Red = "\e[31m";
our $Bold = "\e[1m";
our $Green = "\e[32m";
our $Blue = "\e[34m";
our $Magenta = "\e[35m";
our $Yellow = "\e[33m";
our $White  = "\e[37m";
our $Blink  = "\e[5m";
our $Reset =  "\e[0m";
our $Eol = "$Reset\n";
my $workingdir = "/tmp/Useful";
my $contentfile = "content.xml";
my $title_rec = 0;
my $header_rec = 1;
my $data_rec = 2;
use constant KEYLENGTH => 70;
our %MediaType = (  'mpg'    => 'v',
'avi'    => 'v',
'mpeg'   => 'v',
'mkv'    => 'v',
'mp4'    => 'v',
'mov'    => 'v',
'm2ts'   => 'v',
'srt'    => 's',
'sub'    => 's',
'idx'    => 's',
'ssa'    => 's',
'vobsub' => 's',
'txt'    => 'o',
'jpg'    => 'o',
'png'    => 'o',
'rtf'    => 'o',
'nfo'    => 'b',
'gif'    => 'o',
'xml'    => 'o',
'bmp'    => 'o',
'htm'    => 'o',
'zip'    => 'o',
'jpeg'   => 'o',
'pdf'    => 'o',
'idxorg' => 'b',
'asf'    => 'v',
'mp3'    => 'a',
'wmv'    => 'v',
'vob'    => 'v',
'rm'     => 'v',
'sfv'    => 'v',
'qt'     => 'v',
'flv'    => 'v',
'xls'    => 'o',
'doc'    => 'o',
'ico'    => 'o',
'ec3'    => 'o',
'qpw'    => 'o',
'pps'    => 'o',
'exe'    => 'o',
);
%Quality = ( 0 => 'Silent',
1 => 'Good',
2 => 'Fair',
3 => 'Poor',
4 => 'Bad',
'?' => 'unknown',
);
%Language = (
'0' => 'Silent',
'a' => 'Danish',
'c' => 'Czech',
'd' => 'Dual Audio',
'e' => 'English',
'f' => 'French',
'g' => 'German',
'i' => 'Italian',
'j' => 'Japanese',
'l' => 'Polish',
'n' => 'Chinese_Cantonese_Mandarin',
'o' => 'Other',
'p' => 'Portuguese',
'r' => 'Russian',
's' => 'Spanish',
'w' => 'Swedish',
'?' => 'unknown',
);
%Catagory = ('a' => 'Action-Adventure',
'c' => 'Comedy',
'd' => 'Drama',
'e' => 'Documentary|Short',
'f' => 'Science Fiction',
'h' => 'Horror',
'k' => 'Kids Movie',
'm' => 'Musical|Music|Concert',
'n' => 'Foreign',
'p' => 'Superhero',
'q' => 'Fantasy',
'r' => 'Romance',
's' => 'Christmas',
't' => 'Art|Avant-Garde|Cult',
'w' => 'Western',
'y' => 'Mystery|Detective',
'v' => 'TV|Music Video',
);
%Rating = ('g' => 'Suitable for ALL ages',
'p' => 'Some Sex or Violence',
'r' => 'Large amount of Sex or Violence',
'x' => 'Adults only',
);
$Debug = 0;
%Options = (
'b|debug' => \$Debug,
'h|help' => \&Help_Me,
);
%OptDescript = (
'b|debug' => 'Turn On Debugging Stuff',
'h|help'  => 'Display Help',
);
@Warning_Log = ();
@Error_Log = ();
@Info_Log = ();
$loghandle = '';
%Single_Options = (
"h" => \&Help_Me,
);
%Data_Options   = (
);
@Parms = ( );
sub validate_code {
use strict;
}
sub hexdply {
use strict;
my ($instring) = @_;
my $result = "";
for (my $i=0;$i<length($instring);$i++) {
my $char = ord(substr($instring,$i,1));
my $fmt = ' ';
if ($char > 127) {$fmt=' >';}
$result  = $result . $fmt . sprintf("%2.2lx" ,  $char);
}
return $result;
}
sub Format_Hex {
use strict;
if (!scalar @_){LogIt(410,"Useful:Format_Hex missing string parameter!");}
my $instring = shift @_;
my $ref = shift @_;
if (!$ref){LogIt(412,"Useful:Format_Hex missing array reference parameter!");}
my $result = 0;
my @chars = split //,$instring;
$ref->[0] = '';
$ref->[1] = '';
foreach my $char (@chars) {
my $num = ord($char);
if (($num < 30) or ($num > 127)) {$char = '.';}
$ref->[0] = $ref->[0] . sprintf("%-3.3s",$char);
$ref->[1] = $ref->[1] . sprintf("%2.2lx ",$num);
}
return $result;
}
sub remove_codes {
use strict;
my ($string) = @_;
if (!$string) {return '';}
my $original = $string;
$string =~ s/\xc3\x89/A/g;
$string =~ s/\xc3\x8D/A/g;
$string =~ s/\xc3\x93/A/g;
$string =~ s/\xc3\x94/A/g;
$string =~ s/\xc3\x96/A/g;
$string =~ s/\xc3\xa0/a/g;
$string =~ s/\xc3\xa1/a/g;
$string =~ s/\xc3\xa2/a/g;
$string =~ s/\xc3\xa3/a/g;
$string =~ s/\xc3\xa4/a/g;
$string =~ s/\xc3\xa5/a/g;
$string =~ s/\xc3\xa6/ae/g;
$string =~ s/\xc3\xa7/c/g;
$string =~ s/\xc3\xa8/e/g;
$string =~ s/\xc3\xa9/e/g;
$string =~ s/\xc3\xaa/e/g;
$string =~ s/\xc3\xab/e/g;
$string =~ s/\xc3\xad/a/g;
$string =~ s/\xc3\xaf/i/g;
$string =~ s/\xc3\xb1/n/g;
$string =~ s/\xc3\xb2/o/g;
$string =~ s/\xc3\xb3/o/g;
$string =~ s/\xc3\xb4/'/g;         ### C3B4x-> ' (acute)
$string =~ s/\xc3\xb6/o/g;
$string =~ s/\xc3\xb9/u/g;
$string =~ s/\xc3\xba/u/g;
$string =~ s/\xc3\xbc/u/g;
$string =~ s/\xc3\xbd/y/g;
$string =~ s/\xc3\xbf/?/g;
$string =~ s/\xe2\x80\x99/\'/g;    ### E28099x -> '
$string =~ s/\xe2\x80\x98/\'/g;    ### E28098x -> '
if ($string =~ /\xc3/) {
print STDERR "$Bold USEFUL-Remove_Codes:International code for C3x not processed in =>$Yellow$string$White ";
print STDERR hexdply($string),$Eol;
}
$string =~ tr/\xb2/2/;
$string =~ tr/\xb4/'/;      ### B4x -> '
$string =~ tr/\xc0/A/;
$string =~ tr/\xc1/A/;
$string =~ tr/\xc2/A/;
$string =~ tr/\xc3/A/;
$string =~ tr/\xc4/A/;
$string =~ tr/\xc5/A/;
$string =~ s/\xc6/AE/g;
$string =~ tr/\xc7/C/;
$string =~ tr/\xc8/E/;
$string =~ tr/\xc9/E/;
$string =~ tr/\xca/E/;
$string =~ tr/\xcb/E/;
$string =~ tr/\xcc/I/;
$string =~ tr/\xcd/I/;
$string =~ tr/\xce/I/;
$string =~ tr/\xcf/I/;
$string =~ tr/\xd0/D/;
$string =~ tr/\xd1/N/;
$string =~ tr/\xd2/O/;
$string =~ tr/\xd3/O/;
$string =~ tr/\xd4/O/;
$string =~ tr/\xd5/x/;
$string =~ tr/\xd6/0/;
$string =~ tr/\xd7/U/;
$string =~ tr/\xd8/U/;
$string =~ tr/\xd9/U/;
$string =~ tr/\xda/U/;
$string =~ tr/\xdb/Y/;
$string =~ tr/\xdc/b/;
$string =~ tr/\xdd/s/;
$string =~ tr/\xde/a/;
$string =~ tr/\xdf/a/;
$string =~ tr/\xe0/a/;
$string =~ tr/\xe1/a/;
$string =~ tr/\xe2/a/;
$string =~ tr/\xe3/a/;
$string =~ tr/\xe4/a/;
$string =~ tr/\xe5/a/;
$string =~ s/\xe6/ae/g;
$string =~ tr/\xe7/c/;
$string =~ tr/\xe8/e/;
$string =~ tr/\xe9/e/;
$string =~ tr/\xea/e/;
$string =~ tr/\xeb/e/;
$string =~ tr/\xec/i/;
$string =~ tr/\xed/i/;
$string =~ tr/\xee/i/;
$string =~ tr/\xef/i/;
$string =~ tr/\xf0/d/;
$string =~ tr/\xf1/n/;
$string =~ tr/\xf2/o/;
$string =~ tr/\xf3/o/;
$string =~ tr/\xf4/o/;
$string =~ tr/\xf5/o/;
$string =~ tr/\xf6/o/;
$string =~ tr/\xf7/_/;
$string =~ tr/\xf8/o/;
$string =~ tr/\xf9/u/;
$string =~ tr/\xfa/u/;
$string =~ tr/\xfb/u/;
$string =~ tr/\xfc/u/;
$string =~ tr/\xfd/y/;
$string =~ tr/\xfe/b/;
$string =~ tr/\xff/y/;
$string =~ s/[^[:ascii:]]/\_/g;
my @chars = split "",$string;
while (scalar @chars) {
my $char = shift @chars;
if (ord($char) > 127) {
my $hex = sprintf("%lX",ord($char));
while(scalar @chars) {
$hex = $hex . ' ' . sprintf("%lX",ord(shift @chars));
}
LogIt(628,"REMOVE_CODES:Got invalid chars ($hex" .
"x) after remove_codes =>$string (original=>$original<= hex:" .
hexdply($original),")");
}
}
return $string;
}
sub CapWord {
use strict;
my ($string) = @_;
if (!$string) {return '';}
my %special = ( 'bbc'    => 'BBC',
'mgm'    => 'MGM',
'dvd'    => 'DVD',
'tv'     => 'TV',
'cb'     => 'CB',
'pbs'    => 'PBS',
'abba'   => 'ABBA',
'dj'     => 'DJ',
'p.d.q.' =>'P.D.Q.',
'ii'     => 'II',
'iii'    => 'III',
"Can'T"  => "Can't",
"Won'T"  => "Won't",
"Who'S"  => "Who's",
"We'Ve"  => "We've",
"Don'T"  => "Don't",
"It'S"   => "It's",
"You'D"  => "You'd",
"You'Re" => "You're",
"You'Ve" => "You've",
"Mother'S" => "Mother's",
);
$string =~ s/\`/'/g;### Replace ` with '
my $newstring = capitalize(lc($string));
$newstring =~ s/\&/And/g;
foreach my $key (keys %special) {
my $cmp = ucfirst($key);
$newstring =~ s/$cmp/$special{$key}/g;
}
$newstring =~ s/\'S /\'s /g;
$newstring =~ s/\'T /\'t /g;
$newstring =~ s/\'D /\'d /g;
$newstring =~ s/\'Re /\'re /g;
$newstring =~ s/\'M /\'m /g;
$newstring =~ s/\'Ll /\'ll /g;
return Strip($newstring);
}
sub LastFirst {
my $string = shift @_;
my $outstring = '';
my %special = ('jr' => 'Jr.',
'jr.' => 'Jr.',
'sr' => 'Sr.',
'sr.' => 'Sr.',
'iii' => 'III',
'ii' => 'II',
);
my @names = split /\//,$string;
foreach my $name (@names) {
if (!$name) {next;}
$name = Strip($name);
my $namesave = $name;
my $nick = '';
if (lc($name) ne '(n/a)') {
my $test = $name;
my $quote = $test =~ tr/\'//;  ### number of 's in the string
if ($quote > 1) {
my $a = '';
my $b = '';
($a,$nick,$b) = $name =~ /(.*?)\'(.*)\'(.*)/;
if (lc(substr($nick,-2,2)) eq ' d') {$nick = '';}
else { $name = Strip("$a $b");}
}### Nickname process
my @pieces = split " ",$name;
if ($pieces[0] !~ /\,/)  {
my $sfx = '';
my $last = pop @pieces;
if ($last) {
$last = Strip($last);
if ($special{lc($last)}) {### this is a suffix
$sfx = $special{lc($last)};
$last = pop @pieces;
}
}
if ($last) {
$last =~ s/\,//g;
$name = Strip($last) ;
if ($sfx or $nick or (scalar @pieces)) {$name = "$name,";}
}
else {$name = '';}
while (scalar @pieces) {$name = $name . ' ' .  shift @pieces;}
if ($nick) {$name = "$name '$nick'";}
$name = CapWord($name);
if ($sfx) {$name = "$name $sfx";}
}
else {$name = $namesave;}
}### Name NOT equal to '(n/a)'
if ($outstring) {$outstring = "$outstring/$name";}
else {$outstring = $name;}
}
return $outstring;
}
sub IsNumber {
use strict;
my $var = $_[0];
return looks_like_number($var);
if (
($var =~ /(^[0-9]{1,}?$)|(\,*?)|(\.{1})/) &&
!($var =~ /([a-zA-Z\?<>\+\\\=])|(^[\.\,]|[\.\,]$)/) &&
($var ne '')
) { return(TRUE) }
else { return(FALSE) }
}
sub BenchMark {
use strict;
my $timeref = shift @_;
my $logfile = shift @_;
if (!$timeref) {LogIt(363,"Program Error!$Yellow Useful:BenchMark- Missing hash reference!");}
if (!$logfile) {$logfile = '';}
my %times = ();
foreach my $key (keys %{$timeref}) {
my ($proctype,$procname) = split '_',$key,2;
$proctype = lc($proctype);
if (!$proctype) {$proctype = '';}
if (($proctype ne 'start') and ($proctype ne 'end') ) {
LogIt(429,"Program Error!$Yellow Useful:BenchMark$White unknown process type $Green$proctype for $key!");
}
if (!$procname) {LogIt(431,"Program Error!$Yellow Useful:BenchMark$White no process name  for $key!");}
$times{$procname}{$proctype} = $timeref->{$key};
}
foreach my $procname (keys %times) {
if (!defined $times{$procname}{'start'}) {
LogIt(1,"Program Error!$Yellow Useful:BenchMark missing Start for process=$Green$procname!");
next;
}
if (!defined $times{$procname}{'end'}) {
LogIt(1,"Program Error!$Yellow Useful:BenchMark missing End for process=$Green$procname!");
next;
}
$times{$procname}{'value'} = $times{$procname}{'end'} - $times{$procname}{'start'};
if ($times{$procname}{'value'} == 0) {$times{$procname}{'value'} = '0.1';}
}
LogIt(3,"\nBenchmark timings:");
foreach my $procname (sort keys %times) {
my $seconds = $times{$procname}{'value'};
my $time =  sprintf("%3.1f",$seconds) . "$White seconds";
if ($seconds > 60) {
my $minutes = $seconds/60;
$time =  sprintf("%7.2f",$minutes) . "$White minutes";
}
my $msg = "$Bold " . sprintf("%15.15s",$procname) . ":$Green$time";
LogIt(3,$msg);
$msg =~ s/\x1b\[[^m]+m//g;
}
return 0;
}
sub ReadDBF {
use strict;
my $db = shift @_;
if (!$db) {LogIt(427,"Programming Error!$Yellow Useful:ReadDBF$White missing db value!");}
if (! ref($db)) {LogIt(429,"Programming Error!$Yellow Useful:ReadDBF$White db is not a reference!");}
if (ref($db) ne 'ARRAY') {LogIt(430,"Programming Error!$Yellow Useful:ReadDBF$White db is not a reference to ARRAY!");}
my $filespec = shift @_;
if (!$filespec) {LogIt(433,"Programming Error!$Yellow Useful:ReadDBF$White missing filespec");}
if (!-e $filespec) {
LogIt(1,"$Yellow Useful:ReadDBF$White Cannot locate $Green$filespec");
return 1;
}
my $limit = shift @_;
if (!$limit or !IsNumber($limit)) {$limit = 0;}
my ($filename,$filepath,$fileext) = fileparse($filespec,qr/\.[^.]*/);
if (lc($fileext) ne '.dbf') {
LogIt(1,"$Yellow Useful:ReadDBF- $Green$filespec$White MUST be an .DBF type of file!");
return 2;
}
my $table = new XBase $filespec;
if (!$table) {
LogIt(1,"$Yellow Useful:ReadDBF- $Green$filespec$White open failed!");
return 3;
}
my $dbsize = $table->last_record;
LogIt(0,"   Database file initially has $Bold$Blue$dbsize$Reset records..");
foreach my $r (0..($dbsize-1)) {
if ($limit and ($r >= $limit)) {last;}
my %inrec = $table->get_record_as_hash($r);
my %outrec = ();
foreach my $key (keys %inrec) {
my $newkey = lc($key);
$outrec{$newkey} = $inrec{$key};
}
push @{$db},{%outrec};
}
$table->close;
return 0;
}
sub BuildDBF {
use strict;
my $structure = shift @_;
my $db = shift @_;
if (!$structure) {LogIt(500,"Programming Error!$Yellow Useful:BuildDBF$White missing structure value!");}
if (! ref($structure)  ) {LogIt(501,"Programming Error!$Yellow Useful:BuildDBF$White Structure is not a reference!");}
if (ref($structure) ne 'ARRAY') {LogIt(502,"Programming Error!$Yellow Useful:BuildDBF$White Structure is not a reference to ARRAY!");}
if (!$db) {LogIt(503,"Programming Error!$Yellow Useful:BuildDBF$White missing db value!");}
if (! ref($db)) {LogIt(504,"Programming Error!$Yellow Useful:BuildDBF$White db is not a reference!");}
if (ref($db) ne 'ARRAY') {LogIt(505,"Programming Error!$Yellow Useful:BuildDBF$White db is not a reference to ARRAY!");}
if (!-e $workingdir) {
my $rc = mkdir $workingdir;
if (!$rc) {LogIt(513,"$Yellow Useful:BuildDBF$White Cannot create directory $Green$workingdir$White. Result=$!");}
}
my @field_names = ();
my @field_types = ();
my @field_lengths = ();
my @field_decimals = ();
my @dbstructure = ();
foreach my $fld  (@{$structure}) {
my $use = $fld->{'use'};
if (($use !=0) and ($use != 3)) {next;}
my $name = $fld->{'key'};
if (!$name) {
print Dumper($fld),",n";
LogIt(531,"Programming Error!$Yellow Useful:BuildDBF$White.Empty key name!");
}
my $format = $fld->{'format'};
my $type = 'C';
if ($format eq 'float') {$type = 'N';}
my $len = $fld->{'length'};
if (!$len) {  LogIt(538,"Programming Error!$Yellow Useful:BuildDBF$White.0 or undefined length!");}
push @field_names,uc($name);
push @field_types,uc($type);
push @field_lengths,$len;
push @field_decimals,0;
push @dbstructure,$fld;
}
my $tfile = "$workingdir/temp.dbf";
if (-e $tfile) {`rm $tfile`;}
my $table= XBase->create("name" => $tfile,
"field_names" => [@field_names],
"field_types" => [@field_types],
"field_lengths" => [@field_lengths],
"field_decimals" => [@field_decimals]) ;
if (!$table) {
LogIt(554,"$Yellow Useful:BuildDBF$White Could not create the updated database file!\n Error=>" .
XBase->errstr);
}
foreach my $dbrdc (@{$db}) {
my %record = ();
foreach my $fld (@dbstructure) {
my $dbfield = $fld->{'key'};
my $ucfield = uc($fld->{'key'});
my $value = $dbrdc->{$dbfield};
if (!defined $value) {$value = '-';}
$record{$ucfield} = $dbrdc->{$dbfield};
}
$table->set_record_hash($table->last_record+1,%record);
my $rc = XBase->errstr();
if ($rc) {LogIt(1,"xbase set record returned $rc!");}
}
$table->close;
return $tfile;
}
sub ReadSpread {
use strict;
my $db = shift @_;
if (!$db) {LogIt(381,"Programming Error!$Yellow Useful:ReadSpread$White missing db value!");}
if (! ref($db)) {LogIt(382,"Programming Error!$Yellow Useful:ReadSpread$White db is not a reference!");}
if (ref($db) ne 'ARRAY') {LogIt(387,"Programming Error!$Yellow Useful:ReadSpread$White db is not a reference to ARRAY!");}
my $filespec = shift @_;
if (!$filespec) {LogIt(386,"Programming Error!$Yellow Useful:ReadSpread$White missing filespec");}
if (!-e $filespec) {
LogIt(1,"$Yellow Useful:ReadSpread$White Cannot locate $Green$filespec");
return 1;
}
my ($filename,$filepath,$fileext) = fileparse($filespec,qr/\.[^.]*/);
if (lc($fileext) ne '.ods') {
LogIt(1,"$Yellow Useful:ReadSpread- $Green$filespec$White MUST be an .ODS type of file!");
return 2;
}
if (!-e $workingdir) {
my $rc = mkdir $workingdir;
if (!$rc) {LogIt(406,"$Yellow Useful:ReadSpread-Cannot created directory $Green$workingdir$White. Result=$!");}
}
my $cmd = "unzip $filespec -d $workingdir";
LogIt(0,"$cmd");
system $cmd;
if ($?) {LogIt(408,"$Yellow Useful:ReadSpread$White Unzip failed!");}
LogIt(0,"Unzip complete");
LogIt(0,"Loading file into XML... Be patient!");
my $ref = XMLin("$workingdir/$contentfile",ForceArray => 1, KeyAttr => {});
if (!$ref) {LogIt(415,"$Yellow Useful:ReadSpread$White Cannot get XML for $Green$workingdir");}
LogIt(0,"XML loaded");
my $row = $ref->{'office:body'}[0]{'office:spreadsheet'}[0]{'table:table'}[0]{'table:table-row'};
my $rowcount = scalar @{$row};
my $cols = $ref->{'office:body'}[0]{'office:spreadsheet'}[0]{'table:table'}[0]{'table:table-column'};
my $colcount = scalar @{$cols};
LogIt(0,"spreadsheet has $rowcount rows and $colcount columns...");
my @structure = ();
foreach my $cell (@{$row->[$header_rec]{'table:table-cell'}}) {
my %struc = ('key' => lc($cell->{'text:p'}[0] ),
'use' => 0,
'format' => 'string',
);
push @structure,{%struc};
}
foreach my $thisrow ($data_rec..$rowcount) {
my %outrec = ();
my $cellndx = 0;
foreach my $fld (@structure) {
if ($fld->{'use'} > 1) {next;}
my $name = $fld->{'key'};
my $format = $fld->{'format'};
my $value = '';
foreach my $cell (@{$row->[$thisrow]{'table:table-cell'}[$cellndx]{'text:p'}}) {
$value = "$value$cell ";
}
$outrec{$name} = $value;
$cellndx++;
}
push @{$db},{%outrec};
}
return $ref;
}
sub BuildSpread {
use strict;
my ($pack,$file,$line) = caller();
my @spl = split '/',$file;
$file = pop @spl;
my $caller = "(Caller=$Yellow$file$White:$Green$line$White):";
my $pgmerr = "$Bold$caller$Red Programming Error$White! ";
my $structure = shift @_;
my $db = shift @_;
if (!$structure) {LogIt(437,"$pgmerr Missing structure value!");}
if (! ref($structure)  ) {LogIt(438,"$pgmerr Structure is not a reference!");}
if (ref($structure) ne 'ARRAY') {LogIt(439,"$pgmerr Structure is not a reference to ARRAY! (=>"
. ref($structure) .')' );}
if (!$db) {LogIt(440,"$pgmerr missing db value!");}
if (! ref($db)) {LogIt(441,"$pgmerr db is not a reference! (=>"
. $db . ')' );}
if (ref($db) ne 'ARRAY') {LogIt(442,"$pgmerr DB is not a reference to ARRAY!");}
my $template = shift @_;
if (!$template) {LogIt(446,"$pgmerr Missing template filespec");}
my $title = shift @_;
if (!$title) {$title = '';}
if (!-e $template) {LogIt(450,"$caller Cannot locate $Green$template$White to process!");}
my ($filename,$filepath,$fileext) = fileparse($template,qr/\.[^.]*/);
if (lc($fileext) ne '.ods') {LogIt(452,"$caller $Green$template$White MUST be an .ODS type of file!");}
if (!-e $workingdir) {
my $rc = mkdir $workingdir;
if (!$rc) {LogIt(457,"$caller Cannot create directory $Green$workingdir$White. Result=$!");}
}
`rm -r $workingdir/*`;
my $cmd = "unzip $template -d $workingdir";
my $ziplog = `$cmd`;
if ($?) {
LogIt(0,$ziplog);
LogIt(464,"$caller Unzip failed!");
}
open SPREAD,"$workingdir/$contentfile" or die "cannot open $contentfile";
my @spread = <SPREAD>;
close SPREAD;
my ($header,$trailer,$body) = extract(\@spread);
LogIt(3,"Reading $contentfile using XMLin...");
my $ref = XMLin("$workingdir/$contentfile",ForceArray => 1, KeyAttr => {});
if (!$ref) {LogIt(476,"$caller Cannot get XML for $contentfile");}
my $rows = $ref->{'office:body'}[0]{'office:spreadsheet'}[0]{'table:table'}[0]{'table:table-row'};
my $cols = $ref->{'office:body'}[0]{'office:spreadsheet'}[0]{'table:table'}[0]{'table:table-column'};
my $norows = scalar @{$rows};
my $nocols = scalar @{$cols};
my @spreadstruct = ();
foreach my $fld (@{$structure}) {
if ($fld->{'use'} > 1) {next;}
push @spreadstruct,$fld;
}
my $needed = scalar @spreadstruct;
if ($needed < $nocols) {
LogIt(3,"Creating additional columns...");
foreach my $ndx ($nocols..$needed) {
my %newcol = (
'table:default-cell-style-name' => 'Default');
push @{$cols},{%newcol};
}
}
my %record0 = %{$rows->[$title_rec]};
my $dt = Time_Format(time,'UYEAR');
$dt =~ s/\_/\-/g;
foreach my $cell (@{$record0{'table:table-cell'}}) {
if ($cell->{'office:date-value'}) {
$record0{'table:table-cell'}[0]{'calcext:date-value'} = $dt;
$record0{'table:table-cell'}[0]{'office:date-value'} = $dt;
$record0{'table:table-cell'}[0]{'text:p'}[0] = Time_Format(time,'DATE');
}
elsif (($cell->{'office:value-type'}) and ($cell->{'office:value-type'} eq 'string')) {
if ($title) {$cell->{'text:p'}[0] = $title;}
last;
}
}
my $stylename = 'r01';
if ($rows->[$header_rec]{'table:style-name'}) {
$stylename = $rows->[$header_rec]{'table:style-name'};
}
my @fmt = ();
foreach my $cell (@{$rows->[$header_rec]{'table:table-cell'}}) {
my $fmtstr = $cell->{'table:style-name'};
if (!$fmtstr) {$fmtstr = '';}
push @fmt,$fmtstr;
}
my @data_fmt = ();
foreach my $cell (@{$rows->[$data_rec]{'table:table-cell'}}) {
my $fmtstr = $cell->{'table:style-name'};
if (!$fmtstr) {$fmtstr = '';}
push @data_fmt,$fmtstr;
}
while (scalar @{$rows}) {shift @{$rows} };
my %header = ('table:style-name' => $stylename,
'table:table-cell' => [],
);
foreach my $fld (@spreadstruct) {
my %newcel = ('calcext:value-type' => 'string',
'office:value-type'  => 'string',
'text:p'             => [$fld->{'key'}],
);
my $fmstr = shift @fmt;
if ($fmstr) {$newcel{'table:style-name'} = $fmstr;}
push @{$header{'table:table-cell'}},{%newcel};
}
push @{$rows},{%record0};
push @{$rows},{%header};
LogIt(3,"adding new database records");
foreach my $dbrcd (@{$db}) {
my %newrow = ('table:style-name' => $stylename,
'table:table-cell' => [],);
my $msg = '';
if ($dbrcd->{'recno'}) {$msg = "for record no.$dbrcd->{'recno'}";}
my $colndx = 0;
foreach my $fld (@spreadstruct) {
my $name = $fld->{'key'};
if (!$name) {
print Dumper($fld),",n";
LogIt(893,"$pgmerr.Empty key name!");
}
my $format = $fld->{'format'};
if (!$format) {LogIt(1122,"Missing format for field=$fld->{'key'}");}
my %newcel = ('calcext:value-type' => $format,
'office:value-type'  => $format,
'text:p'             => [],
);
if ($data_fmt[$colndx]) {$newcel{'table:style-name'} = $data_fmt[$colndx];}
$colndx++;
if (!defined $dbrcd->{$name}) {
print Dumper($dbrcd),"\n";
LogIt(906,"$pgmerr $name key is defined in structure but not in data record!" );
}
my $value = $dbrcd->{$name};
$value = encode("utf8",$value);
if ($format eq 'date') {
if (!$value or ($value eq '-')) {
LogIt(1,"$Yellow Useful:BuildSpread:$White Date not available $msg");
$value = '01/01/1900';
}
my ($mm,$dd,$yy) = split /\//,$value;
if (!$yy) {
LogIt(1, "$Yellow Useful:BuildSpread:$White missing year in value=$value $msg");
$yy = '1900';
}
if (!$dd) {
LogIt(1,"$Yellow Useful:BuildSpread:$White missing day in value=$value $msg");
$dd = '01';
}
if (!$mm) {
LogIt(1, "$Yellow Useful:BuildSpread:$White missing month in value=$value $msg");
$mm = '01';
}
$newcel{'office:date-value'} = "$yy-$mm-$dd";
}### date format
elsif ($format eq 'float') {
if (!$value) {$value = 0;}
$newcel{'office:value'} = $value;
}
else {
if (!$value) {$value = '-';}
}
push @{$newcel{'text:p'}},$value;
push @{$newrow{'table:table-cell'}},{%newcel};
}### data column process
push @{$rows},{%newrow};
}
if (!$ref) {LogIt(676,"$Yellow Useful:BuildSpread$White Ref is 0!");}
LogIt(3,"Generating XML...");
system 'vmstat';
my $xml = XMLout($ref,KeyAttr => {});
LogIt(3,"saving XML to spreadsheet file");
system 'vmstat';
my @xml = ($xml);
my ($header2,$trailer2,$body2) = extract(\@xml);
open SPREAD,">$workingdir/$contentfile" or
LogIt(686, "$Yellow Useful:BuildSpread$White cannot write $contentfile");
print SPREAD $header;
print SPREAD $body2;
print SPREAD $trailer;
close SPREAD;
chdir $workingdir;
my $outfile = 'spread.ods';
$cmd = "zip -mor $outfile * >/tmp/ziplog";
LogIt(3,$cmd);
system $cmd;
if ($?) {
LogIt(0,$ziplog);
LogIt(1092,"$Yellow Useful:BuildSpread$White Failure ziping spread.ods");
}
return "$workingdir/$outfile";
}
sub SpreadNuc {
use strict;
my ($pack,$file,$line) = caller();
my @spl = split '/',$file;
$file = pop @spl;
my $caller = "(Caller=$Yellow$file$White:$Green$line$White):";
my $pgmerr = "$Bold$caller$Red Programming Error$White! ";
my $structure = shift @_;
my $db = shift @_;
if (!$structure) {LogIt(437,"$pgmerr Missing structure value!");}
if (! ref($structure)  ) {LogIt(438,"$pgmerr Structure is not a reference!");}
if (ref($structure) ne 'ARRAY') {LogIt(439,"$pgmerr Structure is not a reference to ARRAY! (=>"
. ref($structure) .')' );}
if (!$db) {LogIt(440,"$pgmerr missing db value!");}
if (! ref($db)) {LogIt(441,"$pgmerr db is not a reference! (=>"
. $db . ')' );}
if (ref($db) ne 'ARRAY') {LogIt(442,"$pgmerr DB is not a reference to ARRAY!");}
my $template = shift @_;
if (!$template) {LogIt(446,"$pgmerr Missing template filespec");}
my $title = shift @_;
if (!$title) {$title = '';}
if (!-e $template) {LogIt(450,"$caller Cannot locate $Green$template$White to process!");}
my ($filename,$filepath,$fileext) = fileparse($template,qr/\.[^.]*/);
if (lc($fileext) ne '.ods') {LogIt(452,"$caller $Green$template$White MUST be an .ODS type of file!");}
if (!-e $workingdir) {
my $rc = mkdir $workingdir;
if (!$rc) {LogIt(457,"$caller Cannot create directory $Green$workingdir$White. Result=$!");}
}
`rm -r $workingdir/*`;
my $cmd = "unzip $template -d $workingdir";
my $ziplog = `$cmd`;
if ($?) {
LogIt(0,$ziplog);
LogIt(464,"$caller Unzip failed!");
}
open SPREAD,"$workingdir/$contentfile" or die "cannot open $contentfile";
my @spread = <SPREAD>;
close SPREAD;
my ($header,$trailer,$body) = extract(\@spread);
LogIt(3,"Reading $contentfile using XMLin...");
my $ref = XMLin("$workingdir/$contentfile",ForceArray => 1, KeyAttr => {});
if (!$ref) {LogIt(476,"$caller Cannot get XML for $contentfile");}
my $rows = $ref->{'office:body'}[0]{'office:spreadsheet'}[0]{'table:table'}[0]{'table:table-row'};
my $cols = $ref->{'office:body'}[0]{'office:spreadsheet'}[0]{'table:table'}[0]{'table:table-column'};
my $norows = scalar @{$rows};
my $nocols = scalar @{$cols};
my @spreadstruct = ();
foreach my $fld (@{$structure}) {
if ($fld->{'use'} > 1) {next;}
push @spreadstruct,$fld;
}
my $needed = scalar @spreadstruct;
if ($needed < $nocols) {
LogIt(3,"Creating additional columns...");
foreach my $ndx ($nocols..$needed) {
my %newcol = (
'table:default-cell-style-name' => 'Default');
push @{$cols},{%newcol};
}
}
my %record0 = %{$rows->[$title_rec]};
my $dt = Time_Format(time,'UYEAR');
$dt =~ s/\_/\-/g;
foreach my $cell (@{$record0{'table:table-cell'}}) {
if ($cell->{'office:date-value'}) {
$record0{'table:table-cell'}[0]{'calcext:date-value'} = $dt;
$record0{'table:table-cell'}[0]{'text:p'}[0] = Time_Format(time,'DATE');
}
elsif (($cell->{'office:value-type'}) and ($cell->{'office:value-type'} eq 'string')) {
if ($title) {$cell->{'text:p'}[0] = $title;}
last;
}
}
my $stylename = 'r01';
if ($rows->[$header_rec]{'table:style-name'}) {
$stylename = $rows->[$header_rec]{'table:style-name'};
}
my @fmt = ();
foreach my $cell (@{$rows->[$header_rec]{'table:table-cell'}}) {
my $fmtstr = $cell->{'table:style-name'};
if (!$fmtstr) {$fmtstr = '';}
push @fmt,$fmtstr;
}
my @data_fmt = ();
foreach my $cell (@{$rows->[$data_rec]{'table:table-cell'}}) {
my $fmtstr = $cell->{'table:style-name'};
if (!$fmtstr) {$fmtstr = '';}
push @data_fmt,$fmtstr;
}
while (scalar @{$rows}) {shift @{$rows} };
my %header = ('table:style-name' => $stylename,
'table:table-cell' => [],
);
foreach my $fld (@spreadstruct) {
my %newcel = ('calcext:value-type' => 'string',
'office:value-type'  => 'string',
'text:p'             => [$fld->{'key'}],
);
my $fmstr = shift @fmt;
if ($fmstr) {$newcel{'table:style-name'} = $fmstr;}
push @{$header{'table:table-cell'}},{%newcel};
}
push @{$rows},{%record0};
push @{$rows},{%header};
LogIt(3,"adding new database records");
while (my $dbrcd = shift @{$db}) {
my %newrow = ('table:style-name' => $stylename,
'table:table-cell' => [],);
my $msg = '';
if ($dbrcd->{'recno'}) {$msg = "for record no.$dbrcd->{'recno'}";}
my $colndx = 0;
foreach my $fld (@spreadstruct) {
my $name = $fld->{'key'};
if (!$name) {
print Dumper($fld),",n";
LogIt(893,"$pgmerr.Empty key name!");
}
my $format = $fld->{'format'};
if (!$format) {LogIt(1122,"Missing format for field=$fld->{'key'}");}
my %newcel = ('calcext:value-type' => $format,
'office:value-type'  => $format,
'text:p'             => [],
);
if ($data_fmt[$colndx]) {$newcel{'table:style-name'} = $data_fmt[$colndx];}
$colndx++;
if (!defined $dbrcd->{$name}) {
print Dumper($dbrcd),"\n";
LogIt(906,"$pgmerr $name key is defined in structure but not in data record!" );
}
my $value = $dbrcd->{$name};
$value = encode("utf8",$value);
if ($format eq 'date') {
if (!$value or ($value eq '-')) {
LogIt(1,"$Yellow Useful:BuildSpread:$White Date not available $msg");
$value = '01/01/1900';
}
my ($mm,$dd,$yy) = split /\//,$value;
if (!$yy) {
LogIt(1, "$Yellow Useful:BuildSpread:$White missing year in value=$value $msg");
$yy = '1900';
}
if (!$dd) {
LogIt(1,"$Yellow Useful:BuildSpread:$White missing day in value=$value $msg");
$dd = '01';
}
if (!$mm) {
LogIt(1, "$Yellow Useful:BuildSpread:$White missing month in value=$value $msg");
$mm = '01';
}
$newcel{'office:date-value'} = "$yy-$mm-$dd";
}### date format
elsif ($format eq 'float') {
if (!$value) {$value = 0;}
$newcel{'office:value'} = $value;
}
else {
if (!$value) {$value = '-';}
}
push @{$newcel{'text:p'}},$value;
push @{$newrow{'table:table-cell'}},{%newcel};
}### data column process
push @{$rows},{%newrow};
}
if (!$ref) {LogIt(676,"$Yellow Useful:BuildSpread$White Ref is 0!");}
LogIt(3,"Generating XML...");
system 'vmstat';
my $xml = XMLout($ref,KeyAttr => {});
LogIt(3,"saving XML to spreadsheet file");
system 'vmstat';
my @xml = ($xml);
my ($header2,$trailer2,$body2) = extract(\@xml);
open SPREAD,">$workingdir/$contentfile" or
LogIt(686, "$Yellow Useful:BuildSpread$White cannot write $contentfile");
print SPREAD $header;
print SPREAD $body2;
print SPREAD $trailer;
close SPREAD;
chdir $workingdir;
my $outfile = 'spread.ods';
$cmd = "zip -mor $outfile *";
LogIt(3,$cmd);
system $cmd;
if ($?) {
LogIt(0,$ziplog);
LogIt(1092,"$Yellow Useful:BuildSpread$White Failure ziping spread.ods");
}
return "$workingdir/$outfile";
}
sub extract {
use strict;
my $ref = shift @_;
my $header  = '';
my $trailer = '';
my $body = '';
my $start = 0;
my $end = 0;
foreach my $line (@{$ref}) {
if (!$start) {
my $pos = index($line,'<office:spreadsheet');
if ($pos != -1) {
$header = $header . substr($line,0,$pos);
$start = 1;
$line = substr($line,$pos);
}
else {
$header = $header . $line;
next;
}
}
if ($end) {
$trailer = $trailer . $line;
}
else {
my $pos = index($line,'</office:spreadsheet>');
if ($pos != -1) {
$body = $body . substr($line,0,$pos+21);
$trailer = substr($line,$pos+21);
$end = 1;
}
else {$body = $body . $line;}
}
}
return $header,$trailer,$body;
}
sub CopyBack  {
use strict;
my ($pack,$file,$line) = caller();
my @spl = split '/',$file;
$file = pop @spl;
my $caller = " (Caller=$Yellow$file$White:$Green$line$White)";
my $contents = shift @_;
my $outfile = shift @_;
my $backcode = lc(shift @_);
my $backloc = shift @_;
my $proctype = 'array';
my %validcodes = ('old' => 1,'time' => 1, 'none' => 1);
if (!$contents) {LogIt(1232,"Programming Error!$caller. Missing contents value!");}
if (! ref($contents)  ) {LogIt(438,"Programming Error!$caller. Contents is not a reference!");}
if (ref($contents) eq 'ARRAY') {$proctype ='array';}
elsif (ref($contents) eq 'SCALAR') {$proctype = 'scalar';}
else {LogIt(1238,"Programming Error!$caller. Contents is not a reference to ARRAY or SCALAR! (=>"
. ref($contents) .')' );}
if (!$outfile) {LogIt(1259,"Programming Error!$caller Outfile parm is missing!");}
if (!$backcode) {LogIt(1260,"Programming Error!$caller Backcode parm is missing!");}
if (!$validcodes{$backcode}) {LogIt(1245,"Programming Error!$caller Invalid backcode!");}
if ($backloc and (! -d $backloc)) {
LogIt(1,"$caller. Directory $Green$backloc was not found!");
return 2;
}
my $tmpfile = "/tmp/temp_" . time() . '.tmp';
$outfile =~ s/\"/\\\"/g;
if ($proctype eq 'array') {
if (open TFILE,">$tmpfile") {print TFILE @{$contents};close TFILE;}
else {LogIt(1251,"$caller:Got error $? when opening $Yellow$tmpfile");}
}
else {
$tmpfile = $$contents;
if (!$tmpfile) {LogIt(1276,"Programming Error!$caller filespec is empty!");}
if (! -f $tmpfile) {
LogIt(5,"$caller:$Green$tmpfile$White was not found!");
return 1;
}
if ($tmpfile eq $outfile) {LogIt(1283,"Programming Error!$caller input and output file are the same!");}
}
if (-e $outfile) {
if ($backcode eq 'old') {
my $backfile = "$outfile.old";
my $cmd = "mv $outfile $backfile";
LogIt(3,$cmd);
system "$cmd";
if ($?) {
LogIt(1274,"$caller:Bad code $? from backup!");
}
}
elsif ($backcode eq 'time') {
my $backfile = $outfile . '.' . time();
if ($outfile eq $backfile) {
$backfile = $outfile . '.' . time() . "_1";
}
my $cmd = "mv $outfile $backfile";
LogIt(3,$cmd);
system "$cmd";
if ($?) {
LogIt(1284,"$caller:Bad code $? from backup!");
}
if ($backloc) {
$cmd = "mv $backfile $backloc/";
LogIt(3,$cmd);
system "$cmd";
if ($?) {
LogIt(1291,"$caller:Bad code $? from backup!");
}
}
}
else {
}
}
my $cmd = 'cp -av "' . $tmpfile . '" "' . $outfile .'"';
if ($proctype eq 'array')  {$cmd = "mv -v $tmpfile $outfile";}
LogIt(3,$cmd);
system $cmd;
if ($?) {
LogIt(1304,"$caller:Bad code $? from copy!");
}
return 0;
}
sub List_Of_Files {
use strict;
my ($pack,$file,$line) = caller();
my @spl = split '/',$file;
$file = pop @spl;
my $caller = " (Caller=$Yellow$file$White:$Green$line$White)";
my $ref = shift @_;
if (!$ref) {LogIt(1384,"Programming Error!$caller. Missing array parm!");}
if (! ref($ref)  ) {LogIt(1385,"Programming Error!$caller. Array parm is not a reference!");}
if (ref($ref) ne 'ARRAY') {LogIt(1386,"Programming Error!$caller. Array parm is not a reference to Array!");}
my $option = shift @_;
my $nodir = FALSE;
my $nofiles = FALSE;
if ($option) {
$option = lc(Strip($option));
if ($option eq 'dir') {$nofiles = TRUE;}
elsif ($option eq 'files') {$nodir = TRUE;}
else {if ($option ne 'all') {LogIt(1397,"Programming Error! $caller. Option $option is not valid!");}}
}
my @spec = @_;
if (!scalar @spec) {@spec = @ARGV;}
foreach my $arg (@spec) {
my $fspec = $arg;
if ($arg =~ m/\*/) {
my @newlist = glob "'$arg'";
foreach my $fs (@newlist) {
if ($nodir and (-d $fs)) {next;}
if ($nofiles and (! -d $fs)) {next;}
my ($filename,$filepath,$fileext) = fileparse($fs,qr/\.[^.]*/);
$filepath = abs_path($filepath);
push @{$ref},{'fspec' => $fs,'filename'=>$filename,'ext'=>$fileext,'path'=>$filepath};
}
}
else {
if ($nodir and (-d $fspec)) {next;}
if ($nofiles and (! -d $fspec)) {next;}
my ($filename,$filepath,$fileext) = fileparse($fspec,qr/\.[^.]*/);
$filepath = abs_path($filepath);
push @{$ref},{'fspec' => $fspec,'filename'=>$filename,'ext'=>$fileext,'path'=>$filepath};
}
}
return 0;
}
sub Title_Format {
my $title = shift @_;
if (!$title) {return '';}
$title = Strip($title);
$title = ucfirst($title);
foreach my $test ('the ','a ','an ') {
my $var = '';
if (($var) = $title =~ m/^($test)/i) {
$title  =~ s/$var//i;
$title = Strip("$title, " . ucfirst($var));
last;
}
}
return $title;
}

sub Help_Me {
  
   my $dply =FALSE;
   open (PROGRAM,$0) or die "cannot open $0!";
   my @inlines = <PROGRAM>;
   close PROGRAM;
   my $section = '';
   if (scalar @ARGV) {$section = lc(shift @ARGV);}
  
   
   my ($fn,$path,$ext) = fileparse($0,qr/\.[^.]*/);
   my @outlines;
   push @outlines,"$Bold$Green ################# $Yellow$fn$Blue ";
   if ($Rev) {push @outlines,"Rev $Red",sprintf("%-4.2f",$Rev);}
   else {push @outlines," ########";}
   push @outlines,"$Green ################$Eol\n";
   push @outlines,"$Bold$White";   
   my $skip = FALSE;      
   my $insession = FALSE;  
   my $first = TRUE;     
   my $delim = "##########";  
READ: while (scalar @inlines) {
      my $inrec = shift @inlines;
      if ($inrec =~ m/$delim/) {
         if ($first) {  ### got top
           # print "found first!\n";
            $first = FALSE;
            next; 
         }
         elsif (!$first) {last READ;}   
      }
      if ($first) {
        
       next READ;}
      
      $inrec =~ tr/#//d;   
      my ($keyword) = $inrec =~ m/^\:(\w*)\:/;  
     
      if ($keyword) {
         $keyword = lc($keyword);  
        
         if ($keyword eq 'options') {
      
            push @outlines,"   $Yellow Options:$White\n";
            foreach my $opt (sort keys %Options) {
               my @opchars = split '=',$opt;  
               push @outlines,"       " . sprintf("%-10.10s",$opchars[0]);
               if ($OptDescript{$opt}) {push @outlines," - $Magenta$OptDescript{$opt}$White";}
               push @outlines,"\n";
            }
            push @outlines,"\n";
          
            my $found = FALSE;
            while (!$found) {
               if (scalar @inlines) {
                 if (substr($inlines[0],0,3) eq '#:') {$found = TRUE;}  
                 elsif ($inrec =~ m/$delim/) {$found = TRUE;}          
                 else {$inrec = shift @inlines;}                         
               }
               else {last READ;}  
            }
         }
            
         
      
         elsif ($keyword eq 'syntax') {
            push @outlines, "   $Yellow syntax:$White $'";   
         }
         
         elsif ($keyword eq 'operation') {
            push @outlines,"   $Yellow Operation:$White $'";
               
         }
            
        
         elsif ($keyword eq 'section')  {
          
            if (!$section or ($' =~ m/$section/i)) { 
               my $stuff = $';   
               chomp $stuff;    
               $stuff = Strip($stuff);  
               push @outlines,"  $Yellow <<<<<< $White $stuff $Yellow >>>>>>$White\n";
               
            }
          
            else {
               my $found = FALSE;
               while (!$found) {
                  if (scalar @inlines) {
                     my $str = ':section:';
                     if ($inlines[0] =~ m/$str/i) {$found = TRUE;}  
                     elsif ($inrec =~ m/$delim/) {$found = TRUE;}   
                     else {$inrec = shift @inlines;}                 
                  }
                  else {last READ;}  
               }
            }
         }
                  
            
            
         else {push @outlines,"$inrec";}   
         
      }
         
      else {push @outlines,"$inrec";}
       
   }
   close PROGRAM;
   push @outlines,"$Green################# End Of Help #########$Eol";
   
   foreach my $line (@outlines) {
      print $line;
   }
   exit 9999
   
}


sub WhereAmI {
my @rsp = `cat /proc/cpuinfo`;
my $model = '';
my %hardware;
my $rc = 0;
foreach  my $line (@rsp) {
my $kwd = '';
my $value = '';
chomp $line;
if (!$line) {next;}
($kwd,$value) = split ':',$line,2;
if (!$kwd) {next;}
$kwd = Strip($kwd);
$hardware{$kwd} = Strip($value);
}
if ($hardware{'model name'} eq 'AMD FX(tm)-8350 Eight-Core Processor') {
$rc=1;
}
elsif ($hardware{'model name'} eq 'Intel(R) Core(TM) i7-3610QM CPU @ 2.30GHz'){
$rc = 2;
}
elsif ($hardware{'model name'} eq 'Intel(R) Core(TM) i5-2520M CPU @ 2.50GHz') {
$rc = 3;
}
else {
print "unknown model $hardware{'model name'}\n";
$rc = 0;
}
return $rc;
}
sub Commify {
local $_  = shift;
s{(?<!\d|\.)(\d{4,})}
{my $n = $1;
$n=~s/(?<=.)(?=(?:.{3})+$)/,/g;
$n;
}eg;
return $_;
}
sub Get_Answer {
my $msg = shift @_;
if (!$msg) {$msg = 'OK To Continue?';}
print STDERR "  $Bold$msg$Reset=>";
my $answer = <STDIN>;
chomp($answer);
print STDERR "$Eol";
if (uc(substr($answer,0,1)) ne 'Y') {
print STDERR "\n$Bold script aborted at users request$Eol$Eol";
exit 9999;
}
}
sub MtabRead {
my $mtab = shift @_;
if (!$mtab) {
return ("Error! No reference passed to read_mtab!");
}
open MTAB,"/etc/mtab" or    return "cannot read /etc/mtab.Error=$!";
my @mtab = <MTAB>;
close MTAB;
foreach my $rcd (@mtab) {
chomp $rcd;
my @flds = split(" ",$rcd);
if (substr($flds[0],0,4) ne '/dev') {next;}
$mtab->{$flds[1]} = $flds[0];
}
return '';
}
sub Parms_Proc {
my $k;
my $char_opts = '';
my $retcode = 0;
my @optctl = ();
my @newargv = ();
my %single = ();
my %data = ();
my $caseset = shift @_;
if (defined $caseset) {
if (lc($caseset) eq 'nocase') {$caseset = TRUE;}
else {$caseset = FALSE;}
}
else {$caseset = FALSE;}
local $SIG{__WARN__} = \&warning;
$Getopt::Long::debug = FALSE;
$Getopt::Long::ignorecase = FALSE;
if ($caseset) {
$Getopt::Long::ignorecase = TRUE;
}
foreach $k (keys %Single_Options) {
if (length($k) == 1) {
$char_opts = "$char_opts$k";
$single{$k} = TRUE;
if ($caseset) {$single{lc($k)} = TRUE;}
}
my %opthash = ("$k!" => \$Single_Options{$k});
my $data_type = ref $Single_Options{$k};
if ($data_type) {
if ($data_type eq "CODE" ){
$opthash{"$k!"} = $Single_Options{$k};
}
else {
print STDERR "Parms_Proc:Error! Data_type=$data_type ",
"is not valid for Single_Options{$k}!\n";
exit 9999;
}
}
push @optctl,%opthash;
}
foreach $k (keys %Data_Options) {
if (length($k) == 1) {
$char_opts = "$char_opts$k:";
$data{$k} = TRUE;
if ($caseset) {$data{lc($k)} = TRUE;}
}
my %opthash = ("$k=s" => \$Data_Options{$k});
my $data_type = ref $Data_Options{$k};
if ($data_type) {
if ($data_type eq "ARRAY") {
%opthash = ("$k=s@" =>  \$Data_Options{$k});
}
else {
print STDERR "Parms_Proc:Error! Data_type=$data_type ",
"is not valid for Data_Options{$k}!\n";
exit 9999;
}
}
push @optctl,%opthash;
}
push @optctl,"<>";
push @optctl,\&Data_Parms;
foreach my $arg (@ARGV) {
while (length($arg)) {
if ((length($arg) > 2) and (substr($arg,0,1) eq '-')  and (substr($arg,1,1) ne '-') ){
my $nextchar = substr($arg,1,1);
if ($caseset) {$nextchar = lc($nextchar);}
if ($single{$nextchar}) {
push @newargv,"-$nextchar";
$arg = "-" . substr($arg,2);
}
elsif ($data{$nextchar}) {
push @newargv,"-$nextchar";
push @newargv,substr($arg,2);
$arg = '';
}
else {
push @newargv,$arg;
$arg = '';
}
}
else {
push @newargv,$arg;
$arg = '';
}
}
}
@ARGV = @newargv;
$retcode = &GetOptions(@optctl);
return $retcode;
}
sub Data_Parms {
push @Parms, shift,@_;
return;
}
sub warning {
my $bold = "\e[1m";
my $red = "\e[31m";
my $reset = "\e[0m";
my $os = $^O;
if (substr($os,0,3) eq 'MSW') {
$bold = '';
$red = '';
$reset = '';
}
my $eol = "$reset\n";
my $msg = shift @_;
chomp $msg;
my ($first,$var) = split ":",$msg;
if (substr($first,0,7) eq "Unknown") {
print STDERR "$bold option $red$var$reset$bold ignored $eol";
}
else {
print STDERR "$bold $msg $eol\n";
}
return;
}
sub ConfigFileProc {
my ($filespec,$array,$dtype,$dlm,$validate) =  @_;
if (!$filespec) {
print "$Bold$Red Error!$White No filespec passed to ConfigFileProc!$Eol";
exit 9999;
}
if (!$array) {
print "$Bold$Red Error!$White No array reference passed to ConfigFileProc!$Eol";
exit 9999;
}
if (!-e $filespec) {
return 1;
}
my $errmsgkey = 'errmsg_';
my $recnokey = 'recno_';
my $linekey = 'line_';
my $delim = ' ';
my $type = '';
if ($dtype) {
if ($dtype eq '-') { }
elsif ($dtype eq 'k') {$type = 'k';}
elsif ($dtype eq 'p') {$type = 'p';}
else {
print "$Bold$Red Error!$White Invalid config type spec $dtype in ConfigFileProc!$Eol";
exit 9999;
}
}
if ($dlm) {
if ($dlm eq '-') {  }
elsif ($dlm eq 'c') {$delim = ',';}
elsif ($dlm eq 'b') {$delim = ' ';}
else {
print "$Bold$Red Error!$White Invalid delimiter spec $dlm in ConfigFileProc!$Eol";
exit 9999;
}
}
my @rcds = ();
if (open INFILE,"$filespec") {
@rcds = <INFILE>;
close INFILE;
}
else {
return 2;
}
my $recno = 0;
my $retcode = 0;
foreach my $rcd (@rcds) {
$recno++;
chomp $rcd;
if (!$rcd) {next;}
$rcd =~ s/^\s+//;
if (substr($rcd,0,1) eq '#') { next;}
if (substr($rcd,0,1) eq '*') { next;}
my $comment = '';
($rcd,$comment) = split '#',$rcd,2;
if (!$rcd) {next;}
my %hash = ($recnokey => $recno,$errmsgkey => '',$linekey => $rcd);
my $pos = 0;
my $qcount = () = $rcd =~ /\"/g;
if ($qcount % 2) {
$hash{$errmsgkey} = "$Bold$Red Error!$White Odd number of quotes in line ".
"$Green$recno$White of $Yellow$filespec$White! Line Ignored";
$retcode = 3;
push @{$array},{%hash};
next;
}
if (!$type) {
if ($rcd =~ /\=/) {$type = 'k';}
else {$type = 'p';}
if ($rcd =~ /\,/) {$delim = ',';}
}
my @errors = ();
WORD: while ($rcd) {
$pos++;
my $keywd = sprintf("%04.4u",$pos);
my $value = '';
if ($type eq 'k') {
if ($rcd !~ /\=/) {
push @errors,"$Bold$Red Error!$White Missing '=' after $Blue$rcd$White in line ".
"$Green$recno$White of $Yellow$filespec$White! Rest of line bypassed";
$retcode = 3;
last;
}
($keywd,$rcd) = split '=',$rcd,2;
if (!$keywd) {last;}
if (!defined $rcd) {
push @errors,"$Bold$Red Error!$White Missing value after keyword $Blue$keywd$White in line ".
"$Green$recno$White of $Yellow$filespec$White! Rest of line bypassed";
$retcode = 3;
last;
}
$keywd =~ s/^\s+//;
if (substr($keywd,0,1) eq '"') { ### if keyword quoted, move quotes to after '='
$keywd = substr($keywd,1);
$rcd = '"' . $rcd;     ### add to value
}
$keywd =~ s/\s+$//;
if ($keywd =~ / /) {
push @errors,"$Bold$Red Error!$White keyword $Blue$keywd$White has imbedded blanks in line ".
"$Green$recno$White of $Yellow$filespec$White! Rest of line ($rcd) bypassed";
$retcode = 3;
last;
}
$keywd = lc($keywd);
}
$rcd =~ s/^\s+//;
if (substr($rcd,0,1) eq '"') {
$rcd = substr($rcd,1);
if ($rcd =~ /\"/) {($value,$rcd) = split ('"',$rcd,2);}
else {
push @errors,"$Bold$Red Error!$White Missing closing quote in line ".
"$Green$recno$White of $Yellow$filespec$White! Rest of line bypassed";
$retcode = 3;
last;
}
$rcd =~ s/^\s+//;
if (substr($rcd,0,1) eq $delim) {$rcd = substr($rcd,1);}
}
else {($value,$rcd) = split ($delim,$rcd,2);}
if ($rcd) {$rcd =~ s/^\s+//;}
if ($validate) {
if ($validate->{$keywd}) {
my $keytype = $validate->{$keywd};
my $emsg = "$Bold$Red Error! '$Magenta$value$White' is not valid for keyword $Blue$keywd$White in line ".
"$Green$recno$White of $Yellow$filespec$White!";
if ((ref $keytype) eq 'ARRAY') {
my $found = FALSE;
foreach my $str (@{$keytype}) {
if (lc($value) eq lc($str)) {
$found = TRUE;
last;
}
}
if (!$found) {
push @errors,$emsg;
$retcode = 3;
next WORD;
}### value not found
}#### array check
elsif (lc($keytype) eq 'n') {
if ((!IsNumber($value)) or ($value <= 0)) {
push @errors,$emsg;
$retcode = 3;
next WORD;
}
}### number process
elsif (lc($keytype) eq 'i') {
if ($value !~ /^[0-9]*$/) {
push @errors,$emsg;
$retcode = 3;
next WORD;
}
}### Integer test
elsif (lc($keytype) eq 'x') {
if ($value !~ /^[0-9,a,b,c,d,e,f]*$/i) {
push @errors,$emsg;
$retcode = 3;
next WORD;
}
}### Integer test
elsif (lc($keytype) eq 'b') {
if ($value) {
my $fc = lc(substr($value,0,1));
if (($fc eq 'y') or ($fc eq 't') or ($fc eq '1')) {$value = TRUE;}
else {$value = FALSE;}
}
else {$value = FALSE;}
}
elsif (lc($keytype) eq 'f'){
if ((IsNumber($value)) and ($value > 0)) {
if ($value =~ /\./) {### got a decimal
my ($mhz,$khz) = split /\./,$value,2;
$khz = substr($khz . '000000',0,6);
if (!$mhz) {$mhz = 0;}
$value = "$mhz$khz";
}
}
else {
push @errors,$emsg;
$retcode = 3;
next WORD;
}
}
}
}
$hash{$keywd} = $value;
}
foreach my $msg (@errors) {
if (!$msg) {next;}
if ($hash{$errmsgkey} ) {$hash{$errmsgkey} = $hash{$errmsgkey} . "$Eol$msg";}
else{$hash{$errmsgkey} = $msg;}
}
push @{$array},{%hash};
}### record process
return $retcode;
}
sub Read_Config {
use Text::CSV;
my $retcode = 0;
my $filespec = shift @_;
if (!$filespec) {LogIt(104,"Missing filespec for READ_CONFIG!");}
my $ref = shift @_;
if (!$ref) {LogIt(105,"Missing array reference for READ_CONFIG!");}
my $config = 'b';
if (scalar @_) {$config = lc(substr(shift @_,0,1));}
if (!-e $filespec) {return 1;}
open INFILE,$filespec or return 2;
my @inrecs = <INFILE>;
close INFILE;
my $recno = 0;
my $delim = ' ';
if ($config eq 'c') {$delim = ',';}
my $csv = Text::CSV->new({ sep_char => $delim});
LINE:   foreach my $rec (@inrecs) {
$recno++;
chomp $rec;
if ($rec) {$rec = Strip($rec);}
if (!$rec) {next;}
if ($rec =~ /^\#/) {next;}
if ($rec =~ /^\*/) {next;}
my $comment = '';
my $linemsg = "line $Green$recno$White for $Yellow$filespec$White.";
if ($rec !~ /\"/) { ### no quotes, check for line comment
if ($rec =~ /\#/) {($rec,$comment) = split /\#/,$rec,2;}
if ($rec =~ /\*/) {($rec,$comment) = split /\*/,$rec,2;}
}
else {
if ($rec =~ /\#/) {LogIt(1,"'#' on line with quoted string $linemsg");}
if ($rec =~ /\*/) {LogIt(1,"'*' on line with quoted string $linemsg");}
}
$rec = Strip($rec);
if (!$rec) {next;}
my %outrec = ('line_' => $rec,'rec_' => $recno);
my $valid = 0;
if ($csv->parse($rec)) {
my @fields = $csv->fields();
foreach my $ndx (0..$#fields) {
my $value = Strip($fields[$ndx]);
if (!$value and ($config ne 'c')) {next;}
my $keyword = $ndx+1;
if ($config eq 'k') {
($keyword,$value) = split /\=/,$value,2;
if (!$keyword) {
LogIt(1,"Keyword missing in $linemsg  Line ignored");
print "$rec\n";
$retcode = 3;
next LINE;
}
$keyword = lc(Strip($keyword));
if (($keyword eq 'line_') or ($keyword eq 'rec_')) {
LogIt(1,"Keyword $Magenta$keyword$White is reserved in $linemsg Keyword ignored");
$retcode = 3;
next;
}
if (defined $outrec{$keyword}) {
LogIt(1,"keyword $Magenta$keyword$White used twice in $linemsg Prior value ignored");
}
if ($value) {$value = Strip($value);}
}### 'k' process
$outrec{$keyword} = $value;
$valid++;
}### Foreach $ndx
}
else {
LogIt(1,"Could not parse $linemsg");
$retcode = 3;
next;
}
if ($valid) {push @{$ref},{%outrec};}
}### process all records
return $retcode;
}
sub KeyFormat {
my ($pack,$file,$line) = caller();
my @spl = split '/',$file;
$file = pop @spl;
my $caller = "(Caller=$Yellow$file$White:$Green$line$White):";
my $year = Strip(shift @_);
if (!$year) {$year = '0000';}
my $outstring = shift @_;
my $saveit = $outstring;
if (!$outstring) {$outstring = '?';}
my @options = @_;
my $noyear = FALSE;
my $notrunc = FALSE;
my $noa = FALSE;
my $dbg = FALSE;
foreach my $opt (@options) {
if (lc($opt) eq 'noyear') {$noyear = TRUE;}
elsif (lc($opt) eq 'notrunc') {$notrunc = TRUE;}
elsif (lc($opt) eq 'noa') {$noa = TRUE;}
elsif (lc($opt) eq 'dbg') {$dgg = TRUE;}
else {LogIt(1,"USEFUL.PM l3940:Invalid option $opt passed to KeyFormat routine");}
}
$outstring = Strip(lc($outstring));
my $pos = -1;
$outstring =~ s/ +/ /gs;
$outstring =~ s/\-/ /;
if ($dbg) {print "KEYFORMAT l3959=>$outstring\n";}
$outstring =~ s/\:/ /;
$outstring =~ s/\_/ /;
$outstring =~ s/^the //g;
if ($dbg) {print "KEYFORMAT L3963=>$outstring\n";}
$outstring =~ s/ the$//g;
if ($dbg) {print "KEYFORMAT l3966=>$outstring\n";}
$outstring =~ s/\,the$//g;
if ($dbg) {print "KEYFORMAT l3968=>$outstring\n";}
while( $outstring =~ s/ the / /g) {;}
if ($dbg) {print "KEYFORMAT l3971=>$outstring\n";}
$outstring =~ s/^a //g;
$outstring =~ s/\, a$//g;
$outstring =~ s/\,a$//g;
if ($dbg) {print "KEYFORMAT l3975=>$outstring\n";}
$outstring =~ s/^an //g;
$outstring =~ s/\, an$//g;
$outstring =~ s/\,an$//g;
while($outstring =~ s/ an / /g) {;}
if ($noa) {
$outstring =~ s/ a$//g;
while ($outstring =~ s/ a / /g) {;}
}
$outstring =~ s/\&/and/gs;
$outstring =~ s/[^A-Za-z0-9_ ]*//g;
$outstring =~ s/ +/ /gs;
if ($outstring) {$outstring = Strip($outstring);}
if (!$notrunc) {
if (length($outstring) > KEYLENGTH) {$outstring = substr($outstring,0,KEYLENGTH)};
}
if (!$noyear) {$outstring =  $year . '_' . $outstring;}
return $outstring;
}
sub Title_Unformat {
my $title = shift @_;
if (!$title) {return '';}
$title = Strip($title);
if ($title =~ m/(\,the)$/i) {$title = "The $`$'";}
elsif ($title =~ m/(\, the)$/i) {$title = "The $`$'";}
elsif ($title =~ m/(\,an)$/i) {$title = "An $`$'";}
elsif ($title =~ m/(\, an)$/i) {$title = "An $`$'";}
elsif ($title =~ m/(\,a)$/i) {$title = "A $`$'";}
elsif ($title =~ m/(\, a)$/i) {$title = "A $`$'";}
return Strip($title);
}
sub MakeKey {
my $filename = Strip(shift @_);
my @options = @_;
my $filmdate = "0000";
my $title = $filename;
my $remainder = '';
my $key = '????';
my ($newyear) =  $filename =~ m|\((\d{4})\)|;
if ($newyear) {
$filmdate = $newyear;
$title = $`;
$remainder = $'; ### everything after date
}
$key = KeyFormat($filmdate,$title,@options);
return $key,$filmdate,$title,$remainder;
}
sub Get_Codec {
use strict;
my ($pack,$file,$line) = caller();
my @spl = split '/',$file;
$file = pop @spl;
my $caller = "(Caller=$Yellow$file$White:$Green$line$White):";
my $fspec = shift @_;
my $ref = shift @_;
my $retcode = 0;
if (!$fspec) {LogIt(4804," No filename given for GET_CODEC. Caller=$caller");}
if (!-e $fspec) {return 1;}
if ($fspec =~ m/\?/g) {return 3;}
$fspec =~ s/\"/\\\"/g;
if (!$ref) {LogIt(4808,"Missing hash reference in GET_CODEC. Caller=$caller");}
my ($filename,$path,$ext) = fileparse($fspec,qr/\.[^.]*/);
$ext =~ s/\.//;
if ($MediaType{lc($ext)} ne 'v') {return 2;}
my @info = `mediainfo "$fspec" 2>&1`;
if ($?) {LogIt(1,"I/O error processing $fspec");return 4;}
foreach my $key ('minutes','vcodec','vcodecid','width','height','acodec','acodecid') {
$ref->{$key} = '?';
}
my %keywords = ();
my $type = 'u';
foreach my $rcd (@info) {
chomp $rcd;
if (!$rcd) {next;}
my ($keywd,$value) = split ':',$rcd,2;
$keywd = Strip(lc($keywd));
if (substr($keywd,0,5)  eq 'video') {$type = 'v';next;}
elsif (substr($keywd,0,5)  eq 'audio') {$type = 'a';next;}
elsif (substr($keywd,0,4) eq 'text') {last;}
if (!$value) {$value = '?';}
$keywords{$type}{$keywd} = Strip($value);
}
if ($keywords{'v'}{'width'}) {
my $width = $keywords{'v'}{'width'};
$width =~ s/pixels//i;
$width =~ s/\s//g;
$ref->{'width'} = $width;
}
if ($keywords{'v'}{'height'}) {
my $height = $keywords{'v'}{'height'};
$height =~ s/pixels//i;
$height =~ s/\s//g;
$ref->{'height'} = $height;
}
if ($keywords{'v'}{'codec id'}) {$ref->{'vcodec'} = $keywords{'v'}{'codec id'};}
elsif ($keywords{'v'}{'format'}) {$ref->{'vcodec'} = $keywords{'v'}{'format'};}
if ($keywords{'a'}{'format'}) {$ref->{'acodec'} = $keywords{'a'}{'format'};}
elsif ($keywords{'v'}{'codec_id'}) {$ref->{'acodec'} = $keywords{'v'}{'codec_id'};}
if ($keywords{'v'}{'duration'}) {
my ($hr) = $keywords{'v'}{'duration'} =~ m/(\d*) h/i;
my ($mn) = $keywords{'v'}{'duration'} =~ m/(\d*) min/i;
if (!$hr) {$hr = 0;}
if (!$mn) {$mn = 0;}
$mn = int(($hr * 60) + $mn);
if (!$mn) {$mn = 1;};
$ref->{'minutes'} = ($hr * 60) + $mn;
}
if ($keywords{'v'}{'e'}) {LogIt(1,"$keywords{'v'}{'e'} for $fspec");}
if    (lc($ref->{'vcodec'}) eq 'avc1')               {$ref->{'vcodec'} = 'X264';}
elsif (lc($ref->{'vcodec'}) eq 'xvid')               {$ref->{'vcodec'} = 'XVID';}
elsif (lc($ref->{'vcodec'}) eq '40')                 {$ref->{'vcodec'} = 'MP4V';}
elsif (lc($ref->{'vcodec'}) eq '20')                 {$ref->{'vcodec'} = 'MPEG-4';}
elsif (lc($ref->{'vcodec'}) eq 'mpeg video')         {$ref->{'vcodec'} = 'MPEG';}
elsif (lc(substr($ref->{'vcodec'},0,7)) eq 'v_mpeg4') {$ref->{'vcodec'} = 'X264';}
if (lc($ref->{'acodec'}) eq 'mpeg audio')         {
$ref->{'acodec'} = 'MPEG';
if ($keywords{'a'}{'format profile'}) {
my ($layer) = $keywords{'a'}{'format profile'} =~ m/layer (\d)/i;
if ($layer) {$ref->{'acodec'} = "MP$layer";}
}
}
return $retcode;
}
sub Dir_Glob  {
my $dir = shift @_;
my $array = shift @_;
if (!$dir) {LogIt(4138,"Dir_Glob:Missing directory parameter");}
if (!$array) {LogIt(4139,"Dir_Glob:Missing array parameter");}
if (!-e $dir) {return 1;}
my @allfiles = ();
if (opendir DIRHANDLE,$dir) {
@allfiles = readdir DIRHANDLE;
closedir DIRHANDLE;
}
else {return 2;}
foreach my $file (@allfiles) {
if ($file eq '.') {next;}
if ($file eq '..') {next;}
push @{$array},$dir . '/' . $file;
}
close DIRHANDLE;
return 0;
}
sub NoDouble  {
my $string = shift @_;
my $double = '//';
my $single = '/';
$string =~ s/$double/$single/g;
return $string;
}
sub TrueFalse {
my $str = shift @_;
my $ret = 1;
if ($str) {$str = Strip(lc($str));}
if (!$str) {$ret = 0;}
elsif ($str eq 'no') {$ret = 0;}
elsif ($str eq 'n') {$ret = 0;}
elsif ($str eq 'false') {$ret = 0;}
elsif ($str eq 'f') {$ret = 0;}
elsif ($str eq 'off') {$ret = 0;}
return $ret;
}
sub SystemInfo_Old {
use strict;
use autovivification;
no  autovivification;
my $diskinfo = shift @_;
if (!$diskinfo) {LogIt(4132,"SystemInfo:Missing variable reference!");}
my $maxpartno = 16;
my %mtab = ();
if (open MTAB,"/etc/mtab") {
my @mtab = <MTAB>;
close MTAB;
foreach my $rcd (@mtab) {
chomp $rcd;
my @flds = split(" ",$rcd);
if (substr($flds[0],0,4) ne '/dev') {next;}
$mtab{$flds[0]} = $flds[1];
}
}
else {LogIt(1,"Could not read MTAB!");}
my %devices = ();
my @disk_by_label = ();
if (opendir DIR,"/dev/disk/by-label" ) {
@disk_by_label = readdir DIR;
close DIR;
}
foreach my $lbl (@disk_by_label) {
if ($lbl eq '.') {next;}
if ($lbl eq '..') {next;}
$lbl = Strip($lbl);
my $path = "/dev/disk/by-label/$lbl";
if (-l $path)  {
my $lnk = readlink $path;
my @pths = split '/',$lnk;
my $devname = pop @pths;
my $partno = 0;
my $disk = '';
if ($devname =~ /nvme/) {
($disk,$partno) = $devname =~ /nvme(\d)n1p(.*)/;
}
elsif (substr($devname,0,2) eq 'sd') {
($disk,$partno) = $devname =~ /^sd(.)(\d*)/;
}
else {
LogIt(1,"Don't know how to deal with device $lnk");
next;
}
if (!$partno) {
LogIt(1,"No disk or partno for device $lnk");
next;
}
$devices{$disk} = TRUE;
my $fulldev = "/dev/$devname";
$diskinfo->{$disk}{$partno}{'label'} = $lbl;
$diskinfo->{$disk}{$partno}{'prefix'} = substr($lbl,0,1);
$diskinfo->{$disk}{$partno}{'suffix'} = substr($lbl,1);
}###  Label symlink
}### Label processing
my @disklist  = keys %{$diskinfo};
foreach my $disk (@disklist ) {
foreach my $partno (1..$maxpartno) {
my $devname = '';
if ($disk =~ /^[0-9]$/) {
$devname = "nvme$disk" . "n1p$partno";
}
else {$devname = "sd$disk$partno";}
my $fulldev = "/dev/$devname";
if (! -e "$fulldev") {next;}
$diskinfo->{$disk}{$partno}{'devname'} = $devname;
$diskinfo->{$disk}{$partno}{'device'} = $fulldev;
$diskinfo->{$disk}{$partno}{'disk'} = $disk;
$diskinfo->{$disk}{$partno}{'partno'} = $partno;
if (!$diskinfo->{$disk}{$partno}{'label'}) {
foreach my $key ('label','prefix','suffix') {
$diskinfo->{$disk}{$partno}{'key'} = '';
}
}
$diskinfo->{$disk}{$partno}{'format'}  = '';
$diskinfo->{$disk}{$partno}{'distro'}  = '';
$diskinfo->{$disk}{$partno}{'version'} = '';
$diskinfo->{$disk}{$partno}{'mp'}      = '';
$diskinfo->{$disk}{$partno}{'boot'}    = FALSE;
if (FALSE) {
my $info = `sudo blkid $fulldev`;
if ($info) {
my ($format) = $info =~ /type=(.*?)\s/i;
if ($format) {
$format =~ s/\"//g;   ### remove "s
}
else {
$format = '';
}
$diskinfo->{$disk}{$partno}{'format'} = $format;
}
else {LogIt(1,"Could not get info on $fulldev");}
}
my $mp = $mtab{$fulldev};
if ($mp) {### partition is already mounted
$diskinfo->{$disk}{$partno}{'mp'} = $mp;
if ($mp eq '/') {
my ($dst,$version,$bt,$short) = Os_Version($mp);
$diskinfo->{$disk}{$partno}{'distro'} = $short;
$diskinfo->{$disk}{$partno}{'version'} = $version;
$diskinfo->{$disk}{$partno}{'boot'} = TRUE;
foreach my $key (keys %{$diskinfo->{$disk}{$partno}}) {
$diskinfo->{'boot'}{0}{$key} = $diskinfo->{$disk}{$partno}{$key};
}
}
else {
foreach my $key (keys %{$diskinfo->{$disk}{$partno}}) {
$diskinfo->{$mp}{0}{$key} = $diskinfo->{$disk}{$partno}{$key};
}
}
}
}
}
my @mapper = ();
if (opendir DIR,"/dev/mapper" ) {
@mapper = readdir DIR;
close DIR;
}
foreach my $name (@mapper) {
if ($name eq '.') {next;}
if ($name eq '..') {next;}
$name = Strip($name);
my $path = "/dev/mapper/$name";
if (-l $path)  {
$diskinfo->{'mapper'}{$name}{'mp'}      = '';
if ($mtab{$path}) {$diskinfo->{'mapper'}{$name}{'mp'} = $mtab{$path};}
$diskinfo->{'mapper'}{$name}{'boot'}    = FALSE;
$diskinfo->{'mapper'}{$name}{'label'}   = '';
$diskinfo->{'mapper'}{$name}{'prefix'}   = '';
$diskinfo->{'mapper'}{$name}{'suffix'}   = '';
$diskinfo->{'mapper'}{$name}{'device'}   = $path;
$diskinfo->{'mapper'}{$name}{'type'} = '';
my @devlist = `sudo cryptsetup status $name`;
my $dev = '';
my $loop = '';
foreach my $rcd (@devlist) {
chomp $rcd;
my ($key,$value) = split ':',$rcd;
$key = Strip($key);
if ($key eq 'type') {$diskinfo->{'mapper'}{$name}{'type'} = lc(Strip($value));}
elsif ($key eq 'device') {$dev = Strip($value);}
elsif ($key eq 'loop') {$loop = Strip($value);}
}
if ($dev =~ /loop/) {$diskinfo->{'mapper'}{$name}{'device'} = $loop;}
else { $diskinfo->{'mapper'}{$name}{'device'} = $dev;}
}
}
return 0;
}
sub TVadapter {
my $adapter = -1;
my $user_spec = -1;
if (scalar @_) {$user_spec = shift @_;}
my @adapters = glob("/dev/dvb/*");
foreach my $adp (sort @adapters) {
if ($adp =~ /\./) {next;}
my $device = "$adp/frontend0";
if (!-e $device) {next;}
my ($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$atime,$mtime,$ctime,$blksize,$blocks) = stat("$device");
if (!$gid) {next;}
my ($group,$pwd,$num,$members) = getgrgid($gid);
if ($group eq 'video') {
my $ano = substr($adp,-1,1);
if (($user_spec >= 0 ) and ($user_spec != $ano)) {
print "USEFUL l4732:Skippling $ano as it does not match user spec\n";
next;}
$adapter = $ano;
last;
}
}
return $adapter;
}
sub DiskType  {
my $device = shift @_;
if (-e $device) {
my $result = `sudo fdisk -l -o type $device | grep gpt`;
if ($result =~ /gpt/i) {return 'gpt';}
else {return 'msdos';}
}
return ('?');
}
sub LogIt {
use Scalar::Util qw(looks_like_number);
use Sys::Syslog;
use Sys::Syslog qw(:standard :macros);
my $sev = shift @_;
my $msg = shift @_;
if (!$msg) {$msg = '';}
my ($pack,$file,$line) = caller();
my @spl = split '/',$file;
$file = pop @spl;
my $callinfo = "$Magenta$file$White line $Green$line$White:";
my $callnoansi = "$file line $line:";
if (!looks_like_number($sev)) {
print STDERR "$Bold$Red** Check caller of Logit. Forgot Code number! $callinfo$Eol";
exit 9999;
}
my $noansi = $msg;
$noansi =~ s/\x1b\[[^m]+m//g;
if ($sev == 0) {
print STDOUT "$White$msg$Eol";
push @Info_Log,"$noansi\n";
}
elsif ($sev == 1) {
print STDOUT "$Bold$Yellow Warning! $White$msg$Eol";
push @Warning_Log,"*Warning! $noansi\n";
}
elsif ($sev == 2) {
print STDERR $Bold,$Red,"Error$White! $callinfo=>$msg$Eol";
push @Error_Log,"**Error! $callnoansi=>$noansi\n";
}
elsif ($sev ==3) {
print STDERR "$White$msg$Eol";
push @Info_Log,"$noansi\n";
}
elsif ($sev == 4) {
print STDERR "$callinfo=>$msg$Eol";
push @Info_Log,"$callnoansi=>$noansi\n";
}
elsif ($sev == 5) {
print STDOUT "$Bold$Yellow Warning!$White $callinfo=>$White$msg$Eol";
push @Warning_Log,"*Warning! $noansi\n";
}
elsif ($sev == 6) {
print STDOUT time() . ": $White$msg$Eol";
push @Info_Log,time() . ": $noansi\n";
}
elsif ($sev < 10) {
print STDERR "$Bold$Red**Error! $White Check caller of Logit. Used reserved code number $Red$sev$White $callinfo$Eol";
exit 9999;
}
else {
print STDERR $Bold,$Red,"** ERROR $sev$White! $callinfo=>$msg$Eol";
syslog(LOG_ERR,"***Error $sev! $callnoansi=>$noansi");
print STDERR "script is terminated!$Eol";
exit $sev;
}
return $sev;
}
sub Parms_Parse {
use Getopt::Std;
use Getopt::Long;
my $nodie = 0;
my $winok = 0;
my $rootonly = 0;
my $retcode = 0;
foreach my $keyword (@_) {
if (lc($keyword) eq 'nodie') {$nodie = 1;}
elsif (lc($keyword) eq 'winok') {$winok = 1;}
elsif (lc($keyword) eq 'root') {$rootonly = 1;}
else {
print STDERR "$Bold Logic error! Invalid keyword $keyword for Parms_Parse$Eol";
exit 9999;
}
}
if ((!$winok) and (substr($^O,0,3) eq 'MSW')) {
print STDERR "!!!!!#### This routine cannot be run on Windows!\n";
exit 9999;
}
Getopt::Long::Configure ("bundling");
my @wmsg;
$SIG{'__WARN__'} = sub {
push @wmsg,@_;
};
my $rtc = GetOptions(%Options);
if (!$rtc) {
foreach my $m (@wmsg) {
if (lc(substr($m,0,7)) eq 'unknown') {
print STDERR "$Bold Ignoring $m $Eol";
$retcode = 1;
}
else {
print STDERR "$Bold Parms_Parse:Error parsing options!$Eol";
if ($nodie) {$retcode = 2;}
else {exit 2048;}
}
}
}
$SIG{'__WARN__'} = 'DEFAULT';
if ($rootonly) {
(my $name,) = getpwuid $<;
if ($name ne 'root') {
print STDERR "$Bold ## ERROR! This routine MUST be run as ROOT!$Eol";
exit 9999;
}
}
return $retcode;
}
sub Time_Format {
use Scalar::Util qw(looks_like_number);
my $mtime = shift @_;
if (!$mtime) {$mtime = time();}
if (!looks_like_number($mtime)) {
my ($package,$filename,$line) = caller();
print STDERR "$Bold Non-Numeric time value $mtime passed to Time_Format. Caller=$filename line=$line!$Eol";
return '??/??/?? ??:??';
}
my $keyword = shift @_;
if (!$keyword) {$keyword = 'default';}
else {$keyword = lc($keyword);}
my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) =
localtime($mtime);
$mon = sprintf("%2.2u",$mon+1);
$mday = sprintf("%2.2u",$mday);
my $ampm = '';
if ($keyword ne '24hour') {
$ampm = 'am';
if ($hour < 1) {$hour = 12;}
elsif ($hour < 12) {$ampm = 'am';}
else {
$ampm = 'pm';
if ($hour > 12) {$hour = $hour-12;}
}
}
$year = $year + 1900;
my $dt = "$mon/$mday/$year" ;
my $tm = sprintf("%2.2u",$hour) . ':' . sprintf("%2.2u",$min) . $ampm;
my $return = "$dt $tm";
if ($keyword eq 'time') {$return = $tm;}
elsif ($keyword eq 'date') {$return = $dt;}
elsif ($keyword eq 'dyear') {$return = "$year$mon$mday"; }
elsif ($keyword eq 'uyear') {$return =  $year . '_' . $mon . '_' . $mday;}
elsif ($keyword eq 'year') {$return = $year;}
else {$return = "$dt $tm";}
return $return;
}
sub Os_Version {
my $mp = shift @_;
if (!$mp) {$mp = '/';}
my $version = '?';
my $bittype = 64;
my $distro = '?';
my $short = '?';
my $osfile = "$mp/etc/os-release";
my $tmp = '';
if (-e $osfile) {
open RELEASE,$osfile or die "Cannot open $osfile!";
my @records = <RELEASE>;
close RELEASE;
foreach my $rcd (@records) {
chomp $rcd;
my ($key,$value) = split '=',$rcd,2;
$key = lc($key);
if ($key eq 'version') {
$version = $value;
$version =~ s/\"//g;   ### remove all quotes
if (index(lc($version),'tumbleweed') != -1) {
$version = 'tweed';
}
($version,$tmp) = split " ",$version,2;
}
elsif ($key eq 'pretty_name') {
if (index(lc($value),'x86_64') != -1) {
$bittype = 64;
}
if (index(lc($value),'tumbleweed') != -1) {
$version = 'tweed';
}
}
elsif ($key eq 'name') {
$value  =~ s/\"//g;   ### remove all quotes
($distro,$tmp) = split " ",$value,2;
$distro = lc($distro);
if (lc($tmp) eq 'mint') {$distro = 'linuxmint';}
}
}
}
if (($distro eq 'ubuntu') or ($distro eq 'linuxmint')) {
$osfile = "$mp/etc/lsb-release";
if (-e $osfile) {
open RELEASE,$osfile or die "Cannot open $osfile!";
my @records = <RELEASE>;
close RELEASE;
foreach my $rcd (@records) {
chomp $rcd;
my ($key,$value) = split '=',$rcd,2;
$key = lc($key);
if ($key eq 'distrib_id') {$distro = lc($value);}
elsif ($key eq 'distrib_release') {$version = $value;}
else { }
}
}
}
$short = $distro;
if ($distro eq 'linuxmint') {$short = 'mint';}
if ($distro eq 'opensuse') {$short = 'suse';}
return $distro,$version,$bittype,$short;
}
sub Strip {
my ($string) = @_;
if (! defined $string) {return '';}
$string =~ s/^\s+//;
$string =~ s/\s+$//;
return $string;
}
1;
