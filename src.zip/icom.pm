#!/usr/bin/perl -w
package icom;
require Exporter;
use constant FALSE => 0;
use constant TRUE => 1;
@ISA   = qw(Exporter);
@EXPORT = qw(R7000 IC703 IC705 R8600 ICR30 OTHER icom_cmd
rcmode2icom icom2rcmode %icom_encode %icom_decode
packet_decode
) ;
use Data::Dumper;
use Text::ParseWords;
use threads;
use threads::shared;
use Thread::Queue;
use Time::HiRes qw(time usleep ualarm gettimeofday tv_interval );
use Device::SerialPort qw ( :PARAM :STAT 0.07 );
use Scalar::Util qw(looks_like_number);
use radioctl;
use strict;
use autovivification;
no  autovivification;
use constant ICOM_SIG_ADJUST     => int(255/MAXSIGNAL);
use constant FA                  => 250;
use constant FB                  => 251;
use constant FC                  => 252;
use constant FD                  => 253;
use constant FE                  => 254;
use constant FF                  => 255;
use constant ICOM_TERMINATOR     => FD;
use constant ICOM_PREAMBLE       => FE;
$debug3 = FALSE;
my %icom_commands = ('_set_freq_noack' => {'code' => '00'  ,'ack' => 0,},
'_set_mode_noack' => {'code' => '01'  ,'ack' => 0,},
'_get_range'      => {'code' => '02'  ,'ack' => 2,},
'_get_freq'       => {'code' => '03'  ,'ack' => 2,},
'_get_mode'       => {'code' => '04'  ,'ack' => 2,},
'_set_freq'       => {'code' => '05'  ,'ack' => 1,},
'_set_mode'       => {'code' => '06'  ,'ack' => 1,},
'_vfo_mode'       => {'code' => '07'  ,'ack' => 1,},
'_select_vfoa'    => {'code' => '0700','ack' => 1,},
'_select_vfob'    => {'code' => '0701','ack' => 1,},
'_equalize_vfo'   => {'code' => '07A0','ack' => 1,},
'_swap_vfo'       => {'code' => '07B0','ack' => 1,},
'_select_aband'   => {'code' => '07D0','ack' => 1,},
'_select_bband'   => {'code' => '07D1','ack' => 1,},
'_memory_mode'    => {'code' => '08'  ,'ack' => 1,},
'_select_chan'    => {'code' => '08'  ,'ack' => 1,},
'_select_group'   => {'code' => '08A0','ack' => 1,},
'_vfo_to_mem'     => {'code' => '09'  ,'ack' => 1,},
'_mem_to_vfo'     => {'code' => '0A'  ,'ack' => 1,},
'_clear_mem'      => {'code' => '0B'  ,'ack' => 1,},
'_read_offset'    => {'code' => '0C'  ,'ack' => 2,},
'_write_offset'   => {'code' => '0D'  ,'ack' => 1,},
'_stop_scan'      => {'code' => '0E00','ack' => 1,},
'_memory_scan'    => {'code' => '0E01','ack' => 1,},
'_prog_scan'      => {'code' => '0E02','ack' => 1,},
'_delta_scan'     => {'code' => '0E03','ack' => 1,},
'_select_scan'    => {'code' => '0E23','ack' => 1,},
'_read_duplex'    => {'code' => '0F'  ,'ack' => 2,},
'_split_off'      => {'code' => '0F00','ack' => 1,},
'_split_on'       => {'code' => '0F01','ack' => 1,},
'_duplex_off'     => {'code' => '0F10','ack' => 1,},
'_duplex_plus'    => {'code' => '0F12','ack' => 1,},
'_vfo_step'       => {'code' => '10',  'ack' => 2,},
'_vfo_atten'      => {'code' => '11'  ,'ack' => 2,},
'_select_antenna' => {'code' => '12'  ,'ack' => 1,},
'_af_gain'        => {'code' => '1401','ack' => 2,},
'_rf_gain'        => {'code' => '1402','ack' => 2,},
'_sq_level'       => {'code' => '1403','ack' => 2,},
'_if_shift'       => {'code' => '1404','ack' => 2,},
'_nr_level'       => {'code' => '1406','ack' => 2,},
'_twin_pbt_inside_level' => {'code' => '1407','ack' => 2,},
'_twin_pbt_outside_level' => {'code' => '1408','ack' => 2,},
'_cw_pitch_level'  => {'code' => '1409','ack' => 2,},
'_rf_power_level' => {'code' => '140A','ack' => 2,},
'_mic_gain_level' => {'code' => '140B','ack' => 2,},
'_key_speed' => {'code' => '140C','ack' => 2,},
'_comp_level' => {'code' => '140E','ack' => 2,},
'_breakin_delay' => {'code' => '140F','ack' => 2,},
'_get_squelch'    => {'code' => '1501','ack' => 2,},
'_get_signal'     => {'code' => '1502','ack' => 2,},
'_get_tone_squelch'    => {'code' => '1505','ack' => 2,},
'_get_rf_meter'     => {'code' => '1511','ack' => 2,},
'_get_swr_meter'     => {'code' => '1512','ack' => 2,},
'_get_als_meter'     => {'code' => '1513','ack' => 2,},
'_vfo_preamp'     => {'code' => '1602','ack' => 2,},
'_vfo_agc'        => {'code' => '1612','ack' => 2,},
'_vfo_noise_blanker'     => {'code' => '1622','ack' => 2,},
'_vfo_noise_reduction'   => {'code' => '1640','ack' => 2,},
'_vfo_auto_notch'   => {'code' => '1641','ack' => 2,},
'_vfo_rptr'       => {'code' => '1642','ack' => 2,},
'_vfo_ctcss'      => {'code' => '1643','ack' => 2,},
'_speech_compress'  => {'code' => '1644','ack' => 2,},
'_monitor'   => {'code' => '1645','ack' => 2,},
'_vox'       => {'code' => '1646','ack' => 2,},
'_breakin'      => {'code' => '1647','ack' => 2,},
'_afc'   => {'code' => '164A','ack' => 2,},
'_dtcs'   => {'code' => '164B','ack' => 2,},
'_vsc'   => {'code' => '164C','ack' => 2,},
'_p25_dsql'   => {'code' => '1652','ack' => 2,},
'_dply_type'   => {'code' => '1659','ack' => 2,},
'_dstar_dsql'   => {'code' => '165B','ack' => 2,},
'_dpmr_dsql'   => {'code' => '165F','ack' => 2,},
'_ndxn_dsql'   => {'code' => '1660','ack' => 2,},
'_dcr_dsql'   => {'code' => '1661','ack' => 2,},
'_dpmr_scrambler'   => {'code' => '1662','ack' => 2,},
'_nxdn_encrypt'    => {'code' => '1663','ack' => 2,},
'_dcr_encrypt'    => {'code' => '1664','ack' => 2,},
'_turn_off'       => {'code' => '1800','ack' => 0,},
'_turn_on'        => {'code' => '1801','ack' => 0,},
'_get_id'         => {'code' => '1900','ack' => 2,},
'_memory_direct'  => {'code' => '1A00','ack' => 2,},
'_band_stack'     => {'code' => '1A01','ack' => 2,},
'_earphone'       => {'code' => '1A01','ack' => 2,},
'_memory_keyer'  => {'code' => '1A02','ack' => 2,},
'_rcv_frequency'  => {'code' => '1A02','ack' => 1,},
'_change_direction' => {'code' => '1A03','ack' => 1,},
'_beep_emission'  => {'code' => '1A0301','ack' => 2,},
'_band_edge_beep'  => {'code' => '1A0302','ack' => 2,},
'_beep_level'  => {'code' => '1A0303','ack' => 2,},
'_beep_limit'  => {'code' => '1A0304','ack' => 2,},
'_cw_carrier_point'  => {'code' => '1A0305','ack' => 2,},
'_side_tone_level'  => {'code' => '1A0306','ack' => 2,},
'_op_state' => {'code' => '1A04','ack' => 2,},
'_ab_sync' => {'code' => '1A06','ack' => 2,},
'_af_gain_07' => {'code' => '1A07','ack' => 2,},
'_skip_setting' => {'code' => '1A03','ack' => 2,},
'_recording' => {'code' => '1A09','ack' => 1,},
'_start_a_scan'  => {'code' => '1A0A00','ack' => 1,},
'_cancel_scan'   => {'code' => '1A0A01','ack' => 1,},
'_temp_skip'     => {'code' => '1A0A02','ack' => 1,},
'_get_temp_skip' => {'code' => '1A0A03','ack' => 2,},
'_cancel_temp_skip' => {'code' => '1A0A04','ack' => 1,},
'_transceive_scan'  => {'code' => '1A0B00','ack' => 2,},
'_transceive_settings'  => {'code' => '1A0B01','ack' => 1,},
'_get_transceive_settings'  => {'code' => '1A0B01','ack' => 2,},
'_get_scan_condition'  => {'code' => '1A0B02','ack' => 2,},
'_get_scan_info'   => {'code' => '1A0C','ack' => 2,},
'_get_program_link_name'  => {'code' => '1A0D00','ack' => 2,},
'_get_program_edge_name'  => {'code' => '1A0E00','ack' => 2,},
'_get_program_edge_name_change'  => {'code' => '1A0E01','ack' => 2,},
'_get_memory_group_name'  => {'code' => '1A0F00','ack' => 2,},
'_get_memory_group_name_change'  => {'code' => '1A0F01','ack' => 2,},
'_display_content_change_report'  => {'code' => '1A1000','ack' => 2,},
'_get_display_change_transceive'  => {'code' => '1A1001','ack' => 2,},
'_get_display'  => {'code' => '1A11','ack' => 2,},
'_get_noise_smeter'  => {'code' => '1A12','ack' => 2,},
'_bluetooth_detection'  => {'code' => '1A1300','ack' => 2,},
'_bluetooth_transceive_detection'  => {'code' => '1A1301','ack' => 2,},
'_vfo_rptr_freq'  => {'code' => '1B00','ack' => 2,},
'_vfo_ctcss_freq' => {'code' => '1B01','ack' => 2,},
'_vfo_dsc_code'   => {'code' => '1B02','ack' => 2,},
'_vfo_nac_code'   => {'code' => '1B03','ack' => 2,},
'_vfo_csql_code'  => {'code' => '1B07','ack' => 2,},
'_nxdn_ran'  => {'code' => '1B0A','ack' => 2,},
'_nxdn_crypt_key'  => {'code' => '1B0D','ack' => 2,},
'_get_nxdn_rx_id'  => {'code' => '200A02','ack' => 2,},
'_get_nxdn_rx_status'  => {'code' => '200B02','ack' => 2,},
);
my %cmd_lookup = ();
foreach my $cmd (keys %icom_commands) {$cmd_lookup{$icom_commands{$cmd}{'code'}} = $cmd;}
use constant R7000      => 'R7000';
use constant IC703      => 'IC703';
use constant IC705      => 'IC705';
use constant R8600      => 'R8600';
use constant ICR30      => 'ICR30';
use constant OTHER      => 'ICOM';
my %default_addr = ('68' => IC703,
'96' => R8600,
'08' => R7000,
'9C' => ICR30,
'A4' => IC705,
);
my %supported = ();
foreach my $key (keys %default_addr) {$supported{$default_addr{$key}} = $key;}
my $preamble = 'FEFE';
my %icom_encode = (
'am' => {&R7000    => '02',
&ICR30    => '0201',
'default' => '0202',
},
'amw' => {&R7000    => '02',
'default' => '0201',
},
'amn' => {&R7000    => '02',
&ICR30   => '0202',
'default' => '0203',
},
'fm'  => {&ICR30   => '0501',
'default' => '0502',
},
'fmw' => {&R7000 => '0501',
&ICR30 => '0501',
'default' => '0601',
},
'fmm' => {&R7000 => '0502',
'default' => '0501',
},
'fmn' => {'default' => '0502'},
'fmun' => {&R7000 => '0502',
&ICR30 =>  '0502',
'default' => '0503',
},
'lsb' => {&R7000 => '0500',
'default' => '0001',
},
'usb' => {&R7000 => '0500',
'default' => '0101',
},
'cw' => {&R7000 => '0500',
'default' => '0301',
},
'cw-r' => {&R7000 => '0500',
'default' => '0701',
},
'rtty' => {&R7000 => '0500',
'default' => '0401',
},
'rtty-r' => {&R7000 => '0500',
&ICR30 =>  '0701',
'default' => '0801',
},
'p25'  => {&ICR30 => '1601',
&R8600 => '1601',
'default' => '0502',
},
'dstar'  => {&ICR30 => '1701',
&R8600 => '1701',
&IC705 => '1701',
'default' => '0502',
},
'dpmr' => {&ICR30 => '1801',
&R8600 => '1801',
'default' => '0502',
},
'nxdnvn' => {&ICR30 => '1901',
&R8600 => '1901',
'default' => '0502',
},
'nxdn'   => {&ICR30 => '2001',
&R8600 => '2001',
'default' => '0502',
},
'dcr' => {&ICR30 => '2101',
&R8600 => '2101',
'default' => '0502',
},
'dmr' =>  {'default' => '0502',
},
);
my %icom_decode = (
'00' => 'lsb',
'01' => 'usb',
'02' => 'am',
'03' => 'cw',
'04' => 'rtty',
'05' => 'fmn',
'06' => 'fmw',
'07' => 'cw-r',
'08' => 'rtty-r',
'09' => 'fmn',
'10' => 'fmn',
'11' => 'am',
'12' => 'fmn',
'13' => 'fmn',
'14' => 'am' ,
'15' => 'am',
'16' => 'p25',
'17' => 'dstar',
'18' => 'dpmr',
'19' => 'nxdnvn',### ICR30 only
'20' => 'nxdn',
'21' => 'dcr',
);
my $model = R7000;
my %state_save = (
'state' => '',
'mode'  => '',
'atten' => -1,
'preamp' => -1,
'cmd'   => '',
'sig'   => FALSE,
'freq'  => 0,
'rptr_flag'  => -1,
'ctcss_flag' => -1,
);
my %rssi2sig = (
&ICR30 => [0,1,33,67,101,135,169,203,237,254 ],
&IC703 => [0,1,22,49, 75,101,130,169,211,255 ],
&IC705 => [0,8,33,62, 91,120,138,160,199,232 ],
);
my %sig2meter = (
&IC705 => [0,1,19,33,48,63,76,91,106,120,138,160,178,199,218,242,255],
&ICR30 => [0,1,16,33,67,84,84,101,118,135,152,169,186,203,220,237,255],
);
my @sigmeter = (0,1,2,3,4,5,6,7,8,9,15,20,30,40,50,60,60);
my %step_code  = (
&ICR30 => [
10,
100,
1000,
3125,
5000,
6250,
8330,
9000,
10000,
12500,
15000,
20000,
25000,
30000,
50000,
100000,
125000,
200000,
],
&IC703 =>  [
10,
100,
1000,
5000,
9000,
10000,
12500,
20000,
25000,
100000,
]
);
my %extended = (&IC703 => {'atten'  => TRUE,
'preamp' => TRUE,
'rptr'   => TRUE,
'ctcss'  => TRUE,
},
&ICR30 => {'atten'  => TRUE,
},
);
my %scancodes = ('all'      => '00',
'band'     => '01',
'plink'    => '02',
'pgm'      => '03',
'memory'   => '04',
'mode'     => '05',
'near'     => '06',
'link'     => '07',
'group'    => '08',
'dup'      => '09',
'tone'     => '10',
);
my $default_scan = 'link';
my @send_packet;
my $instr;
my $freqbytes = 5;
my $getmemsize = 40;
my @icom_packet ;
my $warn = TRUE ;
my $protoname = 'icom';
use constant PROTO_NUMBER => 2;
$radio_routine{$protoname} = \&icom_cmd;
$valid_protocols{'icom'} = TRUE;
TRUE;
sub icom_cmd {
my $cmd = shift @_;
if (!$cmd) {LogIt(828,"ICOM_CMD:No command specified!");}
if ($debug3) {LogIt(0,"ICOM_CMD l1625: call cmd=$cmd");}
my $parmref = shift @_;
if (!$parmref) {LogIt(830,"ICOM_CMD:No parmref reference specified. CMD=$cmd");}
if (ref($parmref) ne 'HASH') {LogIt(831,"ICOM_CMD:parmref is NOT a reference to a hash! CMD=$cmd");}
if (!$parmref->{'def'}) {LogIt(833,"ICOM_CMD:No 'def' specified in parmref");}
my $defref    = $parmref->{'def'};
if (ref($defref) ne 'HASH') {LogIt(1875,"ICOM_CMD:defref is NOT a reference to a hash! CMD=$cmd");}
my $out   = $parmref->{'out'};
if (!$out) {LogIt(836,"ICOM_CMD:No 'out' defined in parmref! CMD=$cmd");}
if (ref($out) ne 'HASH') {LogIt(837,"ICOM_CMD:Out spec in parmref is NOT a hash reference! CMD=$cmd");}
my $outsave = $out;
if ((!$parmref->{'portobj'}) and ($cmd ne 'autobaud')) {
print Dumper($parmref),"\n";
LogIt(845,"ICOM_CMD:No portobj in parmref! CMD=$cmd");
}
my $portobj = $parmref->{'portobj'};
my $db = $parmref->{'database'};
if ($db) {
if (ref($db) ne 'HASH') {LogIt(842,"ICOM_CMD:Database spec in parmref is NOT a hash reference! CMD=$cmd");}
}
else {$db = '';}
my $write = $parmref->{'write'};
if (!$write) {$write = FALSE;}
my $in   = $parmref->{'in'};
if ($in) {
if (ref($in) ne 'HASH') {LogIt(580,"IN spec in parmref is NOT a hash reference! CMD=$cmd");}
}
else {$in = '';}
my $insave = $in;
my $compaddr = '00';
my $radioaddr = '08';
if (defined $defref->{'radioaddr'}) {$radioaddr = uc($defref->{'radioaddr'});}
$getmemsize = 40;
my $delay = '1000';
$delay = '1';
if ($debug2) {LogIt(0,"ICOM_CMD l898:cmd=$cmd"); }
my $sendhex = "$preamble$radioaddr$compaddr";
my $cmdcode = '00';
my $ack = 0;
my $rc = 0;
$parmref->{'rc'} = $GoodCode;
if (defined $icom_commands{$cmd}) {
$cmdcode = $icom_commands{$cmd}{'code'};
$sendhex = "$sendhex$cmdcode";
$ack = $icom_commands{$cmd}{'ack'};
}
if ($cmd eq 'init') {
if ($debug1) {LogIt(0,"ICOM_CMD:Starting 'init' command");}
%state_save = ('state' => '','mode' => '','atten' => -1,'cmd'=> $cmd, 'sig' => FALSE);
my %newparms = (
'radioscan' => 0,
'maxchan'   => 99,
'origin'    => 1,
'minfreq'   => 25000000,
'maxfreq'   => 999999999,
'maxigrp'   => 99,
'sigdet'    => 0,
'model'     => R7000,
'chanper'   => 10,
'group'     => FALSE,
'model'     => R7000,
'gap1_low'  => 0,
'gap1_high' => 0,
'gap2_low'  => 0,
'gap2_high' => 0,
);
foreach my $key ('model','chanper') {
if (defined $defref->{$key}) {$newparms{$key} = $defref->{$key};}
}
if ($newparms{'model'} !~ /R7000/i) {### Don't do this for the R7000
my $rc = icom_cmd('_get_id',$parmref);
if (!$rc) {
LogIt(0,"INIT detected ICOM model $model");
if ($model eq IC703) {
$newparms{'sigdet'} = 2;
$newparms{'radioscan'} = 2;
$newparms{'minfreq'} =    30000;
$newparms{'maxfreq'} = 60000000;
icom_cmd('_get_range',$parmref);
if ($out->{'lowfreq'}) {$newparms{'minfreq'} = $out->{'lowfreq'};}
else {LogIt(1,"IC-703 did NOT return low range!");}
if ($out->{'highfreq'}) {$newparms{'maxfreq'} = $out->{'highfreq'};}
else {LogIt(1,"IC-703 did NOT return high range!");}
}
elsif (($model eq ICR30) or ($model eq R8600)) {
$newparms{'minfreq'}   =     100000;
$newparms{'maxfreq'}   = 3304999990;
$newparms{'sigdet'}    = 2;
$newparms{'radioscan'} = 2;
$newparms{'maxchan'}   = 99;
$newparms{'maxigrp'}   = 99;
$newparms{'chanper'}   = 100;
$newparms{'origin'}    = 0;
$newparms{'group'}    = TRUE;
$parmref->{'write'} = FALSE;
$newparms{'gap1_low'} = 812000000;
$newparms{'gap1_high'} = 851000000;
$newparms{'gap2_low'} = 867000000;
$newparms{'gap2_high'} = 896000000;
icom_cmd('_op_state',$parmref);
icom_cmd('_get_scan_condition',$parmref);
LogIt(0,"R30 is in state: $out->{'state'} scanning: $out->{'scan'}");
}
elsif ($model eq IC705) {
$newparms{'minfreq'}   =     100000;
$newparms{'maxfreq'}   =  470000000;
$newparms{'sigdet'}    = 2;
$newparms{'radioscan'} = 2;
$newparms{'maxchan'}   = 99;
$newparms{'maxigrp'}   = 99;
$newparms{'chanper'}   = 100;
$newparms{'origin'}    = 0;
$newparms{'group'}    = TRUE;
$newparms{'gap1_low'} = 200000000;
$newparms{'gap1_high'} = 400000000;
}
else {
LogIt(1,"Radio detected is not currently supported " .
"(Addr:$out->{'addr'}). Defaults used.");
}
}### Good return code from '_get_id'
elsif ($rc == $NotForModel) {
LogIt(1,"Radio does not support _get_id. Defaults used.");
}
else {
return ($parmref->{'rc'} = $CommErr);
}
}### Get parms from the radio
foreach my $key (keys %newparms) {
$defref->{$key} = $newparms{$key};
}
if ($debug3) {LogIt(0,1728,"Current radio model is $model");}
my $frq = 0;
my $atten = FALSE;
if (icom_cmd('_get_freq',$parmref)) {
return ($parmref->{'rc'} = $CommErr);
}
icom_cmd('_get_mode',$parmref);
if ($debug2) {LogIt(0,"$Bold 'init' complete");}
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'autobaud') {
if (!$defref->{'model'}) {
LogIt(1,"Model number not specified in .CONF file. " .
" Cannot automatically determine port/baud");
return ($parmref->{'rc'} = 1);
}
my @allports = ();
if ($in->{'noport'} and $defref->{'port'}) {push @allports,$defref->{'port'};}
else {
if (lc($defref->{'model'}) ne  'r7000') {@allports = glob("/dev/ttyACM*");}
if (lc($defref->{'model'}) ne 'icr30') {push @allports,glob("/dev/ttyUSB*");}
}
my @allbauds = ();
if ($in->{'nobaud'}) {push @allbauds,$defref->{'baudrate'};}
else {push @allbauds,keys %baudrates;}
@allbauds = sort {$b <=> $a} @allbauds;
@allports = sort {$b cmp $a} @allports;
foreach my $port (@allports) {
my $portobj =  Device::SerialPort->new($port) ;
if (!$portobj) {next;}
$parmref->{'portobj'} = $portobj;
$portobj->user_msg("ON");
$portobj->databits(8);
$portobj->handshake('none');
$portobj->read_const_time(100);
$portobj->write_settings || undef $portobj;
$portobj->read_char_time(0);
foreach my $baud (@allbauds) {
$portobj->baudrate($baud);
$warn = FALSE;
$rc = icom_cmd('_get_freq',$parmref);
$warn = TRUE;
if (!$rc) {### command succeeded
$defref->{'baudrate'} = $baud;
$defref->{'port'} = $port;
$defref->{'handshake'} = 'none';
$portobj->close;
$parmref->{'portobj'} = undef;
LogIt(0,"ICOM $model detected on port $port with baudrate $baud");
return ($parmref->{'rc'} = $GoodCode);
}
}
$portobj->close;
$parmref->{'portobj'} = undef;
}
return ($parmref->{'rc'} = 1);
}
elsif ($cmd eq 'manual' ) {
LogIt(0,"ICOM l1828:Called MANUAL");
$state_save{'cmd'} = $cmd;
if ($model eq ICR30) {
icom_cmd('_cancel_scan',$parmref);
$parmref->{'write'} = FALSE;
icom_cmd('_op_state',$parmref);
}
elsif ($model eq IC703) {
icom_cmd('_select_vfoa',$parmref);
}
else {
}
icom_cmd('_get_freq',$parmref);
icom_cmd('_get_mode',$parmref);
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'vfoinit') {
$state_save{'cmd'} = $cmd;
if ($model eq ICR30) {
$parmref->{'write'} = TRUE;
$in->{'state'} = 'vfo';
icom_cmd('_op_state',$parmref);
$in->{'dual'} = FALSE;
icom_cmd('_dply_type',$parmref);
icom_cmd('_select_aband',$parmref);
}
elsif ($model eq IC703) {
icom_cmd('_select_vfoa',$parmref);
}
else {
}
icom_cmd('_get_freq',$parmref);
icom_cmd('_get_mode',$parmref);
LogIt(0,"VFO setup complete");
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'meminit') {
$state_save{'cmd'} = $cmd;
if ($model eq ICR30) {
$parmref->{'write'} = TRUE;
$in->{'state'} = 'mem';
icom_cmd('_op_state',$parmref);
}
elsif ($model eq IC703) {
icom_cmd('_memory_mode',$parmref);
}
else {
}
icom_cmd('_get_freq',$parmref);
icom_cmd('_get_mode',$parmref);
LogIt(0,"VFO setup complete");
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'getinfo') {
icom_cmd('init',$parmref);
$out->{'chan_count'} = $defref->{'maxchan'};
$out->{'model'} = $model;
return ($parmref->{'rc'});
}
elsif ($cmd eq 'getmem') {
$state_save{'cmd'} = $cmd;
my $startstate = $progstate;
if ($debug1) {LogIt(0,"ICOM_CMD l1353:got 'getmem'");}
if (!$in) {LogIt(1287,"ICOM_CMD:No 'in' defined for GETMEM");}
if (!$db) {LogIt(1288,"ICOM_CMD:No database reference for GETMEM");}
my $count = 0;
my $maxcount = 99999;
my $maxigrp = $defref->{'maxigrp'};
my $maxchan = $defref->{'maxchan'};
my $origin =  $defref->{'origin'};
my $chanper = $defref->{'chanper'};
my $hasgroups = $defref->{'group'};
my $firstigrp = 0;
my $channel = $origin - 1;
my $rc_channel = 0;
if ($in->{'count'}) {$maxcount = $in->{'count'};}
my $firstchan = $in->{'firstnum'};
if (!$firstchan) {$firstchan = 0;}
my $comment = TRUE;
if ($in->{'nocomment'}) {$comment = FALSE;}
my $skip = $in->{'skip'};
if (!$skip) {$skip = FALSE;}
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = FALSE;
my $bank_used = $hasgroups;
my %sysrec = ('systemtype' => 'CNV','service' => "ICOM model $model", 'valid' => TRUE,
'bank_used' => $bank_used,);
my $sysno = add_a_record($db,'system',\%sysrec,$parmref->{'gui'});
my $restore_state = $state_save{'state'};
my $restore_scan = $state_save{'scan'};
if ($model eq ICR30) {
$parmref->{'write'} = FALSE;
icom_cmd('_op_state',$parmref);
$restore_state = $myout{'state'};
icom_cmd('_get_scan_condition',$parmref);
$restore_scan = $myout{'scan'};
if ($restore_state ne 'mem') {
$myin{'state'} = 'mem';
$parmref->{'write'} = TRUE;
my $msg = "ICOM_CMD l2493:ICOM $model cannot set MEMORY state";
if (icom_cmd('_op_state',$parmref)) {
LogIt(1,$msg);
add_message($msg);
return ($parmref->{'rc'} = $NotForModel);
}
$parmref->{'write'} = FALSE;
icom_cmd('_op_state',$parmref);
if ($myout{'state'} ne 'mem') {
LogIt(1,$msg);
add_message($msg);
return ($parmref->{'rc'} = $NotForModel);
}
}
}
GROUPLOOP:
foreach my $igrp ($firstigrp..$maxigrp) {
if ($model eq ICR30) {
$myin{'igrp'} = $igrp;
if (icom_cmd('_select_group',$parmref)){
my $msg = "ICOM_CMD l2512:Cannot set group for model $model!";
LogIt(1,$msg);
add_message($msg);
return ($parmref->{'rc'} = $NotForModel);
}
}
if ($hasgroups) {$channel = $origin - 1;}
my $grpndx = 0;
my $grpchcnt = 0;
my $group_service = "ICOM $model group $igrp";
CHANLOOP:
while ($channel < $maxchan) {
$channel++;
$rc_channel++;
if ($rc_channel < $firstchan) {next;}
$vfo{'channel'} = $rc_channel;
$vfo{'group'} = $igrp;
threads->yield;
if ($progstate ne $startstate) {
print "Exited loop as progstate changed\n";
last GROUPLOOP;}
if (!$parmref->{'gui'}) {
print STDERR "\rreading group:$Bold$Yellow" . sprintf("%02.2u",$igrp) . $Reset;
print STDERR " channel:$Bold$Green" . sprintf("%02.2u",$channel) .$Reset ;
}
$myin{'channel'} = $channel;
$myin{'igrp'} = $igrp;
$myout{'valid'} = TRUE;
$myout{'mode'} = 'fmn';
$myout{'frequency'} = 0;
$myout{'sfrequency'} = 0;
$myout{'tone'} = 'off';
$myout{'stone'} = 'off';
$myout{'tone_type'} = 'off';
$myout{'stone_type'} = 'off';
$myout{'adtype'} = 'analog',
$myout{'oplus'} = FALSE;
$myout{'ominus'} = FALSE;
$myout{'service'} = '';
$myout{'atten'} = 0;
$myout{'scangrp'} = 0;
$myout{'channel'} = $channel;
$myout{'dlyrsm'} = 0 ;
$myout{'tgid_valid'} = FALSE;
$myout{'groupno'} = $grpndx;
$myout{'igrp'} = $igrp;
$myout{'_radiochan'} = $channel;
$myout{'_rcchan'} = $rc_channel;
if ($model eq ICR30) {
icom_cmd('_select_chan',$parmref);
get_r30_display($parmref);
}
elsif ($model eq R7000)  {
if (icom_cmd('_select_chan',$parmref)) {last;}
if (icom_cmd('_get_freq',$parmref)) {last;};
if (icom_cmd('_get_mode',$parmref)) {last;};
}
else {
$parmref->{'write'} = FALSE;
if (icom_cmd('_memory_direct',$parmref)) {
};
}
my $freq = $myout{'frequency'} + 0;
if (!$skip or $freq) {
if (!$grpndx) {
my %grouprec = ('sysno' =>$sysno,'service' => $group_service, 'valid' => TRUE, 'igrp' => $igrp);
$grpndx = add_a_record($db,'group',\%grouprec,$parmref->{'gui'});
my $grpchcnt = 0;
$myout{'groupno'} = $grpndx;
my %newfreq = ('frequency' => 0,
'groupno' => $grpndx,
'channel' => $channel,
'service' => "Freqs for group $grpndx",
'_noshow' => TRUE,
'linecomment' => "*\n* ### Channels for group $grpndx ($igrp:$group_service)"
);
if ($comment) {my $ndx1 = add_a_record($db,'freq',\%newfreq,FALSE);}
}### Group record creation
if (!$freq) {$myout{'valid'} = FALSE;}
my $recno = add_a_record($db,'freq',\%myout,$parmref->{'gui'});
$vfo{'index'} = $recno;
$count++;
if ($count >= $maxcount) {last GROUPLOOP;}
}### Non-zero frequency or not skipping 0 frequencies
$grpchcnt++;
if ($grpchcnt >= $chanper) {next GROUPLOOP;}
if ($channel > $defref->{'maxchan'}) {
print STDERR "\n channel number =>$channel exceeded $defref->{'maxchan'}\n";
last;}
if ($channel == 100) {
print STDERR "\n ERROR! Got Channel=>$channel defref = $defref->{'maxchan'}\n";exit;
}
}### for each channel
}### for each group
if ($model eq ICR30) {
$parmref->{'write'} = TRUE;
$myin{'state'} = $restore_state;
icom_cmd('_op_state',$parmref);
if ($restore_state eq 'mem') {
if ($restore_scan) {
icom_cmd('scan',$parmref);
}
else {
$myin{'igrp'} = 1;
$myin{'channel'} = 1;
icom_cmd('_select_group',$parmref);
}
}
}
else {
$myin{'channel'} = 1;
icom_cmd('_select_chan',$parmref);
}
$parmref->{'out'} = $outsave;
$outsave->{'count'} = $count;
$outsave->{'sysno'} = $sysno;
print STDERR "\n";
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'setmem') {
$state_save{'cmd'} = $cmd;
if (!$in) {LogIt(1427,"ICOM_CMD:No 'in' defined for SETMEM");}
if (!$db) {LogIt(1228,"ICOM_CMD:No database reference for SETMEM");}
if ($debug1) {LogIt(0,"Processing ICOM SETMEM command");}
if ($model eq ICR30) {
my $msg = "SETMEM is not functional for the IC-R30!";
add_message($msg,1);
LogIt(1,$msg);
return ($parmref->{'rc'} = $NotForModel);
}
my %chans = ();
if (setmem_sub($parmref,\%chans)) {return ($parmref->{'rc'});}
my $startstate = $progstate;
my %myin = ();
my $writesave = $parmref->{'write'};
my @chlist = sort numerically keys %chans;
$parmref->{'in'} = \%myin;
$parmref->{'write'} = TRUE;
my $storecount=0;
WRTLP1:
foreach my $ch (@chlist) {
foreach my $key (keys %{$chans{$ch}}) {$myin{$key} = $chans{$ch}{$key};}
my $freq =   $chans{$ch}{'frequency'};
my $channel =  $chans{$ch}{'channel'};
my $igrp = $chans{$ch}{'igrp'};
my $mode = $chans{$ch}{'mode'};
if ($parmref->{'gui'}) {
$vfo{'channel'} = $ch;
threads->yield;
if ($progstate ne $startstate) {last WRTLP1;}
%scan_request = ('_cmd' =>'vfodply','_dbn' => 'vfo');
$parmref->{'gui'}->('ICOM_l1685');
my $recno = $chans{$ch}{'recno'};
%scan_request = ('_cmd' => 'sync','_dbn' => 'freq', '_seq'=> $recno,
'channel' => $ch);
$parmref->{'gui'}->('ICOM_l2539');
threads->yield;
}
else {
print STDERR "\rWriting group:$Bold$Yellow" . sprintf("%02.2u",$igrp) . $Reset;
print STDERR " channel:$Bold$Green" . sprintf("%02.2u",$channel) .$Reset ;
print STDERR " ($Yellow" . sprintf("%4.4u",$ch) . ")$Reset";
print STDERR " freq:$Bold$Blue" . rc_to_freq($freq) . $Reset;
print STDERR " mode:$Bold$Magenta$mode$Reset";
}
if ($model eq R7000) {
$rc = icom_cmd('_select_chan',$parmref);
usleep 500;
if ($freq) {
$rc = icom_cmd('_set_freq',$parmref);
usleep 500;
if (!$rc) {$rc = icom_cmd('_set_mode',$parmref);}
usleep 500;
if (!$rc) {$rc = icom_cmd('_vfo_to_mem',$parmref);}
}
else {
$rc = icom_cmd('_clear_mem',$parmref);
}
}
else {
$rc = icom_cmd('_memory_direct',$parmref);
}
$storecount++;
usleep 500;
}### For every channel
$out->{'count'} = $storecount;
LogIt(0,"\n\n$storecount records were stored in the radio");
$parmref->{'in'} = $insave;
$parmref->{'write'} = $writesave;
return $parmref->{'rc'};
}### Setmem
elsif ($cmd eq 'selmem') {
$state_save{'cmd'} = $cmd;
if (!$in) {LogIt(1562,"ICOM_CMD:No 'in' defined for SELMEM");}
if (!defined $in->{'channel'}) {LogIt(1563,"ICOM_CMD:No 'channel' in 'in' for SELMEM!");}
my $channel = $in->{'channel'};
if (!looks_like_number($channel)) {### bad parameter
add_message("Non-Numeric channel number passed to ICOM");
return ($parmref->{'rc'} = $ParmErr);
}
my $chanper = $defref->{'chanper'};
my $igrp = 0;
my $radchan = $channel;
if ($defref->{'group'}) {
--$radchan;
$igrp = int($radchan/$chanper);
$radchan  = $radchan % $chanper;
}
my $retcode = $GoodCode;
if ($igrp and $igrp > $defref->{'maxigrp'}) {$retcode = $NotForModel;}
elsif ($radchan > $defref->{'maxchan'}) {$retcode = $NotForModel;}
if ($retcode) {
add_message("channel $channel is outside range of ICOM radio");
return ($parmref->{'rc'} = $retcode);
}
if  (!$state_save{'state'} ne 'mem'){
if ($model eq ICR30) {
$in->{'state'} = 'mem';
$parmref->{'write'} = TRUE;
icom_cmd('_op_state',$parmref);
}
elsif  ($model eq IC703) {icom_cmd('_memory_mode',$parmref);}
else {
}
}### Radio NOT in memory state
if ($defref->{'group'}) {### Radio supports groups
$in->{'igrp'} = $igrp;
if (icom_cmd("_select_group",$parmref)) {
add_message("ICOM could not select group $igrp");
return ($parmref->{'rc'} = $ParmErr);
}
}
$in->{'channel'} = $radchan;
$parmref->{'write'} = FALSE;
$in->{'caller'} = 'selmem';
if (icom_cmd('_select_chan',$parmref)) {
add_message("ICOM could not select channel $in->{'channel'}");
return ($parmref->{'rc'} = $ParmErr);
}
icom_cmd('_get_freq',$parmref);
if (($parmref->{'rc'} == $GoodCode) and (!$out->{'frequency'})) {
$parmref->{'rc'} = $EmptyChan;
}
return $parmref->{'rc'};
}
elsif ($cmd eq 'getvfo') {
$state_save{'cmd'} = $cmd;
$rc = icom_cmd('_get_freq',$parmref);
if ( !$rc and ($out->{'frequency'})) {
$rc = icom_cmd('_get_mode',$parmref);
if ($rc and ($model eq IC703)) {
$parmref->{'write'} = FALSE;
icom_cmd('_vfo_atten',$parmref);
icom_cmd('_vfo_preamp',$parmref);
icom_cmd('_vfo_rptr',$parmref);
icom_cmd('_vfo_ctcss',$parmref);
icom_cmd('_vfo_rptr_freq',$parmref);
icom_cmd('_vfo_ctcss_freq',$parmref);
}
if ($rc and ($model eq ICR30)) {
if ($state_save{'state'} eq 'mem') {get_r30_display($parmref);}
else {
$parmref->{'write'} = FALSE;
icom_cmd('_vfo_atten',$parmref);
}
}
}
return ($parmref->{'rc'} = $rc);
}
elsif ($cmd eq 'setvfo') {
$state_save{'cmd'} = $cmd;
if (!$in) {LogIt(1672,"ICOM_CMD:No 'in' defined for SETVFO");}
my $freq = $in->{'frequency'} + 0;
if (!$freq) {
add_message("VFO cannot have a 0 frequency");
return ($parmref->{'rc'} = $ParmErr);
}
if (($model eq IC703) and ($state_save{'state'} eq 'mem')){
icom_cmd('_vfo_mode',$parmref);}
if (($model eq ICR30) and ($state_save{'state'} eq 'mem')){icom_cmd('_vfo_mode',$parmref);}
if (icom_cmd('_set_freq',$parmref)) {return $parmref->{'rc'}};
my $mode = $in->{'mode'};
if (!$mode) {LogIt(2681,"No MODE passed for set VFO");}
if (icom_cmd('_set_mode',$parmref)) {return $parmref->{'rc'}};
if (defined $extended{$model}) {
foreach my $ctl (keys %{$extended{$model}}) {
if (!defined $in->{'ctl'}) {next;}
$parmref->{'write'} = TRUE;
icom_cmd("_vfo_$ctl");
}### Each of the extended controls
}### extended controls for the model are defined
if ($model eq ICR30) {usleep(100);}
icom_cmd('_get_freq',$parmref);
if ($freq != $out->{'frequency'}){
LogIt(1,"SETVFO l3424:Tried to set ICOM to freq=$freq but got $out->{'frequency'}");
}
return ($parmref->{'rc'} = $rc);
}
elsif ($cmd eq 'getglob') {
$state_save{'cmd'} = $cmd;
if (!$db) {LogIt(1793,"ICOM_CMD:No database reference for GETGLOB");}
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'setglob') {
$state_save{'cmd'} = $cmd;
if (!$db) {LogIt(1793,"ICOM_CMD:No database reference for SETGLOB");}
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'getsrch') {
if ($model eq ICR30) {
return ($parmref->{'rc'} = $NotForModel);
}
elsif ($model eq IC703) {
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = FALSE;
my $first = 100;
my $last  = 105;
my $odd = FALSE;
my $lastfreq = 0;
my $lastserv = '';
foreach my $ch ($first..$last) {
$myout{'valid'} = FALSE;
$myout{'mode'} = 'fmn';
$myout{'frequency'} = 0;
$myout{'service'} = '';
$myin{'channel'} = $ch;
$parmref->{'write'} = FALSE;
if (icom_cmd('_memory_direct',$parmref)) {last;};
if ($odd) {
my %rec = ('service' => "$lastserv/$myout{'service'}",
'valid' => $myout{'valid'},
'lowfreq' => $myout{'frequency'},
'highfreq' => $myout{'lastfreq'},
'step' => 100,
'mode' => $myout{'mode'},
);
add_a_record($db,'search',\%rec,FALSE);
$lastfreq = 0;
$lastserv = '';
$odd = FALSE;
}
else {
$lastfreq = $myout{'frequency'};
$lastserv = $myout{'service'};
$odd = !$odd;
}
}### run through all scan edges
$parmref->{'out'} = $outsave;
return ($parmref->{'rc'} = $GoodCode);
}
else {
}
}
elsif ($cmd eq 'setsrch') {
if ($model eq ICR30) {
return ($parmref->{'rc'} = $NotForModel);
}
elsif ($model eq IC703) {
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = TRUE;
my $first = 100;
my $last  = 105;
my %chan_name = ( '100' => 'EDGE 1A',
'101' => 'EDGE 1B',
'102' => 'EDGE 2A',
'103' => 'EDGE 2B',
'104' => 'EDGE 3A',
'105' => 'EDGE 3B',
);
my $odd = FALSE;
my $lastfreq = 0;
my $lastserv = '';
my @send = ();
my $ch = $first;
foreach my $rec (@{$db->{'search'}}) {
if (!$rec->{'index'}) {next;}
my $startfreq = $rec->{'lowfreq'};
my $endfreq = $rec->{'highfreq'};
my $mode = $rec->{'mode'};
if (!$startfreq or (!$endfreq)) {next;}
if (!$mode) {$mode = 'fmn';}
my %rec = ('frequency' => $startfreq,
'channel' => $ch,
'mode' => $mode,
'smode' => $mode,
'valid' => FALSE,
'tone' => 'Off',
'stone' => 'Off',
'tone_type' => 'Off',
'stone_type' => 'Off',
'sfrequency' => 0,
);
my $service = $rec->{'service'};
if (!$service) {$service = $chan_name{$ch};}
$rec{'service'} = $service;
push @send,{%rec};
$ch++;
if ($ch > $last) {last;}
$rec{'frequency'} = $endfreq;
$rec{'channel'} = $ch;
if (!$service) {$service = $chan_name{$ch};}
$rec{'service'} = $service;
push @send,{%rec};
$ch++;
}### Build list
foreach my $rec (@send) {
foreach my $key (keys %{$rec}) {$myin{$key} = $rec->{$key};}
print STDERR "\nWriting " . $Reset;
print STDERR " channel:$Bold$Green" . sprintf("%02.2u",$myin{'channel'}) .$Reset ;
print STDERR " freq:$Bold$Blue" . rc_to_freq($myin{'frequency'}) . $Reset;
print STDERR " mode:$Bold$Magenta$myin{'mode'}$Reset";
$rc = icom_cmd('_memory_direct',$parmref);
if ($rc) {
print "\n\n Got Error $rc from ICOM_CMD\n";
last;
}
}
$parmref->{'out'} = $outsave;
return ($parmref->{'rc'} = $GoodCode);
}
else {
}
}
elsif ($cmd eq 'getsig') {
$out->{'signal'} = 0;
$out->{'sql'} = FALSE;
$out->{'rssi'} = 0;
my $udelay = 100;
$rc = $GoodCode;
my $tries = 0;
if ($model eq R7000) {
icom_cmd('poll',$parmref);
return ($parmref->{'rc'});
}### R7000 section
elsif ($model eq ICR30) {
icom_cmd('_get_noise_smeter',$parmref);
}
else { icom_cmd('_get_squelch',$parmref);}
if ($out->{'sql'}) {
icom_cmd('_get_signal',$parmref);
$state_save{'sig'} = TRUE;
if ($model eq ICR30) {
get_r30_display($parmref);
if (!$out->{'service'}) {$out->{'service'} = '.';}
$out->{'_radiochan'} = $out->{'channel'};
$out->{'channel'} = $out->{'_rcchan'};
}
else {
icom_cmd('_get_freq',$parmref);
icom_cmd('_get_mode',$parmref);
$out->{'service'} = '';
}
}### got a signal
else {
if ($progstate eq 'manual') {
$rc = icom_cmd('_get_freq',$parmref);
if ( !$rc and ($out->{'frequency'})) {
$vfo{'frequency'} = $out->{'frequency'};
$rc = icom_cmd('_get_mode',$parmref);
$vfo{'mode'} = $out->{'mode'};
}
}### Manual state
$state_save{'sig'} = FALSE;
}
$state_save{'cmd'} = $cmd;
return ($parmref->{'rc'} = $rc);
}
elsif ($cmd eq 'scan') {
if ($model eq ICR30) {
$in->{'state'} = 'mem';
$parmref->{'write'} = TRUE;
if (icom_cmd('_op_state',$parmref)) {
LogIt(1,"ICOM_CMD l2881:Cannot set op_state");
add_message("ICOM ICR30 cannot set op_state");
return ($parmref->{'rc'} = $NotForModel);
}
$in->{'scan_type'} = $default_scan;
if(icom_cmd('_start_a_scan',$parmref)) {
LogIt(1,"ICOM_CMD l2887:Cannot start scan");
add_message("ICOM ICR30 cannot start scan");
return ($parmref->{'rc'} = $NotForModel);
}
}
elsif ($model eq IC703) {
if(icom_cmd('_memory_scan',$parmref)) {
LogIt(1,"ICOM_CMD l3786:Cannot start scan");
add_message("ICOM IC-703 cannot start scan");
return ($parmref->{'rc'} = $NotForModel);
}
}
elsif ($model eq IC705) {
if(icom_cmd('_select_scan',$parmref)) {
LogIt(1,"ICOM_CMD l3795:Cannot start scan");
add_message("ICOM IC-705 cannot start scan");
return ($parmref->{'rc'} = $NotForModel);
}
}
else {
LogIt(1,"ICOM l3791: Scan not supported on model $model!");
add_message("ICOM model $model does not support radio scan");
return ($parmref->{'rc'} = $NotForModel);
}
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'test') {
$ack = 1;
$sendhex = $in->{'test'};
if ($debug3) {LogIt(0,"TEST command will send=>$sendhex");}
}
elsif ($cmd eq 'poll') {
$sendhex = '';
}
elsif ($cmd eq '_set_freq_noack') {
$sendhex = "$sendhex" .
num2bcd($in->{"frequency"} + 0,$freqbytes,TRUE );
}
elsif ($cmd eq '_set_mode_noack')    {
my $mode = $in ->{'mode'};
my ($modecode,$sdcard) =  rcmode2icom($mode,$model);
$sendhex = "$sendhex$mode";
}
elsif ($cmd eq '_get_range')    {  }
elsif ($cmd eq '_get_freq') { }
elsif ($cmd eq '_get_mode' ) { }
elsif ($cmd eq '_set_freq')     {
if (!defined $in ->{'frequency'}) {
LogIt(1384,"ICOM_CMD: No 'frequency' in out for cmd $cmd");
}
KeyVerify($in ,'frequency');
my $freq = $in ->{'frequency'} + 0;
if (!$freq) {$freq = 0;}
$sendhex = "$sendhex" . num2bcd($freq,$freqbytes,TRUE );
$state_save{'freq'} = $freq;
}
elsif ($cmd eq '_set_mode' ) {
KeyVerify($in ,'mode');
my $mode = Strip(lc($in ->{'mode'}));
if ($mode eq 'auto') {
if ($in->{'frequency'}) {$mode = lc(AutoMode($in->{'frequency'}));}
else {$mode = 'fmn';}
}
my ($modecode,$sdcard) =  rcmode2icom($mode,$model);
if ((defined $state_save{'mode'}) and ($mode eq $state_save{'mode'})) {
return ($parmref->{'rc'} = $GoodCode);
}
$sendhex = "$sendhex$modecode";
$state_save{'mode'} = $mode;
}
elsif ($cmd eq '_vfo_mode')  {
$state_save{'state'} = 'vfo';
}
elsif ($cmd eq '_select_vfoa') {
$state_save{'state'} = 'vfo';
}
elsif ($cmd eq '_select_vfob') {
$state_save{'state'} = 'vfo';
}
elsif ($cmd eq '_equalize_vfo') {
$state_save{'state'} = 'vfo';
}
elsif ($cmd eq '_swap_vfo') {
$state_save{'state'} = 'vfo';
}
elsif ($cmd eq '_select_aband') {
$state_save{'state'} = 'vfo';
}
elsif ($cmd eq '_select_bband') {
$state_save{'state'} = 'vfo';
}
elsif ($cmd eq '_memory_mode')     {
$state_save{'state'} = 'mem';
}
elsif ($cmd eq '_select_chan')     {
if (!defined $in ->{'channel'}) {
LogIt(3556,"ICOM_CMD: No 'channel' defined for cmd $cmd");
}
my $chan = $in ->{'channel'};
my $len = 2;
if ($model eq R7000) {$len = 1;}
else {$state_save{'state'} = 'mem';}
$state_save{'freq'} = '';
$state_save{'mode'} = '';
$sendhex = $sendhex . num2bcd($chan,$len,FALSE);
}
elsif ($cmd eq '_select_group')     {
if (!defined $in ->{'igrp'}) {
LogIt(3467,"ICOM_CMD: No 'igrp' in out for cmd $cmd");
}
if ($in->{'igrp'} > 99) {
LogIt(1,"ICOM_CMD l3470: IGRP number $in->{'igrp'} is too large. Cannot set group");
return ($parmref->{'rc'} = $ParmErr);
}
$sendhex = $sendhex . num2bcd($in->{'igrp'},2,FALSE);
}
elsif ($cmd eq '_vfo_to_mem')     { }
elsif ($cmd eq '_mem_to_vfo')     { }
elsif ($cmd eq '_clear_mem')     { }
elsif ($cmd eq '_stop_scan') {  }
elsif ($cmd eq '_memory_scan')  { }
elsif ($cmd eq '_select_scan')  { }
elsif ($cmd eq '_split_off')  { }
elsif ($cmd eq '_split_on' )  { }
elsif ($cmd eq '_vfo_step') {
if (!defined $step_code{$model}[0]) {
add_message("ICOM_CMD l3314: STEP setting is not defined for $model");
return ($parmref->{'rc'} = $NotForModel);
}
if ($parmref->{'write'}) {
my $step = $in ->{'step'};
if (!$step) {
$step = 5000;
LogIt(1,"ICOM_CMD:Step=0 detected. Changed to 5khz");
}
elsif (lc($step) eq 'auto') {$step = 5000;}
elsif (!looks_like_number($step)) {
LogIt(1,"ICOM_CMD:Step=$step is NOT valid number. Changed to 5khz");
$step = 5000;
}
my $sendhex  = $sendhex . rctostepbcd($step);
}
}
elsif ($cmd eq '_vfo_atten') {
if ($parmref->{'write'}) {
my $att = '00';
if ($in ->{'atten'}) {
$att = '20';
if ($model eq ICR30) {$att = '15';}
}
$sendhex = "$sendhex$att";
if ((defined $state_save{'atten'}) and ($att == $state_save{'atten'})) {
return ($parmref->{'rc'} = $GoodCode);
}
$state_save{'atten'} = $att;
}
}
elsif ($cmd eq '_get_squelch')     { }
elsif ($cmd eq '_get_tone_squelch')     { }
elsif ($cmd eq '_get_signal')     { }
elsif ($cmd eq '_vfo_preamp') {
if ($parmref->{'write'}) {
my $preamp = '00';
if ($in ->{'preamp'}) {$preamp = '01';}
$sendhex = "$sendhex$preamp";
if ((defined $state_save{'preamp'}) and ($preamp eq $state_save{'preamp'})) {
return ($parmref->{'rc'} = $GoodCode);
}
$state_save{'preamp'} = $preamp;
}
}
elsif ($cmd eq '_vfo_rptr') {
if ($parmref->{'write'}) {
my $rptr = '00';
if ($in->{'tone_type'} and (lc($in->{'tone_type'}) eq 'repeater')) {$rptr = '01';}
$sendhex = "$sendhex$rptr";
if ((defined $state_save{'rptr_flag'}) and ($rptr eq $state_save{'rptr_flag'})) {
return ($parmref->{'rc'} = $GoodCode);
}
$state_save{'rptr_flag'} = $rptr;
}
}
elsif ($cmd eq '_vfo_ctcss') {
if ($parmref->{'write'}) {
my $ctcss = '00';
if ($in->{'tone_type'} and (lc($in->{'tone_type'}) eq 'ctcss')) {$ctcss = '01';}
if ((defined $state_save{'ctcss_flag'}) and ($ctcss eq $state_save{'ctcss_flag'})) {
return ($parmref->{'rc'} = $GoodCode);
}
$state_save{'ctcss_flag'} = $ctcss;
$sendhex = "$sendhex$ctcss";
}
}
elsif ($cmd eq '_dply_type') {
if ($parmref->{'write'}) {
my $parm = '00';
if ($in->{'dual'}) {$parm = '01';}
$sendhex = "$sendhex$parm";
}
}
elsif ($cmd eq '_nxdn_encrypt') {
if ($parmref->{'write'}) {
my $parm = '00';
if ($in->{'nxdncrypt'}) {$parm = '01';}
$sendhex = "$sendhex$parm";
}
}
elsif ($cmd eq '_nxdn_ran') {
if ($parmref->{'write'}) {
my $parm = sprintf("%02d",$in->{'nxdnran'});
$sendhex = "$sendhex$parm";
}
}
elsif ($cmd eq '_nxdn_crypt_key') {
if ($parmref->{'write'}) {
my $parm = sprintf("%06d",$in->{'enc'});
$sendhex = "$sendhex$parm";
}
}
elsif ($cmd eq '_get_id')     { }
elsif ($cmd eq '_memory_direct') {
my $chan = $in->{'channel'};
my $igrp = $in->{'igrp'};
if (!defined $chan) { LogIt(2210,"ICOM_CMD:0 or undefined channel in 'in' cmd=MEMORY_DIRECT");}
if (!looks_like_number($chan)) {LogIt(2211,"ICOM_CMD:channel $chan is not a number. cmd=MEMORY_DIRECT");}
if ($defref->{'group'}) {
my $grphex = num2bcd($igrp,2,FALSE);
$sendhex="$sendhex$grphex";
}
else {print "No group support for this radio\n";}
my $chanbcd = num2bcd($chan,2,FALSE);
$sendhex = "$sendhex$chanbcd";
if ($parmref->{'write'}) {
if ($in->{'frequency'}) {
my $service_len = 9;
my @bcdkeys = ('flag1',
'frequency','mode','tone_type','rsvd','tone','rsvd','tone',
'sfrequency','smode','stone_type','rsvd','stone','rsvd','stone',
'service',
);
if ($model eq IC705) {
@bcdkeys = ('flag2',
'frequency','mode',
'data',
'duplex',
'tone_type',
'dsql',
'nybl',
'rsvd',
'tone',
'rsvd',
'tone',
'polarity',
'dtcs',
'dvcode',
'offset',
'callsign',
'callsign',
'callsign',
'sfrequency','smode','data',
'duplex',
'stone_type',
'sdsql',
'nybl',
'rsvd','stone',
'rsvd','stone',
'spolarity',
'sdtcs',
'sdvcode',
'offset',
'callsign','callsign','callsign',
'service',
);
$service_len = 16;
}
elsif ($model eq R8600) {
$service_len = 16;
@bcdkeys = ('flag3',
'frequency','mode','nybl','duplex','offset',
'tsfunc','ts','pts','atten','preamp',
'antenna','ipp',
'service',
'digtone',
);
}
my $valid = 0;
if ($in->{'valid'}) {$valid = 1;}
my $main_freq = $in->{'frequency'};
my $split_freq = $in->{'sfrequency'};
if (!$split_freq) {$split_freq = 0;}
if ($main_freq =~ /\./) {$main_freq = freq_to_rc($main_freq);}
if ($split_freq =~ /\./) {$split_freq = freq_to_rc($split_freq);}
my $offset = 0;
my $duplex = 0;
my $split  = 0;
if ($split_freq and ($split_freq != $main_freq)) {
if ($in->{'ominus'}) {$duplex = 1;}
elsif ($in->{'oplus'}) {$duplex = 2;}
else {$split = TRUE;}
if ($duplex and ($model eq IC703) ) {
if ($duplex == 1) {$split_freq = $main_freq - $split_freq;}
else {$split_freq = $main_freq + $split_freq;}
$duplex = 0;
$split = 1;
}
if ($split and ($model eq R8600)) {
if ($split_freq > $main_freq) {
$duplex = 2;
$offset = $split_freq - $main_freq;
}
else {
$duplex = 1;
$offset = $main_freq - $split_freq;
}
}
}
else {
$split_freq = $main_freq;
$duplex = 0;
}
my $mode = $in->{'mode'};
if (!$mode) {$mode = 'FMn';}
if ($mode =~ /auto/i) {$mode = AutoMode($main_freq);}
my $smode = $in->{'mode'};
if (!$smode) {$smode = 'FMn'};
if ($smode =~ /auto/i) {$smode = AutoMode($split_freq);}
my $adtype = $in->{'adtype'};
if ($model eq R8600) {
if ($adtype =~ /p25/i) {$mode = 'p25';}
elsif ($adtype =~ /nxdn/i) {$mode = 'nxdn';}
elsif ($adtype =~ /vn/i) {$mode = 'nxdnvn';}
elsif ($adtype =~ /star/i) {$mode = 'dstar';}
}
elsif ($model eq IC705) {
if ($adtype =~ /star/i) {$mode = 'dstar'};
}
my $scansel = $in->{'scangrp'};
if (!$scansel) {$scansel = 0;}
if (($model eq IC705) and ($scansel > 3)) {$scansel = 3;}
my %out_hex = (
'rsvd' => '00',
'nybl' => '0',
'flag1' =>  unpack("H*",pack("B8","000000$split$valid")),
'flag2' =>  "$split$scansel",
'flag3' =>  (!$valid) .  $scansel,
'frequency' => num2bcd($main_freq,5,TRUE),
'sfrequency' => num2bcd($split_freq,5,TRUE),
'offset' => num2bcd($offset,3,TRUE),
'duplex' => $duplex,
'tone_type' => '0',
'stone_type' => '0',
'tone' => '0670',
'stone' => '0670',
'dtcs' => '0023',
'sdtcs' => '0023',
'data' => '00',
'dsql' => '0',
'sdsql' => 0,
'dvcode' => '00',
'sdvcode' => '00',
'polarity' => '00',
'spolarity' => '00',
'tsfunc' => '00',
'ts'     => '01',
'pts'    => '0010',
'atten'  => '00',
'preamp' => '00',
'antenna' => '00',
'ipp'     => '00',
'digtone' => '',
'callsign' => '2020202020202020',
);
my $sdcard = '';
($out_hex{'mode'},$sdcard) = rcmode2icom($mode,$model);
($out_hex{'smode'},$sdcard) = rcmode2icom($mode,$model);
foreach my $pass (0,1) {
my $tt_key = 'tone_type';
my $tn_key = 'tone';
my $pre = '';
if ($pass) {
$tt_key = 'stone_type';
$tn_key = 'stone';
$pre = 's';
}
my $tone = $in->{$tn_key};
my $tone_type = $in->{$tt_key};
if (!$tone_type) {$tone_type = 'off';}
if (($tone_type =~ /off/i) or (!$tone)) {
}
elsif ($tone_type =~ /rptr/i) { 
$out_hex{$tn_key} = tone2bcd($tone);
$out_hex{$tt_key} = '1';
}
elsif ($tone_type =~ /ctcss/i) { 
$out_hex{$tn_key} = tone2bcd($tone);
$out_hex{$tt_key} = '2';
if (!$pass) {
$out_hex{'digtone'} = '01' .
'00' .
$out_hex{$tn_key} .
'000023';
}
}
elsif ($tone_type =~ /dcs/i) { 
$out_hex{$pre . 'dtcs'} = num2bcd($tone,2,FALSE);
if ($in->{'polarity'}) {$out_hex{$pre . 'polarity'} = '11';}
$out_hex{$tt_key} = '3';
if (!$pass) {
my $code = $out_hex{$tn_key};
if ($in->{'polarity'}) {$code = "01$code";}
else {$code = "00$code";}
$out_hex{'digtone'} = '02' .
'00' .
'0670'            .
$code;
}
}
elsif ($tone_type =~ /dsql/i) {
my $code = num2bcd($tone,1,FALSE);
$out_hex{$pre . 'dvcode'} = $code;
$out_hex{$pre . 'dsql'} = '2';
if (!$pass) {
$out_hex{'digtone'} = '02' .
$code;
}
}
}### For tones that may also have splits
my $tone_type = $in->{'tone_type'};
my $tone = $in->{'tone'};
if ($tone_type =~ /off/i) {$tone = 0;}
if (!looks_like_number($tone)) {$tone = 0;}
if ($mode =~ /nxdn/i) {
my $enc = '00' .
'000000';
if ($in->{'enc'}) {
$enc = '01' . num2bcd($in->{'enc'},3);
}
my $sqbyte = '00';
my $ran = '00';
if ($tone and $tone_type =~ /nxdn/i) {
$ran = num2bcd($tone,1);
$sqbyte = '01';
}
$out_hex{'digtone'} = $sqbyte . $ran . $enc;
}
elsif ($tone_type =~ /p25/i) {
my $tone = sprintf("%03.3x",$in->{'tone'});
$tone = '0' . substr($tone,0,1) .
'0' . substr($tone,1,1) .
'0' . substr($tone,2,1);
$out_hex{'digtone'} = '01' . $tone;
}### P25 process
my $service = $in->{'service'};
if (!$service) {$service = '';}
$service = substr($service . (' ' x $service_len),0,$service_len);
$out_hex{'service'} = unpack("H*",$service);
foreach my $key (@bcdkeys) {
if (!defined $out_hex{$key}) {
LogIt(4899,"ICOM _MEMORY_DIRECT l4899:Missing def for key $key!");
}
$sendhex = $sendhex . $out_hex{$key};}
}### Non zero frequency
else {$sendhex = $sendhex . 'ff';}
}### Write setup
}### Set/Get Memory channel
elsif ($cmd eq '_band_stack')     {
LogIt(1,"ICOM_CMD:_band_stack command not yet implemented!");
return ($parmref->{'rc'} = $NotForModel);
}
elsif ($cmd eq '_op_state') {
if ($parmref->{'write'}) {
my $state = '00';
if ($in->{'state'}) {
if ($in->{'state'} eq 'vfo') {$state = '00';}
elsif ($in->{'state'} eq 'mem') {$state = '01';}
elsif ($in->{'state'} eq 'wx') {$state = '02';}
else {LogIt(3986,"ICOM:_OP_STATE command invalid state $in->{'state'} given!");}
}
$state_save{'state'} = $state;
$sendhex = "$sendhex$state";
}
}
elsif ($cmd eq '_start_a_scan') {
if (!defined $in->{'scan_type'}) {### oops
LogIt(3588,"ICOM _start_a_scan missing 'scan_type'");}
my $mwscan = '00';
my $scancode = $scancodes{$in->{'scan_type'}};
if (!defined $scancode){
LogIt(3596,"ICOM _start_a_scan invalid 'scan_type' $in->{'scan_type'}");
}
if (($scancode eq '02') or ($scancode == 03)) {
my $groupcd = '00';
if ($in->{'group'}) {
}
$scancode = "$scancode$groupcd";
}
elsif ($scancode eq '08') {
my $groupcd = '0000';
if ($in->{'group'}) {
}
$scancode = "$scancode$groupcd";
}
$sendhex = "$sendhex$mwscan$scancode";
}
elsif ($cmd eq '_cancel_scan') {
}
elsif ($cmd eq '_get_scan_condition') {
}
elsif ($cmd eq '_get_display') {
}
elsif ($cmd eq '_get_noise_smeter')     { }
elsif ($cmd eq '_vfo_rptr_freq') {
if ($parmref->{'write'}) {
my $tone = tone2bcd($in ->{'tone'});;
$sendhex = "$sendhex$tone";
}
}
elsif ($cmd eq '_vfo_ctcss_freq') {
if ($parmref->{'write'}) {
if ($debug3) {LogIt(0,"ICOM_CMD l2405:in->$in->{'tone'}");}
my $tone = tone2bcd($out->{'tone'});
if ($debug3) {LogIt(0,"ICOM_CMD l2407:hex=$tone");}
$sendhex = "$sendhex$tone";
}
}
elsif ($cmd eq '_vfo_dsc_code') {
if ($parmref->{'write'}) {
my $tone = '00';
if ($out->{'tone'} =~ /off/i) {$tone = '000000';}
else {
if ($out->{'polarity'}) {$tone = '01';}
$tone = $tone . '0' . sprintf("%03.3i",$out->{'tone'});
}
$sendhex = "$sendhex$tone";
}
}
elsif ($cmd eq '_vfo_nac_code') {
if ($parmref->{'write'}) {
my $tone = sprintf("%03.3x",$out->{'tone'});
$tone = '0' . substr($tone,0,1) .
'0' . substr($tone,1,1) .
'0' . substr($tone,2,1);
$sendhex = "$sendhex$tone";
}
}
elsif ($cmd eq '_vfo_csql_code') {
if ($parmref->{'write'}) {
$sendhex = $sendhex . $out->{'tone'};
}
}
elsif ($cmd eq '_get_nxdn_rx_id') {
}
elsif ($cmd eq '_get_nxdn_rx_status') {
}
else {
LogIt(3465,"ICOM_CMD: No preprocess defined for command $cmd");
$parmref->{'rc'} = $NotForModel;
return $NotForModel;
}
$sendhex = $sendhex . 'FD';
my $outstr = pack("H*",$sendhex);
my $outlen = length($outstr);
my $ptobj = $parmref->{'portobj'};
RESEND:
if ($cmd ne 'poll') {
my ($cnt,$leftover) = $portobj->read();
if ($leftover and $debug3) {LogIt(0,"ICOM l3439:Leftover before send->",unpack("H*",$leftover));}
$parmref->{'sent'} = $sendhex;
if ($debug3) {LogIt(6,"ICOM_CMD l3428:sent=>$sendhex (command=$cmd) ack=$ack");}
my $countout = $ptobj->write($outstr);
if (!$countout or ($countout != $outlen)) {### send failed
if (!$countout) {$countout = 0;}
if ($debug3) {LogIt(1,"ICOM:Write failure len=$outlen countout=$countout sent=>$sendhex");}
goto UNRESPONSIVE;
}
if (!$ack) {return $parmref->{'rc'} = $GoodCode;}
}### CMD ne 'POLL'
WAITFORREPLY:
if ($debug3) {LogIt(6,"waiting for reply to $cmd ack=$ack");}
my $byte = '';
my $bstr = '';
my $gotpre = FALSE;
my @rcv_packet = ();
my $rcvhex = '';
my $waitcnt = 10;
while (TRUE) {
$ptobj->read_const_time(10);
my ($count_in, $binary) = $ptobj->read(1);
if ($count_in) {
my $byte = uc(unpack("H*",$binary));
if ($debug3) {print "$byte ";}
if ($byte eq 'FD') {### packet terminator
$rcvhex = "$rcvhex$byte";
last;
}
elsif ($byte eq 'FE') {
if (length($rcvhex) > 2) {
LogIt(0,"ICOM l3469:Got start of new packet with no end of last ($rcvhex)!");
@rcv_packet = ();
$rcvhex = '';
}
$gotpre = TRUE;
$rcvhex = "$rcvhex$byte";
}
elsif ($byte eq 'FC') {
$waitcnt = 10;
next;
}
elsif ($gotpre) {
push @rcv_packet,$byte;
$rcvhex = "$rcvhex$byte";
}
else {if ($warn) {LogIt(1,"ICOM l4412:got byte $byte before preamble");}}
$waitcnt = 10;
}
else {
if ($cmd eq 'poll') {return ($parmref->{'rc'} = $GoodCode);}
--$waitcnt;
if ($debug3) {LogIt(0,"Wait count=$waitcnt");}
if (!$waitcnt) {goto UNRESPONSIVE;}
usleep(10);
}
}
if ($debug3) {LogIt(6,"recv packet =@rcv_packet")};
if ((scalar @rcv_packet) < 3) {
LogIt(0,"ICOM l3489:Got short packet $rcvhex. waiting some more");
goto WAITFORREPLY;
}
if ($cmd eq 'test') {
if ($rcvhex eq $sendhex) {
LogIt(0,"Got echo of packet for test");
goto WAITFORREPLY;
}
else {
$out->{'test'} = $rcvhex;
return ($parmref->{'rc'} = $GoodCode);
}
}#### TEST command
my $dest = shift @rcv_packet;
my $source = shift @rcv_packet;
if ($source ne $radioaddr) {
if ($debug3) {LogIt(0,"Got packet from $source but not from $radioaddr");}
goto WAITFORREPLY;
}
$rc = 0;
$parmref->{'rc'} = $GoodCode;
my $firstbyte = shift @rcv_packet;
if ($firstbyte eq 'FA') {
LogIt(1,"ICOM l3787 rejected packet=>$sendhex returned=$rcvhex command issued=>$cmd");
if ($cmd eq '_op_state') {$state_save{'state'} = '';}
elsif ($cmd eq '_set_freq') {$state_save{'freq'} = 0;}
elsif ($cmd eq '_set_mode') {$state_save{'mode'} = '';}
elsif ($cmd eq '_vfo_atten') {$state_save{'atten'} = -1;}
elsif ($cmd eq '_vfo_preamp') {$state_save{'preamp'} = -1;}
elsif ($cmd eq '_vfo_rptr') {$state_save{'rptr_flag'} = -1;}
elsif ($cmd eq '_vfo_ctcss') {$state_save{'ctcss_flag'} = -1;}
elsif ($cmd eq '_select_chan') {print Dumper($in),"\n";}
return ($parmref->{'rc'} = $NotForModel);
}
elsif ($firstbyte eq 'FF') {
if ($debug3) {LogIt(1,"ICOM_CMD l2007:no data returned..");}
return ($parmref->{'rc'} = $EmptyChan);
}
elsif ($firstbyte eq 'FB') {
if ($debug3) {LogIt(0,"ICOM_CMD l2013:ICOM accepted command. No data returned");}
return ($parmref->{'rc'} = $GoodCode);
}
my $cmdlength = int(length($cmdcode)/2);
if (!$cmdlength) {
LogIt(3223,"ICOM_CMD:Got NO byte length for command code $cmdcode");
}
my $retcmd = $firstbyte;
my @save_packet = @rcv_packet;
foreach (2..$cmdlength) {$retcmd = $retcmd . shift @rcv_packet;}
if ($debug3) {LogIt(0," return command code=$retcmd");}
if (($cmd eq 'poll') or ($retcmd ne $cmdcode)) {
if ($debug3) {LogIt(0,"ICOM l3778:Unsolicited message cmdcode=$firstbyte packet=>@save_packet (packet=>$rcvhex)");}
my $queue = $parmref->{'unsolicited'};
my %qe = ('icom_msg' =>$rcvhex,'frequency' => ' ', 'mode' => ' ' );
if ($firstbyte eq '00') {
$qe{'frequency'} =  bcd2num(\@save_packet,TRUE,'4471');
}
elsif ($firstbyte eq '01') {
($qe{'mode'},$qe{'filter'},$qe{'adtype'}) = bcd2mode(\@save_packet,$model) ;
}
else {
LogIt(1,"ICOM_CMD l3770:Unsolicited command $firstbyte ($rcvhex).");
}
if ($queue) {push @{$queue},{%qe};}
else {
print STDERR "Got unsolicited message:freq=>$qe{'frequency'} mode=>$qe{'mode'}\n";
}
if ($cmd eq 'poll') {return ($parmref->{'rc'} = $GoodCode);}
goto WAITFORREPLY;
}
my $retcmdstr = $cmd_lookup{$retcmd};
if (!$retcmdstr) {
print Dumper(%cmd_lookup),"\n";
LogIt(2241,"No lookup for return command code=>$retcmd!");
}
if ($debug3) {LogIt(0,"return command=>$retcmdstr");}
if ($ack < 1) {
LogIt(1,"ICOM_CMD:Got unexpected response for $cmd$Eol Received:$Bold$rcvhex");
return ($parmref->{'rc'} = $OtherErr);
}
elsif ($retcmdstr eq '_get_range') {
my @low = ();
my @high = ();
foreach my $count (1..$freqbytes){
if (scalar @rcv_packet) {push @low,shift @rcv_packet;}
}
my $sep = shift @rcv_packet;
foreach my $count (1..$freqbytes){
if (scalar @rcv_packet) {push @high,shift @rcv_packet;}
}
my $low = bcd2num(\@low,$freqbytes);
my $high = bcd2num(\@high,$freqbytes);
if ($debug2) {LogIt(0,"ICOM_CMD l1905:Returned high=$high low=$low");}
if ($high < $low) {
my $temp = $high;
$high = $low;
$low = $temp;
}
$out->{'highfreq'} = $high;
$out->{'lowfreq'} = $low;
}
elsif ($retcmdstr eq '_get_freq')  {
my $freq = 0;
if ($rcv_packet[0] ne 'FF') {
$freq = bcd2num(\@rcv_packet,TRUE,'1999');
}
$out->{"frequency"} = $freq;
$state_save{'frequency'} = $freq;
if ($debug2)   {LogIt(0,"ICOM_CMD l2014:Returned frequency=$freq");}
if ($out->{"frequency"}) {$out->{'valid'} = TRUE;}
else {$out->{'valid'} = FALSE;}
}
elsif ($retcmdstr eq '_get_mode')   {
my $mode = '';
my $filter = 0;
my $adtype = 'analog';
if ($rcv_packet[0] ne 'FF') {($mode,$filter,$adtype) =  bcd2mode(\@rcv_packet,$model);}
$state_save{'mode'} = $mode;
if ($debug2)   {LogIt(0,"ICOM_CMD l2136:Returned mode=$mode packet=@save_packet");}
$out->{'mode'} = $mode;
$out->{'adtype'} = $adtype ;
$out->{'filter'} = $filter;
}
elsif ($retcmdstr eq '_vfo_step') {
my $scode = shift @rcv_packet;
my $step = $step_code{$model}[$scode];
if (!$step) {### could not get a code
LogIt(1,"ICOM_CMD:Could not find a step for code=$scode");
$step = 5000;
}
$out->{'step'} = $step;
}
elsif ($retcmdstr eq '_vfo_atten') {
my $atten = shift @rcv_packet;
if ($atten eq '00') {$out->{'atten'} = FALSE;}
else {$out->{'atten'} = TRUE;}
$state_save{'atten'} = $atten;
}
elsif ($retcmdstr eq  '_get_squelch')   {
my $sql = shift @rcv_packet;
if ($sql eq '01') {$out->{'sql'} = TRUE;}
else {$out->{'sql'} = FALSE;}
}
elsif ($retcmdstr eq  '_get_tone_squelch')   {
my $sql = shift @rcv_packet;
if ($sql eq '01') {$out->{'sql'} = TRUE;}
else {$out->{'sql'} = FALSE;}
}
elsif ($retcmdstr eq  '_get_signal')   {
my $sql = FALSE;
if ($out->{'sql'} ) {$sql = TRUE;}
my $sig = '';
foreach my $ndx (0..1) {
my $byte = $rcv_packet[$ndx];
if (!defined $byte) {
LogIt(1,"_get_signal did not return a value");
print Dumper(@rcv_packet),"\n";
return ($parmref->{'rc'} =  $OtherErr);
}
$sig = "$sig$byte";
}
if (!looks_like_number($sig)) {### gotta problem
LogIt(1,"_Get_Signal returned a non-numeric value $sig");
return ($parmref->{'rc'} = $OtherErr);
}
$sig = $sig + 0;
my $signal = 0;
my $meter = 0;
$out->{'rssi'} = $sig;
$out->{'signal'} = $signal;
$out->{'meter'} = $meter;
if ($sig) {### gotta be at LEAST one level
my @rssi_table = @{$rssi2sig{$model}};
if (!scalar @rssi_table) {### no definition for this radio
if ($sql) {
$out->{'signal'} = 9;
$out->{'meter'} = 60;
}
}### no definition for radio
else {
foreach my $cmp (@rssi_table) {
if (!$cmp) {next;}
if (($sig < $cmp) or ($signal >= MAXSIGNAL)){
last;
}
$signal++;
}
if ($sig and (!$signal)) {$signal = 1;}
$out->{'signal'} = $signal;
my @meter_table = @{$sig2meter{$model}};
my $meter_ndx = 0;
if (!scalar @meter_table) {$meter_ndx = 9;}
else {
foreach my $cmp (@meter_table) {
if (!$cmp) {next;}
if ($sig < $cmp) {last;}
$meter_ndx++;
}
}
$out->{'meter'} = $sigmeter[$meter_ndx];
}### Table is available
}### $sig has a value
}### _get_signal
elsif ($retcmdstr eq '_vfo_preamp') {
my $preamp = shift @rcv_packet;
if ($preamp eq '01') {$out->{'preamp'} = TRUE;}
else {$out->{'preamp'} = FALSE;}
$state_save{'preamp'} = $preamp;
}
elsif ($retcmdstr eq '_vfo_rptr') {
my $rptr = shift @rcv_packet;
if ($rptr eq '01') {
$out->{'tone_type'} = 'rptr';
}
$state_save{'rptr_flag'} = $rptr;
}
elsif ($retcmdstr eq '_vfo_ctcss') {
my $ctcss = shift @rcv_packet;
if ($ctcss eq '01') {
$out->{'tone_type'} = 'CTCSS';
}
$state_save{'ctcss_flag'} = $ctcss;
}
elsif ($retcmdstr eq '_dply_type') {
$out->{'dual'} = shift @rcv_packet;
}
elsif ($retcmdstr eq '_nxdn_encrypt') {
$out->{'nxdncrypt'} = shift @rcv_packet;
}
elsif ($retcmdstr eq '_nxdn_ran') {
$out->{'tone'} = shift @rcv_packet;
}
elsif ($retcmdstr eq '_nxdn_crypt_key') {
$out->{'enc'} = '';
while (scalar @rcv_packet) {
$out->{'enc'} = $out->{'enc'} . shift @rcv_packet;
}
}
elsif ($retcmdstr eq '_get_nxdn_rx_id') {
$out->{'nxdnrxid'} = '';
while (scalar @rcv_packet) {
$out->{'nxdnrxid'} = $out->{'nxdnrxid'} . shift @rcv_packet;
}
}
elsif ($retcmdstr eq '_get_nxdn_rx_status') {
$out->{'nxdnrxstatus'} = '';
while (scalar @rcv_packet) {
$out->{'nxdnrxstatus'} = $out->{'nxdnrxstatus'} . shift @rcv_packet;
}
}
elsif ($retcmdstr eq  '_get_id')   {
my $addr = shift @rcv_packet;
if ($addr) {
$model =  $default_addr{$addr};
if (!$model) {$model = R7000;}
$out->{'model'} = $model;
$out->{'addr'} = $addr;
if ($debug2) {LogIt(0,"set model number to $model");}
}
else {return $NotForModel;}
}
elsif ($retcmdstr eq '_memory_direct') {
if ($parmref->{'write'}) {
LogIt(0,"ICOM l 4759:Direct write returned:$rcvhex");
}
else {
my $igrp = 0;
if ($defref->{'group'}) {
my @grp = (shift @rcv_packet, shift @rcv_packet);
$igrp = bcd2num(\@grp,FALSE,'1886');
}
my @memchan = (shift @rcv_packet, shift @rcv_packet);
my $ch = bcd2num(\@memchan,FALSE,'1886');
if ($ch != ($in->{'channel'})) {
my $emsg = "ICOM got info for ch $ch but requested $in->{'channel'}!";
LogIt(1,$emsg);
return ($parmref->{'rc'} = $OtherErr);
}
my $flag = shift @rcv_packet;
$out->{'service'} = '';
$out->{'frequency'} = 0;
$out->{'sfrequency'} = 0;
$out->{'mode'}  = 'FMn';
$out->{'smode'} = 'FMn';
$out->{'filter'} = 0;
$out->{'tone'} = 0;
$out->{'stone'} = 0;
$out->{'polarity'} = 0;
$out->{'spolarity'} = 0;
$out->{'tone_type'} = 'off';
$out->{'stone_type'} = 'off';
$out->{'valid'} = FALSE;
$out->{'ominux'} = FALSE;
$out->{'oplus'} = FALSE;
$out->{'atten'} = FALSE;
$out->{'scangrp'} = 0;
$out->{'adtype'} = 'analog';
$out->{'igrp'} = $igrp;
$out->{'channel'} = $ch;
$out->{'enc'} = 0;
if ($flag eq 'FF') {
if ($debug3) {LogIt(1,"channel $ch is empty");}
return $EmptyChan;
}
my $flag_bits = unpack('B*',pack("H*",$flag));
if ($model eq IC703) {
if ( ($flag eq '01') or ($flag eq '03') ) {$out->{'valid'} = TRUE;}
else {$out->{'valid'} = FALSE;}
my @freqbcd = ();
foreach my $ndx (1..5) {push @freqbcd,shift @rcv_packet;}
my @modebcd = (shift @rcv_packet,  shift @rcv_packet);
my $tonemode = shift @rcv_packet;
shift @rcv_packet;
my @rptrbcd = (shift @rcv_packet, shift @rcv_packet);
shift @rcv_packet;
my @ctscbcd = (shift @rcv_packet, shift @rcv_packet);
my @spfreqbcd = ();
foreach my $ndx (1..5) {push @spfreqbcd,shift @rcv_packet;}
my @spmodebcd = (shift @rcv_packet, shift @rcv_packet);
my $sptonemode = shift @rcv_packet;
shift @rcv_packet;
my @sprptrbcd = (shift @rcv_packet, shift @rcv_packet);
shift @rcv_packet;
my @spctscbcd = (shift @rcv_packet, shift @rcv_packet);
my $service = '';
foreach my $ndx (1..9) {$service = $service . chr(hex(shift @rcv_packet));}
if ($debug3) {
LogIt(0,"freqbcd=@freqbcd mode=@modebcd rptrbcd=@rptrbcd  ctsc=@ctscbcd");
LogIt(0,"spfreqbcd=@spfreqbcd spmode=@spmodebcd sprptrbcd=@sprptrbcd  spctsc=@spctscbcd");
LogIt(0,"flag=$flag tonemode=$tonemode sptonemode=$sptonemode");
}
$out->{'service'} = $service;
$out->{'frequency'} = bcd2num(\@freqbcd,TRUE,'2489');
$out->{'mode'} = '';
if (scalar @modebcd) {($out->{'mode'},$out->{'filter'},$out->{'adtype'})  = bcd2mode(\@modebcd,$model);}
my ($ctcss,$junk1) = packet_decode(\@ctscbcd,'tone');
my ($rptr,$junk2) = packet_decode(\@rptrbcd,'tone');
my @tonemode = split '',unpack("B8",pack("H*",$tonemode));
if (pop @tonemode) {
$out->{'tone'} = $ctcss;
$out->{'tone_type'} = 'CTCSS';
}
elsif (pop @tonemode) {
$out->{'tone'} = $rptr;
$out->{'tone_type'} = 'rptr';
}
if (($flag eq '02') or ($flag eq '03')) {
$out->{'sfrequency'} =  bcd2num(\@spfreqbcd,TRUE,'2515');
($out->{'smode'},$out->{'sfilter'},$out->{'adtype'}) = bcd2mode(\@spmodebcd,$model);
my ($ctcss,$junk1) = packet_decode(\@spctscbcd,'tone');
my ($rptr,$junk2) = packet_decode(\@sprptrbcd,'tone');
my @tonemode = split '',unpack("B8",pack("H*",$sptonemode));
if (pop @tonemode) {
$out->{'stone'} = $ctcss;
$out->{'stone_type'} = 'CTCSS';
}
elsif (pop @tonemode) {
$out->{'stone'} = $rptr;
$out->{'stone_type'} = 'rptr';
}
else {
$out->{'stone'} = 'off';
$out->{'stone_type'} = 'Off';
}
}
}### IC-703
elsif ($model eq IC705) {
my $split = FALSE;
my $valid = FALSE;
my $scangrp = 0;
if (substr($flag,0,1)) {$split = TRUE;}
$scangrp = substr($flag,1,1);
if (!$scangrp) {$scangrp = 0;}
if ($scangrp) {$valid = TRUE;}
$out->{'valid'} = $valid;
$out->{'scangrp'} = $scangrp;
my $offset = FALSE;
$out->{'oplus'} = FALSE;
$out->{'ominus'} = FALSE;
$out->{'sfrequency'} = 0;
foreach my $pass (0,1) {
my $pre = '';
if ($pass) {$pre = 's';}
my ($freq,$dummy)  = packet_decode(\@rcv_packet,'frequency',5);
my ($mode,$filter,$adtype) =  packet_decode(\@rcv_packet,'mode',2);
my $datamode = shift @rcv_packet;
my $byte =  shift @rcv_packet;
my ($offcode,$tonecode) = $byte =~ /(.)(.)/;
$out->{$pre . 'offcode'} = $offcode;
my $digsql = shift @rcv_packet;
$digsql = $digsql + 0;
shift @rcv_packet;
my $rptrtone = 0;
($rptrtone,$dummy) = packet_decode(\@rcv_packet,'tone',2);
shift @rcv_packet;
my $ctcstone = 0;
($ctcstone,$dummy) = packet_decode(\@rcv_packet,'tone',2);
my $polarity = shift @rcv_packet;
my $dcscode = 0;
($dcscode,$dummy) = (shift @rcv_packet) . (shift @rcv_packet);
my $dvcode = shift @rcv_packet;
my $duplex = 0;
($duplex,$dummy) =  packet_decode(\@rcv_packet,'frequency',3);
$out->{$pre . 'duplex'} = $duplex;
my %call = ();
foreach my $key ('ur','r1','r2') {
my $cs = '';
foreach (0..7) {
if (scalar @rcv_packet) {$cs = $cs . shift @rcv_packet;}
}
$call{$key} = $cs;
}
if (!$pre) {$out->{'adtype'} = $adtype;}
if ($adtype =~ /star/i) {
if ($digsql) {
$out->{$pre . 'tone_type'} = 'dsql';
$out->{$pre . 'tone'} = $dvcode;
}
}
elsif ($mode =~ /fm/i) {
if ($tonecode == 1) {
$out->{$pre . 'tone_type'} = 'rptr';
$out->{$pre . 'tone'} = $rptrtone;
}
elsif ($tonecode == 2) {
$out->{$pre . 'tone_type'} = 'ctcss';
$out->{$pre . 'tone'} = $ctcstone;
}
elsif ($tonecode == 3) {
$out->{$pre . 'tone_type'} = 'dcs';
$out->{$pre . 'tone'} = $dcscode;
if ($polarity) {$out->{$pre . 'polarity'} = TRUE;}
}
}
$out->{$pre . 'mode'} = $mode;
$out->{$pre . 'frequency'} = $freq;
}## Normal/Split process
my $dummy = '';
($out->{'service'},$dummy) = packet_decode(\@rcv_packet,'ascii',16);
if ($split) {
}
else {
my $offcode = $out->{'offcode'};
if ($offcode == 1) {
$out->{'ominus'} = TRUE;
$out->{'sfrequency'} = $out->{'duplex'};
}
elsif ($offcode == 2) {
$out->{'oplus'} = TRUE;
$out->{'sfrequency'} = $out->{'duplex'};
}
else {$out->{'sfrequency'} = 0;}
}
}### IC-705
elsif ($model eq R8600) {
if (!(substr($flag,0,1))) { $out->{'valid'} = TRUE;}
my $scangrp = substr($flag,1,1);
if (!$scangrp) {$scangrp = 0;}
$out->{'scangrp'} = $scangrp;
my ($freq,$dummy)  = packet_decode(\@rcv_packet,'frequency',5);
my ($mode,$filter,$adtype) =  packet_decode(\@rcv_packet,'mode',2);
my $duplex = shift @rcv_packet;
my ($offset,$dummy2)  = packet_decode(\@rcv_packet,'frequency',4);
my $tsfunction = shift @rcv_packet;
my $ts = shift @rcv_packet;
my $prg_ts = (shift @rcv_packet) . (shift @rcv_packet);
my $atten = shift @rcv_packet;
my $preamp = shift @rcv_packet;
my $antenna = shift @rcv_packet;
my $ipp = shift @rcv_packet;
($out->{'service'},$dummy) = packet_decode(\@rcv_packet,'ascii',16);
my $tone_type = 'off';
my $tone = 0;
my $enc = 0;
my $polarity = FALSE;
if ($adtype =~ /star/i)  {
my $dsql = shift @rcv_packet;
if ($dsql) {
$tone = shift @rcv_packet;
$tone_type = 'dsql';
}
}
elsif ($adtype =~ /nxdn/i) {
my $dsql = shift @rcv_packet;
my $ran = shift @rcv_packet;
if ($dsql) {
$tone = $ran;
$tone_type = 'ran';
}
my $enc = shift @rcv_packet;
if ($enc) {
$out->$enc = packet_decode(\@rcv_packet,'number',3);
}
}
elsif ($adtype =~ /p25/i) {
my $dsql = shift @rcv_packet;
if ($dsql) {
$tone_type = 'nac';
$tone = packet_decode(\@rcv_packet,'nac',3);
}
}
elsif ($adtype =~ /pmr/i) {
$adtype = 'analog';
}
elsif ($mode =~ /dcr/i) {
$adtype = 'analog';
}
else {
if ($mode =~ /fm/i) {
my $ts = shift @rcv_packet;
shift @rcv_packet;
my $ctcss = packet_decode(\@rcv_packet,'tone',2);
$polarity = shift @rcv_packet;
my $dcs =  packet_decode(\@rcv_packet,'number',2);
if ($ts == 1) {
$tone_type = 'ctcss';
$tone = $ctcss;
$polarity = FALSE;
}
elsif ($ts == 2) {
$tone_type = 'dcs';
$tone = $dcs;
}
}### Tone extraction for FM modulation
}
$out->{'frequency'} = $freq;
$out->{'mode'} = $mode;
$out->{'filter'} = $filter;
$out->{'offset'} = $offset;
$out->{'adtype'} = $adtype;
$out->{'tone'} = $tone;
$out->{'tone_type'} = $tone_type;
$out->{'polarity'} = $polarity;
if ($atten) {$out->{'atten'} = TRUE;}
if ($duplex == 1) {
$out->{'ominus'} = TRUE;
$out->{'sfrequency'} = $offset;
}
elsif ($duplex == 2) {
$out->{'oplus'} = TRUE;
$out->{'sfrequency'} = $offset;
}
}### R8600 decode
else {
LogIt(1,"Need decode for model $model");
}
}
}
elsif ($retcmdstr eq '_op_state') {
my $state = shift @rcv_packet;
if (!$state) {$state = 0;}
if ($state == 0) {$out->{'state'} = 'vfo';}
elsif ($state == 1) {$out->{'state'} = 'mem';}
elsif ($state == 2) {$out->{'state'} = 'wx';}
else {
LogIt(1,"ICOM_CMD l5884:_OP_STATE returned unknown state=$state");
$out->{'state'} = '?';
}
$state_save{'state'} = $out->{'state'};
}
elsif ($cmd eq '_get_scan_condition') {
my $state = shift @rcv_packet;
if (!$state) {$state = 0;}
if ($state == 0) {$out->{'scan'} = 'off';}
elsif ($state == 1) {$out->{'scan'} = 'up';}
elsif ($state == 2) {$out->{'scan'} = 'down';}
elsif ($state == 3) {$out->{'scan'} = 'up';}
elsif ($state == 4) {$out->{'scan'} = 'down';}
else {
LogIt(1,"ICOM_CMD l5308:_SCAN_CONDITION returned unknown condition=$state");
$out->{'scan'} = '?';
}
$state_save{'scan'} = $out->{'scan'};
}
elsif ($retcmdstr eq '_get_display') {
my $status = $rcv_packet[0];
my $state = $rcv_packet[1];
if ($state == 0) {$out->{'state'} = 'vfo';}
elsif ($state == 1) {$out->{'state'} = 'mem';}
elsif ($state == 2) {$out->{'state'} = 'wx';}
else {
LogIt(1,"ICOM l5878:Unknown state $state returned for _GET_DISPLAY");
$out->{'state'} = '';
}
$state_save{'state'} = $out->{'state'};
my @freqbcd = ();
foreach my $ndx (2..6) {push @freqbcd,$rcv_packet[$ndx];}
if (lc($freqbcd[0]) eq 'ff') {$out->{'frequency'} = 0;}
else {$out->{'frequency'} = bcd2num(\@freqbcd,TRUE,'4732');}
my @modebcd = ($rcv_packet[8], $rcv_packet[9]);
my $mode = 'FMn';
my $adtype = 'analog';
if (lc($modebcd[0]) eq 'ff') {$mode = 'FMn';}
else {($mode,$out->{'filter'},$adtype)  = bcd2mode(\@modebcd,$model);}
my $bad_audio = '';
if (($adtype =~ /pmr/i) or ($adtype =~ /dcr/i)) {
$bad_audio = $adtype;
$adtype = 'analog';
}
$out->{'mode'} = $mode;
$out->{'adtype'} = $adtype;
$out->{'bad_audio'} = '';
$out->{'enc'} = 0;
my %rfgain_lookup = (
'0012' => 1, '0038' => 2, '0064' => 3, '0089' => 4, '0115' => 5,
'0140' => 6, '0166' => 7, '0192' => 8,  '0217' => 9, '0243' => 10);
my $rfgain =  $rcv_packet[10] . $rcv_packet[11];
if ($rfgain_lookup{$rfgain}) {$out->{'rfgain'} = $rfgain_lookup{$rfgain}; }
else {
LogIt(1,"ICOM l6411: Unable to decode RFGAIN code $rfgain. Value set to 10");
$out->{'rfgain'} = 10;
}
if ($rcv_packet[12] + 0) {$out->{'att'} = TRUE;}
else {$out->{'att'} = FALSE;}
$out->{'duplex'} = $rcv_packet[13];
$out->{'wx'}     = $rcv_packet[14];
$out->{'mute'}   = $rcv_packet[15];
$out->{'afc'}    = $rcv_packet[16];
$out->{'skip'}   = $rcv_packet[17];
$out->{'igrp'} = $rcv_packet[18] . $rcv_packet[19];
$out->{'channel'}   = $rcv_packet[20] . $rcv_packet[21];
$out->{'_rcchan'} = ($out->{'igrp'} * 100) + $out->{'channel'} + 1;
$out->{'_radiochan'} = $out->{'channel'};
my $service = '';
foreach my $ndx (22..37) {$service = $service . chr(hex($rcv_packet[$ndx]));}
if ($state_save{'state'} eq 'mem'){$out->{'service'} = $service;}
$out->{'vsc'} = $rcv_packet[38];
my $tb1 = $rcv_packet[39];
my $tb2 = $rcv_packet[40];
$out->{'tone_type'} = 'off';
$out->{'tone'} = 'off';
if ($mode =~ /fm/i) {
if ($adtype =~ /analog/i) {
if ($tb1) {
$out->{'tone_type'} = 'ctcss';
icom_cmd('_vfo_ctcss_freq',$parmref);
}
elsif ($tb2) {### DCS squelch
$out->{'tone_type'} = 'dsc';
icom_cmd('_vfo_dsc_code',$parmref);
}
}
elsif ($adtype =~ /nxdn/i) {
if ($tb1) {
$out->{'tone_type'} = 'ran';
icom_cmd('_nxdn_ran',$parmref);
}
if ($tb2) {
icom_cmd('_nxdn_crypt_key',$parmref);
}
}
elsif ($adtype =~ /star/i) {### DSTAR format
if ($tb1) {
$out->{'tone_type'} = 'dsql';
icom_cmd('_vfo_csql_code',$parmref);
}
}
elsif ($adtype =~ /p25/i) {### P25 format
if ($tb1)  {## P25 NAC squelch
$out->{'tone_type'} = 'nac';
icom_cmd('_vfo_nac_code',$parmref);
}
}
}
if ($bad_audio) {
$out->{'bad_audio'} = $bad_audio;
}
}### _get_display post process
elsif ($retcmdstr eq '_get_noise_smeter') {
my $sq =  $rcv_packet[0] + 0;
$out->{'sql'} = $sq;
my $sig = '';
foreach my $ndx (1..2) {
my $byte = $rcv_packet[$ndx];
if (!defined $byte) {
LogIt(1,"_get_noise_smeter did not return a value");
return ($parmref->{'rc'} =  $OtherErr);
}
$sig = "$sig$byte";
}
if (!looks_like_number($sig)) {### gotta problem
LogIt(1,"_get_noise_smeter returned a non-numeric value $sig");
return ($parmref->{'rc'} = $OtherErr);
}
$sig = $sig + 0;
$out->{'rssi'} = $sig;
}### _get_noise_meter
elsif ($retcmdstr eq '_vfo_rptr_freq') {
shift @rcv_packet;
my $tone = packet_decode(\@rcv_packet,'tone');
if (!looks_like_number($tone)) {$tone = 0;}
$out->{'tone'} = $tone;
}
elsif ($retcmdstr eq '_vfo_ctcss_freq') {
shift @rcv_packet;
my $tone = packet_decode(\@rcv_packet,'tone');
if (!looks_like_number($tone)) {$tone = 0;}
$out->{'tone'} = $tone;
}
elsif ($retcmdstr eq '_vfo_dsc_code') {
my $polarity = shift @rcv_packet;
if ($polarity) {$out->{'polarity'} = TRUE;}
else {$out->{'polarity'} = FALSE;}
my $tone = '';
foreach (0..2) {
if (scalar @rcv_packet) {$tone = $tone . shift @rcv_packet;}
}
if (!$tone) {$tone = 0;}
$out->{'tone'} = $tone;
}
elsif ($retcmdstr eq '_vfo_nac_code') {
$out->{'tone'} = packet_decode(\@rcv_packet,'nac',3);
}
elsif ($retcmdstr eq '_vfo_csql_code') {
my $tone = 0;
if (scalar @rcv_packet) {$tone = shift @rcv_packet;}
$tone = $tone + 0;
$out->{'tone'} = $tone;
}
else {
LogIt(4341,"No post process for retcmdstr=$retcmdstr cmd=$cmd. Need handler!");
add_message("ICOM got response to $cmd ($cmdcode) retcmdstr=$retcmdstr. Need handler!");
}
$parmref->{'rsp'} = FALSE;
return ($parmref->{'rc'} = $rc);
UNRESPONSIVE:
if ($cmd eq 'test') {
LogIt(1,"No response from the radio for command $sendhex");
$out->{'test'} = '';
}
else {
if (!$parmref->{'rsp'}) {
my $msg = "Radio is not responding";
if ($warn) {
if ($sendhex) {LogIt(1,"ICOM l5611:Radio did not repond to $sendhex");}
else {LogIt(1,$msg);}
add_message($msg);
}
}
}
$parmref->{'rsp'} = TRUE;
return ($parmref->{'rc'} = $CommErr);
}
sub get_r30_display {
my $parmref = shift @_;
my $out = $parmref->{'out'};
my $timeout = 1000;
while ($timeout) {
usleep(300);
$timeout--;
if (icom_cmd('_get_display',$parmref)) {
LogIt(1,"ICOM _get_display command failed");
return ($parmref->{'rc'});
}
if (lc($out->{'bad_audio'}) !~ /dcr/i) {
$timeout = 0;}
}
if (lc($out->{'bad_audio'}) =~ /dcr/) {LogIt(1,"DCR modulation found after 1000 times!");}
return ($parmref->{'rc'});
}
sub tone2bcd {
my $tone = shift @_;
my $newtone = '0670';
if ($tone and  (looks_like_number($tone))){
my $int = int($tone);
my ($dec) = $tone =~ /\d*?\.(\d)/;
if (!$dec) {$dec = 0;}
if ($int < 67) {
LogIt(1,"Conversion error for tone $tone!");
}
else {
$newtone = sprintf("%04.4u","$int$dec");
}
}
return $newtone;
}
sub num2bcd {
my ($num,$bytes,$rev) = @_;
my $digits = $bytes*2;
my $i;
my $out = '';
if (!$num) {$num = '0';}
$num = sprintf("%${digits}.${digits}ld",$num);
if ($rev) {
$i = $digits-2;
while ($i >= 0) {
$out =  $out .  substr($num,$i,2);
$i = $i - 2;
}
}
else {
$i = 0;
while ($i < $digits) {
$out = $out . substr($num,$i,2);
$i = $i + 2;
}
}
return $out;
}
sub clear_bus {
my $portobj = shift @_;
my ($count_in, $data_in) = $portobj->read(1);
while ($count_in) {
($count_in, $data_in) = $portobj->read(1);
usleep(30);
}
}
sub rctostepbcd {
my $step = shift @_;
my $bcd = 0;
if (!defined $step_code{$model}[0]) {
LogIt(1,"ICOM_rctostepbcd:Unsupported model $model for STEP");
return '00';
}
my $code_count = $#{$step_code{$model}};
foreach my $dcd (@{$step_code{$model}}) {
if ($step <= $dcd) {last;}
if ($bcd < $code_count) {$bcd ++};
}
return sprintf("%02.2u",$bcd);
}
sub bcd2mode {
my $array  = shift @_;
my $imodel = shift @_;
if (!$imodel) {$imodel = '';}
my $adtype = 'analog';
my $mode = 'fmn';
my $bw = 0;
if (scalar @{$array} < 2) {
LogIt(1,"BCD2MODE l7268: array size passed is too small");
return ($mode,$bw,$adtype);
}
$mode = $icom_decode{$array->[0]};
if (!defined $mode) {
LogIt(7278,"No Modulation decode for byte value $array->[0]!");
}
if (($model eq R7000) and ($array->[0] eq '05')) {
if (!defined $array->[1]) {$mode = 'fmw';}
elsif ($array->[1] eq '00') {$mode = 'lsb';}
else {$mode = 'fmn';}
}
else {
if ($array->[1]) {
$bw = $array->[1];
if ($mode =~ /am/i) {
if ($bw eq '01') {$mode = 'amw';}
elsif (($bw eq '02') and ($model eq ICR30)) {$mode = 'amn';}
elsif ($bw eq '03') {$mode = 'amn';}
}
elsif ($mode =~ /fm/i) {
if ($bw eq '01') {$mode = 'fmw';}
else {$mode = 'fmn';}
}
}
}
if ($array->[0] > 15) {
$adtype = $mode;
$mode = 'fmn';
}
return ($mode,$bw,$adtype);
}
sub bcd2num {
my ($ref, $rev,$caller) = @_;
my $num = "";
my $temp;
my $start = 0;
my $len = @{$ref};
while ($len) {
my $value = $ref->[$start];
if (!defined $value) {
print Dumper($ref),"\n";
LogIt(2499,"BCD2num bad array value for index $start caller=>$caller");
}
$temp  = $ref->[$start];
if ($temp eq 'FF') {return 0;}
$start++;
$len--;
if ($rev) {$num =   $temp . $num;}
else {$num = $num . $temp ;}
}
return $num;
}
sub packet_decode {
my $ref = shift @_;
if (!$ref) {LogIt(6718,"Programmer forgot 'ref' for packet_decode");}
my $type = shift @_;
if (!$type) {LogIt(6722,"Programmer forgot 'type' for packet_decode");}
my $count = shift @_;
if (!$count) {$count = scalar (@{$ref});}
$type = lc($type);
my $tmodel = shift @_;
if (!$tmodel) {$tmodel = '';}
my $result = '';
my $filter = 0;
my @data = ();
my $data_str = '';
if (!scalar @{$ref}) {
$result = -1;
$filter = -1;
}
foreach (1..$count) {
if (!scalar @{$ref}) {last;}
my $byte = shift @{$ref};
push @data,$byte;
$data_str = "$data_str$byte";
}
if (scalar @data) {
if ($type eq 'bits') {
return unpack('B*',pack("H*",$data_str));
}
elsif ($type eq 'number') {
return  hex($data_str);
}
elsif ($type eq 'frequency') {
foreach my $byte (@data) {
if (lc($byte)  eq 'ff') {
$result = 0;
last;
}
$result = "$byte$result";
}
return $result;
}
elsif ($type eq 'tone')   {
$result = substr($data_str,0,-1) . '.' . substr($data_str,-1,1);
return  sprintf("%3.1f",$result) ;
}
elsif ($type eq 'mode') {
my ($mode,$bw,$adtype) = bcd2mode(\@data,$tmodel);
return $mode,$bw,$adtype;
}
elsif ($type eq 'ascii') {
return  pack('H*',$data_str);
}
elsif ($type eq 'nac') {
my $hex = '';
foreach (0..2) {
if (scalar @data) {
my $byte = shift @data;
$hex = $hex . substr($byte,1,1);
}
}
if (!$hex) {$hex = 0;}
return  hex($hex);
}
else {
LogIt(6734,"ICOM-PACKET_PROC: No process for $type");
}
}### got some data to process
return $result;
}
sub dply_packet {
my @data = @_;
my $hexstr = '';
foreach my $char (@data) {
$hexstr = $hexstr . sprintf("%02.2X",$char) . ' ';
}
return $hexstr;
}
sub numerically {$a<=>$b;}
sub rcmode2icom {
my ($pkg,$fn,$caller) = caller;
my $rcmode = shift @_;
if (!$rcmode) {LogIt(6606,"RCMODE2ICOM: Missing modulation! " .
"caller=>$pkg:$caller");}
my $imodel = shift @_;
if (!$imodel) {
$imodel = R7000;
LogIt(1,"RCMODE2ICOM:Caller $pkg:$caller did not include model. Changed to $imodel!");
}
my $freq = shift @_;
if (!$freq) {$freq = 0;}
my $modestr = 'FM';
my $modecode = '05';
my $filter = '02';
$rcmode = lc(Strip($rcmode));
my $datastr = uc($rcmode);
if ($rcmode eq 'fmw') {$datastr = 'WFM';}
elsif ($datastr =~ /fm/i) {$datastr = 'FM';}
elsif ($datastr =~ /am/i) {$datastr = 'AM';}
elsif ($rcmode eq 'rtty-r') {
if ($imodel eq ICR30)  {$datastr = 'CW-R';}
}
elsif ($rcmode eq 'auto') {
$rcmode = 'fmn';
if ($freq) {
if ($freq < 30000000) {$rcmode = 'am';}
elsif (($freq > 108000000) and ($freq < 138000000)) {$rcmode = 'am';}
}
}
my $datacode = '0502';
if (defined $icom_encode{$rcmode}) {
if (defined $icom_encode{$rcmode}{$imodel}) {
$datacode = $icom_encode{$rcmode}{$imodel};
}
else { $datacode = $icom_encode{$rcmode}{'default'};}
if (!$datacode) {LogIt(6757,"RCMODE2ICOM:No decode/default for mode=$rcmode " .
"model=>$imodel caller=>$pkg:$caller");}
}
else {LogIt(6754,"Missing icom_encode for modulation $rcmode " .
"model=>$imodel caller=>$pkg:$caller");}
if ($datacode eq '0502') {$datastr = 'FM';}
$datastr = Strip($datastr);
return $datacode,$datastr;
}
sub icom2rcmode {
my $bytes = shift @_;
if (!defined $bytes) {LogIt(6864,"RCMODE2ICOM: No BYTE data passed!");}
my $imodel = shift @_;
if (!$imodel) {$imodel = '';}
my $rcmode = 'FMn';
my $filter = 0;
if (length($bytes) < 2) {
LogIt(1,"RCMODE2ICOM l6870:BYTES=>$bytes is too small. " .
"default mode set to $rcmode");
}
else {
my $byte1 = substr($bytes,0,2);
my $byte2 = '';
if (length($bytes) > 3) {$byte2 = substr($bytes,2,2);}
if ($icom_decode{$byte1}) {$rcmode = $icom_decode{$byte1};}
else {LogIt(1,"RCMODE2ICOM l6880:Missing byte1 decode for $byte1");}
if ($byte2) {$filter = $byte2 + 0;}
if ($byte1 eq '05') {
if ($model eq R7000) {
if ($byte2 eq '02') {$rcmode = 'FMn';}
elsif ($byte2 eq '00') {$rcmode = 'LSB';}
else {$rcmode = 'FMw';}
}
elsif ($model eq IC703) {$rcmode = 'FMn';}
elsif ($model eq ICR30) {
if ($byte2 eq '02') {$rcmode = 'FMun';}
}
}
elsif ($byte1 eq '02') {
$rcmode = 'AM';
if ($byte2 eq '01') {$rcmode = 'AMw';}
elsif ($byte2 eq '03') {$rcmode = 'AMn';}
}
}### Bytes found
return $rcmode,$filter;
}
