#!/usr/bin/perl -w
package icom;
require Exporter;
use constant FALSE => 0;
use constant TRUE => 1;
@ISA   = qw(Exporter);
@EXPORT = qw(R7000 IC703 IC705 R8600 ICR30 OTHER icom_cmd
rcmode2icom icom2rcmode %icom_decode
packet_decode
) ;
use Data::Dumper;
use Text::ParseWords;
use threads;
use threads::shared;
use Thread::Queue;
use Time::HiRes qw(time usleep ualarm gettimeofday tv_interval );
use Device::SerialPort qw ( :PARAM :STAT 0.07 );
use Scalar::Util qw(looks_like_number);
use radioctl;
use strict;
use autovivification;
no  autovivification;
use constant ICOM_SIG_ADJUST     => int(255/MAXSIGNAL);
use constant FA                  => 250;
use constant FB                  => 251;
use constant FC                  => 252;
use constant FD                  => 253;
use constant FE                  => 254;
use constant FF                  => 255;
use constant ICOM_TERMINATOR     => FD;
use constant ICOM_PREAMBLE       => FE;
$debug3 = FALSE;
my %icom_commands = ('_set_freq_noack' => {'code' => '00'  ,'ack' => 0,},
'_set_mode_noack' => {'code' => '01'  ,'ack' => 0,},
'_get_range'      => {'code' => '02'  ,'ack' => 2,},
'_get_freq'       => {'code' => '03'  ,'ack' => 2,},
'_get_mode'       => {'code' => '04'  ,'ack' => 2,},
'_set_freq'       => {'code' => '05'  ,'ack' => 1,},
'_set_mode'       => {'code' => '06'  ,'ack' => 1,},
'_vfo_state'       => {'code' => '07'  ,'ack' => 1,},
'_select_vfoa'    => {'code' => '0700','ack' => 1,},
'_select_vfob'    => {'code' => '0701','ack' => 1,},
'_equalize_vfo'   => {'code' => '07A0','ack' => 1,},
'_swap_vfo'       => {'code' => '07B0','ack' => 1,},
'_select_aband'   => {'code' => '07D0','ack' => 1,},
'_select_bband'   => {'code' => '07D1','ack' => 1,},
'_memory_state'    => {'code' => '08'  ,'ack' => 1,},
'_select_chan'    => {'code' => '08'  ,'ack' => 1,},
'_select_group'   => {'code' => '08A0','ack' => 1,},
'_vfo_to_mem'     => {'code' => '09'  ,'ack' => 1,},
'_mem_to_vfo'     => {'code' => '0A'  ,'ack' => 1,},
'_clear_mem'      => {'code' => '0B'  ,'ack' => 1,},
'_read_offset'    => {'code' => '0C'  ,'ack' => 2,},
'_write_offset'   => {'code' => '0D'  ,'ack' => 1,},
'_stop_scan'      => {'code' => '0E00','ack' => 1,},
'_memory_scan'    => {'code' => '0E01','ack' => 1,},
'_prog_scan'      => {'code' => '0E02','ack' => 1,},
'_delta_scan'     => {'code' => '0E03','ack' => 1,},
'_select_scan'    => {'code' => '0E23','ack' => 1,},
'_read_duplex'    => {'code' => '0F'  ,'ack' => 2,},
'_split_off'      => {'code' => '0F00','ack' => 1,},
'_split_on'       => {'code' => '0F01','ack' => 1,},
'_duplex_off'     => {'code' => '0F10','ack' => 1,},
'_duplex_plus'    => {'code' => '0F12','ack' => 1,},
'_vfo_step'       => {'code' => '10',  'ack' => 2,},
'_vfo_atten'      => {'code' => '11'  ,'ack' => 2,},
'_select_antenna' => {'code' => '12'  ,'ack' => 1,},
'_af_gain'        => {'code' => '1401','ack' => 2,},
'_rf_gain'        => {'code' => '1402','ack' => 2,},
'_sq_level'       => {'code' => '1403','ack' => 2,},
'_if_shift'       => {'code' => '1404','ack' => 2,},
'_nr_level'       => {'code' => '1406','ack' => 2,},
'_twin_pbt_inside_level' => {'code' => '1407','ack' => 2,},
'_twin_pbt_outside_level' => {'code' => '1408','ack' => 2,},
'_cw_pitch_level'  => {'code' => '1409','ack' => 2,},
'_rf_power_level' => {'code' => '140A','ack' => 2,},
'_mic_gain_level' => {'code' => '140B','ack' => 2,},
'_key_speed' => {'code' => '140C','ack' => 2,},
'_comp_level' => {'code' => '140E','ack' => 2,},
'_breakin_delay' => {'code' => '140F','ack' => 2,},
'_get_squelch'    => {'code' => '1501','ack' => 2,},
'_get_signal'     => {'code' => '1502','ack' => 2,},
'_get_tone_squelch'    => {'code' => '1505','ack' => 2,},
'_get_rf_meter'     => {'code' => '1511','ack' => 2,},
'_get_swr_meter'     => {'code' => '1512','ack' => 2,},
'_get_als_meter'     => {'code' => '1513','ack' => 2,},
'_vfo_preamp'     => {'code' => '1602','ack' => 2,},
'_vfo_agc'        => {'code' => '1612','ack' => 2,},
'_vfo_noise_blanker'     => {'code' => '1622','ack' => 2,},
'_vfo_noise_reduction'   => {'code' => '1640','ack' => 2,},
'_vfo_auto_notch'   => {'code' => '1641','ack' => 2,},
'_vfo_rptr'       => {'code' => '1642','ack' => 2,},
'_vfo_ctcss'      => {'code' => '1643','ack' => 2,},
'_speech_compress'  => {'code' => '1644','ack' => 2,},
'_monitor'   => {'code' => '1645','ack' => 2,},
'_vox'       => {'code' => '1646','ack' => 2,},
'_breakin'      => {'code' => '1647','ack' => 2,},
'_afc'   => {'code' => '164A','ack' => 2,},
'_vfo_dtcs'  => {'code' => '164B','ack' => 2,},
'_vsc'   => {'code' => '164C','ack' => 2,},
'_p25_dsql'   => {'code' => '1652','ack' => 2,},
'_dply_type'   => {'code' => '1659','ack' => 2,},
'_dstar_dsql'   => {'code' => '165B','ack' => 2,},
'_dpmr_dsql'   => {'code' => '165F','ack' => 2,},
'_ndxn_dsql'   => {'code' => '1660','ack' => 2,},
'_dcr_dsql'   => {'code' => '1661','ack' => 2,},
'_dpmr_scrambler'   => {'code' => '1662','ack' => 2,},
'_nxdn_encrypt'    => {'code' => '1663','ack' => 2,},
'_dcr_encrypt'    => {'code' => '1664','ack' => 2,},
'_turn_off'       => {'code' => '1800','ack' => 0,},
'_turn_on'        => {'code' => '1801','ack' => 0,},
'_get_id'         => {'code' => '1900','ack' => 2,},
'_memory_direct'  => {'code' => '1A00','ack' => 2,},
'_band_stack'     => {'code' => '1A01','ack' => 2,},
'_earphone'       => {'code' => '1A01','ack' => 2,},
'_memory_keyer'  => {'code' => '1A02','ack' => 2,},
'_rcv_frequency'  => {'code' => '1A02','ack' => 1,},
'_change_direction' => {'code' => '1A03','ack' => 1,},
'_beep_emission'  => {'code' => '1A0301','ack' => 2,},
'_band_edge_beep'  => {'code' => '1A0302','ack' => 2,},
'_beep_level'  => {'code' => '1A0303','ack' => 2,},
'_beep_limit'  => {'code' => '1A0304','ack' => 2,},
'_cw_carrier_point'  => {'code' => '1A0305','ack' => 2,},
'_side_tone_level'  => {'code' => '1A0306','ack' => 2,},
'_op_state' => {'code' => '1A04','ack' => 2,},
'_ab_sync' => {'code' => '1A06','ack' => 2,},
'_af_gain_07' => {'code' => '1A07','ack' => 2,},
'_skip_setting' => {'code' => '1A03','ack' => 2,},
'_recording' => {'code' => '1A09','ack' => 1,},
'_start_a_scan'  => {'code' => '1A0A00','ack' => 1,},
'_cancel_scan'   => {'code' => '1A0A01','ack' => 1,},
'_temp_skip'     => {'code' => '1A0A02','ack' => 1,},
'_get_temp_skip' => {'code' => '1A0A03','ack' => 2,},
'_cancel_temp_skip' => {'code' => '1A0A04','ack' => 1,},
'_transceive_scan'  => {'code' => '1A0B00','ack' => 2,},
'_transceive_settings'  => {'code' => '1A0B01','ack' => 1,},
'_get_transceive_settings'  => {'code' => '1A0B01','ack' => 2,},
'_get_scan_condition'  => {'code' => '1A0B02','ack' => 2,},
'_get_scan_info'   => {'code' => '1A0C','ack' => 2,},
'_get_program_link_name'  => {'code' => '1A0D00','ack' => 2,},
'_get_program_edge_name'  => {'code' => '1A0E00','ack' => 2,},
'_get_program_edge_name_change'  => {'code' => '1A0E01','ack' => 2,},
'_get_memory_group_name'  => {'code' => '1A0F00','ack' => 2,},
'_get_memory_group_name_change'  => {'code' => '1A0F01','ack' => 2,},
'_display_content_change_report'  => {'code' => '1A1000','ack' => 2,},
'_get_display_change_transceive'  => {'code' => '1A1001','ack' => 2,},
'_get_display'  => {'code' => '1A11','ack' => 2,},
'_get_noise_smeter'  => {'code' => '1A12','ack' => 2,},
'_bluetooth_detection'  => {'code' => '1A1300','ack' => 2,},
'_bluetooth_transceive_detection'  => {'code' => '1A1301','ack' => 2,},
'_vfo_rptr_freq'  => {'code' => '1B00','ack' => 2,},
'_vfo_ctcss_freq' => {'code' => '1B01','ack' => 2,},
'_vfo_dsc_code'   => {'code' => '1B02','ack' => 2,},
'_vfo_nac_code'   => {'code' => '1B03','ack' => 2,},
'_vfo_csql_code'  => {'code' => '1B07','ack' => 2,},
'_nxdn_ran'  => {'code' => '1B0A','ack' => 2,},
'_nxdn_crypt_key'  => {'code' => '1B0D','ack' => 2,},
'_get_nxdn_rx_id'  => {'code' => '200A02','ack' => 2,},
'_get_nxdn_rx_status'  => {'code' => '200B02','ack' => 2,},
);
my %cmd_lookup = ();
foreach my $cmd (keys %icom_commands) {$cmd_lookup{$icom_commands{$cmd}{'code'}} = $cmd;}
use constant R7000      => 'R7000';
use constant IC703      => 'IC703';
use constant IC705      => 'IC705';
use constant R8600      => 'R8600';
use constant ICR30      => 'ICR30';
use constant OTHER      => 'ICOM';
my %default_addr = ('68' => IC703,
'96' => R8600,
'08' => R7000,
'9C' => ICR30,
'A4' => IC705,
);
my %supported = ();
foreach my $key (keys %default_addr) {$supported{$default_addr{$key}} = $key;}
my $preamble = 'FEFE';
my %icom_decode = (
'00' => 'lsb',
'01' => 'usb',
'02' => 'am',
'03' => 'cw',
'04' => 'rtty',
'05' => 'fmn',
'06' => 'fmw',
'07' => 'cw-r',
'08' => 'rtty-r',
'09' => 'fmn',
'10' => 'fmn',
'11' => 'am',
'12' => 'fmn',
'13' => 'fmn',
'14' => 'am' ,
'15' => 'am',
'16' => 'p25',
'17' => 'dstar',
'18' => 'dpmr',
'19' => 'nxdnvn',### ICR30 only
'20' => 'nxdn',
'21' => 'dcr',
);
my $model = R7000;
my %state_save = ();
my %state_init = (
'state' => '',
'mode'  => '',
'atten' => -1,
'preamp' => -1,
'igrp' => -1,
'cmd'   => '',
'sig'   => FALSE,
'freq'  => 0,
'rptr_flag'  => -1,
'ctcss_flag' => -1,
);
foreach my $key (keys %state_init) {$state_save{$key} = $state_init{$key};}
my %rssi2sig = (
&ICR30 => [0,1,33,67,101,135,169,203,237,254 ],
&IC703 => [0,1,22,49, 75,101,130,169,211,255 ],
&IC705 => [0,8,33,62, 91,120,138,160,199,232 ],
);
my %sig2meter = (
&IC705 => [0,1,19,33,48,63,76,91,106,120,138,160,178,199,218,242,255],
&ICR30 => [0,1,16,33,67,84,84,101,118,135,152,169,186,203,220,237,255],
);
my @sigmeter = (0,1,2,3,4,5,6,7,8,9,15,20,30,40,50,60,60);
my %step_code  = (
&ICR30 => [
10,
100,
1000,
3125,
5000,
6250,
8330,
9000,
10000,
12500,
15000,
20000,
25000,
30000,
50000,
100000,
125000,
200000,
],
&IC703 =>  [
10,
100,
1000,
5000,
9000,
10000,
12500,
20000,
25000,
100000,
]
);
my %scancodes = ('all'      => '00',
'band'     => '01',
'plink'    => '02',
'pgm'      => '03',
'memory'   => '04',
'mode'     => '05',
'near'     => '06',
'link'     => '07',
'group'    => '08',
'dup'      => '09',
'tone'     => '10',
);
my $default_scan = 'link';
my @send_packet;
my $instr;
my $freqbytes = 5;
my $getmemsize = 40;
my @icom_packet ;
my $warn = TRUE ;
my $protoname = 'icom';
use constant PROTO_NUMBER => 2;
$radio_routine{$protoname} = \&icom_cmd;
$valid_protocols{'icom'} = TRUE;
my %sd_format = (
&ICR30 => [
{'Group No'         => 'icomgroup'},
{'Group Name'       => 'groupname'},
{'CH No'            => 'icomch'},
{'Name'             => 'service'},
{'Frequency'        => 'freqmhz'},
{'DUP'              => 'dup'},
{'Offset'           => 'offset'},
{'TS'               => 'step'},
{'Mode'             => 'mode'},
{'RF Gain'          => 'gain'},
{'SKIP'             => 'skip'},
{'Tone'             => 'tone_type'},
{'TSQL Frequency'   => 'ctcss'},
{'DTCS Code'        => 'dcs'},
{'DTCS Polarity'    => 'polarity'},
{'VSC'              => 'vsc'},
{'DV SQL'           => 'dvsql'},
{'DV CSQL'          => 'dvcode'},
{'P25 SQL'          => 'p25sql'},
{'P25 NAC'          => 'p25nac'},
{'dMPR SQL'         => ''},
{'dPMR Common ID'   => ''},
{'dPMR CC'          => ''},
{'dPMR Scrambler'   => ''},
{'dPMR Scrambler Key' => ''},
{'NXDN SQL'         => 'nxdnsql'},
{'NXDN RAN'         => 'nxdnran'},
{'NXDN Encryption'  => 'nxdnenc'},
{'NXDN Encryption Key' => 'nxdnkey'},
{'DCR SQL'          => ''},
{'DCR UC'           => ''},
{'DCR Encryption'   => ''},
{'DCR Encryption Key' => ''},
{'Position'         => 'position'},
{'Latitude'         => 'lat'},
{'Longitude'        => 'lon'},
],
&IC705 => [
{'Group No'         => 'icomgroup'},
{'Group Name'       => 'groupname'},
{'CH No'            => 'icomch'},
{'Name'             => 'service'},
{'SEL'              => 'select'},
{'Frequency'        => 'freqmhz'},
{'DUP'              => 'dup'},
{'Offset'           => 'offset'},
{'Mode'             => 'mode'},
{'DATA'             => 'data'},
{'Filter'           => 'filter'},
{'TONE'             => 'tone_type'},## OFF/TSQL/DTCS/TONE
{'Repeater Tone'    => 'rptrtone'},
{'TSQL Frequency'   => 'ctcss'},
{'DTCS Code'        => 'dcs'},
{'DTCS Polarity'    => 'polarity',},
{'DV SQL'           => 'dvsql'},
{'DV CSQL Code'     => 'dvcode'},
{'Your Call Sign'   => ''},
{'RPT1 Call Sign'   => ''},
{'RPT2 Call Sign'   => ''},
{'Split'            => 'split'},
{'Frequency(2)'     => 'sfrequency'},
{'Dup(2)'           => 'sdup'},
{'Offset(2)'        => 'soffset'},
{'Mode(2)'          => 'smode'},
{'DATA(2)'          => 'sdata'},
{'Filter(2)'        => 'sfilter'},
{'TONE(2)'          => 'stone_type'},
{'Repeater Tone(2)' => 'srptrtone'},## xx.xHz, where 'xx.x' is the tone
{'TSQL Frequency(2)'=> 'sctcss'},
{'DTCS Code(2)'     => 'sdcs'},
{'DTCS Polarity(2)' => 'spolarity'},## For now, defaults to 'BOTH N'
{'DV SQL(2)'        => ''},
{'DV CSQL Code(2)'  => ''},
{'Your Call Sign(2)' => ''},
{'RPT1 Call Sign(2)' => ''},
{'RPT2 Call Sign(2)'=> ''},
],
&R8600 => [
{'Group No'         => 'icomgroup'},
{'Group Name'       => 'groupname'},
{'CH No'            => 'icomch'},
{'Name'             => 'service'},
{'Frequency'        => 'freqmhz'},
{'Mode'             => 'mode'},
{'Tone'             => 'tone_type'},
{'TSQL Frequency'   => 'ctcss'},
{'DTCS Code'        => 'dcs'},
{'DTCS Polarity'    => '',},
{'Offset'           => 'offset'},
{'DUP'              => 'dup'},
{'DV SQL'           => ''},
{'DV CSQL Code'     => ''},
{'SKIP'             => 'skip'},
{'SEL'              => 'select'},
],
);
my $chanper = 100;
my $debug_count = 0;
TRUE;
sub icom_cmd {
my $cmd = shift @_;
if (!$cmd) {LogIt(828,"ICOM_CMD:No command specified!");}
if ($debug3) {LogIt(0,"ICOM_CMD l1625: call cmd=$cmd");}
my $parmref = shift @_;
if (!$parmref) {LogIt(830,"ICOM_CMD:No parmref reference specified. CMD=$cmd");}
if (ref($parmref) ne 'HASH') {LogIt(831,"ICOM_CMD:parmref is NOT a reference to a hash! CMD=$cmd");}
if (!$parmref->{'def'}) {LogIt(833,"ICOM_CMD:No 'def' specified in parmref");}
my $defref    = $parmref->{'def'};
if (ref($defref) ne 'HASH') {LogIt(1875,"ICOM_CMD:defref is NOT a reference to a hash! CMD=$cmd");}
my $out   = $parmref->{'out'};
if (!$out) {LogIt(836,"ICOM_CMD:No 'out' defined in parmref! CMD=$cmd");}
if (ref($out) ne 'HASH') {LogIt(837,"ICOM_CMD:Out spec in parmref is NOT a hash reference! CMD=$cmd");}
my $outsave = $out;
if ((!$parmref->{'portobj'}) and ($cmd ne 'autobaud')) {
print Dumper($parmref),"\n";
LogIt(845,"ICOM_CMD:No portobj in parmref! CMD=$cmd");
}
my $portobj = $parmref->{'portobj'};
my $db = $parmref->{'database'};
if ($db) {
if (ref($db) ne 'HASH') {LogIt(842,"ICOM_CMD:Database spec in parmref is NOT a hash reference! CMD=$cmd");}
}
else {$db = '';}
my $write = $parmref->{'write'};
if (!$write) {$write = FALSE;}
my $in   = $parmref->{'in'};
if ($in) {
if (ref($in) ne 'HASH') {LogIt(580,"IN spec in parmref is NOT a hash reference! CMD=$cmd");}
}
else {$in = '';}
my $insave = $in;
my $compaddr = '00';
my $radioaddr = '08';
if (defined $defref->{'radioaddr'}) {$radioaddr = uc($defref->{'radioaddr'});}
$getmemsize = 40;
my $delay = '1000';
$delay = '1';
if ($debug2) {LogIt(0,"ICOM_CMD l898:cmd=$cmd"); }
my $sendhex = "$preamble$radioaddr$compaddr";
my $cmdcode = '00';
my $ack = 0;
my $rc = 0;
$parmref->{'rc'} = $GoodCode;
if (defined $icom_commands{$cmd}) {
$cmdcode = $icom_commands{$cmd}{'code'};
$sendhex = "$sendhex$cmdcode";
$ack = $icom_commands{$cmd}{'ack'};
}
if ($cmd eq 'init') {
if ($debug1) {LogIt(0,"ICOM_CMD:Starting 'init' command");}
foreach my $key (keys %state_init) {$state_save{$key} = $state_init{$key};}
my %newparms = (
'radioscan' => 0,
'maxchan'   => 99,
'origin'    => 1,
'minfreq'   => 25000000,
'maxfreq'   => 999999999,
'sigdet'    => 0,
'model'     => R7000,
'group'     => FALSE,
'model'     => R7000,
'chanper'   => 10,
'gap1_low'  => 0,
'gap1_high' => 0,
'gap2_low'  => 0,
'gap2_high' => 0,
);
foreach my $key ('model') {
if (defined $defref->{$key}) {$newparms{$key} = $defref->{$key};}
}
if ($newparms{'model'} !~ /R7000/i) {### Don't do this for the R7000
my $rc = icom_cmd('_get_id',$parmref);
if (!$rc) {
LogIt(0,"INIT detected ICOM model $model");
if ($model eq IC703) {
$newparms{'sigdet'} = 2;
$newparms{'radioscan'} = 2;
$newparms{'minfreq'} =    30000;
$newparms{'maxfreq'} = 60000000;
$newparms{'chanper'} = 100;
icom_cmd('_get_range',$parmref);
if ($out->{'minfreq'}) {$newparms{'minfreq'} = $out->{'minfreq'};}
else {LogIt(1,"IC-703 did NOT return low range!");}
if ($out->{'maxfreq'}) {$newparms{'maxfreq'} = $out->{'maxfreq'};}
else {LogIt(1,"IC-703 did NOT return high range!");}
}
elsif (($model eq ICR30) or ($model eq R8600)) {
$newparms{'minfreq'}   =     100000;
$newparms{'maxfreq'}   = 3304999990;
$newparms{'sigdet'}    = 2;
$newparms{'radioscan'} = 2;
$newparms{'maxchan'}   = 9999;
$newparms{'origin'}    = 0;
$newparms{'group'}    = TRUE;
$newparms{'chanper'} = 100;
$parmref->{'write'} = FALSE;
$newparms{'gap1_low'} = 812000000;
$newparms{'gap1_high'} = 851000000;
$newparms{'gap2_low'} = 867000000;
$newparms{'gap2_high'} = 896000000;
icom_cmd('_op_state',$parmref);
icom_cmd('_get_scan_condition',$parmref);
LogIt(0,"R30 is in state: $out->{'state'} scanning: $out->{'scan'}");
}
elsif ($model eq IC705) {
$newparms{'minfreq'}   =     100000;
$newparms{'maxfreq'}   =  470000000;
$newparms{'sigdet'}    = 2;
$newparms{'radioscan'} = 2;
$newparms{'maxchan'}   = 9999;
$newparms{'chanper'} = 100;
$newparms{'origin'}    = 0;
$newparms{'group'}    = TRUE;
$newparms{'gap1_low'} = 200000000;
$newparms{'gap1_high'} = 400000000;
}
else {
LogIt(1,"Radio detected is not currently supported " .
"(Addr:$out->{'addr'}). Defaults used.");
}
}### Good return code from '_get_id'
elsif ($rc == $NotForModel) {
LogIt(1,"Radio does not support _get_id. Defaults used.");
}
else {
return ($parmref->{'rc'} = $CommErr);
}
}### Get parms from the radio
else {$model = R7000;}
foreach my $key (keys %newparms) {
$defref->{$key} = $newparms{$key};
}
print "ICOM l 2378:Current radio model is $model\n";
my $frq = 0;
my $atten = FALSE;
if (icom_cmd('_get_freq',$parmref)) {
return ($parmref->{'rc'} = $CommErr);
}
icom_cmd('_get_mode',$parmref);
if ($debug2) {LogIt(0,"$Bold 'init' complete");}
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'autobaud') {
if (!$defref->{'model'}) {
LogIt(1,"Model number not specified in .CONF file. " .
" Cannot automatically determine port/baud");
return ($parmref->{'rc'} = 1);
}
my @allports = ();
if ($in->{'noport'} and $defref->{'port'}) {push @allports,$defref->{'port'};}
else {
if (lc($defref->{'model'}) ne  'r7000') {@allports = glob("/dev/ttyACM*");}
if (lc($defref->{'model'}) ne 'icr30') {push @allports,glob("/dev/ttyUSB*");}
}
my @allbauds = ();
if ($in->{'nobaud'}) {push @allbauds,$defref->{'baudrate'};}
else {push @allbauds,keys %baudrates;}
@allbauds = sort {$b <=> $a} @allbauds;
@allports = sort {$b cmp $a} @allports;
foreach my $port (@allports) {
my $portobj =  Device::SerialPort->new($port) ;
if (!$portobj) {next;}
$parmref->{'portobj'} = $portobj;
$portobj->user_msg("ON");
$portobj->databits(8);
$portobj->handshake('none');
$portobj->read_const_time(100);
$portobj->write_settings || undef $portobj;
$portobj->read_char_time(0);
foreach my $baud (@allbauds) {
$portobj->baudrate($baud);
$warn = FALSE;
$rc = icom_cmd('_get_freq',$parmref);
$warn = TRUE;
if (!$rc) {### command succeeded
$defref->{'baudrate'} = $baud;
$defref->{'port'} = $port;
$defref->{'handshake'} = 'none';
$portobj->close;
$parmref->{'portobj'} = undef;
LogIt(0,"ICOM $model detected on port $port with baudrate $baud");
return ($parmref->{'rc'} = $GoodCode);
}
}
$portobj->close;
$parmref->{'portobj'} = undef;
}
return ($parmref->{'rc'} = 1);
}
elsif ($cmd eq 'manual' ) {
LogIt(0,"ICOM l1828:Called MANUAL");
$state_save{'cmd'} = $cmd;
if ($model eq ICR30) {
icom_cmd('_cancel_scan',$parmref);
$parmref->{'write'} = FALSE;
icom_cmd('_op_state',$parmref);
}
elsif ($model eq IC703) {
icom_cmd('_select_vfoa',$parmref);
}
else {
}
icom_cmd('_get_freq',$parmref);
icom_cmd('_get_mode',$parmref);
$state_save{'igrp'} = $state_init{'igrp'};
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'vfoinit') {
$state_save{'cmd'} = $cmd;
if ($model eq ICR30) {
$parmref->{'write'} = TRUE;
$in->{'state'} = 'vfo';
icom_cmd('_op_state',$parmref);
$in->{'dual'} = FALSE;
icom_cmd('_dply_type',$parmref);
icom_cmd('_select_aband',$parmref);
}
elsif ($model eq IC703) {
icom_cmd('_select_vfoa',$parmref);
}
else {
}
icom_cmd('_get_freq',$parmref);
icom_cmd('_get_mode',$parmref);
$state_save{'igrp'} = $state_init{'igrp'};
LogIt(0,"VFO setup complete");
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'meminit') {
$state_save{'cmd'} = $cmd;
$out->{'igrp'} = 0;
if ($model eq ICR30) {
$parmref->{'write'} = TRUE;
$in->{'state'} = 'mem';
icom_cmd('_op_state',$parmref);
get_r30_display($parmref);
}
else {
icom_cmd('_memory_state',$parmref);
icom_cmd('_get_freq',$parmref);
icom_cmd('_get_mode',$parmref);
}
$state_save{'igrp'} = $state_init{'igrp'};
LogIt(0,"VFO setup complete");
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'getinfo') {
icom_cmd('init',$parmref);
$out->{'chan_count'} = $defref->{'maxchan'};
$out->{'model'} = $model;
return ($parmref->{'rc'});
}
elsif ($cmd eq 'getmem') {
$state_save{'cmd'} = $cmd;
my $startstate = $progstate;
if ($debug1) {LogIt(0,"ICOM_CMD l2684:got 'getmem'");}
if (!$in) {LogIt(2687,"ICOM_CMD:No 'in' defined for GETMEM");}
if (!$db) {LogIt(2688,"ICOM_CMD:No database reference for GETMEM");}
my $maxcount = MAXCHAN;
my $maxchan = $defref->{'maxchan'};
my $channel =  $defref->{'origin'};
my $hasgroups = $defref->{'group'};
my $comment = TRUE;
my $nodup = FALSE;
if ($in->{'count'}) {$maxcount = $in->{'count'};}
if ($in->{'firstchan'} and ($in->{'firstchan'} < $maxchan)) {
$channel = $in->{'firstchan'};
}
if ($in->{'firstchan'} and ($in->{'lastchan'} < $maxchan)) {
$maxchan = $in->{'lastchan'};
}
if ($in->{'nocomment'}) {$comment = FALSE;}
my $noskip = $in->{'noskip'};
if (!$noskip) {$noskip = FALSE;}
my %duplist = ();
if ($in->{'nodup'}) {
$nodup = TRUE;
foreach my $rec (@{$db->{'freq'}}) {
my $ch = $rec->{'channel'};
if ((defined $ch) and (looks_like_number($ch))) {
$ch = $ch + 0;
$duplist{$ch} = $rec->{'index'}
}### Found a channel number
}### Looking through the current database
}### NODUP specified
my $count = 0;
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = FALSE;
my $sysno = $db->{'system'}[1]{'index'};
if ($sysno and $nodup) {
}
else {
my %sysrec = ('systemtype' => 'CNV','service' => "Kenwood model $model", 'valid' => TRUE);
$sysno = add_a_record($db,'system',\%sysrec,$parmref->{'gui'});
}
my $igrp = 0;
my $grpndx = 0;
my $restore_state = $state_save{'state'};
my $restore_scan = $state_save{'scan'};
if ($model eq ICR30) {
$parmref->{'write'} = FALSE;
icom_cmd('_op_state',$parmref);
$restore_state = $myout{'state'};
icom_cmd('_get_scan_condition',$parmref);
$restore_scan = $myout{'scan'};
if ($restore_state ne 'mem') {
$myin{'state'} = 'mem';
$parmref->{'write'} = TRUE;
my $msg = "ICOM_CMD l2493:ICOM $model cannot set MEMORY state";
if (icom_cmd('_op_state',$parmref)) {
LogIt(1,$msg);
add_message($msg);
return ($parmref->{'rc'} = $NotForModel);
}
$parmref->{'write'} = FALSE;
icom_cmd('_op_state',$parmref);
if ($myout{'state'} ne 'mem') {
LogIt(1,$msg);
add_message($msg);
return ($parmref->{'rc'} = $NotForModel);
}
}
}### ICR30 needs memory state
CHANLOOP:
while ($channel <= $maxchan) {
if (!$grpndx) {
my %grouprec = ('sysno' =>$sysno,
'service' => "ICOM $model Group:$igrp",
'valid' => TRUE
);
$grpndx = add_a_record($db,'group',\%grouprec,$parmref->{'gui'});
$igrp++;
my %newfreq = ('frequency' => 0,
'groupno' => $grpndx,
'channel' => $channel,
'service' => "Freqs for group $grpndx",
'_noshow' => TRUE,
'linecomment' => "*\n* ### Channels for group $grpndx"
);
if ($comment) {my $ndx1 = add_a_record($db,'freq',\%newfreq,FALSE);}
}### New group creation
$vfo{'channel'} = $channel;
$vfo{'groupno'} = $grpndx;
threads->yield;
if ($progstate ne $startstate) {
print "Exited loop as progstate changed\n";
last CHANLOOP;
}
if (!$parmref->{'gui'}) {
print STDERR "\rReading channel:$Bold$Green" . sprintf("%04.4u",$channel) .$Reset ;
}
$myout{'valid'} = TRUE;
$myout{'mode'} = 'fmn';
$myout{'frequency'} = 0;
$myout{'sfrequency'} = 0;
$myout{'tone'} = '_off';
$myout{'stone'} = 'off';
$myout{'tone_type'} = 'off';
$myout{'stone_type'} = 'off';
$myout{'service'} = '';
$myout{'tgid_valid'} = FALSE;
$myout{'atten'} = 0;
$myout{'channel'} = $channel;
$myout{'dlyrsm'} = 0 ;
$myout{'groupno'} = $grpndx;
$myin{'channel'} = $channel;
$myin{'chan_extra'} = 0;
$myin{'group_extra'} = 0;
my $rc = 0;
if ($nodup and $duplist{$channel}) {
}
else {
if ($model eq ICR30) {
$rc = icom_cmd('_select_group',$parmref);
if ($rc) {
my $msg = "ICOM_CMD l2919:Cannot set group for model $model!";
LogIt(1,$msg);
add_message($msg);
return ($parmref->{'rc'} = $NotForModel);
}
$rc = icom_cmd('_select_chan',$parmref);
if (!$rc) {get_r30_display($parmref);}
}### IC-R30
elsif ($model eq R7000)  {
$rc = icom_cmd('_select_chan',$parmref);
if (!$rc) {$rc = icom_cmd('_get_freq',$parmref);}
if (!$rc) {$rc = icom_cmd('_get_mode',$parmref);}
}
else {
$rc = icom_cmd('_memory_direct',$parmref);
}
my $freq = $myout{'frequency'} + 0;
if ($noskip or $freq) {
if (!$freq) {$myout{'valid'} = FALSE;}
my $recno = add_a_record($db,'freq',\%myout,$parmref->{'gui'});
$vfo{'index'} = $recno;
$count++;
if ($count >= $maxcount) {last CHANLOOP;}
}
}### Not skipping duplicates
$channel++;
if (!($channel % $chanper)) {
$grpndx = 0;
}
}### channel creation
print STDERR "\n";
$parmref->{'out'} = $outsave;
$parmref->{'in'} = $insave;
$parmref->{'write'} = $writesave;
$outsave->{'count'} = $count;
$out->{'sysno'} = $sysno;
return ($parmref->{'rc'} = $GoodCode);
}### GETMEM
elsif ($cmd eq 'setmem') {
my $freq = $in->{'frequency'};
my $clear = FALSE;
if ($freq) {
if  (($freq > $defref->{'maxfreq'}) or ($freq < $defref->{'minfreq'}) ) {
return $NotForModel;
}
}
else {$clear = TRUE;}
my $mode = $in->{'mode'};
my $channel = $in->{'channel'};
if ($model eq R7000) {
$rc = icom_cmd('_select_chan',$parmref);
usleep 500;
if ($freq) {
$rc = icom_cmd('_set_freq',$parmref);
usleep 500;
if (!$rc) {$rc = icom_cmd('_set_mode',$parmref);}
usleep 500;
if (!$rc) {$rc = icom_cmd('_vfo_to_mem',$parmref);}
}
else {
$rc = icom_cmd('_clear_mem',$parmref);
}
}### R7000
elsif ($model eq ICR30) {
}
else {
$in->{'chan_extra'} = 0;
$in->{'group_extra'} = 0;
$parmref->{'write'} = TRUE;
$rc = icom_cmd('_memory_direct',$parmref);
}
return $parmref->{'rc'};
}### Setmem
elsif ($cmd eq 'sdcard') {
my $freq = $in->{'frequency'};
my $mode = $in->{'mode'};
my $channel = $in->{'channel'};
my $sd_hash = $parmref->{'sdcard'};
my $retcode = 0;
if (!$sd_hash) {
LogIt(1,"SD_CARD_GEN:Forgot to include $sd_hash");
return 1;
}
if (!$freq) {return ($parmref->{'rc'} = $NotForModel);}
foreach my $model (keys %sd_format) {
my $sd_ref = $sd_hash->{$model};
if (!$sd_ref) {
my $header = '';
foreach my $rcd (@{$sd_format{$model}}) {
foreach my $key (keys %{$rcd}) {
if ($header) {$header = "$header,$key";}
else {$header = $key;}
}
}### For each field in the header
$sd_hash->{$model}[0] = "$header\n";
$sd_ref = $sd_hash->{$model};
}### Build a header record
my %sd_data = (
'step'      => '25kHz',
'data'      => 'OFF',
'sdata'     => 'OFF',
'sdup'      => 'OFF',
'vsc'       => 'OFF',
'soffset'   => '0.000000',
'groupname' => substr($in->{'groupname'},0,16),
'service'   => substr($in->{'service'},0,16),
'freqmhz'   => Strip(rc_to_freq($freq)),
'select' => $in->{'scangrp'},
'offset' => '0.000000',
'split'  => 'OFF',
'dup'    => 'OFF',
'skip'   => 'OFF',
'select' => 'OFF',
'position' => 'None',
'lat'    => 0,
'lon'    => 0,
'polarity' => 'Normal',
);
if (!$in->{'valid'}) {$sd_data{'skip'} = 'ON';}
my $chfmt = sprintf("%04.4i",$channel);
$sd_data{'icomgroup'} = substr($chfmt,0,2);
$sd_data{'icomch'} = substr($chfmt,2,2);
$sd_data{'sfrequency'} = $sd_data{'freqmhz'};
my $split_flag = FALSE;
my $sfreq = $in->{'sfrequency'};
if ($sfreq and ($sfreq != $freq)) {
my $sfreqmhz =  Strip(rc_to_freq($freq));
if ($in->{'oplus'}) {### 'sfrequency' is an +offset
$sd_data{'dup'} = 'DUP+';
$sd_data{'sdup'} = 'DUP+';
$sd_data{'offset'} = $sfreqmhz;
$sd_data{'soffset'} = $sfreqmhz;
}
elsif ($in->{'ominus'}) {### 'sfrequency' is a -offset
$sd_data{'dup'} = 'DUP-';
$sd_data{'sdup'} = 'DUP-';
$sd_data{'offset'} = $sfreqmhz;
$sd_data{'soffset'} = $sfreqmhz;
}
else {
if ($model eq IC705) {
$sd_data{'sfrequency'} = Strip(rc_to_freq($sfreq));
$sd_data{'split'} = 'ON';
$split_flag = TRUE;
}
else {
if ($sfreq > $freq) {
$sd_data{'dup'} = 'DUP+';
$sd_data{'offset'} = Strip(rc_to_freq($sfreq - $freq));
}
else {
$sd_data{'dup'} = 'DUP-';
$sd_data{'offset'} = Strip(rc_to_freq($freq - $sfreq));
}
}### Calculate offsets
}### Split Frequency specified
}### Split frequency process
if ((!$mode) or ($mode eq '-') or ($mode eq '.')) {
$mode = 'FMn';
}
my ($code,$imode) = rcmode2icom($mode,$model);
my $filter = substr($code,-1,1);
$sd_data{'mode'} = $imode;
$sd_data{'filter'} = $filter;
$sd_data{'smode'} = $imode;
$sd_data{'sfilter'} = $filter;
my $sm = $in->{'smode'};
if ($split_flag and $sm and ($sm ne '-') and ($sm ne '.') and ($sm ne $mode)) {
my ($scode,$smode) = rcmode2icom($sm,$model);
$sd_data{'smode'} = $smode;
$sd_data{'sfilter'} = substr($code,-1,1);
}
my $digital = FALSE;
if (($model eq ICR30) or ($model eq R8600)) {
my $adtype = $in->{'adtype'};
if (!$adtype) {$adtype = 'analog';}
if ($adtype =~ /star/i) {
$sd_data{'mode'} = 'DV';
$digital = TRUE;
$sd_data{'dvsq'} = 'OFF';
$sd_data{'dvcode'} = '0';
}
elsif ($adtype =~ /p25/i) {
$sd_data{'mode'} = 'P25';
$sd_data{'p25sql'} = 'OFF';
$sd_data{'p25nac'} = '000';
$digital = TRUE;
}
elsif ($adtype =~ /nxdn/i) {
if ($adtype =~ /vn/i) {$sd_data{'mode'} = 'NXDN-VN';}
else {$sd_data{'mode'} = 'NXDN-N';}
$digital = TRUE;
$sd_data{'nxdnsql'} = 'OFF';
$sd_data{'nxdnran'} = '0';
if ($in->{'enc'}) {
$sd_data{'nxdnenc'} = 'ON';
$sd_data{'nxdnkey'} = $in->{'enc'};
}
else {
$sd_data{'nxdnenc'} = 'OFF';
$sd_data{'nxdnkey'} = '1';
}
$digital = TRUE;
}
}### Additional digital modulations
if ($digital or ($mode !~ /fm/i)) {
$sd_data{'tone_type'} = '';
$sd_data{'dcs'} = '';
$sd_data{'sctcss'} = '';
$sd_data{'ctcss'} = '';
$sd_data{'polarity'} = '';
$sd_data{'vsc'} = '';
}
my $tone = $in->{'tone'};
my $tone_type = $in->{'tone_type'};
if (!$tone_type) {$tone_type = 'off';}
if (!$tone) {$tone = 'off';}
if ($digital) {
if (($tone_type =~ /dsql/i) and ($model eq ICR30))  {
$sd_data{'dvsql'} = 'CSQL';
$sd_data{'dvcode'} = $tone;
}
elsif (($tone_type =~ /p25/i) and ($model eq ICR30))  {
$sd_data{'p25sql'} = 'NAC';
$sd_data{'p25nac'} = $tone;
}
}
else {
$sd_data{'ctcss'} = '88.5Hz';
$sd_data{'rptrtone'} = '88.5Hz';
$sd_data{'dcs'} = '023';
if (($tone =~ /off/i) or ($tone_type =~ /off/i)) {
$sd_data{'tone_type'} = 'OFF';
}
elsif ($tone_type =~ /rptr/i) {
if ($model eq IC705) {
$tone = sprintf("%3.1f",$tone);
$sd_data{'rptrtone'} = $tone . 'Hz';
$sd_data{'tone_type'} = 'TONE';
$sd_data{'polarity'} = 'BOTH N';
$sd_data{'srptrtone'} = {'rptrtone'};
$sd_data{'stone_type'} = 'TONE';
$sd_data{'spolarity'} = 'BOTH N';
}
else {$sd_data{'tone_type'} = 'OFF';}
}
elsif ($tone_type =~ /ctcss/i) {
$sd_data{'tone_type'} = 'TSQL';
$sd_data{'ctcss'} = sprintf("%3.1f",$tone) . 'Hz';
$sd_data{'stone_type'} = $sd_data{'tone_type'};
$sd_data{'sctcss'} = $sd_data{'ctcss'};
}
elsif ($tone_type =~ /dcs/i) {
$sd_data{'tone_type'} = 'DTCS';
$sd_data{'dcs'} = $tone;
$sd_data{'stone_type'} = 'DTCS';
$sd_data{'sdcs'} = {'dcs'};
}
}### Analog Tone values
$sd_data{'gain'} = 'RFG MAX';
my $gain = $in->{'rfgain'};
if (!$gain) {$gain = 0;}
if ($gain and ($gain < 10)) {
$sd_data{'gain'} = 'RFG' . $gain;
}
elsif ($in->{'atten'} or $in->{'r30att'}) {
$sd_data{'gain'} = 'RFG5';
}
my $outrec = '';
foreach my $rcd (@{$sd_format{$model}}) {
foreach my $key (keys %{$rcd}) {
my $rc_key = $rcd->{$key};
my $value = $sd_data{$rc_key};
if (!defined $value) {$value = '';}
if ($outrec) {$outrec = "$outrec,$value";}
else {$outrec = $value;}
}
}### update SD Card fields
push @{$sd_ref},"$outrec\n"
}### For each supported model
return ($parmref->{'rc'} = $retcode);
}### SDCARD process
elsif ($cmd eq 'selmem') {
$state_save{'cmd'} = $cmd;
if (!$in) {LogIt(1562,"ICOM_CMD:No 'in' defined for SELMEM");}
if (!defined $in->{'channel'}) {LogIt(1563,"ICOM_CMD:No 'channel' in 'in' for SELMEM!");}
my $channel = $in->{'channel'};
if (!looks_like_number($channel)) {### bad parameter
add_message("Non-Numeric channel number passed to ICOM");
return ($parmref->{'rc'} = $ParmErr);
}
my $retcode = $GoodCode;
if ($channel > $defref->{'maxchan'}) {$retcode = $NotForModel;}
elsif ($channel < $defref->{'origin'}) {$retcode = $NotForModel;}
if ($retcode) {
print "ICOM:l3318: Channel/group $channel is outside range of radio\n";
add_message("channel/group $channel is outside range of ICOM radio");
return ($parmref->{'rc'} = $retcode);
}
my $chfmt = sprintf("%04.4i",$channel);
my $igrp = substr($chfmt,0,2);
my $ch = substr($chfmt,2,2);
$in->{'igrp'} = $igrp;
$in->{'channel'} = $ch;
if  (!$state_save{'state'} ne 'mem'){
if ($model eq ICR30) {
$in->{'state'} = 'mem';
$parmref->{'write'} = TRUE;
icom_cmd('_op_state',$parmref);
}
elsif  ($model ne R7000) {icom_cmd('_memory_state',$parmref);}
else {
}
}### Radio NOT in memory state
if ($defref->{'group'}) {### Radio supports groups
if (icom_cmd("_select_group",$parmref)) {
add_message("ICOM could not select group $igrp");
return ($parmref->{'rc'} = $ParmErr);
}
usleep(500);
}
$parmref->{'write'} = FALSE;
$in->{'caller'} = 'selmem';
if (icom_cmd('_select_chan',$parmref)) {
print "ICOM:l3350:could not select channel $in->{'channel'}\n";
add_message("ICOM could not select channel $in->{'channel'}");
return ($parmref->{'rc'} = $ParmErr);
}
$out->{'_delay'} = 3000;
if ($model eq ICR30) {
$out->{'_delay'} =  40000;
}
return ($parmref->{'rc'});
}
elsif ($cmd eq 'getvfo') {
$state_save{'cmd'} = $cmd;
if (icom_cmd('_get_freq',$parmref)) {
return $parmref->{'rc'};
}
if ($out->{'frequency'}) {
if (icom_cmd('_get_mode',$parmref)) {
return $parmref->{'rc'};
}
$parmref->{'write'} = FALSE;
if ($model eq IC703) {
icom_cmd('_vfo_atten',$parmref);
icom_cmd('_vfo_preamp',$parmref);
icom_cmd('_vfo_rptr',$parmref);
if ($out->{'tone_type'} =~ /rptr/i) {
icom_cmd('_vfo_rptr_freq',$parmref);
}
icom_cmd('_vfo_ctcss',$parmref);
if ($out->{'tone_type'} =~ /ctcss/i) {
icom_cmd('_vfo_ctcss_freq',$parmref);
}
}
elsif ($model eq ICR30) {
if ($state_save{'state'} eq 'mem') {get_r30_display($parmref);}
else {
icom_cmd('_vfo_atten',$parmref);
icom_cmd('_rf_gain',$parmref);
if (!$out->{'rfgain'}) {$out->{'preamp'} = TRUE;}
$out->{'tone_type'} = 'Off';
icom_cmd('_vfo_ctcss',$parmref);
if ($out->{'tone_type'} =~ /ctcss/i) {
icom_cmd('_vfo_ctcss_freq',$parmref);
}
else {
icom_cmd('_vfo_dtcs',$parmref);
if ($out->{'tone_type'} =~ /dcs/i) {
icom_cmd('_vfo_dsc_freq',$parmref);
}
}
}
}
elsif ($model eq IC705) {
icom_cmd('_vfo_atten',$parmref);
icom_cmd('_vfo_preamp',$parmref);
$out->{'tone_type'} = 'off';
icom_cmd('_vfo_rptr',$parmref);
if ($out->{'tone_type'} =~ /rptr/i) {
icom_cmd('_vfo_rptr_freq',$parmref);
}
else {
icom_cmd('_vfo_ctcss',$parmref);
if ($out->{'tone_type'} =~ /ctcss/i) {
icom_cmd('_vfo_ctcss_freq',$parmref);
}
else {
icom_cmd('_vfo_dtcs',$parmref);
if ($out->{'tone_type'} =~ /dcs/i) {
icom_cmd('_vfo_dsc_freq',$parmref);
}
}
}
}
elsif ($model eq R8600) {
icom_cmd('_vfo_atten',$parmref);
icom_cmd('_vfo_preamp',$parmref);
$out->{'tone_type'} = 'off';
icom_cmd('_vfo_ctcss',$parmref);
if ($out->{'tone_type'} =~ /ctcss/i) {
icom_cmd('_vfo_ctcss_freq',$parmref);
}
else {
icom_cmd('_vfo_dtcs',$parmref);
if ($out->{'tone_type'} =~ /dcs/i) {
icom_cmd('_vfo_dsc_freq',$parmref);
}
}
}
elsif ($model eq R7000) {
}
else {print "Line 3417:No additional settings for $model. rc=>$rc\n";}
}
return ($parmref->{'rc'} = $rc);
}
elsif ($cmd eq 'setvfo') {
$state_save{'cmd'} = $cmd;
if (!$in) {LogIt(1672,"ICOM_CMD:No 'in' defined for SETVFO");}
my $freq = $in->{'frequency'};
if (!looks_like_number($freq)) {$freq = 0;}
if (!$freq) {
add_message("VFO cannot have a 0 frequency");
return ($parmref->{'rc'} = $ParmErr);
}
if (!$in->{'mode'}) {
add_message("ICOM routine detected empty 'mode'. Changed to 'AUTO'");
$in->{'mode'} = 'auto';
}
if ($state_save{'state'} !~ /vfo/i) {
if ($model eq ICR30) {
$in->{'state'} = 'vfo';
$parmref->{'write'} = TRUE;
icom_cmd('_op_state',$parmref);
}
elsif ($model eq R7000) {
}
elsif ($model eq IC705) {
}
else {
icom_cmd('_vfo_state',$parmref);
}
}
$state_save{'igrp'} = $state_init{'igrp'};
if (icom_cmd('_set_freq',$parmref)) {return $parmref->{'rc'}};
if (icom_cmd('_set_mode',$parmref)) {return $parmref->{'rc'}};
my $tone_type = $in->{'tone_type'};
if (!$tone_type) {$tone_type = 'off';}
$in->{'tone_type'} = $tone_type;
my $att = $in->{'atten'};
if (!$att) {$att = 0;}
my $pamp = $in->{'preamp'};
if (!$pamp) {$pamp = 0;}
my $rfgain = $in->{'rfgain'};
if (!$rfgain) {$rfgain = 0;}
$parmref->{'write'} = TRUE;
$out->{'_delay'} = 1000;
if ($model eq ICR30) {
if ($att) {$in->{'rfgain_v'} = 25;}### value for RFG1
elsif ($pamp) {$in ->{'rfgain_v'} = 255;}
elsif ($rfgain) {
if ($rfgain > 8) {$in->{'rfgain_v'} = 229;}
elsif ($rfgain > 7) {$in->{'rfgain_v'} = 204;}
elsif ($rfgain > 6) {$in->{'rfgain_v'} = 178;}
elsif ($rfgain > 5) {$in->{'rfgain_v'} = 153;}
elsif ($rfgain > 4) {$in->{'rfgain_v'} = 127;}
elsif ($rfgain > 3) {$in->{'rfgain_v'} = 102 }
elsif ($rfgain > 2) {$in->{'rfgain_v'} = 76; }
elsif ($rfgain > 1) {$in->{'rfgain_v'} = 51; }
else {$in->{'rfgain_v'} = 25;}
}
else {$in->{'rfgain_v'} = 103;}
icom_cmd('_rf_gain',$parmref);
icom_cmd("_vfo_atten",$parmref);
icom_cmd('_vfo_ctcss',$parmref);
icom_cmd('_vfo_dtcs',$parmref);
if ($tone_type =~ /ctcss/i) {
icom_cmd('_vfo_ctcss_freq',$parmref);
}
elsif ($tone_type =~ /dcs/i) {
icom_cmd('_vfo_dsc_code',$parmref);
}
$out->{'_delay'}  = 39000;
}### R30
elsif ($model eq IC703) {
icom_cmd('_vfo_atten',$parmref);
icom_cmd('_vfo_preamp',$parmref);
icom_cmd('_vfo_rptr',$parmref);
if ($tone_type = /rptr/i) {
icom_cmd('_vfo_rptr_freq',$parmref);
}
icom_cmd('_vfo_ctcss',$parmref);
if ($tone_type =~ /ctcss/i) {
icom_cmd('_vfo_ctcss_freq',$parmref);
}
$out->{'_delay'} = 1000;
}#### IC703
elsif ($model eq IC705) {
icom_cmd('_vfo_atten',$parmref);
icom_cmd('_vfo_preamp',$parmref);
icom_cmd('_vfo_rptr',$parmref);
icom_cmd('_vfo_ctcss',$parmref);
icom_cmd('_vfo_dtcs',$parmref);
if ($tone_type =~ /ctcss/i) {
icom_cmd('_vfo_ctcss_freq',$parmref);
}
elsif ($tone_type =~ /dcs/i) {
icom_cmd('_vfo_dsc_code',$parmref);
}
$out->{'_delay'} = 3000;
}
elsif ($model eq R8600) {
icom_cmd('_vfo_atten',$parmref);
icom_cmd('_vfo_preamp',$parmref);
icom_cmd('_vfo_ctcss',$parmref);
icom_cmd('_vfo_dtcs',$parmref);
if ($tone_type =~ /ctcss/i) {
icom_cmd('_vfo_ctcss_freq',$parmref);
}
elsif ($tone_type =~ /dcs/i) {
icom_cmd('_vfo_dsc_code',$parmref);
}
$out->{'_delay'} = 1000;
}### R8600
else {
}
icom_cmd('poll',$parmref);
return $parmref->{'rc'};
my $delta = 0;
foreach my $cnt (1..1) {
icom_cmd('_get_freq',$parmref);
if ($out->{'frequency'} == $freq) {
last;
}
$delta = abs($out->{'frequency'} - $freq);
usleep(1000);
}
if ($freq != $out->{'frequency'}){
LogIt(1,"ICOM l3783:Requested $freq but got $out->{'frequency'} set instead. Delta=>$delta");
}
return ($parmref->{'rc'} = $rc);
}
elsif ($cmd eq 'getglob') {
$state_save{'cmd'} = $cmd;
if (!$db) {LogIt(1793,"ICOM_CMD:No database reference for GETGLOB");}
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'setglob') {
$state_save{'cmd'} = $cmd;
if (!$db) {LogIt(1793,"ICOM_CMD:No database reference for SETGLOB");}
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'getsrch') {
if ($model eq ICR30) {
return ($parmref->{'rc'} = $NotForModel);
}
elsif ($model eq IC703) {
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = FALSE;
my $first = 0;
my $last  = 5;
my $odd = FALSE;
my $lastfreq = 0;
my $lastserv = '';
foreach my $ch ($first..$last) {
$myout{'valid'} = FALSE;
$myout{'mode'} = 'fmn';
$myout{'frequency'} = 0;
$myout{'service'} = '';
$myin{'channel'} = $ch;
$myin{'chan_extra'} = 100;
$parmref->{'write'} = FALSE;
if (icom_cmd('_memory_direct',$parmref)) {last;};
if ($odd) {
my %rec = ('service' => "$lastserv/$myout{'service'}",
'valid' => $myout{'valid'},
'start_freq' => $myout{'frequency'},
'end_freq' => $myout{'lastfreq'},
'step' => 100,
'mode' => $myout{'mode'},
);
add_a_record($db,'search',\%rec,FALSE);
$lastfreq = 0;
$lastserv = '';
$odd = FALSE;
}
else {
$lastfreq = $myout{'frequency'};
$lastserv = $myout{'service'};
$odd = !$odd;
}
}### run through all scan edges
$parmref->{'out'} = $outsave;
return ($parmref->{'rc'} = $GoodCode);
}
else {
}
}
elsif ($cmd eq 'setsrch') {
if ($model eq ICR30) {
return ($parmref->{'rc'} = $NotForModel);
}
elsif ($model eq IC703) {
my %myin = ();
my %myout = ();
my $writesave = $parmref->{'write'};
$parmref->{'in'} = \%myin;
$parmref->{'out'} = \%myout;
$parmref->{'write'} = TRUE;
my $first = 0;
my $last  = 5;
my %chan_name = ( '0' => 'EDGE 1A',
'1' => 'EDGE 1B',
'2' => 'EDGE 2A',
'3' => 'EDGE 2B',
'4' => 'EDGE 3A',
'5' => 'EDGE 3B',
);
my $odd = FALSE;
my $lastfreq = 0;
my $lastserv = '';
my @send = ();
my $ch = $first;
foreach my $rec (@{$db->{'search'}}) {
if (!$rec->{'index'}) {next;}
my $startfreq = $rec->{'start_freq'};
my $endfreq = $rec->{'end_freq'};
my $mode = $rec->{'mode'};
if (!$startfreq or (!$endfreq)) {next;}
if (!$mode) {$mode = 'fmn';}
my %rec = ('frequency' => $startfreq,
'channel' => $ch,
'mode' => $mode,
'smode' => $mode,
'valid' => FALSE,
'tone' => 'Off',
'stone' => 'Off',
'tone_type' => 'Off',
'stone_type' => 'Off',
'sfrequency' => 0,
);
my $service = $rec->{'service'};
if (!$service) {$service = $chan_name{$ch};}
$rec{'service'} = $service;
push @send,{%rec};
$ch++;
if ($ch > $last) {last;}
$rec{'frequency'} = $endfreq;
$rec{'channel'} = $ch;
if (!$service) {$service = $chan_name{$ch};}
$rec{'service'} = $service;
push @send,{%rec};
$ch++;
}### Build list
foreach my $rec (@send) {
foreach my $key (keys %{$rec}) {$myin{$key} = $rec->{$key};}
print STDERR "\nWriting " . $Reset;
print STDERR " channel:$Bold$Green" . sprintf("%02.2u",$myin{'channel'}) .$Reset ;
print STDERR " freq:$Bold$Blue" . rc_to_freq($myin{'frequency'}) . $Reset;
print STDERR " mode:$Bold$Magenta$myin{'mode'}$Reset";
$myin{'chan_extra'} = 100;
$rc = icom_cmd('_memory_direct',$parmref);
if ($rc) {
print "\n\n Got Error $rc from ICOM_CMD\n";
last;
}
}
$parmref->{'out'} = $outsave;
return ($parmref->{'rc'} = $GoodCode);
}
else {
}
}
elsif ($cmd eq 'getsig') {
$out->{'signal'} = 0;
$out->{'sql'} = FALSE;
$out->{'rssi'} = 0;
my $udelay = 100;
$rc = $GoodCode;
my $tries = 0;
if ($model eq R7000) {
icom_cmd('poll',$parmref);
return ($parmref->{'rc'});
}### R7000 section
elsif ($model eq ICR30) {
icom_cmd('_get_tone_squelch',$parmref);
if ($out->{'sql'}) {
get_r30_display($parmref);
if (!$out->{'service'}) {$out->{'service'} = '.';}
icom_cmd('_get_signal',$parmref);
}
return ($parmref->{'rc'} = $rc);
}### ICR30
elsif ($model eq IC703) {
icom_cmd('_get_squelch',$parmref);
}### IC703
else {
icom_cmd('_get_tone_squelch',$parmref);
}
if ($out->{'sql'}) {
icom_cmd('_get_signal',$parmref);
icom_cmd('_get_freq',$parmref);
icom_cmd('_get_mode',$parmref);
$out->{'service'} = '';
}### got a signal
else {
if ($progstate eq 'manual') {
$rc = icom_cmd('_get_freq',$parmref);
if ( !$rc and ($out->{'frequency'})) {
$vfo{'frequency'} = $out->{'frequency'};
$rc = icom_cmd('_get_mode',$parmref);
$vfo{'mode'} = $out->{'mode'};
}
}### Manual state
}
$state_save{'cmd'} = $cmd;
return ($parmref->{'rc'} = $rc);
}### GETSIG process
elsif ($cmd eq 'scan') {
if ($model eq ICR30) {
$in->{'state'} = 'mem';
$parmref->{'write'} = TRUE;
if (icom_cmd('_op_state',$parmref)) {
LogIt(1,"ICOM_CMD l2881:Cannot set op_state");
add_message("ICOM ICR30 cannot set op_state");
return ($parmref->{'rc'} = $NotForModel);
}
$in->{'scan_type'} = $default_scan;
if(icom_cmd('_start_a_scan',$parmref)) {
LogIt(1,"ICOM_CMD l2887:Cannot start scan");
add_message("ICOM ICR30 cannot start scan");
return ($parmref->{'rc'} = $NotForModel);
}
}
elsif ($model eq IC703) {
if(icom_cmd('_memory_scan',$parmref)) {
LogIt(1,"ICOM_CMD l3786:Cannot start scan");
add_message("ICOM IC-703 cannot start scan");
return ($parmref->{'rc'} = $NotForModel);
}
}
elsif ($model eq IC705) {
if(icom_cmd('_select_scan',$parmref)) {
LogIt(1,"ICOM_CMD l3795:Cannot start scan");
add_message("ICOM IC-705 cannot start scan");
return ($parmref->{'rc'} = $NotForModel);
}
}
else {
LogIt(1,"ICOM l3791: Scan not supported on model $model!");
add_message("ICOM model $model does not support radio scan");
return ($parmref->{'rc'} = $NotForModel);
}
return ($parmref->{'rc'} = $GoodCode);
}
elsif ($cmd eq 'test') {
$ack = 1;
$sendhex = $in->{'test'};
if ($debug3) {LogIt(0,"TEST command will send=>$sendhex");}
}
elsif ($cmd eq 'poll') {
$sendhex = '';
}
elsif ($cmd eq '_set_freq_noack') {
$sendhex = "$sendhex" .
num2bcd($in->{"frequency"} + 0,$freqbytes,TRUE );
}
elsif ($cmd eq '_set_mode_noack')    {
my $mode = $in ->{'mode'};
my ($modecode,$sdcard) =  rcmode2icom($mode,$model);
$sendhex = "$sendhex$mode";
}
elsif ($cmd eq '_get_range')    {  }
elsif ($cmd eq '_get_freq') { }
elsif ($cmd eq '_get_mode' ) { }
elsif ($cmd eq '_set_freq')     {
if (!defined $in ->{'frequency'}) {
LogIt(1384,"ICOM_CMD: No 'frequency' in out for cmd $cmd");
}
KeyVerify($in ,'frequency');
my $freq = $in ->{'frequency'} + 0;
if (!$freq) {$freq = 0;}
$sendhex = "$sendhex" . num2bcd($freq,$freqbytes,TRUE );
$state_save{'freq'} = $freq;
}
elsif ($cmd eq '_set_mode' ) {
KeyVerify($in ,'mode');
my $mode = Strip(lc($in ->{'mode'}));
if ($mode =~ 'auto') {
if ($in->{'frequency'}) {$mode = lc(AutoMode($in->{'frequency'}));}
else {$mode = 'fmn';}
}
my ($modecode,$sdcard) =  rcmode2icom($mode,$model);
if ((defined $state_save{'mode'}) and ($mode eq $state_save{'mode'})) {
return ($parmref->{'rc'} = $GoodCode);
}
$sendhex = "$sendhex$modecode";
$state_save{'mode'} = $mode;
}
elsif ($cmd eq '_vfo_state')  {
$state_save{'state'} = 'vfo';
}
elsif ($cmd eq '_select_vfoa') {
$state_save{'state'} = 'vfo';
}
elsif ($cmd eq '_select_vfob') {
$state_save{'state'} = 'vfo';
}
elsif ($cmd eq '_equalize_vfo') {
$state_save{'state'} = 'vfo';
}
elsif ($cmd eq '_swap_vfo') {
$state_save{'state'} = 'vfo';
}
elsif ($cmd eq '_select_aband') {
$state_save{'state'} = 'vfo';
}
elsif ($cmd eq '_select_bband') {
$state_save{'state'} = 'vfo';
}
elsif ($cmd eq '_memory_state')     {
$state_save{'state'} = 'mem';
}
elsif ($cmd eq '_select_chan')     {
if (!defined $in ->{'channel'}) {
LogIt(3556,"ICOM_CMD: No 'channel' defined for cmd $cmd");
}
my $chan = $in ->{'channel'};
my $len = 2;
if ($model eq R7000) {$len = 1;}
else {$state_save{'state'} = 'mem';}
$state_save{'freq'} = '';
$state_save{'mode'} = '';
$sendhex = $sendhex . num2bcd($chan,$len,FALSE);
}
elsif ($cmd eq '_select_group')  {
my $grp = $in->{'igrp'};
if ((!defined $grp) or (!looks_like_number($grp)) ) {
my ($pkg,$fn,$caller) = caller;
print Dumper($in),"\n";
LogIt(4536,"ICOM_CMD: No 'igrp' specified for cmd $cmd. Caller=>$caller");
}
if ($grp > 99) {
LogIt(1,"ICOM_CMD l3470: IGRP number $grp is too large. Cannot set group");
return ($parmref->{'rc'} = $ParmErr);
}
if (defined $state_save{'igrp'}) {
if ($grp == $state_save{'igrp'}) {
return 0;
};
}
else {
print "ICOM l4650:", Dumper(%state_save),"\n";
}
$state_save{'igrp'} = $grp;
$sendhex = $sendhex . num2bcd($grp,2,FALSE);
}
elsif ($cmd eq '_vfo_to_mem')     { }
elsif ($cmd eq '_mem_to_vfo')     { }
elsif ($cmd eq '_clear_mem')     { }
elsif ($cmd eq '_stop_scan') {  }
elsif ($cmd eq '_memory_scan')  { }
elsif ($cmd eq '_select_scan')  { }
elsif ($cmd eq '_split_off')  { }
elsif ($cmd eq '_split_on' )  { }
elsif ($cmd eq '_vfo_step') {
if (!defined $step_code{$model}[0]) {
add_message("ICOM_CMD l3314: STEP setting is not defined for $model");
return ($parmref->{'rc'} = $NotForModel);
}
if ($parmref->{'write'}) {
my $step = $in ->{'step'};
if (!$step) {
$step = 5000;
LogIt(1,"ICOM_CMD:Step=0 detected. Changed to 5khz");
}
elsif (lc($step) eq 'auto') {$step = 5000;}
elsif (!looks_like_number($step)) {
LogIt(1,"ICOM_CMD:Step=$step is NOT valid number. Changed to 5khz");
$step = 5000;
}
my $sendhex  = $sendhex . rctostepbcd($step);
}
}
elsif ($cmd eq '_vfo_atten') {
if ($parmref->{'write'}) {
my $att = '00';
if ($in ->{'atten'}) {
$att = '20';
if ($model eq ICR30) {$att = '15';}
elsif ($model eq R8600) {$att = '10';}
}
$sendhex = "$sendhex$att";
if ((defined $state_save{'atten'}) and ($att == $state_save{'atten'})) {
return ($parmref->{'rc'} = $GoodCode);
}
$state_save{'atten'} = $att;
}
}
elsif ($cmd eq '_rf_gain') {
if ($parmref->{'write'}) {
my $parm = sprintf("%04d",$in->{'rfgain_v'});
$sendhex = "$sendhex$parm";
}
}
elsif ($cmd eq '_get_squelch')     { }
elsif ($cmd eq '_get_tone_squelch')     { }
elsif ($cmd eq '_get_signal')     { }
elsif ($cmd eq '_vfo_preamp') {
if ($parmref->{'write'}) {
my $preamp = '00';
if ($in ->{'preamp'}) {$preamp = '01';}
$sendhex = "$sendhex$preamp";
if ((defined $state_save{'preamp'}) and ($preamp eq $state_save{'preamp'})) {
return ($parmref->{'rc'} = $GoodCode);
}
$state_save{'preamp'} = $preamp;
}
}
elsif ($cmd eq '_vfo_rptr') {
if ($parmref->{'write'}) {
my $rptr = '00';
if ($in->{'tone_type'} and (lc($in->{'tone_type'}) eq 'repeater')) {$rptr = '01';}
$sendhex = "$sendhex$rptr";
if ((defined $state_save{'rptr_flag'}) and ($rptr eq $state_save{'rptr_flag'})) {
return ($parmref->{'rc'} = $GoodCode);
}
$state_save{'rptr_flag'} = $rptr;
}
}
elsif ($cmd eq '_vfo_ctcss') {
if ($parmref->{'write'}) {
my $ctcss = '00';
if ($in->{'tone_type'} and (lc($in->{'tone_type'}) eq 'ctcss')) {$ctcss = '01';}
if ((defined $state_save{'ctcss_flag'}) and ($ctcss eq $state_save{'ctcss_flag'})) {
return ($parmref->{'rc'} = $GoodCode);
}
$state_save{'ctcss_flag'} = $ctcss;
$sendhex = "$sendhex$ctcss";
}
}
elsif ($cmd eq '_vfo_dtcs') {
if ($parmref->{'write'}) {
my $dtcs = '00';
if ($in->{'tone_type'} and (lc($in->{'tone_type'}) eq 'dcs')) {$dtcs = '01';}
if ((defined $state_save{'dtc_flag'}) and ($dtcs eq $state_save{'dcs_flag'})) {
return ($parmref->{'rc'} = $GoodCode);
}
$state_save{'dcs_flag'} = $dtcs;
$sendhex = "$sendhex$dtcs";
}
}
elsif ($cmd eq '_dply_type') {
if ($parmref->{'write'}) {
my $parm = '00';
if ($in->{'dual'}) {$parm = '01';}
$sendhex = "$sendhex$parm";
}
}
elsif ($cmd eq '_nxdn_encrypt') {
if ($parmref->{'write'}) {
my $parm = '00';
if ($in->{'nxdncrypt'}) {$parm = '01';}
$sendhex = "$sendhex$parm";
}
}
elsif ($cmd eq '_nxdn_ran') {
if ($parmref->{'write'}) {
my $parm = sprintf("%02d",$in->{'nxdnran'});
$sendhex = "$sendhex$parm";
}
}
elsif ($cmd eq '_nxdn_crypt_key') {
if ($parmref->{'write'}) {
my $parm = sprintf("%06d",$in->{'enc'});
$sendhex = "$sendhex$parm";
}
}
elsif ($cmd eq '_get_id')     { }
elsif ($cmd eq '_memory_direct') {
my $channel = $in->{'channel'};
my $chfmt = sprintf("%04.4i",$channel);
my $igrp = substr($chfmt,0,2);
my $chan = substr($chfmt,2,2);
if ($in->{'chan_extra'}) {$chan = $chan + $in->{'chan_extra'};}
if ($in->{'group_extra'}) {$igrp = $igrp + $in->{'group_extra'};}
if ($defref->{'group'}) {
my $grphex = num2bcd($igrp,2,FALSE);
$sendhex="$sendhex$grphex";
}
else {
print "ICOM 6128:Channel $channel outside of radio range\n";
if ($channel > 99) {return $NotForModel;}
}
my $chanbcd = num2bcd($chan,2,FALSE);
$sendhex = "$sendhex$chanbcd";
if ($parmref->{'write'}) {
if ($in->{'frequency'}) {
my $service_len = 9;
my @bcdkeys = ('flag1',
'frequency','mode','tone_type','rsvd','tone','rsvd','tone',
'sfrequency','smode','stone_type','rsvd','stone','rsvd','stone',
'service',
);
if ($model eq IC705) {
@bcdkeys = ('flag2',
'frequency','mode',
'data',
'duplex',
'tone_type',
'dsql',
'nybl',
'rsvd',
'tone',
'rsvd',
'tone',
'polarity',
'dtcs',
'dvcode',
'offset',
'callsign',
'callsign',
'callsign',
'sfrequency','smode','data',
'duplex',
'stone_type',
'sdsql',
'nybl',
'rsvd','stone',
'rsvd','stone',
'spolarity',
'sdtcs',
'sdvcode',
'offset',
'callsign','callsign','callsign',
'service',
);
$service_len = 16;
}
elsif ($model eq R8600) {
$service_len = 16;
@bcdkeys = ('flag3',
'frequency','mode','nybl','duplex','offset',
'tsfunc','ts','pts','atten','preamp',
'antenna','ipp',
'service',
'digtone',
);
}
my $valid = 0;
if ($in->{'valid'}) {$valid = 1;}
my $main_freq = $in->{'frequency'};
my $split_freq = $in->{'sfrequency'};
if (!$split_freq) {$split_freq = 0;}
if ($main_freq =~ /\./) {$main_freq = freq_to_rc($main_freq);}
if ($split_freq =~ /\./) {$split_freq = freq_to_rc($split_freq);}
my $offset = 0;
my $duplex = 0;
my $split  = 0;
if ($split_freq and ($split_freq != $main_freq)) {
if ($in->{'ominus'}) {$duplex = 1;}
elsif ($in->{'oplus'}) {$duplex = 2;}
else {$split = TRUE;}
if ($duplex and ($model eq IC703) ) {
if ($duplex == 1) {$split_freq = $main_freq - $split_freq;}
else {$split_freq = $main_freq + $split_freq;}
$duplex = 0;
$split = 1;
}
if ($split and ($model eq R8600)) {
if ($split_freq > $main_freq) {
$duplex = 2;
$offset = $split_freq - $main_freq;
}
else {
$duplex = 1;
$offset = $main_freq - $split_freq;
}
}
}
else {
$split_freq = $main_freq;
$duplex = 0;
}
my $mode = $in->{'mode'};
if (!$mode) {$mode = 'FMn';}
if ($mode =~ /auto/i) {$mode = AutoMode($main_freq);}
my $smode = $in->{'mode'};
if (!$smode) {$smode = 'FMn'};
if ($smode =~ /auto/i) {$smode = AutoMode($split_freq);}
my $adtype = $in->{'adtype'};
if ($model eq R8600) {
if ($adtype =~ /p25/i) {$mode = 'p25';}
elsif ($adtype =~ /nxdn/i) {$mode = 'nxdn';}
elsif ($adtype =~ /vn/i) {$mode = 'nxdnvn';}
elsif ($adtype =~ /star/i) {$mode = 'dstar';}
}
elsif ($model eq IC705) {
if ($adtype =~ /star/i) {$mode = 'dstar'};
}
my $scansel = $in->{'scangrp'};
if (!$scansel) {$scansel = 0;}
if (($model eq IC705) and ($scansel > 3)) {$scansel = 3;}
my %out_hex = (
'rsvd' => '00',
'nybl' => '0',
'flag1' =>  unpack("H*",pack("B8","000000$split$valid")),
'flag2' =>  "$split$scansel",
'flag3' =>  (!$valid) .  $scansel,
'frequency' => num2bcd($main_freq,5,TRUE),
'sfrequency' => num2bcd($split_freq,5,TRUE),
'offset' => num2bcd($offset,3,TRUE),
'duplex' => $duplex,
'tone_type' => '0',
'stone_type' => '0',
'tone' => '0670',
'stone' => '0670',
'dtcs' => '0023',
'sdtcs' => '0023',
'data' => '00',
'dsql' => '0',
'sdsql' => 0,
'dvcode' => '00',
'sdvcode' => '00',
'polarity' => '00',
'spolarity' => '00',
'tsfunc' => '00',
'ts'     => '01',
'pts'    => '0010',
'atten'  => '00',
'preamp' => '00',
'antenna' => '00',
'ipp'     => '00',
'digtone' => '',
'callsign' => '2020202020202020',
);
my $sdcard = '';
($out_hex{'mode'},$sdcard) = rcmode2icom($mode,$model);
($out_hex{'smode'},$sdcard) = rcmode2icom($mode,$model);
foreach my $pass (0,1) {
my $tt_key = 'tone_type';
my $tn_key = 'tone';
my $pre = '';
if ($pass) {
$tt_key = 'stone_type';
$tn_key = 'stone';
$pre = 's';
}
my $tone = $in->{$tn_key};
my $tone_type = $in->{$tt_key};
if (!$tone_type) {$tone_type = 'off';}
if (($tone_type =~ /off/i) or (!$tone)) {
}
elsif ($tone_type =~ /rptr/i) { 
$out_hex{$tn_key} = tone2bcd($tone);
$out_hex{$tt_key} = '1';
}
elsif ($tone_type =~ /ctcss/i) { 
$out_hex{$tn_key} = tone2bcd($tone);
$out_hex{$tt_key} = '2';
if (!$pass) {
$out_hex{'digtone'} = '01' .
'00' .
$out_hex{$tn_key} .
'000023';
}
}
elsif ($tone_type =~ /dcs/i) { 
$out_hex{$pre . 'dtcs'} = num2bcd($tone,2,FALSE);
if ($in->{'polarity'}) {$out_hex{$pre . 'polarity'} = '11';}
$out_hex{$tt_key} = '3';
if (!$pass) {
my $code = $out_hex{$tn_key};
if ($in->{'polarity'}) {$code = "01$code";}
else {$code = "00$code";}
$out_hex{'digtone'} = '02' .
'00' .
'0670'            .
$code;
}
}
elsif ($tone_type =~ /dsql/i) {
my $code = num2bcd($tone,1,FALSE);
$out_hex{$pre . 'dvcode'} = $code;
$out_hex{$pre . 'dsql'} = '2';
if (!$pass) {
$out_hex{'digtone'} = '02' .
$code;
}
}
}### For tones that may also have splits
my $tone_type = $in->{'tone_type'};
my $tone = $in->{'tone'};
if ($tone_type =~ /off/i) {$tone = 0;}
if (!looks_like_number($tone)) {$tone = 0;}
if ($mode =~ /nxdn/i) {
my $enc = '00' .
'000000';
if ($in->{'enc'}) {
$enc = '01' . num2bcd($in->{'enc'},3);
}
my $sqbyte = '00';
my $ran = '00';
if ($tone and $tone_type =~ /nxdn/i) {
$ran = num2bcd($tone,1);
$sqbyte = '01';
}
$out_hex{'digtone'} = $sqbyte . $ran . $enc;
}
elsif ($tone_type =~ /p25/i) {
my $tone = sprintf("%03.3x",$in->{'tone'});
$tone = '0' . substr($tone,0,1) .
'0' . substr($tone,1,1) .
'0' . substr($tone,2,1);
$out_hex{'digtone'} = '01' . $tone;
}### P25 process
my $service = $in->{'service'};
if (!$service) {$service = '';}
$service = substr($service . (' ' x $service_len),0,$service_len);
$out_hex{'service'} = unpack("H*",$service);
foreach my $key (@bcdkeys) {
if (!defined $out_hex{$key}) {
LogIt(4899,"ICOM _MEMORY_DIRECT l4899:Missing def for key $key!");
}
$sendhex = $sendhex . $out_hex{$key};}
}### Non zero frequency
else {
$sendhex = $sendhex . 'ff';
}
}### Write setup
}### Set/Get Memory channel
elsif ($cmd eq '_band_stack')     {
LogIt(1,"ICOM_CMD:_band_stack command not yet implemented!");
return ($parmref->{'rc'} = $NotForModel);
}
elsif ($cmd eq '_op_state') {
if ($parmref->{'write'}) {
my $state = '00';
if ($in->{'state'}) {
if ($in->{'state'} eq 'vfo') {$state = '00';}
elsif ($in->{'state'} eq 'mem') {$state = '01';}
elsif ($in->{'state'} eq 'wx') {$state = '02';}
else {LogIt(3986,"ICOM:_OP_STATE command invalid state $in->{'state'} given!");}
}
$state_save{'state'} = $state;
$sendhex = "$sendhex$state";
}
}
elsif ($cmd eq '_start_a_scan') {
if (!defined $in->{'scan_type'}) {### oops
LogIt(3588,"ICOM _start_a_scan missing 'scan_type'");}
my $mwscan = '00';
my $scancode = $scancodes{$in->{'scan_type'}};
if (!defined $scancode){
LogIt(3596,"ICOM _start_a_scan invalid 'scan_type' $in->{'scan_type'}");
}
if (($scancode eq '02') or ($scancode == 03)) {
my $groupcd = '00';
if ($in->{'group'}) {
}
$scancode = "$scancode$groupcd";
}
elsif ($scancode eq '08') {
my $groupcd = '0000';
if ($in->{'group'}) {
}
$scancode = "$scancode$groupcd";
}
$sendhex = "$sendhex$mwscan$scancode";
}
elsif ($cmd eq '_cancel_scan') {
}
elsif ($cmd eq '_get_scan_condition') {
}
elsif ($cmd eq '_get_display') {
}
elsif ($cmd eq '_get_noise_smeter')     { }
elsif ($cmd eq '_vfo_rptr_freq') {
if ($parmref->{'write'}) {
my $tone = tone2bcd($in ->{'tone'});;
$sendhex = "$sendhex$tone";
}
}
elsif ($cmd eq '_vfo_ctcss_freq') {
if ($parmref->{'write'}) {
if ($debug3) {LogIt(0,"ICOM_CMD l2405:in->$in->{'tone'}");}
my $tone = tone2bcd($in->{'tone'});
if ($debug3) {LogIt(0,"ICOM_CMD l2407:hex=$tone");}
$sendhex = "$sendhex$tone";
}
}
elsif ($cmd eq '_vfo_dsc_code') {
if ($parmref->{'write'}) {
my $rev = '00';
if ($in->{'polarity'}) {$rev = '01';}
my $tone = $in->{'tone'};
if (!$tone) {$tone = 'off';}
my $tone_code = '0000';
if (looks_like_number($tone)) {
$tone_code = sprintf("%04.4i",$tone);
}
$sendhex = "$sendhex$rev$tone_code";
}
}
elsif ($cmd eq '_vfo_nac_code') {
if ($parmref->{'write'}) {
my $tone = sprintf("%03.3x",$out->{'tone'});
$tone = '0' . substr($tone,0,1) .
'0' . substr($tone,1,1) .
'0' . substr($tone,2,1);
$sendhex = "$sendhex$tone";
}
}
elsif ($cmd eq '_vfo_csql_code') {
if ($parmref->{'write'}) {
$sendhex = $sendhex . $out->{'tone'};
}
}
elsif ($cmd eq '_get_nxdn_rx_id') {
}
elsif ($cmd eq '_get_nxdn_rx_status') {
}
else {
LogIt(3465,"ICOM_CMD: No preprocess defined for command $cmd");
$parmref->{'rc'} = $NotForModel;
return $NotForModel;
}
$sendhex = $sendhex . 'FD';
my $outstr = pack("H*",$sendhex);
my $outlen = length($outstr);
my $ptobj = $parmref->{'portobj'};
RESEND:
if ($cmd ne 'poll') {
my ($cnt,$leftover) = $portobj->read();
if ($leftover and $debug3) {LogIt(0,"ICOM l3439:Leftover before send->",unpack("H*",$leftover));}
$parmref->{'sent'} = $sendhex;
if ($debug3) {LogIt(6,"ICOM_CMD l3428:sent=>$sendhex (command=$cmd) ack=$ack");}
my $countout = $ptobj->write($outstr);
if (!$countout or ($countout != $outlen)) {### send failed
if (!$countout) {$countout = 0;}
if ($debug3) {LogIt(1,"ICOM:Write failure len=$outlen countout=$countout sent=>$sendhex");}
goto UNRESPONSIVE;
}
if (!$ack) {return $parmref->{'rc'} = $GoodCode;}
}### CMD ne 'POLL'
WAITFORREPLY:
if ($debug3) {LogIt(6,"waiting for reply to $cmd ack=$ack");}
my $byte = '';
my $bstr = '';
my $gotpre = FALSE;
my @rcv_packet = ();
my $rcvhex = '';
my $waitcnt = 10;
while (TRUE) {
$ptobj->read_const_time(10);
my ($count_in, $binary) = $ptobj->read(1);
if ($count_in) {
my $byte = uc(unpack("H*",$binary));
if ($debug3) {print "$byte ";}
if ($byte eq 'FD') {### packet terminator
$rcvhex = "$rcvhex$byte";
last;
}
elsif ($byte eq 'FE') {
if (length($rcvhex) > 2) {
LogIt(0,"ICOM l3469:Got start of new packet with no end of last ($rcvhex)!");
@rcv_packet = ();
$rcvhex = '';
}
$gotpre = TRUE;
$rcvhex = "$rcvhex$byte";
}
elsif ($byte eq 'FC') {
$waitcnt = 10;
next;
}
elsif ($gotpre) {
push @rcv_packet,$byte;
$rcvhex = "$rcvhex$byte";
}
else {if ($warn) {LogIt(1,"ICOM l4412:got byte $byte before preamble");}}
$waitcnt = 10;
}
else {
if ($cmd eq 'poll') {return ($parmref->{'rc'} = $GoodCode);}
--$waitcnt;
if ($debug3) {LogIt(0,"Wait count=$waitcnt");}
if (!$waitcnt) {goto UNRESPONSIVE;}
usleep(10);
}
}
if ($debug3) {LogIt(6,"recv packet =@rcv_packet")};
if ((scalar @rcv_packet) < 3) {
LogIt(0,"ICOM l3489:Got short packet $rcvhex. waiting some more");
goto WAITFORREPLY;
}
if ($cmd eq 'test') {
if ($rcvhex eq $sendhex) {
LogIt(0,"Got echo of packet for test");
goto WAITFORREPLY;
}
else {
$out->{'test'} = $rcvhex;
return ($parmref->{'rc'} = $GoodCode);
}
}#### TEST command
my $dest = shift @rcv_packet;
my $source = shift @rcv_packet;
if ($source ne $radioaddr) {
if ($debug3) {LogIt(0,"Got packet from $source but not from $radioaddr");}
goto WAITFORREPLY;
}
$rc = 0;
$parmref->{'rc'} = $GoodCode;
my $firstbyte = shift @rcv_packet;
if ($firstbyte eq 'FA') {
if ($cmd eq '_op_state') {$state_save{'state'} = '';}
elsif ($cmd eq '_set_freq') {$state_save{'freq'} = 0;}
elsif ($cmd eq '_set_mode') {$state_save{'mode'} = '';}
elsif ($cmd eq '_vfo_atten') {
$state_save{'atten'} = -1;
if ($model eq IC705) {return ($parmref->{'rc'} = $GoodCode);}
}
elsif ($cmd eq '_vfo_preamp') {$state_save{'preamp'} = -1;}
elsif ($cmd eq '_vfo_rptr') {$state_save{'rptr_flag'} = -1;}
elsif ($cmd eq '_vfo_ctcss') {$state_save{'ctcss_flag'} = -1;}
elsif ($cmd eq '_select_chan') {print Dumper($in),"\n";}
LogIt(1,"ICOM l5945 rejected packet=>$sendhex returned=$rcvhex command issued=>$cmd");
return ($parmref->{'rc'} = $NotForModel);
}
elsif ($firstbyte eq 'FF') {
if ($debug3) {LogIt(1,"ICOM_CMD l2007:no data returned..");}
return ($parmref->{'rc'} = $EmptyChan);
}
elsif ($firstbyte eq 'FB') {
if ($debug3) {LogIt(0,"ICOM_CMD l2013:ICOM accepted command. No data returned");}
return ($parmref->{'rc'} = $GoodCode);
}
my $cmdlength = int(length($cmdcode)/2);
if (!$cmdlength) {
LogIt(3223,"ICOM_CMD:Got NO byte length for command code $cmdcode");
}
my $retcmd = $firstbyte;
my @save_packet = @rcv_packet;
foreach (2..$cmdlength) {$retcmd = $retcmd . shift @rcv_packet;}
if ($debug3) {LogIt(0," return command code=$retcmd");}
if (($cmd eq 'poll') or ($retcmd ne $cmdcode)) {
if ($debug3) {LogIt(0,"ICOM l3778:Unsolicited message cmdcode=$firstbyte packet=>@save_packet (packet=>$rcvhex)");}
my $queue = $parmref->{'unsolicited'};
my %qe = ('icom_msg' =>$rcvhex,'frequency' => ' ', 'mode' => ' ' );
if ($firstbyte eq '00') {
$qe{'frequency'} =  bcd2num(\@save_packet,TRUE,'4471');
}
elsif ($firstbyte eq '01') {
($qe{'mode'},$qe{'filter'},$qe{'adtype'}) = bcd2mode(\@save_packet,$model) ;
}
else {
LogIt(1,"ICOM_CMD l3770:Unsolicited command $firstbyte ($rcvhex).");
}
if ($queue) {push @{$queue},{%qe};}
else {
print STDERR "Got unsolicited message:freq=>$qe{'frequency'} mode=>$qe{'mode'}\n";
}
if ($cmd eq 'poll') {return ($parmref->{'rc'} = $GoodCode);}
goto WAITFORREPLY;
}
my $retcmdstr = $cmd_lookup{$retcmd};
if (!$retcmdstr) {
print Dumper(%cmd_lookup),"\n";
LogIt(2241,"No lookup for return command code=>$retcmd!");
}
if ($debug3) {LogIt(0,"return command=>$retcmdstr");}
if ($ack < 1) {
LogIt(1,"ICOM_CMD:Got unexpected response for $cmd$Eol Received:$Bold$rcvhex");
return ($parmref->{'rc'} = $OtherErr);
}
elsif ($retcmdstr eq '_get_range') {
my @low = ();
my @high = ();
foreach my $count (1..$freqbytes){
if (scalar @rcv_packet) {push @low,shift @rcv_packet;}
}
my $sep = shift @rcv_packet;
foreach my $count (1..$freqbytes){
if (scalar @rcv_packet) {push @high,shift @rcv_packet;}
}
my $low = bcd2num(\@low,$freqbytes);
my $high = bcd2num(\@high,$freqbytes);
if ($debug2) {LogIt(0,"ICOM_CMD l1905:Returned high=$high low=$low");}
if ($high < $low) {
my $temp = $high;
$high = $low;
$low = $temp;
}
$out->{'maxfreq'} = $high;
$out->{'minfreq'} = $low;
}
elsif ($retcmdstr eq '_get_freq')  {
my $freq = 0;
if ($rcv_packet[0] ne 'FF') {
$freq = bcd2num(\@rcv_packet,TRUE,'1999');
}
$out->{"frequency"} = $freq;
$state_save{'frequency'} = $freq;
if ($debug2)   {LogIt(0,"ICOM_CMD l2014:Returned frequency=$freq");}
if ($out->{"frequency"}) {$out->{'valid'} = TRUE;}
else {$out->{'valid'} = FALSE;}
}
elsif ($retcmdstr eq '_get_mode')   {
my $mode = '';
my $filter = 0;
my $adtype = 'analog';
if ($rcv_packet[0] ne 'FF') {($mode,$filter,$adtype) =  bcd2mode(\@rcv_packet,$model);}
$state_save{'mode'} = $mode;
if ($debug2)   {LogIt(0,"ICOM_CMD l2136:Returned mode=$mode packet=@save_packet");}
$out->{'mode'} = $mode;
$out->{'adtype'} = $adtype ;
$out->{'filter'} = $filter;
}
elsif ($retcmdstr eq '_vfo_step') {
my $scode = shift @rcv_packet;
my $step = $step_code{$model}[$scode];
if (!$step) {### could not get a code
LogIt(1,"ICOM_CMD:Could not find a step for code=$scode");
$step = 5000;
}
$out->{'step'} = $step;
}
elsif ($retcmdstr eq '_vfo_atten') {
my $atten = shift @rcv_packet;
if ($atten eq '00') {$out->{'atten'} = FALSE;}
else {$out->{'atten'} = TRUE;}
$state_save{'atten'} = $atten;
}
elsif ($cmd eq '_rf_gain') {
my $rfgain = bcd2num(\@rcv_packet,0,5869);
if (!$rfgain) {$rfgain = 0;}
$out->{'rfgain_v'} = $rfgain;
my $rfg = 1;
if    ($rfgain > 230) {$rfg = 0;}
elsif ($rfgain > 204) {$rfg = 9;}
elsif ($rfgain > 178) {$rfg = 8;}
elsif ($rfgain > 153) {$rfg = 7;}
elsif ($rfgain > 127) {$rfg = 6;}
elsif ($rfgain > 102) {$rfg = 5;}
elsif ($rfgain >  76) {$rfg = 4;}
elsif ($rfgain >  52) {$rfg = 3;}
elsif ($rfgain >  25) {$rfg = 2;}
$out->{'rfgain'} = $rfg;
}
elsif ($retcmdstr eq  '_get_squelch')   {
my $sql = shift @rcv_packet;
if ($sql eq '01') {$out->{'sql'} = TRUE;}
else {$out->{'sql'} = FALSE;}
}
elsif ($retcmdstr eq  '_get_tone_squelch')   {
my $sql = shift @rcv_packet;
if ($sql eq '01') {$out->{'sql'} = TRUE;}
else {$out->{'sql'} = FALSE;}
}
elsif ($retcmdstr eq  '_get_signal')   {
my $sql = FALSE;
if ($out->{'sql'} ) {$sql = TRUE;}
my $sig = '';
foreach my $ndx (0..1) {
my $byte = $rcv_packet[$ndx];
if (!defined $byte) {
LogIt(1,"_get_signal did not return a value");
print Dumper(@rcv_packet),"\n";
return ($parmref->{'rc'} =  $OtherErr);
}
$sig = "$sig$byte";
}
if (!looks_like_number($sig)) {### gotta problem
LogIt(1,"_Get_Signal returned a non-numeric value $sig");
return ($parmref->{'rc'} = $OtherErr);
}
$sig = $sig + 0;
my $signal = 0;
my $meter = 0;
$out->{'rssi'} = $sig;
$out->{'signal'} = $signal;
$out->{'meter'} = $meter;
if ($sig) {### gotta be at LEAST one level
my @rssi_table = @{$rssi2sig{$model}};
if (!scalar @rssi_table) {### no definition for this radio
if ($sql) {
$out->{'signal'} = 9;
$out->{'meter'} = 60;
}
}### no definition for radio
else {
foreach my $cmp (@rssi_table) {
if (!$cmp) {next;}
if (($sig < $cmp) or ($signal >= MAXSIGNAL)){
last;
}
$signal++;
}
if ($sig and (!$signal)) {$signal = 1;}
$out->{'signal'} = $signal;
my @meter_table = @{$sig2meter{$model}};
my $meter_ndx = 0;
if (!scalar @meter_table) {$meter_ndx = 9;}
else {
foreach my $cmp (@meter_table) {
if (!$cmp) {next;}
if ($sig < $cmp) {last;}
$meter_ndx++;
}
}
$out->{'meter'} = $sigmeter[$meter_ndx];
}### Table is available
}### $sig has a value
}### _get_signal
elsif ($retcmdstr eq '_vfo_preamp') {
my $preamp = shift @rcv_packet;
if ($preamp eq '01') {$out->{'preamp'} = TRUE;}
else {$out->{'preamp'} = FALSE;}
$state_save{'preamp'} = $preamp;
}
elsif ($retcmdstr eq '_vfo_rptr') {
my $rptr = shift @rcv_packet;
if ($rptr eq '01') {
$out->{'tone_type'} = 'rptr';
}
$state_save{'rptr_flag'} = $rptr;
}
elsif ($retcmdstr eq '_vfo_ctcss') {
my $ctcss = shift @rcv_packet;
if (looks_like_number($ctcss)) {$ctcss = $ctcss + 0;}
else {$ctcss = 0;}
if ($ctcss > 0) {$out->{'tone_type'} = 'CTCSS';}
$state_save{'ctcss_flag'} = $ctcss;
}
elsif ($retcmdstr eq '_vfo_dtcs') {
my $dtcs = shift @rcv_packet;
if (looks_like_number($dtcs)) {$dtcs = $dtcs + 0;}
else {$dtcs = 0;}
if ($dtcs > 0) {$out->{'tone_type'} = 'CTCSS';}
$state_save{'dtcs_flag'} = $dtcs;
}
elsif ($retcmdstr eq '_dply_type') {
$out->{'dual'} = shift @rcv_packet;
}
elsif ($retcmdstr eq '_nxdn_encrypt') {
$out->{'nxdncrypt'} = shift @rcv_packet;
}
elsif ($retcmdstr eq '_nxdn_ran') {
$out->{'tone'} = shift @rcv_packet;
}
elsif ($retcmdstr eq '_nxdn_crypt_key') {
$out->{'enc'} = '';
while (scalar @rcv_packet) {
$out->{'enc'} = $out->{'enc'} . shift @rcv_packet;
}
}
elsif ($retcmdstr eq '_get_nxdn_rx_id') {
$out->{'nxdnrxid'} = '';
while (scalar @rcv_packet) {
$out->{'nxdnrxid'} = $out->{'nxdnrxid'} . shift @rcv_packet;
}
}
elsif ($retcmdstr eq '_get_nxdn_rx_status') {
$out->{'nxdnrxstatus'} = '';
while (scalar @rcv_packet) {
$out->{'nxdnrxstatus'} = $out->{'nxdnrxstatus'} . shift @rcv_packet;
}
}
elsif ($retcmdstr eq  '_get_id')   {
my $addr = shift @rcv_packet;
if ($addr) {
$model =  $default_addr{$addr};
if (!$model) {$model = R7000;}
$out->{'model'} = $model;
$out->{'addr'} = $addr;
if ($debug2) {LogIt(0,"set model number to $model");}
}
else {return $NotForModel;}
}
elsif ($retcmdstr eq '_memory_direct') {
if ($parmref->{'write'}) {
LogIt(0,"ICOM l 4759:Direct write returned:$rcvhex");
}
else {
my $igrp = 0;
my $group_extra = 0;
my $chan_extra = 0;
if ($defref->{'group'}) {
my @grp = (shift @rcv_packet, shift @rcv_packet);
$igrp = bcd2num(\@grp,FALSE,'1886');
if ($igrp > 99) {
$group_extra = int($igrp/100);
$igrp = $igrp - $group_extra;
}
}
my @memchan = (shift @rcv_packet, shift @rcv_packet);
my $ch = bcd2num(\@memchan,FALSE,'1886');
if ($ch > 99) {
$chan_extra = int($ch/100);
$ch = $ch - $chan_extra;
}
my $channel = $ch + ($igrp * 100);
if ($channel != ($in->{'channel'})) {
my $emsg = "ICOM got info for ch $channel but requested $in->{'channel'}!";
LogIt(1,$emsg);
return ($parmref->{'rc'} = $OtherErr);
}
my $flag = shift @rcv_packet;
$out->{'service'} = '';
$out->{'frequency'} = 0;
$out->{'sfrequency'} = 0;
$out->{'mode'}  = 'FMn';
$out->{'smode'} = 'FMn';
$out->{'filter'} = 0;
$out->{'tone'} = 0;
$out->{'stone'} = 0;
$out->{'polarity'} = 0;
$out->{'spolarity'} = 0;
$out->{'tone_type'} = 'off';
$out->{'stone_type'} = 'off';
$out->{'valid'} = FALSE;
$out->{'ominux'} = FALSE;
$out->{'oplus'} = FALSE;
$out->{'atten'} = FALSE;
$out->{'scangrp'} = 0;
$out->{'adtype'} = 'analog';
$out->{'channel'} = $channel;
$out->{'group_extra'} = $group_extra;
$out->{'chan_extra'} = $chan_extra;
$out->{'enc'} = 0;
if ($flag eq 'FF') {
if ($debug3) {LogIt(1,"channel $ch is empty");}
return $EmptyChan;
}
my $flag_bits = unpack('B*',pack("H*",$flag));
if ($model eq IC703) {
if ( ($flag eq '01') or ($flag eq '03') ) {$out->{'valid'} = TRUE;}
else {$out->{'valid'} = FALSE;}
my @freqbcd = ();
foreach my $ndx (1..5) {push @freqbcd,shift @rcv_packet;}
my @modebcd = (shift @rcv_packet,  shift @rcv_packet);
my $tonemode = shift @rcv_packet;
shift @rcv_packet;
my @rptrbcd = (shift @rcv_packet, shift @rcv_packet);
shift @rcv_packet;
my @ctscbcd = (shift @rcv_packet, shift @rcv_packet);
my @spfreqbcd = ();
foreach my $ndx (1..5) {push @spfreqbcd,shift @rcv_packet;}
my @spmodebcd = (shift @rcv_packet, shift @rcv_packet);
my $sptonemode = shift @rcv_packet;
shift @rcv_packet;
my @sprptrbcd = (shift @rcv_packet, shift @rcv_packet);
shift @rcv_packet;
my @spctscbcd = (shift @rcv_packet, shift @rcv_packet);
my $service = '';
foreach my $ndx (1..9) {$service = $service . chr(hex(shift @rcv_packet));}
if ($debug3) {
LogIt(0,"freqbcd=@freqbcd mode=@modebcd rptrbcd=@rptrbcd  ctsc=@ctscbcd");
LogIt(0,"spfreqbcd=@spfreqbcd spmode=@spmodebcd sprptrbcd=@sprptrbcd  spctsc=@spctscbcd");
LogIt(0,"flag=$flag tonemode=$tonemode sptonemode=$sptonemode");
}
$out->{'service'} = $service;
$out->{'frequency'} = bcd2num(\@freqbcd,TRUE,'2489');
$out->{'mode'} = '';
if (scalar @modebcd) {($out->{'mode'},$out->{'filter'},$out->{'adtype'})  = bcd2mode(\@modebcd,$model);}
my ($ctcss,$junk1) = packet_decode(\@ctscbcd,'tone');
my ($rptr,$junk2) = packet_decode(\@rptrbcd,'tone');
my @tonemode = split '',unpack("B8",pack("H*",$tonemode));
if (pop @tonemode) {
$out->{'tone'} = $ctcss;
$out->{'tone_type'} = 'CTCSS';
}
elsif (pop @tonemode) {
$out->{'tone'} = $rptr;
$out->{'tone_type'} = 'rptr';
}
if (($flag eq '02') or ($flag eq '03')) {
$out->{'sfrequency'} =  bcd2num(\@spfreqbcd,TRUE,'2515');
($out->{'smode'},$out->{'sfilter'},$out->{'adtype'}) = bcd2mode(\@spmodebcd,$model);
my ($ctcss,$junk1) = packet_decode(\@spctscbcd,'tone');
my ($rptr,$junk2) = packet_decode(\@sprptrbcd,'tone');
my @tonemode = split '',unpack("B8",pack("H*",$sptonemode));
if (pop @tonemode) {
$out->{'stone'} = $ctcss;
$out->{'stone_type'} = 'CTCSS';
}
elsif (pop @tonemode) {
$out->{'stone'} = $rptr;
$out->{'stone_type'} = 'rptr';
}
else {
$out->{'stone'} = 'off';
$out->{'stone_type'} = 'Off';
}
}
}### IC-703
elsif ($model eq IC705) {
my $split = FALSE;
my $valid = FALSE;
my $scangrp = 0;
if (substr($flag,0,1)) {$split = TRUE;}
$scangrp = substr($flag,1,1);
if (!$scangrp) {$scangrp = 0;}
if ($scangrp) {$valid = TRUE;}
$out->{'valid'} = $valid;
$out->{'scangrp'} = $scangrp;
my $offset = FALSE;
$out->{'oplus'} = FALSE;
$out->{'ominus'} = FALSE;
$out->{'sfrequency'} = 0;
foreach my $pass (0,1) {
my $pre = '';
if ($pass) {$pre = 's';}
my ($freq,$dummy)  = packet_decode(\@rcv_packet,'frequency',5);
my ($mode,$filter,$adtype) =  packet_decode(\@rcv_packet,'mode',2);
my $datamode = shift @rcv_packet;
my $byte =  shift @rcv_packet;
my ($offcode,$tonecode) = $byte =~ /(.)(.)/;
$out->{$pre . 'offcode'} = $offcode;
my $digsql = shift @rcv_packet;
$digsql = $digsql + 0;
shift @rcv_packet;
my $rptrtone = 0;
($rptrtone,$dummy) = packet_decode(\@rcv_packet,'tone',2);
shift @rcv_packet;
my $ctcstone = 0;
($ctcstone,$dummy) = packet_decode(\@rcv_packet,'tone',2);
my $polarity = shift @rcv_packet;
my $dcscode = 0;
($dcscode,$dummy) = (shift @rcv_packet) . (shift @rcv_packet);
my $dvcode = shift @rcv_packet;
my $duplex = 0;
($duplex,$dummy) =  packet_decode(\@rcv_packet,'frequency',3);
$out->{$pre . 'duplex'} = $duplex;
my %call = ();
foreach my $key ('ur','r1','r2') {
my $cs = '';
foreach (0..7) {
if (scalar @rcv_packet) {$cs = $cs . shift @rcv_packet;}
}
$call{$key} = $cs;
}
if (!$pre) {$out->{'adtype'} = $adtype;}
if ($adtype =~ /star/i) {
if ($digsql) {
$out->{$pre . 'tone_type'} = 'dsql';
$out->{$pre . 'tone'} = $dvcode;
}
}
elsif ($mode =~ /fm/i) {
if ($tonecode == 1) {
$out->{$pre . 'tone_type'} = 'rptr';
$out->{$pre . 'tone'} = $rptrtone;
}
elsif ($tonecode == 2) {
$out->{$pre . 'tone_type'} = 'ctcss';
$out->{$pre . 'tone'} = $ctcstone;
}
elsif ($tonecode == 3) {
$out->{$pre . 'tone_type'} = 'dcs';
$out->{$pre . 'tone'} = $dcscode;
if ($polarity) {$out->{$pre . 'polarity'} = TRUE;}
}
}
$out->{$pre . 'mode'} = $mode;
$out->{$pre . 'frequency'} = $freq;
}## Normal/Split process
my $dummy = '';
($out->{'service'},$dummy) = packet_decode(\@rcv_packet,'ascii',16);
if ($split) {
}
else {
my $offcode = $out->{'offcode'};
if ($offcode == 1) {
$out->{'ominus'} = TRUE;
$out->{'sfrequency'} = $out->{'duplex'};
}
elsif ($offcode == 2) {
$out->{'oplus'} = TRUE;
$out->{'sfrequency'} = $out->{'duplex'};
}
else {$out->{'sfrequency'} = 0;}
}
}### IC-705
elsif ($model eq R8600) {
if (!(substr($flag,0,1))) { $out->{'valid'} = TRUE;}
my $scangrp = substr($flag,1,1);
if (!$scangrp) {$scangrp = 0;}
$out->{'scangrp'} = $scangrp;
my ($freq,$dummy)  = packet_decode(\@rcv_packet,'frequency',5);
my ($mode,$filter,$adtype) =  packet_decode(\@rcv_packet,'mode',2);
my $duplex = shift @rcv_packet;
my ($offset,$dummy2)  = packet_decode(\@rcv_packet,'frequency',4);
my $tsfunction = shift @rcv_packet;
my $ts = shift @rcv_packet;
my $prg_ts = (shift @rcv_packet) . (shift @rcv_packet);
my $atten = shift @rcv_packet;
my $preamp = shift @rcv_packet;
my $antenna = shift @rcv_packet;
my $ipp = shift @rcv_packet;
($out->{'service'},$dummy) = packet_decode(\@rcv_packet,'ascii',16);
my $tone_type = 'off';
my $tone = 0;
my $enc = 0;
my $polarity = FALSE;
if ($adtype =~ /star/i)  {
my $dsql = shift @rcv_packet;
if ($dsql) {
$tone = shift @rcv_packet;
$tone_type = 'dsql';
}
}
elsif ($adtype =~ /nxdn/i) {
my $dsql = shift @rcv_packet;
my $ran = shift @rcv_packet;
if ($dsql) {
$tone = $ran;
$tone_type = 'ran';
}
my $enc = shift @rcv_packet;
if ($enc) {
$out->$enc = packet_decode(\@rcv_packet,'number',3);
}
}
elsif ($adtype =~ /p25/i) {
my $dsql = shift @rcv_packet;
if ($dsql) {
$tone_type = 'nac';
$tone = packet_decode(\@rcv_packet,'nac',3);
}
}
elsif ($adtype =~ /pmr/i) {
$adtype = 'analog';
}
elsif ($mode =~ /dcr/i) {
$adtype = 'analog';
}
else {
if ($mode =~ /fm/i) {
my $ts = shift @rcv_packet;
shift @rcv_packet;
my $ctcss = packet_decode(\@rcv_packet,'tone',2);
$polarity = shift @rcv_packet;
my $dcs =  packet_decode(\@rcv_packet,'number',2);
if ($ts == 1) {
$tone_type = 'ctcss';
$tone = $ctcss;
$polarity = FALSE;
}
elsif ($ts == 2) {
$tone_type = 'dcs';
$tone = $dcs;
}
}### Tone extraction for FM modulation
}
$out->{'frequency'} = $freq;
$out->{'mode'} = $mode;
$out->{'filter'} = $filter;
$out->{'offset'} = $offset;
$out->{'adtype'} = $adtype;
$out->{'tone'} = $tone;
$out->{'tone_type'} = $tone_type;
$out->{'polarity'} = $polarity;
if ($atten) {$out->{'atten'} = TRUE;}
if ($duplex == 1) {
$out->{'ominus'} = TRUE;
$out->{'sfrequency'} = $offset;
}
elsif ($duplex == 2) {
$out->{'oplus'} = TRUE;
$out->{'sfrequency'} = $offset;
}
}### R8600 decode
else {
LogIt(1,"Need decode for model $model");
}
}
}
elsif ($retcmdstr eq '_op_state') {
my $state = shift @rcv_packet;
if (!$state) {$state = 0;}
if ($state == 0) {$out->{'state'} = 'vfo';}
elsif ($state == 1) {$out->{'state'} = 'mem';}
elsif ($state == 2) {$out->{'state'} = 'wx';}
else {
LogIt(1,"ICOM_CMD l5884:_OP_STATE returned unknown state=$state");
$out->{'state'} = '?';
}
$state_save{'state'} = $out->{'state'};
}
elsif ($cmd eq '_get_scan_condition') {
my $state = shift @rcv_packet;
if (!$state) {$state = 0;}
if ($state == 0) {$out->{'scan'} = 'off';}
elsif ($state == 1) {$out->{'scan'} = 'up';}
elsif ($state == 2) {$out->{'scan'} = 'down';}
elsif ($state == 3) {$out->{'scan'} = 'up';}
elsif ($state == 4) {$out->{'scan'} = 'down';}
else {
LogIt(1,"ICOM_CMD l5308:_SCAN_CONDITION returned unknown condition=$state");
$out->{'scan'} = '?';
}
$state_save{'scan'} = $out->{'scan'};
}
elsif ($retcmdstr eq '_get_display') {
my $status = $rcv_packet[0];
my $state = $rcv_packet[1];
if ($state == 0) {$out->{'state'} = 'vfo';}
elsif ($state == 1) {$out->{'state'} = 'mem';}
elsif ($state == 2) {$out->{'state'} = 'wx';}
else {
LogIt(1,"ICOM l5878:Unknown state $state returned for _GET_DISPLAY");
$out->{'state'} = '';
}
$state_save{'state'} = $out->{'state'};
my @freqbcd = ();
foreach my $ndx (2..6) {push @freqbcd,$rcv_packet[$ndx];}
if (lc($freqbcd[0]) eq 'ff') {$out->{'frequency'} = 0;}
else {$out->{'frequency'} = bcd2num(\@freqbcd,TRUE,'4732');}
my @modebcd = ($rcv_packet[8], $rcv_packet[9]);
my $mode = 'FMn';
my $adtype = 'analog';
if (lc($modebcd[0]) eq 'ff') {$mode = 'FMn';}
else {($mode,$out->{'filter'},$adtype)  = bcd2mode(\@modebcd,$model);}
my $bad_audio = '';
if (($adtype =~ /pmr/i) or ($adtype =~ /dcr/i)) {
$bad_audio = $adtype;
$adtype = 'analog';
}
$out->{'mode'} = $mode;
$out->{'adtype'} = $adtype;
$out->{'bad_audio'} = '';
$out->{'enc'} = 0;
my %rfgain_lookup = (
'0012' => 1, '0038' => 2, '0064' => 3, '0089' => 4, '0115' => 5,
'0140' => 6, '0166' => 7, '0192' => 8,  '0217' => 9, '0243' => 10);
my $rfgain =  $rcv_packet[10] . $rcv_packet[11];
if ($rfgain_lookup{$rfgain}) {$out->{'rfgain'} = $rfgain_lookup{$rfgain}; }
else {
LogIt(1,"ICOM l6411: Unable to decode RFGAIN code $rfgain. Value set to 10");
$out->{'rfgain'} = 10;
}
if ($rcv_packet[12] + 0) {$out->{'att'} = TRUE;}
else {$out->{'att'} = FALSE;}
$out->{'duplex'} = $rcv_packet[13];
$out->{'wx'}     = $rcv_packet[14];
$out->{'mute'}   = $rcv_packet[15];
$out->{'afc'}    = $rcv_packet[16];
$out->{'skip'}   = $rcv_packet[17];
my $igrp = $rcv_packet[18] . $rcv_packet[19];
if (!$igrp) {$igrp = 0;}
my $ch  = $rcv_packet[20] . $rcv_packet[21];
if (!$ch) {$ch = 0;}
$out->{'channel'} = (($igrp * 100) + $ch) + 0;
my $service = '';
foreach my $ndx (22..37) {
my $char = $rcv_packet[$ndx];
if ($char)  {$service = $service . chr(hex($char));}
}
if ($state_save{'state'} eq 'mem'){$out->{'service'} = $service;}
$out->{'vsc'} = $rcv_packet[38];
my $tb1 = $rcv_packet[39];
if (!$tb1 or (!looks_like_number($tb1))) {$tb1 = 0;}
my $tb2 = $rcv_packet[40];
if (!$tb2 or (!looks_like_number($tb2))) {$tb2 = 0;}
$tb1 = $tb1  + 0;
$tb2 = $tb2  + 0;
$out->{'tone_type'} = 'off';
$out->{'tone'} = 'off';
if ($mode =~ /fm/i) {
if ($adtype =~ /analog/i) {
if ($tb1) {
$out->{'tone_type'} = 'ctcss';
icom_cmd('_vfo_ctcss_freq',$parmref);
}
elsif ($tb2) {### DCS squelch
$out->{'tone_type'} = 'dsc';
icom_cmd('_vfo_dsc_code',$parmref);
}
}### Analog tone types
elsif ($adtype =~ /nxdn/i) {
if ($tb1) {
$out->{'tone_type'} = 'ran';
icom_cmd('_nxdn_ran',$parmref);
}
if ($tb2) {
icom_cmd('_nxdn_crypt_key',$parmref);
}
}
elsif ($adtype =~ /star/i) {### DSTAR format
if ($tb1) {
$out->{'tone_type'} = 'dsql';
icom_cmd('_vfo_csql_code',$parmref);
}
}
elsif ($adtype =~ /p25/i) {### P25 format
if ($tb1)  {## P25 NAC squelch
$out->{'tone_type'} = 'nac';
icom_cmd('_vfo_nac_code',$parmref);
}
}
}
if ($bad_audio) {
$out->{'bad_audio'} = $bad_audio;
}
}### _get_display post process
elsif ($retcmdstr eq '_get_noise_smeter') {
my $sq =  $rcv_packet[0] + 0;
$out->{'sql'} = $sq;
my $sig = '';
foreach my $ndx (1..2) {
my $byte = $rcv_packet[$ndx];
if (!defined $byte) {
LogIt(1,"_get_noise_smeter did not return a value");
return ($parmref->{'rc'} =  $OtherErr);
}
$sig = "$sig$byte";
}
if (!looks_like_number($sig)) {### gotta problem
LogIt(1,"_get_noise_smeter returned a non-numeric value $sig");
return ($parmref->{'rc'} = $OtherErr);
}
$sig = $sig + 0;
$out->{'rssi'} = $sig;
my $signal = 0;
if ($sq) {
if ($sig > 221) {$signal = 9;}
elsif ($sig > 169) {$signal = 8;}
elsif ($sig > 135) {$signal = 7;}
elsif ($sig > 101) {$signal = 6;}
elsif ($sig >  84) {$signal = 5;}
elsif ($sig > 67) {$signal = 4;}
elsif ($sig > 50) {$signal = 3;}
elsif ($sig > 33) {$signal = 2;}
else {$signal = 1;}
}
$out->{'signal'} = $signal;
}### _get_noise_meter
elsif ($retcmdstr eq '_vfo_rptr_freq') {
shift @rcv_packet;
my $tone = packet_decode(\@rcv_packet,'tone');
if (!looks_like_number($tone)) {$tone = 0;}
$out->{'tone'} = $tone;
}
elsif ($retcmdstr eq '_vfo_ctcss_freq') {
shift @rcv_packet;
my $tone = packet_decode(\@rcv_packet,'tone');
if (!looks_like_number($tone)) {$tone = 0;}
$out->{'tone'} = $tone;
}
elsif ($retcmdstr eq '_vfo_dsc_code') {
my $polarity = shift @rcv_packet;
if ($polarity) {$out->{'polarity'} = TRUE;}
else {$out->{'polarity'} = FALSE;}
my $tone = '';
foreach (0..2) {
if (scalar @rcv_packet) {$tone = $tone . shift @rcv_packet;}
}
if (!$tone) {$tone = 0;}
$out->{'tone'} = $tone;
}
elsif ($retcmdstr eq '_vfo_nac_code') {
$out->{'tone'} = packet_decode(\@rcv_packet,'nac',3);
}
elsif ($retcmdstr eq '_vfo_csql_code') {
my $tone = 0;
if (scalar @rcv_packet) {$tone = shift @rcv_packet;}
$tone = $tone + 0;
$out->{'tone'} = $tone;
}
else {
LogIt(4341,"No post process for retcmdstr=$retcmdstr cmd=$cmd. Need handler!");
add_message("ICOM got response to $cmd ($cmdcode) retcmdstr=$retcmdstr. Need handler!");
}
$parmref->{'rsp'} = FALSE;
return ($parmref->{'rc'} = $rc);
UNRESPONSIVE:
if ($cmd eq 'test') {
LogIt(1,"No response from the radio for command $sendhex");
$out->{'test'} = '';
}
else {
if (!$parmref->{'rsp'}) {
my $msg = "Radio is not responding";
if ($warn) {
if ($sendhex) {LogIt(1,"ICOM l5611:Radio did not repond to $sendhex");}
else {LogIt(1,$msg);}
add_message($msg);
}
}
}
$parmref->{'rsp'} = TRUE;
return ($parmref->{'rc'} = $CommErr);
}
sub get_r30_display {
my $parmref = shift @_;
my $out = $parmref->{'out'};
my $timeout = 1000;
while ($timeout) {
usleep(300);
$timeout--;
if (icom_cmd('_get_display',$parmref)) {
LogIt(1,"ICOM _get_display command failed");
return ($parmref->{'rc'});
}
if (lc($out->{'bad_audio'}) !~ /dcr/i) {
$timeout = 0;}
}
if (lc($out->{'bad_audio'}) =~ /dcr/) {LogIt(1,"DCR modulation found after 1000 times!");}
return ($parmref->{'rc'});
}
sub tone2bcd {
my $tone = shift @_;
my $newtone = '0670';
if ($tone and  (looks_like_number($tone))){
my $int = int($tone);
my ($dec) = $tone =~ /\d*?\.(\d)/;
if (!$dec) {$dec = 0;}
if ($int < 67) {
LogIt(1,"Conversion error for tone $tone!");
}
else {
$newtone = sprintf("%04.4u","$int$dec");
}
}
return $newtone;
}
sub num2bcd {
my ($num,$bytes,$rev) = @_;
my $digits = $bytes*2;
my $i;
my $out = '';
if (!$num) {$num = '0';}
$num = sprintf("%${digits}.${digits}ld",$num);
if ($rev) {
$i = $digits-2;
while ($i >= 0) {
$out =  $out .  substr($num,$i,2);
$i = $i - 2;
}
}
else {
$i = 0;
while ($i < $digits) {
$out = $out . substr($num,$i,2);
$i = $i + 2;
}
}
return $out;
}
sub clear_bus {
my $portobj = shift @_;
my ($count_in, $data_in) = $portobj->read(1);
while ($count_in) {
($count_in, $data_in) = $portobj->read(1);
usleep(30);
}
}
sub rctostepbcd {
my $step = shift @_;
my $bcd = 0;
if (!defined $step_code{$model}[0]) {
LogIt(1,"ICOM_rctostepbcd:Unsupported model $model for STEP");
return '00';
}
my $code_count = $#{$step_code{$model}};
foreach my $dcd (@{$step_code{$model}}) {
if ($step <= $dcd) {last;}
if ($bcd < $code_count) {$bcd ++};
}
return sprintf("%02.2u",$bcd);
}
sub bcd2mode {
my $array  = shift @_;
my $imodel = shift @_;
if (!$imodel) {$imodel = '';}
my $adtype = 'analog';
my $mode = 'fmn';
my $bw = 0;
my $byte1 = $array->[0];
my $byte2 = $array->[1];
if (!defined $byte2) {$byte2 = '';}
$mode = $icom_decode{$byte1};
if (!defined $mode) {
LogIt(7864,"No Modulation decode for byte value $byte1");
}
if (($model eq R7000) and ($byte1 eq '05')) {
if ($byte2 eq '') {$mode = 'fmw';}
elsif ($byte1 eq '00') {$mode = 'lsb';}
else {$mode = 'fmn';}
}
else {
if ($byte2 ne '') {
$bw = $byte2;
if ($mode =~ /am/i) {
if ($bw eq '01') {$mode = 'amw';}
elsif (($bw eq '02') and ($model eq ICR30)) {$mode = 'amn';}
elsif ($bw eq '03') {$mode = 'amn';}
}
elsif ($mode =~ /fm/i) {
if ($byte1 eq '05') {
if ($bw eq  '01') {$mode = 'fmm';}
elsif ($bw eq '03') {$mode = 'fmun';}
else {$mode = 'fmn';}
}
}
}
}
if ($array->[0] > 15) {
$adtype = $mode;
$mode = 'fmn';
}
return ($mode,$bw,$adtype);
}
sub bcd2num {
my ($ref, $rev,$caller) = @_;
my $num = "";
my $temp;
my $start = 0;
my $len = @{$ref};
while ($len) {
my $value = $ref->[$start];
if (!defined $value) {
print Dumper($ref),"\n";
LogIt(2499,"BCD2num bad array value for index $start caller=>$caller");
}
$temp  = $ref->[$start];
if ($temp eq 'FF') {return 0;}
$start++;
$len--;
if ($rev) {$num =   $temp . $num;}
else {$num = $num . $temp ;}
}
return $num;
}
sub packet_decode {
my $ref = shift @_;
if (!$ref) {LogIt(6718,"Programmer forgot 'ref' for packet_decode");}
my $type = shift @_;
if (!$type) {LogIt(6722,"Programmer forgot 'type' for packet_decode");}
my $count = shift @_;
if (!$count) {$count = scalar (@{$ref});}
$type = lc($type);
my $tmodel = shift @_;
if (!$tmodel) {$tmodel = '';}
my $result = '';
my $filter = 0;
my @data = ();
my $data_str = '';
if (!scalar @{$ref}) {
$result = -1;
$filter = -1;
}
foreach (1..$count) {
if (!scalar @{$ref}) {last;}
my $byte = shift @{$ref};
push @data,$byte;
$data_str = "$data_str$byte";
}
if (scalar @data) {
if ($type eq 'bits') {
return unpack('B*',pack("H*",$data_str));
}
elsif ($type eq 'number') {
return  hex($data_str);
}
elsif ($type eq 'frequency') {
foreach my $byte (@data) {
if (lc($byte)  eq 'ff') {
$result = 0;
last;
}
$result = "$byte$result";
}
return $result;
}
elsif ($type eq 'tone')   {
$result = substr($data_str,0,-1) . '.' . substr($data_str,-1,1);
return  sprintf("%3.1f",$result) ;
}
elsif ($type eq 'mode') {
my ($mode,$bw,$adtype) = bcd2mode(\@data,$tmodel);
return $mode,$bw,$adtype;
}
elsif ($type eq 'ascii') {
return  pack('H*',$data_str);
}
elsif ($type eq 'nac') {
my $hex = '';
foreach (0..2) {
if (scalar @data) {
my $byte = shift @data;
$hex = $hex . substr($byte,1,1);
}
}
if (!$hex) {$hex = 0;}
return  hex($hex);
}
else {
LogIt(6734,"ICOM-PACKET_PROC: No process for $type");
}
}### got some data to process
return $result;
}
sub dply_packet {
my @data = @_;
my $hexstr = '';
foreach my $char (@data) {
$hexstr = $hexstr . sprintf("%02.2X",$char) . ' ';
}
return $hexstr;
}
sub numerically {$a<=>$b;}
sub rcmode2icom {
my ($pkg,$fn,$caller) = caller;
my $rcmode = shift @_;
if (!$rcmode) {LogIt(6606,"RCMODE2ICOM: Missing modulation! " .
"caller=>$pkg:$caller");}
my $imodel = shift @_;
if (!$imodel) {
$imodel = R7000;
LogIt(1,"RCMODE2ICOM:Caller $pkg:$caller did not include model. Changed to $imodel!");
}
my $freq = shift @_;
if (!$freq) {$freq = 0;}
my $modestr = 'FM-N';
my $sdfilter = '';
my $modecode = '05';
my $filter = '02';
if ($rcmode =~ /am/i) {
$modecode = '02';
$modestr = 'AM';
if ($imodel eq R7000) {$filter = '';}
elsif ($rcmode =~ /amw/i) {
$filter = '01';
$sdfilter = 1;
}
elsif ($rcmode =~ /amn/i) {
if ($imodel eq ICR30) {
$filter = '02';
$modestr = 'AM-N';
}
else {$filter = '03';}
$sdfilter = 3;
}
else {
if ($imodel eq ICR30) {$filter = '01';}
else {$filter = '02';}
$sdfilter = 2;
}
}### AM modulation
elsif ($rcmode =~ /lsb/i) { 
$modecode = '00';
$filter = '01';
$modestr = 'LSB';
if ($imodel eq R7000) {
$filter = '00';
$modecode = '05';
}
}
elsif ($rcmode =~ /usb/i) {### upper sideband
$modecode = '01';
$filter = '01';
$modestr = 'USB';
if ($imodel eq R7000) {
$filter = '00';
$modecode = '05';
}
}
elsif ($rcmode =~ /cw/i) {### CW
$modecode = '03';
$filter = '01';
$modestr = 'CW';
if ($rcmode =~ /r/i) {### CW-R
$modecode = '07';
$modestr = 'CW-R';
}
if ($imodel eq R7000) {
$filter = '00';
$modecode = '05';
}
}
elsif ($rcmode =~ /rtty/i) {### RTTY
if ($imodel eq R7000) {
$filter = '00';
$modecode = '05';
}
elsif ($imodel eq ICR30) {
$modecode = '03';
$filter = '01';
$modestr = 'CW';
}
elsif (($imodel eq IC705) or ($imodel eq IC703)) {
$modecode = '04';
$filter = '01';
$modestr = 'RTTY';
if ($rcmode =~ /\-r/i) { 
$modecode = '08';
$modestr = 'RTTY-R';
}
}
elsif ($imodel eq R8600) {
$modecode = '04';
$filter = '01';
$modestr = 'FSK';
if ($rcmode =~ /\-r/i) { 
$modecode = '08';
$modestr = 'FSK-R';
}
}
else {
}
}### RTTY process
elsif ($rcmode =~ /fm/i) {
$modecode = '05';
$sdfilter = 1;
$modestr = 'FM';
if ($rcmode =~ /fmw/i) {
$filter = '01';
$modecode = '06';
$modestr = 'WFM';
if (($imodel eq R7000) or ($imodel eq IC703)) {
$modecode = '05';
}
}
elsif ($rcmode =~ /fmm/i) {
$filter = '01';
if ($imodel eq R7000) {$filter = '02';}
}
else {
$filter = '03';
if ($imodel eq R7000) {$filter = '02';}
elsif ($imodel eq ICR30) {
$filter = '02';
$modestr = 'FM-N';
}
elsif ($imodel eq R8600) {
$modestr = 'FM-N';
}
}### FMn or FMun
}### FM modulations
elsif ($rcmode =~ /p25/i) {
if (($imodel eq ICR30) or ($imodel eq R8600)) {
$modecode = '16';
$filter = '01';
$modestr = 'P25';
}
}
elsif ($rcmode =~ /dstar/i) {
if (($imodel eq ICR30) or ($imodel eq R8600) or ($imodel eq IC705)) {
$modecode = '17';
$filter = '01';
$modestr = 'D-STAR';
}
}
elsif ($rcmode =~ /nxdnvn/i) {
if (($imodel eq ICR30) or ($imodel eq R8600)) {
$modecode = '19';
$filter = '01';
$modestr = 'NXDN-VN';
}
}
elsif ($rcmode =~ /nxdn/i) {
if (($imodel eq ICR30) or ($imodel eq R8600)) {
$modecode = '20';
$filter = '01';
$modestr = 'NXDN-N';
}
}
elsif ($rcmode =~ /dmr/i) {
}
else {
print "ICOM l8619:No decode for RadioCtl modulation:$rcmode\n";
}
return "$modecode$filter",$modestr,$sdfilter;
}
sub icom2rcmode {
my $bytes = shift @_;
if (!defined $bytes) {LogIt(6864,"RCMODE2ICOM: No BYTE data passed!");}
my $imodel = shift @_;
if (!$imodel) {$imodel = '';}
my $rcmode = 'FMn';
my $filter = 0;
if (length($bytes) < 2) {
LogIt(1,"RCMODE2ICOM l6870:BYTES=>$bytes is too small. " .
"default mode set to $rcmode");
}
else {
my $byte1 = substr($bytes,0,2);
my $byte2 = '';
if (length($bytes) > 3) {$byte2 = substr($bytes,2,2);}
if ($icom_decode{$byte1}) {$rcmode = $icom_decode{$byte1};}
else {LogIt(1,"RCMODE2ICOM l6880:Missing byte1 decode for $byte1");}
if ($byte2) {$filter = $byte2 + 0;}
if ($byte1 eq '05') {
if ($model eq R7000) {
if ($byte2 eq '02') {$rcmode = 'FMn';}
elsif ($byte2 eq '00') {$rcmode = 'LSB';}
else {$rcmode = 'FMw';}
}
elsif ($model eq IC703) {$rcmode = 'FMn';}
elsif ($model eq ICR30) {
if ($byte2 eq '02') {$rcmode = 'FMun';}
}
}
elsif ($byte1 eq '02') {
$rcmode = 'AM';
if ($byte2 eq '01') {$rcmode = 'AMw';}
elsif ($byte2 eq '03') {$rcmode = 'AMn';}
}
}### Bytes found
return $rcmode,$filter;
}
