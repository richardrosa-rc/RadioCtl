#!/usr/bin/perl -w
my $author = 'Lydia & Richard';
my $office_prog = 'libreoffice --view';
use constant TRUE  => 1;
use constant FALSE => 0;
use strict;
use autovivification;
no  autovivification;
use Device::SerialPort qw ( :PARAM :STAT 0.07 );
use Text::ParseWords;
use Text::CSV;
use File::Basename;
use Scalar::Util qw(looks_like_number);
use threads;
use threads::shared;
use Thread::Queue;
use Config;
$Config{useithreads} or die "Perl Thread Support missing!";
use Gtk3 '-init';
use constant PANGO_SCALE => 1024;
use constant PANGO_WEIGHT_BOLD => 700;
use constant PANGO_WEIGHT_LIGHT => 300;
use Data::Dumper;
use Time::HiRes qw( usleep ualarm gettimeofday tv_interval );
my $os = $^O;
my $linux;
my $homedir;
use FindBin qw($Bin);
use lib "$Bin";
my $callpath = "$Bin/";
print STDERR "callpath = $callpath\n";
use scanner;
use radioctl;
print "$Bold RadioCtl GUI$Red Rev=$White$Rev$Eol";
if (substr($os,0,3) eq 'MSW') {
$os = 'WINDOWS';
$homedir = $ENV{"USERPROFILE"};
$linux = FALSE;
print STDERR "$Bold$Red WARNING! $White This program MAY not work correctly on Windows$Eol";
}
else {
$os = 'LINUX';
$homedir = $ENV{"HOME"};
$linux = TRUE;
my $progname = $0;
}
use constant MINCHAN         => 20;
use constant MAXMESSAGE      => 10;
use constant MESSAGELENGTH   => 200;
use constant FILEFORMAT      => 3;
use constant BUTTON_TIMER    => 3;
use constant MAXTIMER        => 6;
our $deffile = "$homedir/radioctl.conf";
if (!-e $deffile) {
$deffile = "$callpath/radioctl.conf";
if (-e $deffile) {
LogIt(1,"No custom radioctl.conf found in $Green$homedir$White.\n" .
"  Set configuration file to $Yellow$deffile");
}
else {
LogIt(1,"No$Yellow radioctl.conf$White file was located!\n" .
"Some functions may not work!");
$deffile = '';
}
}
our $inifile = "$homedir/radioctl.vars";
@dblist = ('system','group','freq','search','lookup');
our @sub_windows = ('ops','vfo','status','select','signal','global');
our %col_active = ();
our %drop_lookup = ();
our $debug  = FALSE;
our %menu_hash = ();
our $lastdir = "";
our @ports = ();
our $pop_up = FALSE;
our $radiosel = '';
our %col_xref = ();
our %db_view_menus = ();
our %iters = ();
our %was_focus = ();
$initmessage = "Welcome To RadioCtl Rev $Rev";
our @msgno = ('msg1','msg2','msg3','msg4');
our @timer         = (
0,
0,
0,
0,
0,
0,
);
our @progstates = (
{'state' => 'manual',         'dply' => 'Manual'},
{'state' => 'frequency_scan', 'dply' => 'Scan by Database Frequency' },
{'state' => 'channel_scan',   'dply' => "Scan by Radio's Channel"},
{'state' => 'radio_scan',     'dply' => 'Radio Scan'},
{'state' => 'search',         'dply' => 'Frequency Search'},
{'state' => 'bank_search',    'dply' => 'Frequency Bank Search'},
{'state' => 'load',           'dply' => 'Load From Radio'},
{'state' => 'init',        'dply' => ''},
{'state' => 'quit',        'dply' => ''},
);
if ($deffile) {
LogIt(0,"RadioCtl l413:reading configuration file $deffile");
spec_read($deffile);
}
my %w_info = (
'main'      => {'xsize' => 700,'ysize'=> 300,'xpos'=> 550, 'ypos' =>  80, 'active'=> 1,'init' => 0},
'freq'      => {'xsize' => 900,'ysize'=> 320,'xpos'=>  90, 'ypos' => 270, 'active'=> 1,'init' => 0},
'group'     => {'xsize' => 500,'ysize'=> 320,'xpos'=>  40, 'ypos' => 150, 'active'=> 1,'init' => 0},
'search'    => {'xsize' => 750,'ysize'=> 270,'xpos'=>   1, 'ypos' =>  20, 'active'=> 1,'init' => 0},
'message'   => {'xsize' => 320,'ysize'=> 320,'xpos'=> 900, 'ypos' => 620, 'active'=> 1,'init' => 0},
'parms'     => {'xsize' => 320,'ysize'=> 320,'xpos'=> 200, 'ypos' => 600, 'active'=> 1,'init' => 0},
'system'    => {'xsize' => 300,'ysize'=> 310,'xpos'=> 220, 'ypos' => 620, 'active'=> 1,'init' => 0},
);
read_ini();
foreach my $key (keys %struct_fields) {
if (!defined $clear{$key}) {$clear{$key} = $struct_fields{$key}[3];}
}
$clear{'lookup'} = 0;
%vfo = %clear;
my %colors = ('channel'    => 'blanchedalmond',
'groupno'    => 'aliceblue',
'count'      => 'beige',
'duration'   => 'gainsboro',
'signal'     => 'tomato',
'frequency'  => 'lightgreen',
'start_freq' => 'lightgreen',
'end_freq'   => 'moccasin',
'step'       => 'orange',
'timestamp'  => 'khaki',
'mode'       => 'yellow',
'service'    => 'lightsteelblue',
'tgid'       => 'lightsalmon',
'ctcss'      =>  'lightcyan',
'dcs'        => 'moccasin',
'att_amp'    =>  'orange',
'sysno'      => 'palegreen',
'systemname' => 'sandybrown',
'groupname'  => 'skyblue',
'dlyrsm'     => 'thistle',
);
my $font = 'face="DejaVu Sans Mono"';
my $fg = 'foreground="blue" ';
my $bg = 'background="black" ';
my $weight = 'weight="heavy"';
my $size = 'size="33300"';
my $style = 'style="normal"';
my $dark = FALSE;
my @str = `cat ~/.config/gtk-3.0/settings.ini`;
foreach my $rec (@str) {
if ($rec =~ /prefer/i) {
if ($rec =~ /theme\=true/){$dark = TRUE;}
last;
}
}
if ($dark) {LogIt(0,"DARK theme detected");}
my $lastfilesave = '';
my %guidb = ('freq' => 0,'system' => 0, 'group' => 0, 'search' => 0,'lookup' => 0,);
my @signal_values  =  ( 0,1, 3, 5, 7, 9, 15, 20, 40, 60);
my $radioctl_icon;
my $radioctl_logo;
if (-e "$callpath/radioctl.ico") {
$radioctl_logo = Gtk3::Image->new_from_file("$callpath/radioctl.ico");
$radioctl_icon = Gtk3::Gdk::Pixbuf->new_from_file("$callpath/radioctl.ico");
}
my @file_menu = (
{'name' => 'open',    'title' => '_Open Frequency File (add records)',     'icon' => 'document-open'},
{'name' => 'opennew', 'title' => 'Open _Frequency File (replace records)', 'icon' => 'open_for_editing'},
{'name' => 'save',    'title' => '_Save Frequency File',                   'icon' => 'document-save-as'},
{'name' => 'read',    'title' => '_Read Radio Definition File',            'icon' => 'document-open-remote'},
{'name' => 'write',   'title' => '_Write Message Log',                     'icon' => 'mail-message-new-list'},
{'name' => 'quit',    'title' => '_Quit',                                  'icon' => 'gtk-quit'},
);
my @help_menu = (
{'name' => 'help',    'title'  => '_Contents', 'icon' => 'help-contents'},
{'name' => 'about',   'title'  => '_About', 'icon' => 'help-about'},
);
my @edit_menu = (
{'name' => 'create', 'title' => '_Add a new record',            'icon' => 'gtk-add'},
{'name' => '_line',},
{'name' => 'delete', 'title' => '_Delete the selected records', 'icon' => 'edit-delete'},
{'name' => 'clear_db',  'title' => 'Remove ALL records in this database',    'icon' => 'project-development-close'},
{'name' => '_line',},
{'name' => 'swap',   'title' => 'S_wap records',                'icon' => 'system-switch-user'},
{'name' => 'edit',   'title' => 'E_dit/Change multiple records','icon' => 'edit-copy'},
{'name' => 'sortf',  'title' => '_Sort by frequency',           'icon' => 'view-sort-ascending', 'dbn' => 'freq'},
{'name' => 'sortc',  'title' => 'Sort by Channel _Number',      'icon' => 'sort_incr', 'dbn' => 'freq'},
{'name' => 'renum',  'title' => 'Renumber Channel Number',      'icon' => 'view-sort-ascending', 'dbn' => 'freq'},
{'name' => 'xfer',   'title' => 'Transfer Selected to lookup', 'icon' => 'go-next-view-page', 'dbn' => 'freq'},
);
my %menu_item = ();
my %panels = (
'main' => {'title' => "RadioCtl v$Rev by $author", 'type' => 'w'},
'vfo'  => {'title' => "VFO",     'type' => 'p', 'parent' => 'main'},
'freq' => {'title' => "Frequencies and channels", 'type' => 'd'},
'radio' => {'title' => "Radio",   'type' => 'p', 'parent' =>'main'},
'group' => {'title' => "Groups", 'type' => 'd'},
'search' => {'title' => "Search Banks", 'type' => 'd'},
'lookup' => {'title' => "Lookup Frequencies", 'type' => 'd'},
'system' => {'title' => "Systems", 'type' => 'd'},
'messages' => {'title' => "messages", 'type' => 'p'},
'ops' => {'title' => "Operations", 'type' => 'p', 'parent' => 'main' },
'vchan' => {'title' => "Index", 'type' => 'p','parent' => 'main' },
'vstep' => {'title' => "Step", 'type' => 'p','parent' => 'main' },
'vfreq' => {'title' => "Frequency", 'type' => 'p','parent' => 'main' },
'vmode' => {'title' => "Modulation", 'type' => 'p','parent' => 'main' },
'vext' => {'title' => "Extra Controls", 'type' => 'p','parent' => 'main' },
'rchan' => {'title' => "Channel",       'type' => 'p','parent' => 'main' },
'status' => {'title' => "Status", 'type' => 'p','parent' => 'main'},
'op_left' => {'title' => "Operation Options", 'type' => 'p','parent' => 'main'},
'op_right' => {'title' => "Operation Options", 'type' => 'p','parent' => 'main'},
'speed' => {'title' => "Speed Limit (Channels/Second)", 'type' => 'p','parent' => 'main'},
'select' => {'title' => "Radio Selection",'type' => 'p','parent' => 'main'},
'signal' => {'title' => "Signal Meter", 'type' => 'p','parent' => 'main'},
);
my %digit_names = (
'vchan' => {'title' => "Index",        'type' => 'p','parent' => 'main', 'len' => (length(MAXINDEX))},
'rchan' => {'title' => "Channel",      'type' => 'p','parent' => 'main', 'len' => (length(MAXCHAN))},
'vstep' => {'title' => "Step",         'type' => 'p','parent' => 'main', 'len' => $fdigits},
'vfreq' => {'title' => "Frequency",    'type' => 'p','parent' => 'main', 'len' => $fdigits},
);
foreach my $key ((keys %panels),(keys %digit_names)) {
if ($digit_names{$key}{'title'}) {$digit_names{$key}{'enable'} = TRUE;}
if ($panels{$key}{'type'} eq 'p') {
$panels{$key}{'gtk'} = Gtk3::Frame->new($panels{$key}{'title'});
my $child = $panels{$key}{'gtk'}->get_child();
}
else {
$panels{$key}{'gtk'} = Gtk3::Window->new;
$panels{$key}{'gtk'}->set_icon($radioctl_icon);
$panels{$key}{'gtk'}->set_decorated(TRUE);
$panels{$key}{'gtk'}->set_resizable(TRUE);
$panels{$key}{'gtk'}->set_title($panels{$key}{'title'});
}
}
our @model = ("Glib::Int");
our %drop_list = (
'mode'     => {'strings' => [@modestring]},
'ctcss'    => {'strings' => [@tonestring]},
'dcs'      => {'strings' => [@dcsstring]},
'att_amp'  => {'strings' => ['off','att','amp']},
);
our %liststore;
our %treeview;
our %treecol;
DROPDOWNINIT:
foreach my $key (keys %drop_list) {
my @text = ();
if ($key eq 'hld') {
foreach my $ndx (0..255) {push @text,$ndx;}
}
elsif ($key eq 'tag') {
foreach my $ndx (0..999,'-') {push @text,$ndx;}
}
elsif ($key eq 'p25waiting') {
foreach my $ndx (0..10) { push @text,($ndx * 100);}
}
elsif ($key eq 'qkey') {
foreach my $syskey (0..99,'-') {push @text,$syskey;}
}
elsif ($key eq 'systemtype') {
my $ndx = 0;
$text[0] = "Conventional";
}
else {@text = @{$drop_list{$key}{'strings'}};}
my $ndx = (push @model,"Gtk3::ListStore") - 1;
$drop_list{$key}{'model'} = $ndx;
my $liststore = Gtk3::ListStore->new ("Glib::String");
$drop_list{$key}{'liststore'} = $liststore;
foreach my $str (@text) {
my $iter = $liststore->append;
$liststore->set($iter,0,$str);
}
}
our $treendx = -1;
our %dply_def = ();
foreach my $dbndx (keys %panels) {
if ($panels{$dbndx}{'type'} ne 'd') {next;}
foreach my $key (@{$structure{$dbndx}}) {
if ($key eq '_guiend') {
$dply_def{$key}{'title'} = ' ';
my $modeltype = 'Glib::String';
$dply_def{$key}{'modeltype'} = $modeltype;
my $modndx = (push @model,$modeltype) - 1;
$dply_def{$key}{'dbcol'} = $modndx;
$dply_def{$key}{'dplycol'} = $modndx;
$dply_def{$key}{'affect'}{$dbndx} = TRUE;
$dply_def{$key}{'readonly'} = TRUE;
$dply_def{$key}{'type'}  = 'text';
$col_xref{$key} = $modndx;
last;
}
if (!$struct_fields{$key}) {LogIt(1372,"Pass1:Key $key not defined in STRUCT_FIELDS!");}
if (defined $dply_def{$key}{'dbcol'}) {next;}
$dply_def{$key}{'title'} = $key;
my $modeltype = undef;
my $dplyndx = undef;
my $type = $struct_fields{$key}[0];
my $flags = $struct_fields{$key}[2];
if (($dbndx eq 'freq') and ($key eq 'sysno')) {
LogIt(1005,"RADOICTL.PL: SYSNO was defined for a FREQ record");
$flags = $flags . 'r';
LogIt(0,"RadioCtl.pl l1002: $dbndx key=$key flags=$flags");
}
if ($flags =~ /x/i) {
my $xdb = '';
if ($key eq 'groupno') {$xdb = 'group';}
elsif ($key eq 'sysno') {$xdb = 'system';}
else {LogIt(1398,"PASS-1:Unknown XREF field $key");}
$dply_def{$key}{'xref'} = $xdb;
push @{$xrefs{$xdb}},($dbndx,$key);
}
if ($flags =~ /r/i) {  
$dply_def{$key}{'readonly'} = TRUE;
}
if (($type eq 'c') or ($type eq 'g') or ($type eq 'o') ){
$modeltype = 'Glib::String';
my $ndx = $drop_list{$key}{'model'};
if (defined $ndx) {
$dplyndx = $ndx;
$dply_def{$key}{'signal'} = \&comboproc;
$dply_def{$key}{'type'}   = 'combo';
$dply_def{$key}{'list'}   = $key;
}
else {
$dply_def{$key}{'signal'} = \&db_text_proc;
$dply_def{$key}{'type'}  = 'text';
}
}
elsif ($type eq 'b') {
$dply_def{$key}{'type'} = 'toggle';
$modeltype = 'Glib::Boolean';
$dply_def{$key}{'signal'} = \&toggleproc;
}
elsif ($type eq 'f') {
$dply_def{$key}{'type'} = 'freq';
$modeltype = 'Glib::UInt';
$dply_def{$key}{'signal'} = \&db_num_proc;
$dplyndx = (push @model,"Glib::String") - 1;
}
elsif ($type eq 'i') {
if (($key eq 'channel') or ($key eq 'index')) {
$dply_def{$key}{'type'}  = 'index';
$dply_def{$key}{'render'} = \&chan_render;
}
else {
$dply_def{$key}{'type'}  = 'number';
$dply_def{$key}{'render'} = \&number_render;
}
$modeltype = 'Glib::String';
if ($key eq 'index') {$modeltype = 'Glib::Int';}
$dply_def{$key}{'signal'} = \&db_num_proc;
}
elsif ($type eq 'n') {
$dply_def{$key}{'type'}  = 'number';
$modeltype = 'Glib::String';
$dply_def{$key}{'render'} = \&number_render;
}
elsif($type eq 't') {
$dply_def{$key}{'type'}  = 'time';
$modeltype = 'Glib::String';
$dplyndx = (push @model,"Glib::String") - 1;
}
elsif ($type eq 's') {
my $sourcedb = '';
if ($key eq 'systemname') {$sourcedb = 'system';}
elsif ($key eq 'groupname') {$sourcedb = 'group';}
elsif ($key eq 'sitename') {$sourcedb = 'site';}
else {LogIt(1381,"PASS-1:Unknown shadowed field $key");}
$dply_def{$key}{'shadow'} = $sourcedb ;
$dply_def{$key}{'readonly'} = TRUE;
$dply_def{$key}{'type'}  = 'shadow';
$modeltype = 'Glib::String';
}
else {LogIt(1458,"PASS-1:Donno how to deal with key=>$key of type $type for database=>$dbndx");}
my $modndx = (push @model,$modeltype) - 1;
if (!defined $dplyndx) {$dplyndx = $modndx;}
$dply_def{$key}{'modeltype'} = $modeltype;
$dply_def{$key}{'dbcol'} = $modndx;
$dply_def{$key}{'dplycol'} = $dplyndx;
$dply_def{$key}{'affect'}{$dbndx} = TRUE;
if ($dply_def{$key}{'readonly'}) {$dply_def{$key}{'signal'} = undef;}
$col_xref{$key} = $modndx;
}
}### for every database
my %rowsel = ();
foreach my $dbndx (keys %panels) {
if ($panels{$dbndx}{'type'} ne 'd') {next;}
$liststore{$dbndx} = Gtk3::ListStore->new (@model);
$treeview{$dbndx} = Gtk3::TreeView->new ($liststore{$dbndx});
$treeview{$dbndx}->signal_connect(button_press_event => sub {
my ($self,$widget,$dbndx) = @_;
if ($response_pending) {return 0;}
my $type    = $widget->type;
my $button  = $widget->button;
if ($button == 1) { }
elsif ($button == 2) { }
elsif ($button == 3) {
$menu_item{$dbndx}{'_Edit'}->popup_at_pointer();
}
else {LogIt(1,"RADIOCTL l1997:No process for button $button");}
return FALSE;
},$dbndx);
$treeview{$dbndx}->set_activate_on_single_click(TRUE);
$treeview{$dbndx}->get_selection()->set_mode('multiple');
$rowsel{$dbndx} = FALSE;
$treeview{$dbndx}->signal_connect('cursor_changed' => sub {
my $treeview = shift @_;
my $dbndx = shift @_;
$rowsel{$dbndx} = TRUE;
return FALSE;
},$dbndx);
}
LogIt(0,"Processing Pass 2");
PASS2:
foreach my $dbndx (keys %panels) {
if ($panels{$dbndx}{'type'} ne 'd') {next;}
foreach my $key (@{$structure{$dbndx}}) {
my $coldb  = $dply_def{$key}{'dbcol'};
my $dplycol  = $dply_def{$key}{'dplycol'};
my $type  = $dply_def{$key}{'type'};
if (!$type) {LogIt(957,"PASS2:Missing type for key=>$key");}
if (!$dplycol) {LogIt(1688,"PASS2:Missing dplycol for key=$key");}
if (!$coldb) {LogIt(1685,"PASS2:Missing coldb for key=$key");}
my $title  = $dply_def{$key}{'title'};
if ($key eq 'index') {
if ($dbndx eq 'system') {$title = 'System-Num';}
elsif ($dbndx eq 'group') {$title = 'Group-Num';}
elsif ($dbndx eq 'site') {$title = 'Site-Num';}
}
$title =~ s/\_/\-/g;
$title = ucfirst($title);
if ($title =~ /att/i) {$title = 'Att-Amp';}
elsif ($title =~ /ctcss/i) {$title = 'CTCSS';}
elsif ($title =~ /dcs/i) {$title = 'DCS';}
elsif ($title =~ /dlyrsm/i) {$title = 'Dly-Rsm';}
elsif ($title =~ /tgid/i) {$title = 'TGID';}
my $renderer = $dply_def{$key}{'render'};
my $signal_call = $dply_def{$key}{'signal'};
my $right_j = FALSE;
if (($type eq 'number') or ($type eq 'freq')) {$right_j = TRUE;}
my $hide = FALSE;
my $sortfunction = undef;
my %dbinfo = ('coldb' => $coldb,
'dbndx' => $dbndx,
'key'   => $key,
'dplycol' => $dplycol,
'type'   => $type,
);
my $cellrender;
my @colattributes = ($title);
if ($type eq 'toggle') {
$cellrender = Gtk3::CellRendererToggle->new;
if ($signal_call) {
$cellrender->signal_connect (toggled => $signal_call, \%dbinfo);
$cellrender->set(activatable => TRUE);
}
else {$cellrender->set(activatable => FALSE);}
push @colattributes,$cellrender,'active' => $dplycol;
}
elsif ($type eq 'combo') {
$cellrender = Gtk3::CellRendererCombo->new;
if ($signal_call) {
$cellrender->set(editable => TRUE);
$cellrender->signal_connect (edited => $signal_call, \%dbinfo);
}
else {$cellrender->set(editable => FALSE);}
$cellrender->set(
text_column => 0,
has_entry => FALSE
);
push @colattributes,$cellrender,'text' => $coldb,'model' => $dplycol;
}
else {
$cellrender = Gtk3::CellRendererText->new;
if ($signal_call) {
$cellrender->set(editable => TRUE);
$cellrender->signal_connect (edited => $signal_call, \%dbinfo);
}
else {
$cellrender->set(editable => FALSE);
}
push @colattributes,$cellrender,'text' => $dplycol;
}
if ($right_j) {$cellrender->set(xalign => 1.0);}
else {$cellrender->set(xalign =>0);}
$treecol{$dbndx}{$coldb} = Gtk3::TreeViewColumn->new_with_attributes(@colattributes,);
if ($right_j) {$treecol{$dbndx}{$coldb}->set_alignment(1.0);}
if ($renderer) {$treecol{$dbndx}{$coldb}->set_cell_data_func($cellrender,$renderer,\%dbinfo);}
else {
if ($colors{$key}) {
if ($dark) {$cellrender->set_property('foreground',$colors{$key});}
else {$cellrender->set_property('background',$colors{$key});}
}
}
$treecol{$dbndx}{$coldb}->set_sort_indicator(TRUE);
$treecol{$dbndx}{$coldb}->set_sort_column_id($coldb);
if ($sortfunction) {
}
$treecol{$dbndx}{$coldb}->set_visible(FALSE);
if (!$hide) {
if (!defined $col_active{$dbndx}{$coldb}) {
$col_active{$dbndx}{$coldb} = TRUE;
}
$treecol{$dbndx}{$coldb}->set_resizable(TRUE);
if (!defined $treeview{$dbndx}) {
LogIt(2487,"Oops forgot to define treeview for $dbndx ($title)!");
}
$treeview{$dbndx}->append_column($treecol{$dbndx}{$coldb});
if (!defined $db_view_menus{$dbndx}) {
$db_view_menus{$dbndx} =  Gtk3::Menu->new();
}
if (substr($key,0,1) ne '_') {
my $item = make_view_menu_item($title,
$dbndx,
$treecol{$dbndx}{$coldb},
\$col_active{$dbndx}{$coldb},
'treecol',
$coldb,
);
$db_view_menus{$dbndx} -> append($item);
}
else {$treecol{$dbndx}{$coldb}->set_visible(TRUE);}
}
else {$treecol{$dbndx}{$coldb}->set_visible(FALSE);  }
if ($key eq '_guiend') {
$treecol{$dbndx}{$coldb}->set_visible(TRUE);
last;
}
}### For each key
}### each database
LogIt(0,"Pass 2 complete");
our $thread_ptr ;
$thread_ptr = threads->new(\&manual_state);
$thread_ptr->detach();
my $init_done = FALSE;
my $delaydisplay = 0;
my %active;
foreach my $db (@dblist) {$active{$db} = -1;}
my %up_down_button = (
'time_stamp' => 0,
'delay'      => 0,
'parms'      => '',
'widget'     => '',
);
my @req_queue;
my %validreq = ('control' => 1,
'open'    => 1,
'save'    => 1,
'create'  => 1,
'delete'  => 1,
'clear'   => 1,
'newradio' => 1,
'connect' => 1,
'sort'    => 1,
'batch'   => 1,
'renum'   => 1,
);
my %mem_set   = %clear;
my %copy = %clear;
my $status_dialog = '';
show_long_run('testing');
my %combo = ();
my @combos = ('vmode','ctcss','dcs','name','port','baud','vchan','beep','att_amp');
foreach my $key (@combos) {$combo{$key} = Gtk3::ComboBoxText->new;}
my @dbload;
my @dbsave;
my $end_mark;
my @write_col = ();
my %valid_col = ();
my %handler_id;
my @signal_meter;
my @labels;
my @option_text;
my %radio_dply_label;
my @radio_dply_value;
my %opt_button;
my %opt_value;
my %expand_box;
my %expand_buttons;
my %entry;
my %window_display;
my %window_menu;
my @rparms;
my %scrolled;
my %view_menu;
my @vbox;
my @hbox;
my $hz;
my $color;
my $found;
my $iter;
my $cellrender;
my %headers = ();
my @view_menu = ();
LogIt(0,"Setting up display panels");
my %popup_menu = ();
foreach my $dbndx (keys %panels) {
if ($panels{$dbndx}{'type'} ne 'd') {next;}
my $view_menu_item = Gtk3::MenuItem->new('_View');
$view_menu_item->set_submenu($db_view_menus{$dbndx});
my $menu_bar = Gtk3::MenuBar->new;
$menu_bar->append(make_menu("_File",\@file_menu,$dbndx));
$menu_bar->append($view_menu_item);
$menu_bar->append(make_menu("_Edit",\@edit_menu,$dbndx));
foreach my $rec (@edit_menu) {
my $item = $rec->{'name'};
if ($item eq 'create') {next;}
if ($menu_item{$dbndx}{$item}) {
$menu_item{$dbndx}{$item}->set_sensitive(FALSE);
}
}
$menu_bar->append(make_menu("_Help",\@help_menu,$dbndx));
$vbox[0] = Gtk3::Box->new('vertical',5);
$vbox[0] ->pack_start($menu_bar,FALSE,TRUE ,0);
my $scrolled = Gtk3::ScrolledWindow->new;
$scrolled->set_policy('automatic','automatic');
$scrolled->set_shadow_type('in');
if (TRUE) {
$treeview{$dbndx}->set_grid_lines('horizontal');
$scrolled->add($treeview{$dbndx});
$vbox[0]->pack_start($scrolled,TRUE,TRUE ,0);
$panels{$dbndx}{'gtk'} ->add($vbox[0]);
}
else {
$vbox[0]->pack_start($treeview{$dbndx},TRUE,TRUE,0);
$scrolled->add($vbox[0]);
$panels{$dbndx}{'gtk'} ->add($scrolled);
}
}#### create record type windows
LogIt(0,"Line 1673:  Generating VFO panels");
my %maxdply = ();
foreach my $dbndx (@dblist) {
$maxdply{$dbndx} = Gtk3::Label->new($dbcounts{$dbndx});
}
my $vfo_service = Gtk3::Label->new("");
$vfo_service->set_justify('left');
foreach (@modestring) {$combo{'vmode'}->append_text($_);}
my $child = $combo{'vmode'}->get_child;
$child->set_background_rgba(Gtk3::Gdk::RGBA->new(1,.3,0,.5));
my $desc = Pango::FontDescription-> new();
$desc->set_weight("bold");
$desc->set_size(20000);
$child->override_font($desc);
$handler_id{'vmode'} = $combo{'vmode'}->signal_connect(changed=> sub {
my $widget = shift @_;
my $text = Strip($widget->get_active_text);
my $value = $widget->get_active;
my %set = ( '_cmd' => 'control','_ctl' => 'vmode', '_value' => $text,'_debug' =>1801);
push @req_queue,{%set};
return TRUE;
});
$combo{'vmode'}->set_active(0);
my %txref = ();
my %ctl_strings = (
'ctcss' => [@tonestring],
'dcs'   => [@dcsstring],
'att_amp' => ['Attenuation','Preamp'],
);
my %bgclr = ( 'ctcss' => [1,0,0,.1],
'dcs'   => [0,1,0,.1],
'att_amp' => [0,0,1,.1],
);
foreach my $ctl (keys %ctl_strings) {
$combo{$ctl}->append_text('Off');
$txref{$ctl}{'off'} = 0;
my $ndx = 1;
foreach my $str (@{$ctl_strings{$ctl}}) {
if ($str =~ /off/i) {next;}    
my $key = Strip(lc($str));
my $text = $str;
$text =~ s/\_//g;  
$text = sprintf("%-13.13s",ucfirst($text));
$combo{$ctl}->append_text($text);
$txref{$ctl}{$key} = $ndx;
$ndx++;
}
my $child = $combo{$ctl}->get_child();
my $clr = $bgclr{$ctl};
$child->set_background_rgba(Gtk3::Gdk::RGBA->new(@{$clr}));
my $desc = Pango::FontDescription-> new();
$desc->set_weight("bold");
$child->override_font($desc);
$combo{$ctl}->set_active(0);
$handler_id{$ctl} = $combo{$ctl}->signal_connect(changed=> sub {
my $widget = shift @_;
my $ctl = shift @_;
my $text = Strip($widget->get_active_text);
my $value = $widget->get_active;
my %set = ( '_cmd' => 'control','_ctl' => $ctl, '_value' => $text,'_debug' =>1941);
push @req_queue,{%set};
return TRUE;
},$ctl);
}
my @opt_button_dply = (
{'key' => 'dlyrsm',   'panel' => "right", 'dply' => 'Signal Delay. If Negative, Signal Resume) '},
{'key' => 'scansys',  'panel' => "right", 'dply' => 'Scans Use System Records'},
{'key' => 'scangroup','panel' => "right", 'dply' => 'Scans Use Group Records'},
{'key' => 'start',    'panel' => "right" , 'dply' => 'Starting Channel Or Record'},
{'key' => 'stop',     'panel' => "right" , 'dply' => 'Ending Channel Or Record'},
{'key' => 'usesys',   'panel' => "right", 'dply' => 'LOAD uses existing System'},
{'key' => 'clear',    'panel' => "right", 'dply' => 'Clear database before LOAD operation'},
{'key' => 'noskip',   'panel' => "right", 'dply' => "Don't Skip empty channels on LOAD operation"},
{'key' => 'nodup',    'panel' => "right", 'dply' => "Don't keep duplicate channels on LOAD"},
{'key' => 'manlog',   'panel' => "right", 'dply' => 'Update database in Manual'},
{'key' => 'recorder',   'panel' => "right", 'dply' => 'Record audio when signal'},
{'key' => 'logging',      'panel' => "right", 'dply' => 'Log events to this file'},
);
my $op_right = Gtk3::Box->new('vertical',5);
my $op_left  = Gtk3::Box->new('vertical',5);
foreach my $rec (@opt_button_dply) {
my $key = $rec->{'key'};
$opt_button{$key} = Gtk3::CheckButton ->new($rec->{'dply'});
my $child = $opt_button{$key} -> get_child();
my $bgc = '';
my $fg = '';
my $weight = ' weight="normal" ';
my $str = "<span $fg $bgc $weight > $rec->{'dply'} </span";
$opt_button{$key}->signal_connect(toggled => sub {
my $widget = shift @_;
my $key = shift @_;
$control{$key} = $widget->get_active;
if (($key eq 'usesys') and $control{'usesys'}) {$opt_button{'clear'}->set_active(FALSE);}
if (($key eq 'clear') and $control{'clear'}) {$opt_button{'usesys'}->set_active(FALSE);}
if ($key eq 'logging') {
if ($control{$key}) {$entry{$key}->set_sensitive(FALSE);}
else {$entry{$key}->set_sensitive(TRUE);}
}
},$key);
$hbox[0] = Gtk3::Box->new('horizontal',5);
if (defined $control{$key . '_value'}) {
$entry{$key} = Gtk3::Entry->new;
$entry{$key} -> set_width_chars(4);
$entry{$key}->signal_connect(activate => \&number_entry,$key);
$entry{$key}->signal_connect(focus_out_event => \&focus_lost,$key);
my $ctlinit = $key . '_value';
my $value = $control{$ctlinit};
if (!defined $value) {
print Dumper(%control),"\n";
LogIt(1,"undefined value for control->$ctlinit ($key)");
}
$opt_value{$key} = Gtk3::Label->new($value);
$entry{$key}->set_text($value);
number_entry($entry{$key},$key);
$hbox[0]->pack_start($entry{$key},FALSE,FALSE,0);
$hbox[0]->pack_start($opt_value{$key},FALSE,FALSE,0);
}### Entry field defined for a number
elsif (defined $control{$key . '_file'}) {
$entry{$key} = Gtk3::Entry->new;
$entry{$key} -> set_width_chars(16);
my $ctlname = $key . '_file';
my $value = $control{$ctlname};
if (!$value) {$opt_button{$key}->set_sensitive(FALSE)};
$entry{$key}->set_text($value);
$entry{$key}->signal_connect(activate => \&log_filename_proc,$key);
$hbox[0]->pack_start($entry{$key},FALSE,FALSE,0);
}
else {
$hbox[0]->pack_start(Gtk3::Label->new(">>>>>>>>>"),FALSE,FALSE,3);
}### No entry field defined
$hbox[0]->pack_start($opt_button{$key},FALSE ,FALSE,0);
if ($rec->{'panel'} eq 'right') {$op_right->pack_start($hbox[0],FALSE,FALSE,0);}
else {$op_left->pack_start($hbox[0],FALSE,FALSE,0);}
}
my $sqadj = Gtk3::Adjustment->new(0, 0, 90, 1, 1.0, 1.0);
my $sqscale = Gtk3::HScale->new($sqadj);
my $sqlvalue = Gtk3::Label->new("squelch");
$sqscale->set_digits(1);
$sqscale->set_value_pos('left');
$sqscale->set_draw_value(TRUE);
$handler_id{'squelch'} = $sqscale->signal_connect(value_changed => \&squelch_bar_change);
$sqscale->set_value($control{'squelch'});
my @speed_value = (0,10,9,8,7,6,5,4,3,2,1,.5);
my $bar_size = (scalar @speed_value) - 1;
my $spscale = Gtk3::Scale->new_with_range('horizontal',0,$bar_size,1);
$spscale->set_value_pos('top');
$spscale->set_draw_value(TRUE);
$spscale->set_has_origin(TRUE);
foreach my $ndx (1..$bar_size) {$spscale->add_mark($ndx,'left',$speed_value[$ndx]);}
$spscale->show;
$spscale->set_sensitive(TRUE);
$control{'speed_bar'} = 0;
$spscale->signal_connect(
value_changed => sub {
my $speed = $speed_value[$spscale->get_value];
if (!$speed) {$speed = 0;}
$control{'speed_bar'} = $speed;
return TRUE;
}
);
$spscale->signal_connect(
format_value  => sub {
my $fmt = shift @_;
my $value = shift @_;
my $retvalue = $speed_value[$value] ;
if (!$retvalue) {$retvalue = 'Off';}
return $retvalue;
}
);
my %status_ctl = ();
my @status_keys = ('sysno','groupno','index','bank','lookup');
my @status2_keys = ('delay','resume');
foreach my $key (@status_keys,@status2_keys) {$status_ctl{$key} = Gtk3::Label->new('0');}
my $connect_status = Gtk3::Button->new_with_label("");
$connect_status->signal_connect(pressed =>
sub {
push @req_queue,{'_cmd' => 'connect'};
});
my $rescan_button = Gtk3::Button->new_with_label("rescan");
$rescan_button->signal_connect(pressed =>
sub {refreshserial();});
my $autobaud_button = Gtk3::CheckButton ->new("Autobaud");
$autobaud_button->signal_connect(toggled => sub {
my $widget = shift @_;
$control{'autobaud'} = $widget->get_active;
if ($control{'autobaud'}) {
$combo{'port'}->set_sensitive(FALSE);
$combo{'baud'}->set_sensitive(FALSE);
}
else {
$combo{'port'}->set_sensitive(TRUE);
$combo{'baud'}->set_sensitive(TRUE);
}
});
$autobaud_button->set_active($control{'autobaud'});
$handler_id{'port'} = $combo{'port'} ->signal_connect(changed => \&serialproc);
refreshserial();
$combo{'port'} ->signal_connect(popup => \&refreshserial);
my $bdndx = 0;
foreach my $baud (reverse sort numerically keys %baudrates) {
$combo{'baud'} -> append_text($baud);
$baudrates{$baud} = $bdndx;
$bdndx++;
}
$handler_id{'baud'} = $combo{'baud'} -> signal_connect(changed => \&baudrateproc);
$combo{'name'}->append_text($defaultradio);
foreach my $name (sort keys %All_Radios) {
if ($name eq lc($defaultradio)) {next;}
my $realname = $All_Radios{$name}{'realname'};
if (!$realname) {
print Dumper(%All_Radios),"\n";
LogIt(2861,"No 'realname' key for name=$name");
}
$combo{'name'}->append_text($realname);
}
$combo{'name'} ->signal_connect(changed => \&radioselproc);
$combo{'name'}->set_active(0);
my %view_parms = ();
$view_menu{'main'} = Gtk3::Menu->new();
my $separator = Gtk3::MenuItem->new('#### Panels #####');
$child = $separator->get_child;
$separator->set_sensitive(FALSE);
$view_menu{'main'} ->append($separator);
$vbox[0] = Gtk3::Box->new('vertical',10);
our $message_box = Gtk3::TextView->new;
$message_box->set_cursor_visible(FALSE);
$message_box->set_editable(FALSE);
my $top_messages = TRUE;
my $buffer = $message_box->get_buffer();
$buffer->create_tag ("red", foreground => "red");
$buffer->create_tag ("black", );
$buffer->create_tag ("green",);
$buffer->create_tag ("blue", );
$buffer->create_tag ("yellow",);
$buffer->create_tag ("cyan", );
$buffer->create_tag ("bold", weight => PANGO_WEIGHT_BOLD);
$buffer->create_tag ("normal", weight => PANGO_WEIGHT_LIGHT);
$buffer->create_tag ("big", size => 15 * PANGO_SCALE);
$scrolled{'messages'} = Gtk3::ScrolledWindow->new;
$scrolled{'messages'}->set_policy('automatic','automatic');
$scrolled{'messages'}->set_placement('top-left');
if (TRUE) {
$scrolled{'messages'}->add_with_viewport($message_box);
$vbox[0]->pack_start($scrolled{'messages'},TRUE,TRUE,0);
}
else {
$vbox[0]->pack_start($message_box,FALSE,FALSE,0);
}
my $clrbutton = Gtk3::Button->new_with_label("Press to Clear Messages");
$vbox[0] ->pack_end($clrbutton,FALSE,FALSE,0);
$clrbutton->signal_connect(pressed => sub {
my $buffer = $message_box->get_buffer();
my $dialog = Gtk3::Dialog->new_with_buttons('Save Messages?',$panels{'main'}{'gtk'},
[qw/modal destroy-with-parent/],
'gtk-cancel' => 'cancel',
'gtk-yes' => 'yes',
'gtk-no'  =>  'no',
);
my $text = Gtk3::Label->new("Save messages to a file before clearing?");
my $font = 'face="DejaVu Sans Mono"';
my $size = 'size="18000"';
my $weight = ' weight="normal" ';
$text->set_markup ('<span ' . "$font $size $weight " . '>' .
"Save Messages to a file before clearing?" . '</span>');
my $content = $dialog->get_content_area();
$content->add($text);
$dialog->show;
my $response = $dialog->run;
$dialog->destroy;
if ($response eq 'cancel') {return 0;}
if ($response eq 'yes') {
if (file_ops('messages')) {return 0;}
}
my ($start,$end) = $buffer->get_bounds;
$buffer->delete($start,$end);
}
);
$panels{'messages'}{'gtk'} ->add($vbox[0]);
add_view_menu('messages');
my %rbuttons;
my $group = undef;
$vbox[0] = Gtk3::Box->new('vertical',5);
$vbox[1] = Gtk3::Box->new('vertical',5);
my $ndx = 0;
foreach my $sm (@progstates) {
if ($sm-> {'dply'}) {
my $title = $sm->{'dply'};
my $mode = $sm->{'state'};
$rbuttons{$mode}  = Gtk3::RadioButton->new_with_label($group,$title);
my $child = $rbuttons{$mode}->get_child();
if ($child) {
my $fg = '';
$child -> set_markup('<span ' .
$fg .
'>' .
$title . '</span>');
}
if (!$group) { $group = $rbuttons{$mode}->get_group;}
$vbox[$ndx]->pack_start($rbuttons{$mode},FALSE ,FALSE,0);
$handler_id{$mode} =  $rbuttons{$mode}->signal_connect(pressed => \&operation_select, $sm);
$rbuttons{$mode}->signal_connect(released => sub {return 0});
}
}
$hbox[0] =Gtk3::Box->new('horizontal',5);
$hbox[0]->pack_start($vbox[0] ,FALSE,FALSE,0);
$hbox[0]->pack_start($vbox[1] ,FALSE,FALSE,0);
$rbuttons{'cancel'} = Gtk3::Button->new_with_label('Cancel operation');
$child = $rbuttons{'cancel'} -> get_child;
$child->set_markup('<span foreground="red" > Cancel Operation </span>');
my %op_parm = ('state' => 'cancel');
$handler_id{'cancel'} =  $rbuttons{'cancel'}->signal_connect(pressed => \&operation_select,\%op_parm);
$vbox[2] = Gtk3::Box->new('vertical',5);
$vbox[2] -> pack_start($hbox[0],FALSE,FALSE,0);
$vbox[2] -> pack_start($rbuttons{'cancel'},FALSE,FALSE,0);
$panels{'ops'}{'gtk'}->add($vbox[2]);
add_view_menu('ops');
$panels{'speed'}{'gtk'}->add($spscale);
add_view_menu('speed');
DIGIT_BUILD:
my %digit = ();
my %digit_dply = ();
my %sbuttons = ();
foreach my $type (keys %digit_names) {
my $count = $digit_names{$type}{'len'};
my @ndx = ();
$digit_dply{$type} = Gtk3::Box->new('horizontal',5);
$digit_dply{$type}->set_spacing(0);
for my $i (0..($count-1)) {
if (defined $digit{$type}{$i}{'ctl'}) { LogIt(2578,"Redefining a digit!");}
push @ndx,$i;
$digit{$type}{$i}{'ctl'} = Gtk3::Label->new();
$digit_dply{$type}->pack_end($digit{$type}{$i}{'ctl'},FALSE,TRUE,0);
$digit{$type}{$i}{'sel'} = FALSE;
$digit{$type}{$i}{'ctl'}->set_selectable(TRUE);
$digit{$type}{$i}{'ctl'}->set_sensitive(TRUE);
foreach my $event ('scroll-event','button_press_event','button_release_event',
) {
my %parms = ('type' => $type,'digit' => $i,'event'=> $event);
$digit{$type}{$i}{'ctl'}->signal_connect($event =>\&vfo_digit,\%parms);
}
$digit{$type}{$i}{'ctl'}->add_events('enter-notify-mask');
$digit{$type}{$i}{'ctl'}->add_events('scroll-mask');
}### all digits
$entry{$type}  = Gtk3::Entry->new;
$entry{$type}->set_width_chars($digit_names{$type}{'len'});
my $proc = \&frequency_entry;
if ($type =~ /chan/i) {$proc = \&number_entry;}
$entry{$type}->signal_connect(activate => $proc,$type);
$entry{$type}->signal_connect(focus_out_event => \&focus_lost,$type);
my $arrows = Gtk3::Box->new('vertical',5);
foreach my $updown ('up','down') {
$sbuttons{$type}{$updown} = Gtk3::ToggleButton->new;
my $arrow = '';
if ($updown eq 'up') {$arrow = Gtk3::Arrow->new('up','in'); }
else {$arrow = Gtk3::Arrow->new('down','out'); }
$sbuttons{$type}{$updown} ->add($arrow);
my $parms = "$type,$updown";
$sbuttons{$type}{$updown} ->signal_connect(pressed => \&inc_press, $parms);
$sbuttons{$type}{$updown} ->signal_connect(released => sub {
$up_down_button{'widget'} = '';
$up_down_button{'delay'} = 0;
$up_down_button{'parms'} = '';
$up_down_button{'time_stamp'} = 0;
});
$arrows->pack_start($sbuttons{$type}{$updown},FALSE,FALSE,0);
}
$vbox[0] = Gtk3::Box->new('vertical',5);
$vbox[0]->pack_start($digit_dply{$type},FALSE,FALSE,0);
$vbox[0]->pack_start($entry{$type},FALSE,FALSE,0);
$hbox[0] = Gtk3::Box->new('horizontal',5);
if ($type =~ /igrp/i) {
$hbox[0]->pack_end($arrows,FALSE,FALSE,0);
}
else {
$hbox[0]->pack_start($arrows,FALSE,FALSE,0);
}
$hbox[0]->pack_start($vbox[0],FALSE,FALSE,0);
$panels{$type}{'gtk'}->add($hbox[0]);
if ($type eq 'rchan') {
}
else {
add_view_menu($type);
}
}
$vbox[0] = Gtk3::Box->new('vertical',5);
$vbox[0]->pack_start($combo{'vmode'},FALSE,FALSE,0);
$vbox[0]->pack_start(Gtk3::Label->new(" "),FALSE,FALSE,0);
$panels{'vmode'}{'gtk'}->add($vbox[0]);
add_view_menu('vmode');
$vbox[0] = Gtk3::Box->new('vertical',5);
foreach my $type (sort keys %ctl_strings) {
$hbox[0] = Gtk3::Box->new('horizontal',5);
my $label = $type;
if ($type =~ 'amp') {$label = 'att/preamp';}
$hbox[0]->pack_start($combo{$type},FALSE,FALSE,0);
$hbox[0]->pack_start(Gtk3::Label->new($label),FALSE,FALSE,0);
$vbox[0]->pack_start($hbox[0],FALSE,FALSE,0);
}
$panels{'vext'}{'gtk'}->add($vbox[0]);
add_view_menu('vext');
$vbox[0] = Gtk3::Box->new('horizontal',5);
$vbox[0]->pack_start($panels{'rchan'}{'gtk'},FALSE,FALSE,0);
$vbox[0]->show_all;
$panels{'radio'}{'gtk'}->add($vbox[0]);
dply_vfo_num('rchan',0);
$hbox[2] = Gtk3::Box->new('horizontal',5);
foreach my $type ('vchan','vstep','vfreq','vmode','vext') {
$hbox[2]->pack_start($panels{$type}{'gtk'},FALSE,FALSE,0);
}
$vbox[0] = Gtk3::Box->new('vertical',5);
$vbox[0] ->pack_start($hbox[2],FALSE,FALSE,0);
$hbox[0] = Gtk3::Box->new('horizontal',5);
$hbox[0] ->pack_start($vfo_service,FALSE,FALSE,0);
$vbox[0] ->pack_start($hbox[0],TRUE,TRUE,0);
$vbox[0]->show_all;
$panels{'vfo'}{'gtk'} ->add($vbox[0]);
LogIt(0,"VFO panel complete");
add_view_menu('vfo');
$vbox[0] =  Gtk3::Box->new('vertical',5);
$hbox[0] = Gtk3::Box->new('horizontal',5);
$hbox[0]->pack_start(Gtk3::Label->new("      Radio->"),FALSE,FALSE,0);
$hbox[0]->pack_start($combo{'name'},FALSE,FALSE,0);
$vbox[0]->pack_start($hbox[0],FALSE,FALSE,0);
$hbox[0] = Gtk3::Box->new('horizontal',5);
$hbox[0]->pack_start(Gtk3::Label->new("         Port->"),FALSE,FALSE,0);
$hbox[0]->pack_start($combo{'port'},FALSE,FALSE,0);
$hbox[0]->pack_start($rescan_button,FALSE,FALSE,0);
$vbox[0]->pack_start($hbox[0],FALSE,FALSE,0);
$hbox[0] = Gtk3::Box->new('horizontal',5);
$hbox[0]->pack_start(Gtk3::Label->new("Baudrate->"),FALSE,FALSE,0);
$hbox[0]->pack_start($combo{'baud'},FALSE,FALSE,0);
$hbox[0]->pack_start($autobaud_button,FALSE,FALSE,0);
$vbox[0]->pack_start($hbox[0],FALSE,FALSE,0);
$hbox[0] = Gtk3::Box->new('horizontal',5);
$hbox[0]->pack_start(Gtk3::Label->new("    Status->"),FALSE,FALSE,0);
$hbox[0]->pack_start($connect_status,FALSE,FALSE,0);
$vbox[0]->pack_start($hbox[0],FALSE,FALSE,0);
$panels{'select'}{'gtk'}->add($vbox[0]);
add_view_menu('select');
$vbox[0] = Gtk3::Box->new('vertical',5);
$hbox[1] = Gtk3::Box->new('horizontal',5);
$hbox[0] = Gtk3::Box->new('horizontal',5);
$hbox[2] = Gtk3::Box->new('horizontal',5);
$hbox[3] = Gtk3::Box->new('horizontal',5);
foreach my $key (@status_keys) {
my $title = Strip(ucfirst($key));
if (lc($key) eq 'groupno') {$title = 'Group';}
elsif (lc($key) eq '_seq') {$title = 'Freq ';}
elsif (lc($key) eq 'bank') {$title = 'Srch ';}
elsif (lc($key) eq 'sysno'){$title = 'Systm';}
elsif (lc($key) eq 'lookup') {$title = 'Lookup';}
else {$title = sprintf("%-5.5s",$title);}
my $label = Gtk3::Label->new($title);
$label -> set_markup ('<span ' .
'size="8000" face="DejaVu Sans Mono"' .
'weight="light" style="italic">' .
$title . '</span>');
$hbox[0]->pack_start($label,FALSE,FALSE,13);
$hbox[1]->pack_start($status_ctl{$key},FALSE,FALSE,10);
}
$hbox[1]->pack_start(Gtk3::Label->new("<<<-Current"),FALSE,FALSE,0);
foreach my $key (@dblist) {
$hbox[2]->pack_start($maxdply{$key},FALSE,FALSE,10);
}
$hbox[2]->pack_start(Gtk3::Label->new("<<<-Maximums"),FALSE,FALSE,0);
foreach my $ctl (@status2_keys) {
my $label = Gtk3::Label->new();
$label-> set_justify("right");
$label -> set_markup ('<span ' .
'size="8000" face="DejaVu Sans Mono"' .
'weight="light" style="italic">' .
ucfirst($ctl) . '=></span>');
$hbox[3]->pack_start($label,FALSE,FALSE,13);
$hbox[3]->pack_start($status_ctl{$ctl},FALSE,FALSE,0);
$hbox[3]->pack_start( Gtk3::Label->new('                   '),FALSE,FALSE,0);
}
$vbox[0]->pack_start($hbox[0],FALSE,FALSE,0);
$vbox[0]->pack_start($hbox[1],FALSE,FALSE,0);
$vbox[0]->pack_start($hbox[2],FALSE,FALSE,0);
$vbox[0]->pack_start($hbox[3],FALSE,FALSE,0);
$panels{'status'}{'gtk'}->add($vbox[0]);
add_view_menu('status');
$vbox[0] = Gtk3::Box->new('vertical',5);
$hbox[0] = Gtk3::Box->new('horizontal',8);
foreach my $i (0..MAXSIGNAL) {
$signal_meter[$i] = Gtk3::Label->new(' ');
my $eventbox = Gtk3::EventBox->new();
$eventbox->add($signal_meter[$i]);
$eventbox->signal_connect('button_press_event' => sub {
push @req_queue,{'_cmd' => 'control',
'_ctl', => 'signal',
'_value' => $i,
'_debug' => 'signal_button',
};
return $GoodCode;
},$i);
$hbox[0]->pack_start($eventbox,FALSE,FALSE,0);
}
$vbox[0]->pack_start($hbox[0],FALSE,FALSE,0);
$hbox[0] = Gtk3::Box->new('horizontal',5);
$hbox[0]->pack_start($sqscale,TRUE,TRUE,0);
$hbox[0]->pack_start($sqlvalue,FALSE,FALSE,0);
$vbox[0]->pack_start($hbox[0],FALSE,FALSE,0);
$panels{'signal'}{'gtk'} ->add($vbox[0]);
add_view_menu('signal');
$panels{'op_right'}{'gtk'}->add($op_right);
add_view_menu('op_right');
foreach my $dbndx (sort keys %panels) {
if ($panels{$dbndx}{'type'} eq 'p') {next;}
$panels{$dbndx}{'gtk'} ->signal_connect (delete_event => \&close_window,$dbndx);
if (defined $w_info{$dbndx}) {
if ($w_info{$dbndx}{'xpos'} and $w_info{$dbndx}{'ypos'}) {
$panels{$dbndx}{'gtk'} ->move($w_info{$dbndx}{'xpos'},$w_info{$dbndx}{'ypos'});
}
if ($w_info{$dbndx}{'xsize'} and $w_info{$dbndx}{'ysize'}) {
$panels{$dbndx}{'gtk'} ->resize($w_info{$dbndx}{'xsize'},$w_info{$dbndx}{'ysize'});
}
}
if ($dbndx eq 'main') {next;}
if (!defined $w_info{$dbndx}{'active'}) {$w_info{$dbndx}{'active'} = FALSE;}
$window_menu{$dbndx} = make_view_menu_item($panels{$dbndx}{'title'},$dbndx,$panels{$dbndx}{'gtk'},\$w_info{$dbndx}{'active'});
$view_menu{'main'} -> prepend($window_menu{$dbndx});
LogIt(0,"Finished updating window $dbndx");
}
$vbox[0] = Gtk3::Box->new('vertical',5);
$vbox[1] = Gtk3::Box->new('vertical',5);
$vbox[2] = Gtk3::Box->new('vertical',5);
$vbox[3] = Gtk3::Box->new('vertical',5);
$hbox[0] = Gtk3::Box->new('horizontal',5);
$hbox[1] = Gtk3::Box->new('horizontal',5);
foreach my $panel ('select','status','signal','speed') {
if ($panels{$panel}{'type'} eq 'p') {
$vbox[0] ->pack_start($panels{$panel}{'gtk'},FALSE,FALSE,0);
}
}
foreach my $panel ('op_right') {
if ($panels{$panel}{'type'} eq 'p') {
$vbox[2] ->pack_start($panels{$panel}{'gtk'},TRUE,TRUE,0);
}
}
foreach my $panel ('ops') {
if ($panels{$panel}{'type'} eq 'p') {
$vbox[3] ->pack_start($panels{$panel}{'gtk'},TRUE,TRUE,0);
}
}
$vbox[3]->pack_start($panels{'radio'}{'gtk'},TRUE,TRUE,0);
$vbox[3]->show_all;
foreach my $ndx (3,0,2) {$hbox[0]->pack_start($vbox[$ndx],FALSE,FALSE,0);}
$hbox[0]->pack_start(Gtk3::Box->new('horizontal',5),TRUE,TRUE,0);
$hbox[0]-> show_all;
$vbox[1] -> pack_start($hbox[0],FALSE,FALSE,0);
if ($panels{'vfo'}{'type'} eq 'p') {
$hbox[2] = Gtk3::Box->new('horizontal',5);
$hbox[2] -> pack_start($panels{'vfo'}{'gtk'},FALSE,FALSE,0);
$hbox[2] -> pack_start(Gtk3::Box->new('horizontal',5),FALSE,FALSE,0);
$vbox[1] -> pack_start($hbox[2],FALSE,FALSE,0);
}
$vbox[1]->pack_start($panels{'messages'}{'gtk'},TRUE,TRUE,0);
$vbox[1]->show_all;
my $menu_bar = Gtk3::MenuBar->new;
$menu_bar->append(make_menu('_File',\@file_menu,'main'));
my $view_menu_item = Gtk3::MenuItem->new('_View');
$view_menu_item->set_submenu($view_menu{'main'});
$menu_bar->append($view_menu_item);
$menu_bar->append(make_menu('_Help',\@help_menu,'main'));
$vbox[2] = Gtk3::Box->new('vertical',5);
$vbox[2] -> pack_start($menu_bar,FALSE,FALSE,0);
$scrolled{'main'} = Gtk3::ScrolledWindow->new;
$scrolled{'main'}->set_policy('automatic','automatic');
if (TRUE) {
$scrolled{'main'}->add($vbox[1]);
$vbox[2]->pack_start($scrolled{'main'},TRUE,TRUE,0);
$panels{'main'}{'gtk'}  ->add ($vbox[2]);
$panels{'main'}{'gtk'} ->show_all;
}
else {
$vbox[2]->pack_start($vbox[1],FALSE,FALSE,0);
$scrolled{'main'}->add($vbox[2]);
$panels{'main'}{'gtk'} -> add($scrolled{'main'});
}
$panels{'main'}{'gtk'}->show_all;
my %req = ('_cmd' => 'newradio','protocol' => 'local');
my $timer = Glib::Timeout->add($usleep{'TIMEPOP'},\&timepop, undef, 10);
Gtk3->main;
exit 0;
sub timepop {
my $found;
if ($pop_up) {
@req_queue = ();
return 1;
}
if ($delaydisplay) {
$delaydisplay--;
return 1;
}
if ($response_pending) {
if (!$status_dialog) {show_long_run($response_pending);}
}
else {
if ($status_dialog) {
$status_dialog->destroy();
$status_dialog = '';
if ($was_focus{'window'}) {
$panels{$was_focus{'window'}}{'gtk'}->activate();
}
}
}
{
lock @messages;
while (scalar @messages) {
my $msg = shift @messages;
my $sev = 0;
($sev,$msg) = split ',',$msg,2;
message_dply($msg,$sev);
}
}
foreach my $dbndx (keys %panels) {
if ($rowsel{$dbndx}) {
my $treeselection = $treeview{$dbndx}->get_selection();
my $count = $treeselection->count_selected_rows();
foreach my $item ('delete','swap','xfer','edit') {
if (!$menu_item{$dbndx}{$item}) {next;}
if (!$count) {$menu_item{$dbndx}{$item}->set_sensitive(FALSE);}
else {
if ($item eq 'swap') {
if ($count == 2) {$menu_item{$dbndx}{$item}->set_sensitive(TRUE);}
else {$menu_item{$dbndx}{$item}->set_sensitive(FALSE);}
}
else {$menu_item{$dbndx}{$item}->set_sensitive(TRUE);}
}
}
$rowsel{$dbndx} = FALSE;
}
}
if ((defined $scan_request{'_rdy'}) ) {
if (!$scan_request{'_cmd'}) {
LogIt(1,"TIMEPOP-3983:ScanRequest missing command=>");
print Dumper(%scan_request),"\n";
return 1;
}
my $command = $scan_request{'_cmd'};
if ($command eq 'update') {
if (!defined $scan_request{'_dbn'}) {
print Dumper(%scan_request),"\n";
LogIt(3369,"Undefined '_dbn' in scan_scanquest");
}
my $dbndx = lc($scan_request{'_dbn'});
if (($dbndx eq -1) or ($dbndx eq 'vfo')) {
print Dumper(%scan_request),"\n";
LogIt(3378,"TIMEPOP:Scanner Requested VFO display sync. Remove this call!");
}
if (!defined $scan_request{'_seq'}) {
print Dumper(%scan_request),"\n";
LogIt(3382,"TIME_POP:Undefined _seq in scan request");
}
if (!$liststore{$dbndx}) {
print Dumper(%scan_request),"\n";
LogIt(3386,"SCAN_REQUEST:Bad database index=>$dbndx");
}
my @indexes = ($scan_request{'_seq'});
set_db_data($dbndx,\@indexes,\%scan_request);
}### sync requested
elsif ($command eq 'batch'){
if (!defined $scan_request{'_dbn'}) {
print Dumper(%scan_request),"\n";
LogIt(3489,"Undefined '_dbn' in scan_scanquest");
}
my $dbndx = lc($scan_request{'_dbn'});
if (!$liststore{$dbndx}) {
print Dumper(%scan_request),"\n";
LogIt(3515,"SCAN_REQUEST:Bad database index=>$dbndx");
}
if (scalar @selected) {
set_db_data($dbndx,\@selected,\%scan_request);
}
else {LogIt(1,"TIMEPOP l3428:No selection for BATCH scanner request!");}
}
elsif ($command eq 'vfodply') {
my $freq = $vfo{'frequency'};
if (!$freq and $vfo{'tgid'}) {
$freq = "TGID:" . sprintf("%6.6s",$vfo{'tgid'});
}
dply_vfo_num('vfreq',$freq);
dply_vfo_num('vchan',$vfo{'index'});
dply_vfo_num('rchan',$vfo{'channel'});
dply_vfo_num('vstep',$vfo{'step'});
dply_signal($vfo{'signal'});
dply_modulation($vfo{'mode'});
dply_expanded();
dply_status();
my $value = $vfo{'service'};
if (!$value) {$value = '';}
if ($vfo{'tgid'}) {$value = "$value (TGID:$vfo{'tgid'})";}
dply_service($value);
my $bgc = '';
my $fg = '';
my $weight = ' weight="normal" ';
my $msg = 'Record Audio When Signal';
if ($dark) {$fg = ' foreground="white" ';}
else {$fg = ' foreground="black" ';}
if ($start_recording) {
$fg = 'foreground="red"';
$msg = 'Recording Audio';
$weight = 'weight="heavy"';
}
my $child =  $opt_button{'recorder'}->get_child();
$child->set_markup("<span $fg $bgc $weight > $msg </span>");
}
elsif ($command eq 'sigdply') {
dply_signal($vfo{'signal'});
}
elsif ($command eq 'init') {
LogIt(0,"GUI started INIT request from scanner");
foreach my $dbndx (keys %panels) {
if ($dbndx eq 'main') {next;}
if ($panels{$dbndx}{'type'} eq 'p') {next;}
if ($w_info{$dbndx}{'active'}) {$panels{$dbndx}{'gtk'} -> show;}
}
radio_parms_dply();
$panels{'main'}{'gtk'} ->show;
$init_done = TRUE;
add_message("test initialization complete.");
lock (%scan_request);
%scan_request = ();
LogIt(0,"GUI completed INIT command");
return 1;
}
elsif ($command eq 'message') {
add_message($scan_request{'msg'},$scan_request{'severity'});
}
elsif ($command eq 'delete') {
if (!defined $scan_request{'_dbn'}) {
print Dumper(%scan_request),"\n";
LogIt(3545,"Undefined '_dbn' in scan_scanquest");
}
my $dbndx = lc($scan_request{'_dbn'});
if (!$liststore{$dbndx}) {
print Dumper(%scan_request),"\n";
LogIt(3551,"SCAN_REQUEST:Bad database index=>$dbndx");
}
if (!scalar @selected) {
LogIt(1,"TIMEPOP l3554: no selected records found for DELETE!");
}
foreach my $no (@selected) {
if (!$no) {next;}
if ($no < 0) {next;}
my $iter = find_iter($dbndx,$no,FALSE,FALSE,3975);
if ($iter eq -1) {
LogIt(1,"TIMEPOP:DELETE:Could not find record $no to delete");
next;
}
print "Deleting record $no iter=>$iter\n";
$liststore{$dbndx}->remove($iter);
$guidb{$dbndx}--;
if ($guidb{$dbndx} < 0) {LogIt(3568,"RADIOCTL:negative GUIDB value for $dbndx");}
}### for each selected
}### DELETE processing
elsif ($command eq 'clear') {
my $dbndx = $scan_request{'_dbn'};
LogIt(0,"RADIOCTL.PL l3645:Requesting clear of $dbndx");
$liststore{$dbndx} -> clear();
foreach my $rec (@edit_menu) {
my $item = $rec->{'name'};
if ($item eq 'create') {next;}
if ($menu_item{$dbndx}{$item}) {$menu_item{$dbndx}{$item} -> set_sensitive(FALSE);}
}
lock @selected;
@selected = ();
$guidb{$dbndx} = 0;
}
elsif ($command eq 'clearall') {
foreach my $dbndx (@dblist) {
$liststore{$dbndx}->clear();
$guidb{$dbndx} = 0;
foreach my $rec (@edit_menu) {
my $item = $rec->{'name'};
if ($item eq 'create') {next;}
if ($menu_item{$dbndx}{$item}) {$menu_item{$dbndx}{$item} -> set_sensitive(FALSE);}
}
}
lock @selected;
@selected = ();
}### Clear all
elsif ($command eq 'statechange') {
if (!defined $scan_request{'state'}) {
LogIt(1, "TIMEPOP line 4426:Undefined state  in scan_req! Code needs update");
return 1;
}
print "progstate BEFORE change=$progstate\n";
my $progstate = $scan_request{'state'};
if ($progstate eq 'manual') {
my $sm = {'state' => 'manual'};
$rbuttons{$progstate}->set_active(TRUE);
LogIt(0,"set $progstate button active");
}
else {
print "Request block=>",Dumper(%scan_request),"\n";
LogIt(4226,"TIMEPOP:Scanner thread issued statechange request=$progstate");
}
}
elsif ($command eq 'radio') {
if (defined $scan_request{'connect'}) {
radio_status_dply($scan_request{'connect'});
}
else {LogIt(1,"undefined 'connect' key for 'RADIO' scan_request");}
}
elsif ($command eq 'pop-up') {
err_dialog($scan_request{'msg'},'info','queue');
return 1;
}
elsif ($command eq 'baud') {
my $baud = $scan_request{'rate'};
my $port = $scan_request{'port'};
my $rc = find_combo_string($combo{'baud'},$baud,TRUE);
if ($rc) {
LogIt(0, "RadioCtl l3769: Got return code $rc from find_combo_string for $baud");
}
$rc = find_combo_string($combo{'port'},$port,TRUE);
if ($rc) {
LogIt(0, "RadioCtl l3769: Got return code $rc from find_combo_string for $port");
}
radio_parms_dply();
}### 'baud' command
elsif ($command eq 'control') {
foreach my $key (keys %scan_request) {
if ($key =~ /^\-/) {next;}  
my $action = $scan_request{$key};
if (defined $control{$key}) {
if ($action eq 'disable') {
if ($key =~ /value/i) {
my ($vkey) = $key =~ /(.*)\_value/i;
$entry{$vkey}-> set_sensitive(FALSE);
}
}
elsif ($action eq 'enable') {
if ($key =~ /value/i) {
my ($vkey) = $key =~ /(.*)\_value/i;
$entry{$vkey}-> set_sensitive(TRUE);
}
}
}### Control item
elsif (defined $menu_item{'freq'}{$key}) {
foreach my $dbndx ('freq','group','system') {
if (defined $menu_item{$dbndx}{$key}) {
if ($action eq 'disable') {
$menu_item{$dbndx}{$key}->set_sensitive(FALSE);
}
else {
$menu_item{$dbndx}{$key}->set_sensitive(TRUE);
}
}### If menu item defined
}### For each database
}### Menu item control
elsif (defined $panels{$key}{'gtk'}) {
if ($action eq 'disable') {
$digit_names{$key}{'enable'} = FALSE;
}
elsif ($action eq 'enable') {
$digit_names{$key}{'enable'} = TRUE;
}
elsif ($action =~ /hide/i) {
$panels{$key}{'gtk'} ->hide();
}
elsif ($action =~ /show/i) {
$panels{$key}{'gtk'} ->show_all();
}
else {
print "RADIOCTL l4133: Need process for display key $key\n";
}
}### Enabling/disabling/showing/hiding panels
elsif (defined $combo{$key}) {
if ($action eq 'disable') {$combo{$key}->set_sensitive(FALSE);}
elsif ($action eq 'enable') {$combo{$key}->set_sensitive(TRUE);}
}
}### Scan request keys
}### CONTROL request
else {
print STDERR Dumper(%scan_request),"\n";
LogIt(4485,"TIMEPOP:No processing defined for scan_request =>$command on GUI!");
}
{### mark the request as complete
lock (%scan_request);
%scan_request = ();
}
threads->yield;
}### scanner request
if (!$init_done) {return 1};
my $proc_time = 160;
if ($up_down_button{'widget'}) {
my $queue_size = scalar @req_queue;
if ($queue_size < 5) {
if ($up_down_button{'time_stamp'}) {
my $now = Time::HiRes::time();
my $delta = $now - $up_down_button{'time_stamp'};
if ($delta > $up_down_button{'delay'}) {
inc_press($up_down_button{'widget'},$up_down_button{'parms'});
$up_down_button{'delay'} = .1;
}
}
}
}
REQ:
while (scalar @req_queue) {
my $queue_size = scalar @req_queue;
if ($queue_size > 5) {
}
my $key_count = 0;
{### Block for locking
lock %gui_request;
$key_count = scalar keys %gui_request;
}
if ($key_count) {
lock %gui_request;
if (!$gui_request{'_cmd'}) {
print "radioctl.pl l4377: GUI request has leftovers but no _CMD\n";
print "request=>",Dumper(%gui_request),"\n";
%gui_request = ();
next REQ;
}
else {
if ($gui_request{'_in_process'}) {
}
else {
$gui_request{'_count'}++;
if ($gui_request{'_count'} > 100) {
LogIt(1,"RADIOCTL.PL:REQ line 4394:GUI request was not acknowledged by SCANNER thread.\n" .
"  Request is nullified");
print Dumper(%gui_request),"\n";
%gui_request = ();
next REQ;
}
}
return 1;
}###
}### Outstanding GUI Request
if (!scalar @req_queue) {return 1;}
my %request = %{shift @req_queue};
if (!scalar keys(%request)) {
LogIt(1,"TIMER_POP:Got an empty req_queue element!");
next REQ;
}
{### Block for locking
lock %gui_request;
%gui_request = %request;
$gui_request{'_count'} = 0;
$gui_request{'_timestamp'} = Time::HiRes::time();
$gui_request{'_rdy'} = TRUE;
}
threads->yield;
usleep($proc_time);
}
return 1;
}### timepop
sub show_long_run {
my $msg = shift @_;
if (!$msg) {$msg = "please wait for completion";}
%was_focus = ();
foreach my $win (keys %panels) {
if ($panels{$win}{'type'} eq 'p') {next;}
if ($panels{$win}{'gtk'} ->is_active) {
$was_focus{'widget'} = $panels{$win}{'gtk'} ->get_focus();
$was_focus{'window'} = $win;
last;
}
}
if (!$was_focus{'window'}) {print "Could not find focus window!\n";}
my $parent = $was_focus{'window'};
if (!$parent) {$parent = 'main';}
$status_dialog = Gtk3::Dialog->new_with_buttons(
'wait',
$panels{$parent}{'gtk'},
[qw/modal destroy-with-parent/],
'gtk-cancel' => 'cancel',
);
my $text = Gtk3::Label->new($msg);
my $font = 'face="DejaVu Sans Mono"';
my $size = 'size="21000"';
my $weight = ' weight="bold" ';
$text->set_markup ('<span ' . "$font $size $weight " . '>' .
$msg . '</span>');
my $content = $status_dialog->get_content_area();
$content->add($text);
$status_dialog->signal_connect(delete_event => sub {
return TRUE;
});
$status_dialog->signal_connect(response => sub {
my $parm1 = shift @_;
my $parm2 = shift @_;
if ($parm2 eq 'cancel') {
$rbuttons{'manual'}->set_active(TRUE);
lock $progstate;
$progstate = 'manual';
}
});
$content->show_all;
$status_dialog->show;
$status_dialog->set_keep_above(TRUE);
return 0;
}
sub dply_vfo_num {
my $type = shift @_;
my $value = shift @_;
my $signal = shift @_;
if (!$signal) {$signal = FALSE;}
my  $font = 'face="DejaVu Sans Mono"';
my  $size = 'size="33300"';
my  $bgnorm = 'background="black" ';
my  $bghi   = 'background="#aaaaff"';
my  $bg = $bgnorm;
my  $inverse = FALSE;
my  $fg = 'foreground="red" ';
my  $select = 'background="#555555"';
my $weight = 'weight="heavy"';
my $style = 'style="normal"';
my $fmt = $digit_names{$type}{'len'};
if ($type eq 'vstep') {
$fg = 'foreground="white" ';
$size  = 'size="16100"';
if (looks_like_number($value)) {
$value = rc_to_freq($value);
}
else {
print "RadioCtl 4474:Non-numeric step value $value\n";
return 0;
}
}
elsif ($type eq 'vfreq') {
if (looks_like_number($value)) {
if ($value) {$value = rc_to_freq($value);}
else {$value = " ---.------";}
}
else {$value = sprintf("%${fmt}.${fmt}s",$value);}
}
elsif ($type eq 'vchan') {
$fg = 'foreground="#0FFFFF" ';## channel is blueish
if ($value  =~ /^[0-9]+$/) {$value = sprintf("%${fmt}.${fmt}u",$value);}
else {$value = sprintf("%${fmt}.${fmt}s",$value);}
}
elsif ($type eq 'rchan') {
$fg = 'foreground="yellow"';
$bg = 'background="black"';
if ($value  =~ /^[0-9]+$/) {$value = sprintf("%${fmt}.${fmt}u",$value);}
else {$value = sprintf("%${fmt}.${fmt}s",$value);}
}
my @chars = reverse split '',$value;
foreach my $ndx (0..($fmt-1)) {
my $bgc = $bg;
my $char = shift @chars;
if (!$digit{$type}{$ndx}{'ctl'}) {### This is a problem
LogIt(1,"RadioCtl l4564:no definition for $type digit=$ndx char=$char value=$value");
last;
}
if ($digit{$type}{$ndx}{'sel'}) {
print "RadioCtl line 4566:Digit $ndx is selected\n";
$bgc = $select; }
$digit{$type}{$ndx}{'ctl'}->set_markup (
'<span ' .
$fg . $font . $size . $weight . $style .$bgc . '>' .
$char . '</span>');
}
return 0;
}
sub dply_signal {
my $value = shift @_;
if (!$value) {$value = 0;}
$fg = ' foreground="black" ';
$size = 'size="21000"';
foreach my $i (0..$#signal_meter) {
if (!$i) {
$bg = ' background="lightgreen" ';
$hz = 'Off';
}
else {
$bg = ' background="white" ';
$hz = $signal_values[$i];
if ($value  >= $i) {$bg = ' background="red" ';}
}
$child = $signal_meter[$i];
if ($child) {
$child -> set_markup('<span ' .
'stretch="condensed" ' .
$fg . $font . $size . $weight . $style .$bg . '>' .
$hz . '</span>');
}
else {LogIt(1,"Line 3888:Could not get signal meter child");}
}
return 0;
}
sub dply_modulation   {
my $modulation =  $vfo{'mode'};
if (!$modulation) {$modulation = 'Auto';}
if (looks_like_number($modulation)) { LogIt(3811,"DPLY_MODULATION:Numeric modulation code $modulation given");}
$modulation = $rc_hash{Strip(lc($modulation))};
if (!$modulation) {$modulation = 0;}
$combo{'vmode'}->signal_handler_block($handler_id{'vmode'});
$combo{'vmode'}->set_active($modulation);
$combo{'vmode'}->signal_handler_unblock($handler_id{'vmode'});
}
sub dply_service   {
my $text = shift @_;
if (!length($text)) {return;}
my $fg = '';
my $size = 'size="18000"';
my $weight = ' weight="normal" ';
my $font = 'face="DejaVu Sans Mono"';
my $style = 'style="normal"';
$text =~ s/>/\)/g;
$text =~ s/</\(/g;
$text =~ s/\&/and/g;   
$vfo_service->set_markup ('<span ' .
$fg . $font . $size . $weight . $style . '>' .
$text . '</span>');
return 0;
}
sub dply_expanded {
my %ndx  = ('att_amp' => 0,
'ctcss' => 0,
'dcs' => 0,
);
if ($vfo{'atten'}) {$ndx{'att_amp'} = 1;}
elsif ($vfo{'preamp'}) {$ndx{'att_amp'} = 2;}
my $tone = Strip(lc($vfo{'tone'}));
my $tone_type = $vfo{'tone_type'};
if ($tone =~ /off/i) {$tone_type = 'off';}
if ($tone_type and ($tone_type !~ /off/i)) {
if ($tone_type =~ /ctcss/i) {
my $ndx = $txref{'ctcss'}{$tone};
if ($ndx) {$ndx{'ctcss'} = $ndx;}
else {
LogIt(1,"RADIOCTL.PL Line 4704:Lookup failed for CTCSS tone=>$tone");
}
}
elsif ($tone_type =~ /dcs/i) {
my $ndx = $txref{'dcs'}{$tone};
if ($ndx) {$ndx{'dcs'} = $ndx;}
else {LogIt(1,"RADIOCTL.PL Line 4527:Lookup failed for DCS tone=>$tone");}
}
}
foreach my $cntl (keys %ctl_strings) {
if (!defined $ndx{$cntl}) {
LogIt(1,"RadioCtl line 4530:No index was set for control=>$cntl");
next;
}
$combo{$cntl}->signal_handler_block($handler_id{$cntl});
$combo{$cntl}->set_active($ndx{$cntl});
$combo{$cntl}->signal_handler_unblock($handler_id{$cntl});
}
return 0;
}
sub dply_status {
my $fg = '';
my $bg = '';
my $weight = ' weight="light" ';
my $size = ' size="12000" ';
my $font = 'face="DejaVu Sans Mono"';
my $style = 'style="normal"';
foreach my $ctl (@status_keys,@status2_keys) {
if ($ctl eq '_seq') {next;}
my $value = $vfo{$ctl};
if (!defined $vfo{$ctl}) {
LogIt(1,"DPLY_STATUS:VFO key $ctl was not initialized!");
$value = 0;
}
my $l = length(MAXCHAN);
if ($ctl eq 'index') {$l = length(MAXINDEX);}
if (!looks_like_number($value)) {$value = 0;}
if (($ctl eq 'delay') or ($ctl eq 'resume')) {
if ($value) { $fg = ' foreground="red" ';}
else {
if ($dark) {$fg = ' foreground="white" ';}
else {$fg = ' foreground="black" ';}
}
}
else {$fg = '';}
$status_ctl{$ctl} ->set_markup('<span ' .
$fg . $font . $size . $weight . $style .$bg . '>' .
sprintf("%${l}.${l}i",$value) . '</span>');
}
$fg = '';
$bg = '';
foreach my $dbndx (@dblist) {
my $value = $dbcounts{$dbndx};
if (!looks_like_number($value)) {$value = 0;}
my $l = length(MAXCHAN);
if ($dbndx eq 'freq') {$l = length(MAXINDEX);}
$maxdply{$dbndx} ->set_markup('<span ' .
$fg . $font . $size . $weight . $style .$bg . '>' .
sprintf("%${l}.${l}i",$value) . '</span>');
}
return 0;
}
sub radio_status_dply {
my $status = shift @_;
my $bg = ' background = "red" ';
my $fg = ' foreground="black" ';
my $size = 'size="9000"';
if (lc($status) eq 'connected') {
$bg = ' background="green"';
$fg = ' foreground="white"';
$rescan_button->set_sensitive(FALSE);
}
elsif (lc($status) eq 'connecting'){$bg = ' background = "yellow" ';}
elsif (lc($status) eq 'unresponsive'){$bg = ' background = "blue" ';}
else {### should be disconnected
$rescan_button->set_sensitive(TRUE);
}
$child = $connect_status->get_child;
$child->set_markup('<span ' .
$fg . $font . $size . $weight . $style .$bg . '>' .
"Radio is " . sprintf("%-12.12s",$status) . "\n" .
"Click To Change      " . '</span>');
return 0;
}
sub radio_parms_dply {
return 0;
my $bg = ' background="white" ';
$bg = '';
my $darkgreen = ' foreground="darkgreen" ';
my $blue = ' foreground="blue" ';
my $size = 'size="9999"';
my $heavy = 'weight="heavy"';
my $normal = 'style="normal"';
my $italic = 'style="italic" ';
my $proto = $radio_def{'protocol'};
my $font = 'face="DejaVu Sans Mono"';
if ($radio_def{'model'}) {$radio_dply_label{'model'}->set_text($radio_def{'model'});}
else {$radio_dply_label{'model'}->set_text('?');}
foreach my $x (1,2,3,4) {
my $key = "msg$x";
if ($All_Radios{$radiosel}{$key}) {
$entry{$key}->set_text($All_Radios{$radiosel}{$key});
}
else {
$entry{$key}->set_text('');
}
}
}
sub radioselproc {
my ($cell, $dbinfo) = @_;
if ($response_pending) {return 0;}
my $new_radiosel = lc(Strip($cell->get_active_text));
LogIt(0,"RADIOSELPROC:Called. Old=$radiosel New=$new_radiosel");
if ($radiosel eq $new_radiosel) {return 0;}
my  %new_def = (
'parity' => 'none',
'stopbits' => 1,
'baudrate' => 9600,
'port' => 'none',
'name' => $new_radiosel,
);
my @radiokeys = keys %{$All_Radios{$new_radiosel}};
foreach my $key (@radiokeys) {
$new_def{$key} = $All_Radios{$new_radiosel}{$key};
}
refreshserial();
my $found = 0;
if ($new_def{'protocol'} ne 'local') {
foreach my $ndx (0..$#ports) {if ($ports[$ndx] eq $new_def{'port'}) {$found = $ndx;last;}}
if (!$found) {
my $type = 'ttys';
if ($new_def{'port'} =~ /acm/i) {$type = 'acm';}
elsif ($new_def{'port'} =~ /usb/i) {$type = 'usb';}
foreach my $ndx (0..$#ports) {
if ($ports[$ndx] =~ /$type/i)  {
$found = $ndx;
last;
}
}
}### if current port not found
}### not local protocol
else {$new_def{'active'} = TRUE;}
$new_def{'port'} = $ports[$found];
$combo{'port'}->signal_handler_block($handler_id{'port'});
my $portndx = $combo{'port'}->set_active($found);
$combo{'port'}->signal_handler_unblock($handler_id{'port'});
$All_Radios{$new_radiosel}{'port'} = $ports[$found];
if (!$new_def{'baudrate'}) {
LogIt(1,"Default baudrate not set for $new_radiosel. Changed to 9600");
$new_def{'baudrate'} = '9600';
}
my $baud = $new_def{'baudrate'};
if (!defined $baudrates{$baud}) {
LogIt(1,"Baudrate of $baud is not valid for $new_radiosel. Changed to 9600");
$new_def{'baudrate'} = '9600';
$baud = '9600';
}
my $baud_ndx = $baudrates{$baud};
$combo{'baud'}->signal_handler_block($handler_id{'baud'});
$combo{'baud'}->set_active($baud_ndx);
$combo{'baud'}->signal_handler_unblock($handler_id{'baud'});
$new_def{'_cmd'} = 'newradio';
push @req_queue,{%new_def};
$radiosel = $new_radiosel;
radio_parms_dply();
return 0;
}
sub serialproc   {
my ($cell, $dbinfo) = @_;
my $portsel  = $cell->get_active_text;
if ($portsel eq $radio_def{'port'}) {return 0;}
$All_Radios{$radiosel}{'port'} = $portsel;
my %new_def = ('_cmd' => 'newradio','port' => $portsel);
push @req_queue,{%new_def};
radio_parms_dply();
return 0;
}
sub baudrateproc   {
my ($cell, $dbinfo) = @_;
my $baud = $cell->get_active_text;
if ($baud eq $radio_def{'baudrate'}) {return;}
$All_Radios{$radiosel}{'baudrate'} = $baud;
my %new_def = ('_cmd' => 'newradio','baudrate' => $baud);
push @req_queue,{%new_def};
radio_parms_dply();
return 0;
}
sub refreshserial {
my $default = 0;
$combo{'port'}->signal_handler_block($handler_id{'port'});
$combo{'port'}->remove_all();
port_read();
foreach my $pt (@ports) {
$combo{'port'}->append_text($pt);
$ndx++;
}
$combo{'port'}->set_active($default);
$combo{'port'}->signal_handler_unblock($handler_id{'port'});
return 1;
}
sub operation_select {
my $widget = shift @_;
my $parms = shift @_;
if ($parms->{'state'} eq 'cancel') {
LogIt(0,"$Bold$Green Current operation being canceled");
$progstate = 'manual';
$rbuttons{'manual'}->set_active(TRUE);
}
else {
if ($response_pending and ($parms->{'state'} ne 'manual')) {return 0;}
$widget->set_active(TRUE);
$progstate = $parms->{'state'};
}
LogIt(0,"$Bold$White OPERATION_SELECT:Changed scan mode to $Green$progstate");
return 1;
}
sub inc_press {
my $widget = shift @_;
my $parms   = shift @_;
my ($ctl,$direction) = split ',',$parms;
my $sigkill = FALSE;
if (!$digit_names{$ctl}{'enable'}) {return 0;}
$up_down_button{'widget'} = $widget;
$up_down_button{'parms'} = $parms;
$up_down_button{'delay'} = .8;
$up_down_button{'time_stamp'} = Time::HiRes::time();
my $value = 0;
if ($ctl eq 'vstep') {
my $inc = 100;
if ($direction eq 'down') {$inc = -$inc;}
my $newstep = $vfo{'step'};
if (!$newstep) {$newstep = MINFREQ;}
$newstep = $newstep + $inc;
if ($newstep > MAXFREQ) {$newstep = MINFREQ;}
elsif ($newstep < MINFREQ) {$newstep = MAXFREQ;}
lock %vfo;
$vfo{'step'} = $newstep;
dply_vfo_num('vstep',$newstep);
return 0;
}
else {
my %set = ('_cmd' => 'incr', '_ctl' => $ctl,
'_dir' => $direction, '_debug' => 5593);
push @req_queue,{%set};
}
return 0;
}### INC_PRESS process
sub focus_lost {
my ($widget, $event, $ctl) = @_;
return FALSE;
return FALSE;
}
sub frequency_entry {
my ($widget, $ctl) = @_;
my $text = $widget->get_text;
if (length($text) == 0) {return 0;}
$widget->set_text("");
if (!$digit_names{$ctl}{'enable'}) {return 0;}
if ($ctl eq 'vfreq') {
my $frq = freq_to_rc($text);
if (($frq < MINFREQ) or ($frq > MAXFREQ))  {
err_dialog("$text is not a valid frequency",'error','frequency_entry');
return FALSE;
}
my %set = ( '_cmd' => 'control','_ctl' => $ctl, '_value' => $frq, '_debug' => 5494);
push @req_queue,{%set};
}
elsif ( $ctl eq 'vstep') {
my $frq = freq_to_rc($text);
if (($frq < MINFREQ) or ($frq > MAXFREQ)) {
err_dialog("$text is not a valid step",'error','frequency_entry');
return FALSE;
}
lock %vfo;
$vfo{'step'} = $frq;
dply_vfo_num('vstep',$frq);
}
else {LogIt(6357,"VFO_FREQ_PROC:No process for control=>$ctl");}
return TRUE;
}
sub number_entry {
my ($widget, $ctl) = @_;
my $value = $widget->get_text;
if ($value eq '') {return FALSE;}
if ($digit_names{$ctl}{'title'} and (!$digit_names{$ctl}{'enable'})) {
$widget->set_text("");
return 0;
}
my $bad = '';
my $maxchan = MAXCHAN;
my $minchan = 0;
if ($ctl eq 'rchan') {
$maxchan = 999;
}
elsif ($ctl eq 'vchan') {
$minchan = 1;
}
elsif ($ctl =~ /dly/i) {
$minchan = -(MAXCHAN);
}
if ( (!looks_like_number($value)) or ($value < $minchan) or ($value > $maxchan)) {
$bad = "Value must be $minchan or positive number less than or equal to $maxchan";
}
else {
$value = $value + 0;
$widget->set_text("");
if ($ctl =~ /chan/i)  {   
$widget->set_text("");
my %set = (
'_cmd' => 'control',
'_ctl' => $ctl,
'_value' => $value,
'_debug' => 5492,
);
push @req_queue,{%set};
}### Channel change request
else {
my $ctl_key = $ctl . '_value';
$opt_value{$ctl} -> set_markup ('<span ' .
'size="9000" face="DejaVu Sans Mono"' .
'weight="light" style="italic">' .
$value .
'</span>');
$control{$ctl_key} = $value;
}
}### if not bad
if ($bad) {
err_dialog ("invalid input ($value) $bad!",'error','number_entry');
}
return TRUE;
}
sub log_filename_proc {
my ($widget, $ctl) = @_;
my $value = $widget->get_text;
my $ctlname = $ctl . '_file';
if (!$value) {
$control{$ctlname} = '';
$opt_button{$ctl}->set_sensitive(FALSE);
return TRUE;
}
my $filespec = "$settings{'logdir'}/$value";
if (-l $filespec) {### Symlink?
$filespec = readlink $filespec;
}
if (-d $filespec) {
my $msg = "'$value' resolves to '$filespec' which is a directory.\n      Setting bypassed!";
err_dialog($msg,'error','log_filename_proc');
LogIt(1,$msg);
$widget->set_text($control{$ctlname});
return TRUE;
}
my $finalmsg = "Log data file '$filespec'";
if (-e $filespec) {
my $msg = "File $filespec already exists!";
LogIt(1,"$msg");
my $dialog = Gtk3::Dialog->new_with_buttons("File Exists",
$panels{'main'}{'gtk'},
[qw/modal destroy-with-parent/],
'gtk-cancel' => 'cancel',
'gtk-ok' => 'ok',
);
my $content = $dialog ->get_content_area();
my $text = Gtk3::Label->new("$msg");
my $font = 'face="DejaVu Sans Mono"';
my $size = 'size="18000"';
my $weight = ' weight="bold" ';
my $red = 'foreground="red"';
my $markup = "<span $font $size $weight $red >" .
"$msg\n</span> <span $font $size $weight >             OK to replace? </span>";
$text->set_markup ($markup);
$content->add($text);
my $action_area = $dialog->get_action_area();
$action_area->set_property("halign","GTK_ALIGN_CENTER");
$dialog->show_all;
my $response = $dialog->run;
$dialog->destroy;
if ($response ne 'ok') {
LogIt(1,"User canceled setting of existing logfile");
return TRUE;
}
$finalmsg = "$finalmsg will be created for logging";
}
else {
$finalmsg = "$finalmsg will be appended to for logging";
}
$control{$ctlname} = $value;
$opt_button{$ctl} ->set_sensitive(TRUE);
add_message($finalmsg,0);
LogIt(0,"$Bold$finalmsg");
return TRUE;
}
sub vfo_digit {
my $widget = shift @_;
my $gevt = shift @_;
my $parm = shift @_;
my $digitno = $parm->{'digit'};
my $type = $parm->{'type'};
my $action = $parm->{'event'};
if (!$digit_names{$type}{'enable'}) {return 0;}
my $curtext = $digit{$type}{$digitno}{'ctl'}->get_text();
if ($curtext =~ /[a-z,A-Z,\.]/) {return 0;}
if (($action eq 'scroll-event') or ($action eq 'button_press_event')) {
my $add = 1;
if ($action eq 'scroll-event') {
my $event = '';
$event = Gtk3->get_current_event;
if ($event and ($event->direction() eq 'down')) {$add = -1;}
}
else {
my $button = $gevt->button();
if ($button == 1) {$add = 1;}
elsif ($button == 3) {$add = -1;}
else {return 0;}
}
if ($curtext =~ /[0-9]/) { 
$curtext = $curtext + $add;
if ($curtext < 0) {$curtext = 9;}
if ($curtext > 9) {$curtext = 0;}
}
else {
if ($add > 0) {$curtext = 1;}
else {$curtext = 9;}
}
my $count = $digit_names{$type}{'len'};
my $newval = '';
foreach my $i (0..($count-1)) {
my $newdigit = $digit{$type}{$i}{'ctl'}->get_text();
if ($i == $digitno) {$newdigit = $curtext;}
$newval = "$newdigit$newval";
}
print "Radioctl 5932:newval = $newval\n";
if (($type =~ /freq/i) or ($type =~ /step/i)) {
$newval = freq_to_rc($newval);
}
if ($type =~ /step/i) {
lock %vfo;
$vfo{'step'} = $newval;
dply_vfo_num($type,$newval);
}
else {
lock %vfo;
$vfo{'direction'} = $add;
my %set = ( '_cmd' => 'control','_ctl' => $type, '_value' => $newval,'_debug' => 5368);
push @req_queue,{%set};
}
}
elsif (($action eq 'enter_notify_event') or ($action eq 'motion_notify_event')) {
if (!$digit{$type}{$digitno}{'sel'}) {
$digit{$type}{$digitno}{'sel'} = TRUE;
}
}
elsif ($action eq 'leave_notify_event') {
$digit{$type}{$digitno}{'sel'} = FALSE;
}
else {LogIt(0,"VFO_DIGIT:got action=$action for digit=$digitno");}
return TRUE;
}
sub squelch_bar_change {
my  $widget = shift @_;
$control{'squelch'} = int($widget->get_value);
my $dply = int($control{'squelch'}/10);
if ($dply > MAXSIGNAL) {$dply = MAXSIGNAL;}
my $color =  'foreground="red"';
if ($dply) {
$dply = '@' . sprintf("%2.2u","$signal_values[$dply]");
}
else {
$dply = 'Off';
$color = 'foreground="green"';
}
my $markup = '<span face="DejaVu Sans Mono">squelch </span>' .
'<span face="DejaVu Sans Mono" ' . $color . '>' . $dply . '</span>';
$sqlvalue ->set_markup($markup);
if ($debug) {print "\nsquelch value from squelch_bar_change=$control{'squelch'}\n";}
return 0;
}
sub make_view_menu_item {
my $title = shift @_;
my $window = shift @_;
my $winref = shift @_;
my $global = shift @_;
if (!$global) {$global = '';}
my $wintype = shift @_;
if (!$wintype) {$wintype = 'panel';}
my $col = shift @_;
if (!$col) {$col = '';}
my $item = Gtk3::CheckMenuItem->new("$title");
my %view_parms = ('title' => $title,
'window' => $window,
'winref' => $winref,
'wintype' => $wintype,
'global'  => $global,
'col'     => $col,
);
$item->signal_connect('toggled' => \&view_ops,\%view_parms);
if (!$global) {$item->set_active(TRUE);}
else {$item->set_active($$global);}
my $child = $item->get_child;
return ($item);
}
sub make_menu {
my $parent = shift @_;
my $menu_ref  = shift @_;
my $dbndx = shift @_;
my $routine = \&menu_ops;
my $menu = Gtk3::Menu->new();
foreach my $rcd (@{$menu_ref}) {
my $key = $rcd->{'name'};
if ($key eq '_line') {
my $separator = Gtk3::SeparatorMenuItem->new();
$menu->append($separator);
next;
}
if ($rcd->{'dbn'} and ($rcd->{'dbn'} !~ /$dbndx/)) {next;}
my $title = $rcd->{'title'};
my $icon = $rcd->{'icon'};
$menu_item{$dbndx}{$key} = Gtk3::MenuItem->new();
my $image = Gtk3::Image->new_from_icon_name($rcd->{'icon'},'menu');
my $label = Gtk3::Label->new($title);
my $hbox = Gtk3::Box->new('horizontal',5);
$hbox->pack_start($image,FALSE,FALSE,0);
$hbox->pack_start($label,FALSE,FALSE,0);
$menu_item{$dbndx}{$key} -> add($hbox);
$menu_item{$dbndx}{$key} -> show_all;
my %parms = (
'name' => $key,
'dbndx' => $dbndx,
);
$menu_item{$dbndx}{$key}->signal_connect('activate' =>$routine,\%parms);
$menu->append($menu_item{$dbndx}{$key});
}
$menu_item{$dbndx}{$parent} = $menu;
my $submenu = Gtk3::MenuItem->new($parent);
$submenu->set_submenu($menu);
$child = $submenu->get_child;
return $submenu;
}
sub add_view_menu {
my $key = shift @_;
if ($panels{$key}{'type'} eq 'p') {
my $parent = $panels{$key}{'parent'};
if (!$parent) {$parent = 'main';}
$view_menu{$parent} -> append(make_view_menu_item($panels{$key}{'title'},$key,$panels{$key}{'gtk'}));
}
return 0;
}
sub swap_proc {
LogIt(1,"Swap not yet functional");
return 0;
my ($node1, $node2, $dbndx) = @_;
print "5323 swap proc $node1 $node2 $dbndx \n";
my $max = $guidb{$dbndx};
my $emsg = '';
if ($node1 !~ /[0-9]/) {
$emsg = "Node 1 Invalid input ($node1)\n Data must be numeric!\n";}
else {
if ($node1  > $max) {
$emsg = "Node 1 Invalid input ($node1)\n "
. "Data must be less than or = $max!\n";}
}
if ($node2 !~ /[0-9]/) {
$emsg = $emsg .
"Node 2 invalid input ($node2)\n Data must be numeric!\n";
}
else {
if ($node2  > $max) {
$emsg = $emsg .
"Node 2 invalid input ($node2)\n" .
" Data must be less than or = $max!\n";
}
}
my $iter1;
my $iter2;
if (!$emsg) {
$iter1 = $liststore{$dbndx}->get_iter_from_string($node1);
$iter2 = $liststore{$dbndx}->get_iter_from_string($node2);
if (!$iter1) {$emsg = $emsg . "Empty iter for node 1!\n";}
if (!$iter2) {$emsg = $emsg . "Empty iter for node 2!\n";}
}
if (!$emsg) {
my @ch;
$ch[1] = $liststore{$dbndx}->get($iter1,$col_xref{'index'});
$ch[2] = $liststore{$dbndx}->get($iter2,$col_xref{'index'});
my %chan1 = ('_dbn' => $dbndx,'channel' => $ch[1],'node' => -1);
my %chan2 = ('_dbn' => $dbndx,'channel' => $ch[2],'node' => -1);
get_db_data(\%chan1,'swap_proc');
get_db_data(\%chan2,'swap_proc');
$chan1{'channel'} = $ch[2];
$chan2{'channel'} = $ch[1];
set_db_data(\%chan1,'swap_proc');
set_db_data(\%chan2,'swap_proc');
add_message("Swapped channel $ch[1] with $ch[2]");
}
if ($emsg) {
err_dialog($emsg,'error','swap_proc');
return 1;
}
else {add_message("Error! NULL iter on one or both channels!",1);}
return 0;
}
sub find_iter {
my $dbndx = shift @_;
my $seq = shift @_;
my $makenew = shift @_;
my $sync = shift @_;
my $caller = shift @_;
my $iter = -1;
if (!$liststore{$dbndx}) {LogIt(7010,"FIND_ITER:no liststore reference for database->$dbndx caller=>$caller");}
if (!$col_xref{'index'}) {LogIt(7776,"No DBCOL for 'index'");}
foreach my $row (0..($guidb{$dbndx} - 1) ) {
my $itertest = $liststore{$dbndx}->get_iter_from_string($row);
if ($itertest) {
my $index = $liststore{$dbndx}->get($itertest,$col_xref{'index'});
if ($index) {
if ($index == $seq) {return $itertest;}
}
else {LogIt(1,"FIND_ITER:No index found for row=$row");}
}### itertest
}### Row search
if ($makenew) {
$iter = $liststore{$dbndx}->append;
$guidb{$dbndx}++;
foreach my $key (keys %drop_list) {
my $colno =  $drop_list{$key}{'model'};
if (!defined $colno) {
print Dumper(%drop_list),"\n";
LogIt(7848,"No col number for drop_list $key");
}
$liststore{$dbndx} ->set($iter,$colno,$drop_list{$key}{'liststore'});
}
$liststore{$dbndx} ->set($iter,$col_xref{'index'},$seq);
if ($sync) {
my %request = ();
foreach my $key (keys %clear) {
$request{$key} = $clear{$key};
}
$request{'_dbn'} = $dbndx;
$request{'_seq'} = $seq;
$request{'_cmd'} = 'sync';
$request{'debug'} = 'find_iter';
push @req_queue,{%request};
}
}### makenew
return $iter;
}### FIND_ITER
sub get_db_data {
my $ref = shift @_;
my $caller = shift @_;
if (!$ref) {LogIt(7495,"GET_DB_DATA:Hash ponter is empty! Caller=$caller"); }
foreach my $key ('sysno','index','dbtype') {LogIt(7496,"GET_DB_DATA:Missing key $key! Caller=$caller");}
my $sysno = $ref->{'sysno'};
my $index =  $ref->{'index'};
my $dbtype = $ref->{'dbtype'};
return;
}
sub set_db_data {
my $dbndx = shift @_;
my $indexes = shift @_;
my $keyref = shift @_;
my @options = @_;
if (!$dbndx) {LogIt(6411,"No DBN for SET_DB_DATA!");}
if (!$indexes) {LogIt(6412,"No Indexes for SET_DB_DATA!");}
if (!$keyref) {LogIt(6413,"No Keyref for SET_DB_DATA!");}
if (!$liststore{$dbndx}) {LogIt(6414,"SET_DB_DATA:Liststore for $dbndx was not defined");}
my $newrec = FALSE;
foreach my $opt (@options) {
if (lc($opt) eq 'create') {$newrec = TRUE;}
}
foreach my $item ('clear_db','sortf','sortc','renum') {
if ($menu_item{$dbndx}{$item} and ($progstate !~ /chan/i)) {
$menu_item{$dbndx}{$item}->set_sensitive(TRUE);
}
}
foreach my $seq (@{$indexes}) {
my $iter = $iters{$seq};
if (!$iter) {$iter = find_iter($dbndx,$seq,TRUE,FALSE,6419);}
if ($iter == -1) {LogIt(6431,"SET_DB_DATA:Iter was -1");}
my $path = $liststore{$dbndx}->get_path($iter);
my $found = FALSE;
foreach my $key (keys %{$keyref}) {
if ($key =~ /^\_.*$/) {next;}     
if ($key eq 'rsvd') {next;}
my $ref = $dply_def{$key};
if (!$ref) {next;}
my $colndx = $ref->{'dbcol'};
if (!$colndx) {LogIt(1,"SET_DB_DATA:No 'dbcol' for $key");next;}
my $dplyndx = $ref->{'dplycol'};
if (!$dplyndx) {LogIt(1,"SET_DB_DATA:No 'dplycol' for $key");next;}
$found = TRUE;
my $value = $keyref->{$key};
if (!defined $value) {$value = $clear{$key};}
if (($model[$colndx] eq 'Glib::Int') and ($value eq '')) {$value = -1;}
elsif ($ref->{'type'} eq 'freq') {
my $dplyfreq = rc_to_freq($value);
$liststore{$dbndx}->set($iter,$dplyndx,$dplyfreq);### display formatted as MHZ
}
elsif ($ref->{'type'} eq 'time') {
my $dplystamp = '--';
if (looks_like_number($value) and ($value > 2)) {
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) =
localtime($value);
$dplystamp = sprintf("%02.2i",($mon +1)) . '/' .
sprintf("%02.2i",$mday) . '/' . ($year+ 1900) .
' ' . sprintf("%02.2i",$hour) . ':' . sprintf("%02.2i",$min);
}
$liststore{$dbndx}->set($iter,$dplyndx,$dplystamp);
}
elsif ($key eq 'mode') {
if ($value eq '') {$value = 'Auto';}
else {
my $cmp = Strip(lc($value));
foreach my $mode (@modestring) {
if ($cmp eq Strip(lc($mode))) {
$value = $mode;
last;
}
}
}
}
elsif ($key eq 'tone_type') {
my $cmp = lc(Strip($value));
foreach my $str (@tone_type_values) {
if ($cmp eq lc(Strip($str))) {
$value = $str;
last;
}
}
}
else { }
$liststore{$dbndx}->set($iter,$colndx,$value,);
}### For every key specified
my $l = length(MAXINDEX);
$liststore{$dbndx}->set($iter,$col_xref{'index'},sprintf("%${l}.${l}i",$seq));
}### For every index specified
%iters = ();
return 0;
}### set_db_data
sub toggleproc {
if ($response_pending) {return 0;}
my ($cell, $row, $dbinfo) = @_;
my $dbndx = $dbinfo->{'dbndx'};
my $colnum = $dbinfo->{'coldb'};
my $keyword = $dbinfo->{'key'};
if (!$keyword) {LogIt(7849,"TOGGLEPROC:No key for column $colnum in comboproc for database $dbndx");}
my $iter = $liststore{$dbndx}->get_iter_from_string ($row);
my $value = ! $liststore{$dbndx}-> get($iter,$colnum);
my $seq = $liststore{$dbndx} -> get($iter,$col_xref{'index'});
my %request = ('_seq' => $seq, '_dbn' => $dbndx, '_cmd' => 'sync',
$keyword => $value);
push @req_queue,{%request};
return 0;
}
sub comboproc {
if ($response_pending) {return 0;}
my ($cell, $row, $value, $dbinfo) = @_;
my $dbndx = $dbinfo->{'dbndx'};
my $colnum = $dbinfo->{'coldb'};
my $keywd = $dbinfo->{'key'};
if (!$keywd) {LogIt(7798,"COMBOPROC:No key for column $colnum in comboproc for database $dbndx");}
my $iter = $liststore{$dbndx}->get_iter_from_string ($row);
$value = Strip(lc($value));
my $seq = $liststore{$dbndx} -> get($iter,$col_xref{'index'});
my %request = ('_seq' => $seq, '_dbn'=> $dbndx, '_cmd' => 'sync',
$keywd => $value,
);
push @req_queue,{%request};
return 0;
}
sub db_num_proc {
if ($response_pending) {return 0;}
my ($cell, $row, $value, $dbinfo) = @_;
if (!defined $value) {return;}
if ($value eq "") {return;}
my $dbndx = $dbinfo->{'dbndx'};
my $colnum = $dbinfo->{'coldb'};
my $dplynum = $dbinfo->{'dplycol'};
my $extra = $dbinfo->{'extra'};
my $keywd = $dbinfo->{'key'};
my $type  = $dbinfo->{'type'};
if (!$keywd) {LogIt(7798,"COMBOPROC:No key for column $colnum in comboproc for database $dbndx");}
my $iter = $liststore{$dbndx}->get_iter_from_string ($row);
my $seq = $liststore{$dbndx} -> get($iter,$col_xref{'index'});
my $emsg = '';
if (($keywd eq 'channel') and (substr(Strip($value),0,1) eq '-')) {$value = -1;}
if (!looks_like_number($value)) {$emsg = "$value is not a valid number!";}
else {
if ($type eq 'freq') {
my $frq = freq_to_rc($value);
if (($frq < 0) or ($frq > MAXFREQ)) {$emsg = "$value is out of range";}
$value = $frq;
}
}
my %request = ('_seq' => $seq, '_dbn'=> $dbndx, '_cmd' => 'sync',
$keywd => $value,
);
if ($emsg) {
err_dialog($emsg,'error','db_num_proc');
return 0;
}
push @req_queue,{%request};
return 0;
}
sub db_text_proc {
if ($response_pending) {return 0;}
my ($cell, $row, $value, $dbinfo) = @_;
my $dbndx = $dbinfo->{'dbndx'};
my $colnum = $dbinfo->{'coldb'};
my $dplynum = $dbinfo->{'dplycol'};
my $extra = $dbinfo->{'extra'};
my $keywd = $dbinfo->{'key'};
my $type  = $dbinfo->{'type'};
if (!defined $value) {$value = '';}
if (!$keywd) {LogIt(7798,"COMBOPROC:No key for column $colnum in comboproc for database $dbndx");}
my $iter = $liststore{$dbndx}->get_iter_from_string ($row);
my $seq = $liststore{$dbndx} -> get($iter,$col_xref{'index'});
my %request = ('_seq' => $seq, '_dbn'=> $dbndx, '_cmd' => 'sync',
$keywd => $value,
);
push @req_queue,{%request};
return 0;
}
sub chan_render {
my ($colnum, $cell, $model, $iter, $dbinfo) = @_;
my $mycol = $dbinfo->{'dplycol'};
if (!$mycol) {
LogIt(1,"Empty my column for $dbinfo dplycol");
$mycol = 0;
}
my $dbndx = $dbinfo->{'dbndx'};
my $key   = $dbinfo->{'key'};
my $data = $cell->get("text");
if (!$data) {$data = 0;}
my $l = length(MAXCHAN);
if ($dbndx eq 'freq') {$l = length(MAXINDEX);}
if (looks_like_number($data)) {
if ($data < 0) {$data = '  -  ';}
else {$data  = sprintf("%${l}.${l}i",$data);}
}
else {$data = '  -  ';}
if ($key eq 'index') {
if ($chan_active{$dbndx} == $data)  {### %chan_active is set in SCANNER thread
$cell->set_property("background","red","foreground","white");
}
else {
if ($dark) {$cell->set_property("background","black","foreground","white");}
else {$cell->set_property("background","white","foreground","black");}
}
}
else {
if ($colors{$key}) {
if ($dark) {$cell->set_property("foreground",$colors{$key});}
else {$cell->set_property("background",$colors{$key});}
}
}
$cell->set("text" => $data);
return 0;
}
sub time_render {
my ($colnum, $cell, $model, $iter, $dbinfo) = @_;
my $mycol = $dbinfo->{'dplycol'};
if (!$mycol) {
LogIt(1,"Empty my column for $dbinfo dplycol");
$mycol = 0;
}
my $dbndx = $dbinfo->{'dbndx'};
my $key   = $dbinfo->{'key'};
my $value = $cell->get("text");
print "RADIOCTL4-TIME_RENDER:column->$colnum cell->$cell model->$model iter-$iter value=>$value\n";
print Dumper($dbinfo),"\n";
my $dplystamp = "     ----     ";
if (looks_like_number($value) and ($value > 2)) {
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) =
localtime($value);
$dplystamp = sprintf("%02.2i",($mon +1)) . '/' .
sprintf("%02.2i",$mday) . '/' . ($year+ 1900) .
' ' . sprintf("%02.2i",$hour) . ':' . sprintf("%02.2i",$min);
}
if ($colors{$key}) {
if ($dark) {$cell->set('forground-gdk',$colors{$key});}
else {$cell->set('background-gdk',$colors{$key});}
}
$cell->set("text" => $dplystamp);
return 0;
}
sub number_render {
my ($colnum, $cell, $model, $iter, $dbinfo) = @_;
my $mycol = $dbinfo->{'dplycol'};
if (!$mycol) {
LogIt(1,"Empty my column for $dbinfo dplycol");
$mycol = 0;
}
my $dbndx = $dbinfo->{'dbndx'};
my $key   = $dbinfo->{'key'};
my $value = $cell->get("text");
if (!$value) {$value = 0;}
if ($colors{$key}) {
if ($dark) {$cell->set_property('foreground',$colors{$key});}
else {$cell->set_property('background',$colors{$key});}
}
$cell->set("text" => $value);
return 0;
}
sub numsort {
my ($liststore, $itera, $iterb, $dbinfo) = @_;
my ($sortkey, $dbndx, $colndx) = split ' ', $dbinfo;
my $v1 = $liststore->get ($itera,$sortkey);
my $v2 = $liststore->get ($iterb,$sortkey);
my $sortdir = $treecol{$dbndx}[$colndx]->get_sort_order();
if ($v1 == $v2) {return 0;}
if ((!$v2) and ($sortdir eq 'ascending')) {return -1;}
return $v1 <=> $v2;
}
sub stringsort {
my ($liststore, $itera, $iterb, $dbinfo) = @_;
my ($sortkey, $dbndx, $colndx) = split ' ', $dbinfo;
my $v1 = $liststore->get ($itera,$sortkey);
my $v2 = $liststore->get ($iterb,$sortkey);
if (!defined $v1) {$v1 = '';}
if (!defined $v2) {$v2 = '';}
my $sortdir = $treecol{$dbndx}[$colndx]->get_sort_order();
if ($v1 eq $v2) {return 0;}
if (looks_like_number($v1) and looks_like_number($v2)) {return $v1 <=> $v2;}
return $v1 cmp $v2;
}
sub test_ops {
my ($parm1, $parm2, $parm3) = @_;
print "test_ops parm1=>$parm1 parm2=>$parm2 parm3=>$parm3 \n";
return FALSE;
}
sub message_dply {
my ($new_msg,$severity) = @_;
if (!$message_box) {
print "$new_msg (no message box)\n";
return;
}
my $color = 'black';
my $weight = 'normal';
if ($severity) {
if ($severity == 2) {$color = 'green';}
elsif ($severity ==3 ) {$color = 'black';}
else {
$color = 'red';
$weight = 'bold';
}
}
my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) =
localtime(time);
my $timestamp = sprintf("%2.2u",($mon +1))    . '/' .
sprintf("%2.2u",$mday)       . '/' .
sprintf("%4.4u",($year+ 1900)) . " " .
sprintf("%2.2u",$hour)         . ":" .
sprintf("%2.2u",$min)         . ':' .
sprintf("%2.2u",$sec)         . ' '
;
if ($severity > 1) {$timestamp = '';}
my $buffer = $message_box->get_buffer();
if (!$top_messages) {
if ($severity != 3) {
$buffer->insert_with_tags_by_name ($buffer->get_end_iter(),$timestamp,"blue",);
}
$buffer->insert_with_tags_by_name ($buffer->get_end_iter()," $new_msg\n",$color,);
$message_box->scroll_to_iter ($buffer->get_end_iter(), 0, TRUE, 0,1);
my $adjustments = $scrolled{'messages'}->get_vadjustment();
$adjustments->set_value($adjustments->get_upper());
}
else {
$buffer->insert_with_tags_by_name ($buffer->get_start_iter()," $new_msg\n",$color,);
if ($severity != 3) {
$buffer->insert_with_tags_by_name ($buffer->get_start_iter(),$timestamp,"blue",);
}
}
}
sub testclick {
foreach my $parm (@_) {
print "parm=$parm\n";
}
}
sub port_read {
@ports = ();
push @ports, "(none)";
if ($os eq "LINUX") {
my @tty = </dev/tty*> ;
foreach my $file (@tty) {
if ($file =~ /ttyacm/i) {push @ports,$file;} 
}
foreach my $file (@tty) {
if ($file =~ /ttyusb/i) {push @ports,$file;} 
}
foreach my $file (@tty) {
if ($file =~ /ttys/i) {push @ports,$file;} 
}
}
elsif ($os eq "WINDOWS") {
push @ports,"com1";
push @ports,"com2";
push @ports,"com3";
push @ports,"com4";
}
}
sub find_combo_string {
my $combo = shift @_;
my $string = shift @_;
my $add = shift @_;
my $i = 0;
my $model = $combo->get_model();
my $cmpr = Strip(lc($string));
while (TRUE) {
my $iter = $model->get_iter_from_string($i);
last if not defined $iter;
my $newstr = Strip(lc($model->get($iter,0)));
if ($newstr eq $cmpr) {
$combo->set_active($i);
return 0;
}
++$i;
}
if ($add) {
$combo->append_text($string);
$combo->set_active($i);
return 1;
}
return 2;
}
sub menu_ops {
my $widget = shift @_;
my $parms = shift @_;
my $dbndx = $parms->{'dbndx'};
my $command = $parms->{'name'};
my $filename = '';
if ($response_pending) {
LogIt(1,"Response pending. Menu operation nullified");
return 0;
}
if ($command eq 'help') {
LogIt(1,"No help function available at this time!");
}
elsif (($command eq 'open') or ($command eq 'opennew')) {
my $file_dialog = Gtk3::FileChooserDialog->new(
$command . " Radioctl file",
$panels{'main'}{'gtk'},
'open',
'gtk-cancel'=> 'cancel',
'gtk-ok' => 'ok'
);
my $response = $file_dialog->run;
if ($response eq 'ok') {
$filename = $file_dialog->get_filename;
}
$file_dialog->destroy;
if ($filename) {
my %request = ('_cmd' => 'open', 'filespec' =>$filename, 'replace' => FALSE);
if ($command eq 'opennew') {$request{'replace'} = TRUE;}
push @req_queue,{%request};
$lastfilesave = $filename;
}
}### OPEN process
elsif ($command eq 'save') {
my %request = ('_cmd' => 'save');
my $dialog = Gtk3::Dialog->new_with_buttons('Save',
$panels{'main'}{'gtk'},
[qw/modal destroy-with-parent/],
'gtk-cancel' => 'cancel',
'gtk-ok' => 'ok',
);
my $filetext =  Gtk3::Entry->new();
$filetext->set_text($lastfilesave);
my $filespec = '';
my $getfilename = Gtk3::Button->new_with_label("Enter full filespec above. \n Press this button to search");
my $errmsg = Gtk3::Label->new();
$getfilename->signal_connect(pressed =>
sub {
$errmsg->set_text('');
my $file_dialog = Gtk3::FileChooserDialog->new(
$command . " Radioctl file",
$dialog,
'save',
'gtk-cancel'=> 'cancel',
'gtk-ok' => 'ok'
);
my $response = $file_dialog->run;
if ($response eq 'ok') {
$filetext->set_text($file_dialog->get_filename);
}
$file_dialog->destroy;
}### Sub for getfilename action
);
my $content = $dialog->get_content_area();
$content->add($filetext);
$content->add($getfilename);
$content->add($errmsg);
my %usedb = ();
foreach my $key ('main','search','xref') {
$usedb{$key}{'ctl'} = Gtk3::CheckButton->new_with_label("Include $key Database");
if ($key eq 'xref') {$usedb{$key}{'ctl'}->set_active(FALSE);}
else {$usedb{$key}{'ctl'}->set_active(TRUE);}
$content->add($usedb{$key}{'ctl'});
$usedb{$key}{'ctl'}->signal_connect(toggled =>
sub {
}
);
}
$content->show_all;
my $response = '';
while (!$response) {
$response = $dialog->run;
if ($response eq 'ok') {
$filespec = Strip($filetext->get_text());
if (!$filespec) {
my $font = 'face="DejaVu Sans Mono"';
my $size = 'size="18000"';
$size = '';
my $fg = 'foreground="red"';
my $weight = 'weight="bold" ';
$errmsg->set_markup ('<span ' . "$fg $font $size $weight " . '>' .
"Filename cannot be blank" . '</span>');
$response = '';
}
else {
if ((-e $filespec) and ($filespec ne $lastfilesave)) {
my $confirm = Gtk3::MessageDialog->new(
$dialog,
'modal',
'question', 'cancel',
"Overwrite existing  $filespec");
$confirm->add_button('overwrite','ok');
$response = $confirm->run;
if ($response eq 'yes') {
$request{'append'} = TRUE;
$response = 'ok';
}
$dialog->destroy;
}
}### filespec has been specified
}### response is OK
}### any response
if ($response eq 'ok') {
foreach my $key (keys %usedb) {
$request{$key} = $usedb{$key}{'ctl'}->get_active;
}
$request{'filespec'} = $filespec;
$lastfilesave = $filespec;
push @req_queue,{%request};
}### OK response
$dialog->destroy;
}### Save command
elsif ($command eq 'create') {
my %request = ('_cmd' => 'create', '_dbn' => $dbndx);
push @req_queue,{%request};
}
elsif ($command eq 'delete') {
if (get_selected($dbndx)) {
LogIt(1,"RADIOCTL l7226, No selected records to delete!");
}
else  {
my %request = ('_cmd' => 'batch', '_dbn' => $dbndx, '_type' => 'delete');
lock $response_pending;
$response_pending = TRUE;
show_long_run('please wait');
unshift @req_queue,{%request};
}
}### Delete process
elsif ($command eq 'edit'  ) {
my @editable = ('valid','sysno','groupno','mode','service');
if ($progstate =~ /chan/i) {@editable = ('valid');}
my $dialog = Gtk3::Dialog->new_with_buttons('Edit',
$panels{$dbndx}{'gtk'},
[qw/modal destroy-with-parent/],
'gtk-cancel' => 'cancel',
'gtk-ok' => 'ok',
);
my $content = $dialog->get_content_area();
if (get_selected($dbndx)) {
LogIt(1,"RADIOCTL l7226, No selected records to edit!");
}
else {
my %use = ();
my %value =();
foreach my $fld (@editable) {
if ($fld eq 'valid') {
$use{$fld}  = Gtk3::CheckButton ->new("Change $fld to =>");
$value{$fld} = Gtk3::CheckButton ->new("Valid");
}
else {
foreach my $key (@{$structure{$dbndx}}) {
if ($key eq $fld) {
$use{$fld} = Gtk3::CheckButton ->new("Change $fld to =>");
$value{$fld} = Gtk3::Entry->new;
last;
}
}### looking for key in this structure
}### not the VALID flag
if ($use{$fld}) {
$hbox[0] = Gtk3::Box->new('horizontal',5);
$hbox[0]->pack_start($use{$fld},FALSE,FALSE,0);
$hbox[0]->pack_start($value{$fld},FALSE,FALSE,0);
$content->add($hbox[0]);
}
}### Foreach field that can be edited
my $errmsg = Gtk3::Label->new();
$content->add($errmsg);
$content->show_all;
my $response = '';
while (!$response) {
$response = $dialog->run;
if ($response eq 'ok') {
my %request = ('_cmd' => 'batch',  '_dbn' => $dbndx, '_type' => 'edit');
foreach my $fld (keys %use) {
if ($use{$fld}->get_active()) {
if ($fld eq 'valid') {
$request{$fld} = $value{$fld}->get_active();
}
else {$request{$fld} = $value{$fld}->get_text();}
}
}### fill in the fields
lock $response_pending;
$response_pending = TRUE;
show_long_run('please wait');
unshift @req_queue,{%request};
}### response is OK
}
$dialog->destroy;
}### user selected something to edit
}
elsif ($command eq 'swap') {
if (get_selected($dbndx)) {
LogIt(1,"RADIOCTL l7226, No selected records to swap!");
}
else {
if (scalar @selected == 2) {
my %request = ('_cmd' => 'swap', '_dbn' => $dbndx );
push @req_queue,{%request};
}
else {
LogIt(1,"RADIOCTL l7419:Must have two and ONLY two records selected for SWAP");
}
}
}
elsif ($command eq 'xfer') {
if (get_selected($dbndx)) {
LogIt(1,"RADIOCTL l7226, No selected records to swap!");
}
else {
my %request = ('_cmd' => 'batch', '_dbn' => $dbndx, type => 'xfer' );
push @req_queue,{%request};
}
}
elsif ($command eq 'clear_db') {
my %request = ('_cmd' => 'clear', '_dbn' => $dbndx );
push @req_queue,{%request};
}
elsif ($command =~ /sort/) {
my %request = ('_cmd' => 'sort', '_dbn' => $dbndx, 'type' => $command );
push @req_queue,{%request};
}
elsif ($command eq 'renum') {
my %request = ('_cmd' => 'renum', '_dbn' => $dbndx );
push @req_queue,{%request};
}
elsif ($command eq 'quit') {quit_prog();}
else {LogIt(1,"MENU_OPS:need process for command $command");}
return 0;
}### menu ops
sub get_selected {
my $dbndx = shift @_;
@selected = ();
my $treeselection = $treeview{$dbndx}->get_selection();
my ($paths,$model) = $treeselection->get_selected_rows();
foreach my $pth (@{$paths}) {
my $row = $pth->to_string();
my $iter = $liststore{$dbndx}->get_iter_from_string($row);
my $index = $liststore{$dbndx}->get($iter,$col_xref{'index'});
push @selected,$index;
}
if (!scalar @selected) {return $EmptyChan;}
else {return $GoodCode;}
}
sub write_ini {
open INIFILE, '>' . $inifile or return;
foreach my $wndx (keys %w_info) {
$w_info{$wndx}{'init'} = FALSE;
foreach my $key (keys %{$w_info{$wndx}}) {
print INIFILE '$' . "w_info{$wndx}{$key} = ";
if ($w_info{$wndx}{$key}) {print INIFILE $w_info{$wndx}{$key}, "\n";}
else {print INIFILE "0\n";}
}
}
foreach my $dbndx (keys %col_active) {
foreach my $col (keys %{$col_active{$dbndx}}) {
print INIFILE '$col_active{' . $dbndx . '}{' . $col . '} =' . "$col_active{$dbndx}{$col}\n";
}
}
if ($lastdir) {
print INIFILE '$','lastdir = "', $lastdir, '"',"\n";
}
foreach my $dbndx (@dblist) {
}
close INIFILE;
}
sub read_ini {
open INIFILE, '<' . $inifile or return;
while (my $inrec = <INIFILE>) {
chomp $inrec;
if (substr($inrec,0,1) eq '$') {
eval $inrec;
}
}
close INIFILE;
}
sub view_ops {
my $widget = shift @_;
my $parms = shift @_;
my $winref = $parms->{'winref'};
my $wintype = $parms->{'wintype'};
my $winname = $parms->{'window'};
my $global = $parms->{'global'};
my $col    = $parms->{'col'};
if (!$col) {$col = '';}
if (!$winref) {LogIt(1,"VIEW_OPS:no winref for $winname!");return 0;}
my $active = $widget->get_active;
if (!$active) {$active = 0;}
if ($wintype eq 'treecol') {$winref->set_visible($active); }
else {
if ($active) {$winref->show_all;}
else {$winref->hide;}
}
if ($global) {
$$global = $active;
}
return 0;
}
sub close_window {
my ($window, $event, $dbndx) = @_;
if ($dbndx eq 'main') {quit_prog();}
else {$window_menu{$dbndx} -> set_active(FALSE);}
return TRUE;
}
sub numerically {
if (looks_like_number($a) and (looks_like_number($b))) {$a <=> $b;}
else {$a cmp $b;}
}
sub err_dialog {
my ($emsg,$type,$caller) = @_;
my $image = 'gtk-dialog-warning';
my $foreground = ' foreground="red" ';
if ($type eq 'info') {
$foreground  = ' foreground="green" ';
$image = 'gtk-dialog-info';
}
my $dialog = Gtk3::Dialog->new(
$type,
$panels{'main'}{'gtk'},
'modal',
'gtk-ok' => 'ok',
);
my $label = Gtk3::Label->new($emsg);
my $font = ' face="DejaVu Sans Mono" ';
$label->set_markup('<span '. $foreground  . $font .
'size="15000" weight="heavy" style="normal"' .
'>'.
$emsg .
'</span>');
my $icon = Gtk3::Image->new_from_stock($image,'dialog');
$dialog->get_content_area() ->add($icon);
$dialog->get_content_area() -> add($label);
$dialog->signal_connect(response =>sub {
$_[0]->destroy;
%scan_request = ();
$pop_up = FALSE;
});
$dialog->show_all;
$pop_up = TRUE;
return 1;
}
sub quit_prog {
LogIt(0,"$Bold Got $Green Quit$White request");
for (my $i=0;$i<MAXTIMER;$i++){
$timer[$i] = 0;
}
foreach  my $i (keys %panels) {
if ($panels{$i}{'type'} eq 'p') {next;}
my $pointer = $panels{$i}{'gtk'};
if (!defined $pointer) {next;}
($w_info{$i}{'xsize'},$w_info{$i}{'ysize'}) = $pointer->get_size;
($w_info{$i}{'xpos'},$w_info{$i}{'ypos'}) = $pointer->get_position;
}
write_ini();
foreach my $win (keys %panels) {
if ($panels{$win}{'type'} ne 'p') {$panels{$win}{'gtk'} -> hide;}
}
%gui_request = ('_cmd' => 'term');
%scan_request = ();
$gui_request{'_rdy'} = TRUE;
my $loopcnt = 500;
while ($scanner_thread){
%scan_request = ();
threads->yield;
usleep(10000);
if (!(--$loopcnt)) {
LogIt(1,"could not kill scanner thread");
goto QUIT_ANYWAY;
}
}
QUIT_ANYWAY:
foreach my $win (keys %panels) {
if ($panels{$win}{'type'} ne 'p') {$panels{$win}{'gtk'} ->destroy;}
}
Gtk3->main_quit;
return TRUE;
}
sub defunct {
return 0;
}
