#!/usr/bin/perl -w
package scanner;
require Exporter;
use constant FALSE => 0;
use constant TRUE => 1;
@ISA   = qw(Exporter);
@EXPORT = qw(
manual_state
) ;
use Data::Dumper;
use Text::ParseWords;
use threads;
use threads::shared;
use Thread::Queue;
use Time::HiRes qw( time usleep ualarm gettimeofday tv_interval );
use Scalar::Util qw(looks_like_number);
use radioctl;
use kenwood;
use bearcat;
use uniden;
use icom;
use aor8000;
use local;
my $debug = FALSE;
use strict;
use autovivification;
no  autovivification;
my $use_memory = FALSE;
my $opchanges = 0;
my $dont_update = FALSE;
my $delay_flag  = FALSE;
my $portobj;
my %database = ();
my %delete_count = ();
my %lockout = ();
my %known = ();
foreach my $dbndx (@dblist) {
clear_database($dbndx);
$delete_count{$dbndx} = 0;
}
my $sysno = 1;
my %radio_parms = ();
my $last_squelch = 0;
my $Resume = 6;
my $StateChange = 7;
my $SigKill = 8;
my @unsolicited = ();
return TRUE;
sub manual_state {
my $cmd;
my $parms;
$scanner_thread = TRUE;
add_message("Starting program Initialization...");
$vfo{'_seq'} = -1;
$vfo{'index'} = 0;
$vfo{'service'} = $initmessage;
my $recorder_thread = threads->create('record_thread');
%scan_request = ('_cmd' => 'init');
tell_gui(281);
if (!defined $vfo{'channel'}) {
LogIt(223,"SCANNER l223:VFO 'channel' not defined!");
}
MANUAL_START:
$vfo{'channel'} = $radio_def{'origin'};
$vfo{'index'} = 1;
$vfo{'freq'} = $radio_def{'minfreq'};
$vfo{'direction'} = 1;
radio_sync('init',227);
radio_sync('manual',383);
radio_sync('getvfo',249);
add_message('manual mode started');
while ($progstate ne 'quit') {
if ($response_pending) {$response_pending = FALSE;}
scanner_sync();
if ($progstate  eq   'scan_freq')          {
$control{'scanmem'} = FALSE;
scanning_state();
}
elsif ($progstate eq 'scan_chan') {
$control{'scanmem'} = TRUE;
scanning_state();
}
elsif ($progstate eq 'chanscan')       {chanscan_state();}
elsif ($progstate eq 'radioscan')      {radioscan_state();}
elsif ($progstate eq 'search')         {searching_state();}
elsif ($progstate eq 'bank')           {searching_state();}
elsif ($progstate eq 'load')           {loading_state();  }
elsif ($progstate eq 'set')            {setting_state();}
elsif ($progstate eq 'vfo2mem') {vfo2mem_mode();}
elsif ($progstate eq 'mem2vfo') {
add_message("code has not been written yet!",1);
set_manual_state();
}
elsif ($progstate eq 'quit') {
LogIt(0,"progstate now=quitting");
goto MANUAL_END;
}
elsif ($progstate eq 'manual') {
$vfo{'_seq'} = -1;
if ($control{'manlog'}) {$vfo{'_seq'} = 0;}
if ($radio_def{'active'}) {signal_check(284);}
}
else {LogIt(424,"MANUAL_STATE:Unknown progstate $progstate");}
scanner_sync();
while (scalar @unsolicited) {
my $qe = shift @unsolicited;
if ($qe->{'frequency'}) {
$vfo{'frequency'} = $qe->{'frequency'};
dply_vfo();
}
if ($qe->{'mode'}) {
$vfo{'mode'} = $qe->{'mode'};
dply_vfo();
}
}
usleep($usleep{'MANUAL'});
dply_vfo();
}### while progstate ne QUIT
MANUAL_END:
LogIt(0,"$Bold SCANNER_THREAD:Got $Green QUIT$White from GUI");
if ($recorder_thread) {$recorder_thread->join();}
$scanner_thread = FALSE;
return TRUE;
}
sub scanning_state {
my $starting_progstate = $progstate;
my $reason = '';
my $sev = 0;
if (!$radio_def{'active'}) {
$reason = 'Due To Radio not active';
$sev = 2;
goto SCAN_TERMINATE2
}
radio_sync('vfoinit',485);
if (!defined $database{'system'}[0]) {
LogIt(1,"SCANNING_STATE l397: called with no SYSTEM database defined!");
$database{'system'}[0]{'index'} = 0;
}
if (!defined $database{'group'}[0]) {
LogIt(1,"SCANNING_STATE l404: called with no GROUP database defined!");
$database{'group'}[0]{'index'} = 0;
}
if (scalar @{$database{'freq'}} < 3) {
$reason = 'Due To too few frequency records';
$sev = 2;
goto SCAN_TERMINATE2
}
my $nocount = 0;
while ($progstate eq $starting_progstate) {
my %selected = ();
foreach my $sysrec (@{$database{'system'}}) {
my $sysno = 0;
if ($sysrec->{'index'}) {$sysno = $sysrec->{'index'};}
else {next;}
if ($control{'scansys'} and $sysno and (!$sysrec->{'valid'})) {next;}
foreach my $grouprec (@{$database{'group'}}) {
my $groupno = 0;
if ($grouprec->{'index'}) {$groupno = $grouprec->{'index'};}
else {next;}
if ($control{'scangroup'} and $groupno and (!$grouprec->{'valid'})) {next;}
my $recndx = 0;
if ($vfo{'direction'} < 0) {$recndx = scalar @{$database{'freq'}};}
while (TRUE) {
$recndx = $recndx + $vfo{'direction'};
if (($recndx < 1) or ($recndx > scalar @{$database{'freq'}}) ) {last;}
threads->yield;
scanner_sync();
if ($progstate ne $starting_progstate) {
$reason = "State change from $starting_progstate to $progstate";
goto SCAN_TERMINATE2;
}
my $freqrec = $database{'freq'}[$recndx];
if (!$freqrec->{'index'}) {next;}
if ($selected{$recndx}) {delete $selected{$recndx}};
if (!$freqrec->{'valid'}) {next;}
if ($control{'scansys'} and ($freqrec->{'sysno'} ne $sysno)) {next;}
if ($control{'scangroup'} and ($freqrec->{'groupno'} ne $groupno)) {next;}
if ($control{'stop'} and ($freqrec->{'index'} > $control{'stop_value'})) {next;}
if ($control{'start'} and ($freqrec->{'index'} < $control{'start_value'})) {next;}
my $cmd = 'setvfo';
if ($control{'scanmem'}) {
$cmd = 'selmem';
}### scanning memory channels
else {
if ($freqrec->{'frequency'} > $radio_def{'maxfreq'}) {next;}
if ($freqrec->{'frequency'} < $radio_def{'minfreq'}) {next;}
foreach  my $key ('frequency','mode','atten','service') {
$vfo{$key} = $freqrec->{$key};
}
}### Scanning the Frequencies
$selected{$recndx} = TRUE;
$vfo{'channel'} = $freqrec->{'channel'};
$vfo{'index'} = $freqrec->{'index'};
$vfo{'_seq'} = $freqrec->{'index'};
$vfo{'groupno'} = $groupno;
$vfo{'sysno'} = $sysno;
dply_vfo();
if (!radio_sync($cmd,479)) {
signal_check();
}
}### For each Freq
}### for each group
}### For each system
if ((scalar keys %selected) < 2) {
$reason = 'Not enough valid records to scan';
$sev = 2;
goto SCAN_TERMINATE2;
}
else {$nocount= 0;}
}### Loop forever
SCAN_TERMINATE2:
$vfo{'channel'} = $radio_def{'origin'};
$vfo{'index'} = 1;
$vfo{'dlyrsm'} = 0;
$vfo{'vrsm'} = 0;
$vfo{'vdly'} = 0;
$vfo{'service'} = '';
add_message("Scanning mode terminated $reason",$sev);
LogIt(0,"SCANNER.PM:Scanning mode terminated due to $Yellow$reason");
dply_vfo(438);
if ($progstate eq $starting_progstate) {set_manual_state();}
return $GoodCode ;
}
sub chanscan_state {
my $starting_progstate = $progstate;
my $reason = '';
if ((defined $radio_def{'memory'})  and ($radio_def{'memory'} eq 'dy')) {
pop_up("This radio model does not support Channel Scan!");
add_message("Channel Scan ended due to radio incompatiblity",2);
set_manual_state();
return $NotForModel;
}
my $channel = 1;
my $maxchan = $radio_def{'maxchan'};
if ($radio_def{'group'}) {
$maxchan = $radio_def{'maxchan'} * $radio_def{'maxigrp'};
}
if (!$radio_def{'origin'}) {$maxchan++;}
print "CHANSCAN_STATE l620:Radioctl Maximum channel scan is $maxchan\n";
if ($control{'start'}) {$channel = $control{'start_value'};}
if ($channel > $maxchan) {### No good for this radio
pop_up("START channel number $channel is to large for this radio. Maximum is $maxchan)");
add_message("Channel Scan ended due to bad channel START selection",2);
set_manual_state();
return $ParmErr;
}
if ($control{'stop'}) {
if (($control{'stop'} - $channel) > 2) {
pop_up("STOP channel number $channel must be at LEAST 1 more than START");
add_message("Channel Scan ended due to bad channel STOP selection",2);
set_manual_state();
return $ParmErr;
}
}
while (TRUE) {
$vfo{'channel'} = $channel;
dply_vfo();
threads->yield;
scanner_sync();
if ($progstate ne $starting_progstate) {
last;
}
radio_sync('selmem',867);
$vfo{'_seq'} = 0;
if ($vfo{'frequency'}) {signal_check(744);}
my $newchan = $channel + $vfo{'direction'};
if ($control{'stop'}) {
if ($newchan > $control{'stop_value'}) {
if ($control{'start'}) {$newchan = $control{'start_value'};}
else {$newchan = 1;}
}
}### Stop used
else {
if ($newchan > $maxchan) {
if ($control{'start'}) {$newchan = $control{'start_value'};}
else {$newchan = 1;}
}
}### stop not used
if ($control{'start'}) {
if ($newchan < $control{'start_value'}) {
if ($control{'stop'}) {$newchan = $control{'stop_value'};}
else {$newchan = $maxchan;}
}
}### Start used
else {
if ($newchan < 1) {
if ($control{'stop'}) {$newchan =  $control{'stop_value'};}
else {$channel = $maxchan;}
}
}
if ($newchan == $channel) {
LogIt(1,"Newchan = $newchan channel= $channel ");
$reason = "due to no channels within ranges";
goto CHANSCAN_TERMINATE;
}
$channel = $newchan;
}
CHANSCAN_TERMINATE:
$vfo{'channel'} = $radio_def{'origin'};
$vfo{'index'} = 1;
$vfo{'_seq'} = 1;
$vfo{'delay'} = 0;
$vfo{'resume'} = 0;
$vfo{'service'} = '';
add_message("ChanScan mode terminated $reason");
dply_vfo(788);
if ($progstate eq $starting_progstate) {set_manual_state();}
return $GoodCode;
}
sub radioscan_state {
my $starting_progstate = $progstate;
my $reason = '';
if (!$radio_def{'radioscan'}) {
pop_up("This radio model does not support Radio Scan!");
add_message("Radio Scan ended due to radio incompatiblity",2);
set_manual_state();
return $NotForModel;
}
elsif ($radio_def{'radioscan'} == 1) {
pop_up("please press SCAN on radio to start...");
}
else {radio_sync('scan',727);}
my $index = 0;
my $statstring = '--scanning';
my $dlytime = time();
while (TRUE) {
threads->yield;
scanner_sync();
if ($progstate ne $starting_progstate) {
$reason = "Scan state changed from $starting_progstate to $progstate";
last;
}
my $dply = substr("$statstring$statstring",$index,4);
$vfo{'chandply'} = $dply;
$vfo{'service'} = '';
dply_vfo(782);
my $delta = int( (time() - $dlytime) * 10);
if ($delta) {
$index++;
$dlytime = time();
}
if ($index > length($statstring)) {$index = 0;}
$vfo{'_seq'} = 0;
my $sigcode = signal_check(1079);
if ($sigcode == $StateChange) {
$reason = "Mode change from $starting_progstate to $progstate line 888";
goto RADIOSCAN_TERMINATE;
}
if ($sigcode == $CommErr) {
$reason = "radio disconnected line 754";
goto RADIOSCAN_TERMINATE;
}
@unsolicited = ();
usleep($usleep{'SCAN'});
}### waiting for radio loop
RADIOSCAN_TERMINATE:
if ($radio_def{'radioscan'} == 1) {
pop_up("please press the scan stop button on the radio...");
}
$vfo{'channel'} = $radio_def{'origin'};
$vfo{'chandply'} = '';
$vfo{'index'} = 1;
$vfo{'_seq'} = 1;
$vfo{'delay'} = 0;
$vfo{'resume'} = 0;
$vfo{'service'} = '';
radio_sync('manual',1043);
add_message("RadioScan mode terminated due to $reason");
dply_vfo(788);
if ($progstate eq $starting_progstate) {set_manual_state();}
return $GoodCode;
}
sub searching_state {
my $starting_progstate = $progstate;
my $rsm = 0;
my $dly = 0;
my $freq = $vfo{"frequency"};
my $mode = $vfo{"mode"};
my $step = $vfo{"step"};
$vfo{'service'} = '';
$vfo{'direction'} = 1;
my $bank = 0;
my $index = 0;
my $statstring = '--Searching';
my $dlytime = time();
my $reason = '';
SEARCH_START:
add_message("$progstate Started...");
radio_sync('init',850);
radio_sync('vfoinit',851);
if (!$radio_def{'active'}) {
$reason = "search State ended due to radio failure";
goto SEARCH_END;
}
if (!$radio_def{'minfreq'}) {
LogIt(797,"No minimum frequency defined for this radio!");
}
if (!$radio_def{'maxfreq'}) {
LogIt(797,"No maximum frequency defined for this radio!");
}
$use_memory = 0;
%lockout = ();
foreach my $rec (@{$database{'freq'}}) {
if (!$rec->{'index'}) {next;}
my $freq = $rec->{'frequency'};
if (!$freq) {next;}
if (!$rec->{'valid'}) {$lockout{Strip($freq)} = TRUE;}
}
while ($progstate eq $starting_progstate) {
scanner_sync();
if ($progstate ne $starting_progstate) {goto SEARCH_END;}
my $dply = substr("$statstring$statstring",$index,4);
$vfo{'chandply'} = $dply;
my $delta = int( (time() - $dlytime) * 10);
if ($delta) {
$index++;
$dlytime = time();
}
if ($index > length($statstring)) {$index = 0;}
if ($progstate eq 'search') {
if (!$control{'step'}) {
$reason = "search mode ended due to step = 0!";
goto SEARCH_END;
}
while (scalar @unsolicited) {
my $qe = shift @unsolicited;
if ($qe->{'frequency'}) {
$freq = $qe->{'frequency'};
}
if ($qe->{'mode'}) {
vfo{'mode'} = $qe->{'mode'};
dply_vfo();
}
}### reading unsolicited messages
}
elsif ($progstate eq 'bank') {
my $loopcnt = 3;
while (!$database{'search'}[$bank]{'valid'} or !$database{'search'}[$bank]{'index'}) {
$freq = 0;
$bank++;
if ($bank > $#{$database{'search'}}) {
$bank = 1;
$loopcnt --;
if (!$loopcnt) {
$reason = "search mode ended due to no valid search banks";
goto SEARCH_END;
}
}### rollover for valid search bank
}### look for a valid bank
if (!$freq) {
my $lowf = $database{'search'}[$bank]{'lowfreq'};
my $hif = $database{'search'}[$bank]{'highfreq'};
if ($vfo{'direction'} > 0) {
if ($lowf <= $hif) {$freq = $lowf;}
else {$freq = $hif;}
}
else {
if ($hif <= $lowf) {$freq = $hif;}
else {$freq = $lowf;}
}
}
my $step = $database{'search'}[$bank]{'step'};
if (!$step) {
$reason = "search mode ended due to bank $bank having step size of 0!";
goto SEARCH_END
}
{
lock %control;
$control{'step'} = $step;
}
$vfo{'mode'} = $database{'search'}[$bank]{'mode'};
$vfo{'bank'} = $bank;
@unsolicited = ();
}### bank process
else {
LogIt(1,"$progstate search is not implemented!");
$reason = "search mode ended due to unsupported progstate=>$progstate";
goto SEARCH_END;
}
if (!$freq) {
LogIt(1,"Detected 0 frequency. Setting to minimum");
$freq = 30000000;
}
$vfo{'frequency'} = $freq;
my $chsave = $vfo{'channel'};
my $radio_code = 0;
if ($lockout{$freq}) {
}
else {
dply_vfo(783);
$radio_code = radio_sync('setvfo',843);
$vfo{'channel'} = $chsave;
my $sigcode = 0;
$vfo{'_seq'} = 0;
$sigcode = signal_check(976);
if ($sigcode == $StateChange) {
$reason = "search mode ended due to State Change during signal_check";
goto SEARCH_END;
}
if ($sigcode == $CommErr) {
$reason = "radio disconnected!";
goto SEARCH_END;
}
}### Not bypassing this frequency
if ($progstate ne $starting_progstate) {goto SEARCH_END;}
if ($progstate eq 'bank') {$freq = $freq + $control{'step'};}
else {$freq = $freq + ($control{'step'} * $vfo{'direction'});}
if ($freq > $radio_def{'maxfreq'}) {$freq = $radio_def{'minfreq'};}
if ($freq < $radio_def{'minfreq'}) {$freq = $radio_def{'maxfreq'};}
if ($progstate eq 'bank') {
my $lowf = $database{'search'}[$bank]{'lowfreq'};
my $hif = $database{'search'}[$bank]{'highfreq'};
if ($lowf <= $hif) {
if (($freq < $lowf) or ($freq > $hif)) {
$bank++;
$freq = 0;
}
}
else {
if (($freq > $lowf) or ($freq < $hif)) {
$bank++;
$freq = 0;
}
}
}### bank post process
}
SEARCH_END:
if ($reason) {add_message($reason,1);}
else {add_message("Search terminated");}
$vfo{'channel'} = 0;
$vfo{'chandply'} = '';
$vfo{'dly'} = 0;
$vfo{'rsm'} = 0;
$vfo{'service'} = '';
dply_vfo(993);
if ($progstate eq $starting_progstate) {set_manual_state();}
}
sub loading_state {
if ((defined $radio_def{'memory'}) and ($radio_def{'memory'} eq 'ro')) {
pop_up("This radio model does not support LOAD process!");
add_message("LOAD ended due to radio incompatiblity",2);
set_manual_state();
return $NotForModel;
}
my $ch;
my $stepsave;
my $starting_progstate = $progstate;
my $reason = '';
$response_pending = TRUE;
LOADING_START:
add_message("Loading State Started...");
$stepsave = $vfo{"step"};
radio_sync('init',1151);
if (!$radio_def{'active'}) {
$reason = "Loading ended due to radio failure";
goto LOADING_END;
}
if ($control{'clear'}) {
foreach my $dbndx (@dblist) {
clear_database($dbndx);
%scan_request = ('_cmd' => 'clear', '_dbn' => $dbndx);
tell_gui(2937);
{
lock(%gui_request);
%gui_request = ();
}
threads->yield;
}
}
if ($progstate ne $starting_progstate) {goto LOADING_END;}
scanner_sync();
if ($progstate ne $starting_progstate) {goto LOADING_END;}
radio_sync('getmem',1118);
if ($progstate ne $starting_progstate) {goto LOADING_END;}
radio_sync('getglob',1111);
LOADING_END:
$vfo{"step"} = $stepsave;
$vfo{'channel'} = 0;
$vfo{'service'} = '';
dply_vfo(1246);
if ($reason) {add_message($reason,1);}
else {add_message("Loading ended normally...");}
if ($progstate eq $starting_progstate) {set_manual_state();}
return $GoodCode;
}
sub setting_state {
return $GoodCode;
my $starting_progstate = $progstate;
my $reason = '';
if ((defined $radio_def{'memory'}) and (
($radio_def{'memory'} eq 'ro') or ($radio_def{'memory'} eq 'no'))) {
pop_up("This radio model does not support SET process!");
add_message("SET ended due to radio incompatiblity",2);
set_manual_state();
return $NotForModel;
}
$response_pending = TRUE;
add_message("Set Entered...");
scanner_sync();
if ($progstate ne $starting_progstate) {goto SAVING_END;}
radio_sync('init',1235);
if (!$radio_def{'active'}) {
$reason = "SET ended due to radio failure";
goto SAVING_END;
}
if (radio_sync('setmem',1081)) {
$reason = "setmem failure";
}
SAVING_END:
$vfo{'channel'} = 0;
$vfo{'service'} = '';
dply_vfo(1074);
if ($reason) {add_message($reason,1);}
else {add_message("Set ended normally...");}
if ($progstate eq $starting_progstate) {set_manual_state();}
return $GoodCode;
}
sub vfo2mem_mode {
$response_pending = TRUE;
my $starting_progstate = $progstate;
add_message("VFO To Memory Started...");
if ($control{'useradio'}) {
if ($radio_def{'protocol'} eq 'uniden') {
}
else {
if (($vfo{'channel'} > $radio_def{'maxchan'}) or ($vfo{'channel'} < $radio_def{'origin'})) {
add_message("VFO to Memory ended. Channel is out of range of the radio!");
goto VFO2MEM_END;
}
}
if (($vfo{'frequency'} > $radio_def{'maxfreq'}) or ($vfo{'frequency'} < $radio_def{'minfreq'})) {
add_message("VFO to Memory ended. Frequency is out of range of the radio!");
goto VFO2MEM_END;
}
my %vfo_save = %vfo;
radio_sync('init',1285);
if (!$radio_def{'active'}) {
add_message("VFO to Memory ended due to radio failure",1);
goto VFO2MEM_END;
}
%vfo = %vfo_save;
radio_sync('vfo2mem',1290);
}
else {
my $maxrec = $#{$database{'freq'}};   
if ((!$vfo{'channel'}) or ($vfo{'channel'} > $maxrec)) {
my $maxchan = 0;
foreach my $rec (@{$database{'freq'}}) {
if (!$rec->{'index'}) {next;}
if ($rec->{'channel'} and ($rec->{'channel'} > $maxchan)) {$maxchan = $rec->{'channel'};}
}
$vfo{'channel'} = ++$maxchan;
print "Scanner4 l1298:Creating a new record\n";
my %newrec = ('frequency' => $vfo{'frequency'},
'mode' => $vfo{'mode'}, 'valid' => TRUE, 'channel' => $vfo{'channel'},
'tone_type' => $vfo{'tone_type'}, 'tone' => $vfo{'tone'},
'service' => "",);
KeyVerify(\%newrec,@{$structure{'freq'}});
$vfo{'_seq'} = add_a_record(\%database,'freq',\%newrec,\&add_shadow);
}#### Add a new channel
else {
my $chan = $vfo{'channel'};
%scan_request = ('_cmd' => 'update', '_dbn' => 'freq','_seq' => $chan);
if ($vfo{'frequency'} ne $database{'freq'}[$chan]{'frequency'}) {
foreach my $key ('signal','count','duration') {
$database{'freq'}[$chan]{$key} = 0;
$scan_request{$key} = 0;
}
$database{'freq'}[$chan]{'timestamp'} = '';
$scan_request{'timestamp'} = '';
$database{'freq'}[$chan]{'valid'} = TRUE;
$scan_request{'valid'} = TRUE;
}
foreach my $key ('frequency','mode','channel','tone','tone_type') {
$database{'freq'}[$chan]{$key} = $vfo{$key};
$scan_request{$key} = $vfo{$key};
}
tell_gui(1318);
}### update existing channel
}### use RadioCtl memory
VFO2MEM_END:
add_message("VFO 2 Memory Ended...");
if ($progstate eq $starting_progstate) {set_manual_state();}
return $GoodCode;
}
sub signal_check {
my $retcode = $GoodCode;
my $caller = shift @_;
my $recorder = '';
if (!defined $vfo{'channel'}) {LogIt(1773,"Signal Check l1773: VFO channel undefined. Caller->$caller");}
my $ontime  = 0;
my $offtime = 0;
my $duration = 0;
my $chkcount = 0;
my $resume = 0;
my $delay = 0;
$vfo{'resume'} = 0;
$vfo{'delay'} = 0;
$vfo{'vrsm'} = FALSE;
$vfo{'vdly'} = FALSE;
my $lastfreq = 0;
my %loginfo = ();
my $dbndx = 'freq';
my $entry_progstate = $progstate;
my $starttime = Time::HiRes::time();
SIGLOOP:
while (TRUE) {
if (!$radio_def{'active'}) {
$retcode = $CommErr;
LogIt(1,"Radio is not active");
goto END_SIGNAL;
}
threads->yield;
$retcode = scanner_sync();
if ($retcode) {
goto END_SIGNAL;
}
if ($entry_progstate ne $progstate) {### new program state
LogIt(1,"Signal_Check l1585:State change from $entry_progstate to $progstate!");
$retcode = $StateChange;
goto END_SIGNAL;
}
if (($vfo{'_seq'} > 0) and
(!$database{$dbndx}[$vfo{'_seq'}]{'valid'} or !$database{$dbndx}[$vfo{'_seq'}]{'index'})) {
%loginfo = ();
$retcode = $EmptyChan;
LogIt(0,"Signal_Check l1545:Signal check ended due to !VALID on $vfo{'index'}");
goto END_SIGNAL;
}
radio_sync('getsig',1414);### get any signal value from the radio
$chkcount++;
if ($vfo{'signal'} and squelch_level(1411)) {
LogIt(0,"SCANNER l1824:Squelch suppressed signal check");
goto END_SIGNAL;
}
if ($vfo{'signal'}) {
dply_vfo(1573);
$starttime = Time::HiRes::time();
$delay = 0;
$vfo{'delay'}  = 0;
$vfo{'vdly'} = FALSE;
$vfo{'chandply'} = '';
$offtime = 0;
if ($control{'manlog'} or ($progstate ne 'manual'))   {
if (($vfo{'_seq'} == 0)) {
my $maxchan = -1;
if (!$vfo{'mode'}) {
LogIt(1,"SCANNER L1899:VFO Mode is empty!");
$vfo{'mode'} = 'FMn';
}
foreach my $rec (@{$database{$dbndx}}) {
if (!$rec->{'index'}) {next;}
if (!looks_like_number($rec->{'channel'})) {
LogIt(1,"Channel number for $rec->{'index'} => $rec->{'channel'}");
next;
}
if ($rec->{'channel'} > $maxchan) {$maxchan = $rec->{'channel'};}
if ($progstate eq 'radioscan') {
if ($rec->{'tgid_valid'} and $vfo{'tgid'}) {
if (!$rec->{'tgid'} or ($vfo{'tgid'} ne $rec->{'tgid'})) {next;}
}
elsif ($rec->{'service'}) {
if ($rec->{'service'} ne $vfo{'service'}) {next;}
}
else {
if ($rec->{'frequency'} != $vfo{'frequency'}) {next;}
if (lc($rec->{'mode'}) ne lc($vfo{'mode'})) {next;}
}
}### progstate eq 'radioscan'
elsif ($progstate eq 'chanscan') {
if ($rec->{'channel'} ne $vfo{'channel'}) {next;}
}
else {
if ($rec->{'frequency'} != $vfo{'frequency'}) {
next;}
if (lc($rec->{'mode'}) ne lc($vfo{'mode'})) {
LogIt(0,"SCANNER l1926:rec:$rec->{'mode'} ne vfo:$vfo{'mode'}");
next;}
}
if (!$rec->{'valid'}) {
%loginfo = ();
$retcode = $EmptyChan;
goto END_SIGNAL;
}
$vfo{'_seq'} = $rec->{'index'};
$vfo{'index'} = $vfo{'_seq'};
$vfo{'service'} = $rec->{'service'};
$vfo{'tgid'} = $rec->{'tgid'};
}
if (!$vfo{'_seq'}) {
my $sysno = 0;
foreach my $rcd (@{$database{'system'}}) {
if ($rcd->{'index'}) {
$sysno = $rcd->{'index'};
last;
}
}
if (!$sysno) {
my %newrec = ('service' => 'Autolog System', 'systemtype' => 'cnv', 'valid' => TRUE);
$sysno = add_a_record(\%database,'system',\%newrec,\&add_shadow);
}
my $groupno = 0;
foreach my $rcd (@{$database{'group'}}) {
if ($rcd->{'index'}) {
$groupno = $rcd->{'index'};
last;
}
}
if (!$groupno) {
my %newrec = ('service' => 'Autolog Group', 'sysno' => $sysno, 'valid' => TRUE);
$groupno = add_a_record(\%database,'group',\%newrec,\&add_shadow);
}
$maxchan++;
my $freq = $vfo{'frequency'} + 0;
my %newrec = ('frequency' => $freq,
'mode' => $vfo{'mode'}, 'valid' => TRUE, 'channel' => $maxchan,
'tone_type' => $vfo{'tone_type'}, 'tone' => $vfo{'tone'},
'atten' => $vfo{'atten'},
'sysno' => $sysno, 'groupno' => $groupno,
'timestamp' => time(), 'signal' => $vfo{'signal'},
'service' => "",'tgid' => '');
if ($vfo{'service'} and ($vfo{'service'} ne $initmessage)) {$newrec{'service'} = $vfo{'service'};}
elsif ($known{$freq}) {$newrec{'service'} = $known{$freq};}
else  {$newrec{'service'} = 'Found '. Time_Format(time()) . '. Signal:' . $vfo{'signal'};}
if ($vfo{'tgid'}) {$newrec{'tgid'} = $vfo{'tgid'};}
if ($progstate eq 'chanscan') {$newrec{'channel'} = $vfo{'channel'};}
$loginfo{'service'} = $newrec{'service'};
KeyVerify(\%newrec,@{$structure{$dbndx}});
$vfo{'index'} = add_a_record(\%database,$dbndx,\%newrec,\&add_shadow);
$vfo{'_seq'} = $vfo{'index'};
%newrec = ();
}### Add a new record
}### Search for a database record
if ($vfo{'service'} eq $initmessage) {$vfo{'service'} = '';}
foreach my $key ('signal','frequency','mode','service','channel','rssi','dbmv','meter') {
$loginfo{$key} = $vfo{$key};
}
if ($vfo{'_seq'} > 0) {
$chan_active{'freq'} = $vfo{'_seq'};
%scan_request = ('_cmd' => 'update', '_dbn' => 'freq', '_seq' => $vfo{'_seq'},
'tone' => $vfo{'tone'}, 'tone_type' => $vfo{'tone_type'},
'signal' =>$vfo{'signal'});
tell_gui(1598);
}
}### Not in MANUAL mode
if (!$ontime) {
$ontime = time();
$loginfo{'init_time'} = $ontime;
$vfo{'vrsm'} = FALSE;
$vfo{'resume'} = 0;
$resume = 0;
if (!$lastfreq) {$lastfreq = $vfo{'frequency'};}
if ($control{'recorder'} and (!$recorder)) {
my $outfile =  Strip(rc_to_freq($vfo{'frequency'})) . ".wav";
if ($vfo{'tgid'}) {
$outfile = Strip($vfo{'tgid'}) . '-' . Strip($vfo{'service'}) . ".wav";
}
$outfile =~ s/\//_/g;   
$outfile =~ s/\&/and/g; 
if (! -e $settings{'recdir'}) {mkdir $settings{'recdir'};}
$record_file = "$settings{'recdir'}/$outfile";
$outfile = undef;
$start_recording = TRUE;
threads->yield;
}### Starting the recorder function
$vfo{'resume'} = 0;
$vfo{'vrsm'} = FALSE;
$resume = 0;
if ($progstate eq 'manual') {next SIGLOOP;}
if ($control{'dlyrsm'}) {
if ($progstate eq 'radioscan') {
}
elsif (($vfo{'_seq'} > 0) and ($database{$dbndx}[$vfo{'_seq'}]{'dlyrsm'} < 0)) {
$resume = abs($database{$dbndx}[$vfo{'_seq'}]{'dlyrsm'});
$vfo{'resume'} = int($resume);
$vfo{'vrsm'} = TRUE;
}
elsif ($control{'dlyrsm_value'} < 0) {
$resume = abs($control{'dlyrsm_value'});
$vfo{'resume'} = int($resume);
$vfo{'vrsm'} = TRUE;
}
else {
}
}### Resume control enabled
$ontime = time();
}### First signal on process
else {
if ($vfo{'vrsm'}) {
my $delta = int(time() - $ontime);
$vfo{'resume'} = $resume - $delta;
dply_vfo(1824);
if ($vfo{'resume'} < 1) {goto END_SIGNAL;}
}
}
dply_vfo(1582);
}#### signal present
else {### signal is now off
$vfo{'resume'} = 0;
$vfo{'vrsm'} = FALSE;
$resume = 0;
if ($progstate eq 'manual') {goto END_SIGNAL;}
elsif ($progstate eq 'radioscan') {goto END_SIGNAL;}
if (!$offtime) {
$offtime = time();
if ($ontime) {
LogIt(0,"SCANNER l1872:Signal went off for $database{$dbndx}[$vfo{'_seq'}]{'channel'}");
$duration = $duration + (time() - $ontime);
my $starttime = Time::HiRes::time();
if ($control{'dlyrsm'}) {
if (($vfo{'_seq'} > 0) and ($database{$dbndx}[$vfo{'_seq'}]{'dlyrsm'} > 0)) {
$delay = abs($database{$dbndx}[$vfo{'_seq'}]{'dlyrsm'});
$vfo{'delay'} = $delay;
$vfo{'vdly'} = TRUE;
}
elsif ($control{'dlyrsm_value'} > 0) {
$delay = abs($control{'dlyrsm_value'});
$vfo{'delay'} = $delay;
$vfo{'vdly'} = TRUE;
}
else {
}
}### control enabled
dply_vfo(1614);
}#### Signal was on, but now is off
else {
if ($control{'speed'}) {
usleep int($control{'speed'}/10);
next SIGLOOP;
}
goto END_SIGNAL;
}
}### first off pass
$ontime = 0;
if ($vfo{'vdly'}) {### delay being done
my $delta = int(time() - $offtime);
$vfo{'delay'} = $delay - $delta;
dply_vfo(1903);
if ($vfo{'delay'} < 1) {goto END_SIGNAL;}
else {next SIGLOOP;}
}
else {
if ($control{'speed'}) {
my $elapsed = 100 * (Time::HiRes::time() - $offtime);
if ($elapsed < $control{'speed'}) {
usleep int($control{'speed'}/10);
next SIGLOOP;
}
}
goto END_SIGNAL;
}
}### Signal is OFF
}### Forever loop
END_SIGNAL:
$start_recording = FALSE;
if ($chan_active{'freq'} > 0) {
$chan_active{'freq'} = 0;
}
if ($ontime) {
$duration = $duration + (time() - $ontime);
dply_vfo(1930);
}
$duration = sprintf("%4.1f",$duration);
if ($vfo{'signal'}) {### Is signal still on?
$vfo{'signal'} = 0;
$vfo{'sql'} = FALSE;
dply_sig(1846);
}
if ($loginfo{'frequency'}) {### something happened
$chan_active{'freq'} = 0;
my $msg = Time_Format($loginfo{'init_time'}) . ' ' .
rc_to_freq($loginfo{'frequency'}) . 'mhz ' .
$loginfo{'mode'} . ' ' .
"signal:$loginfo{'signal'} " .
"rssi:$loginfo{'rssi'} " .
"dbmv:$loginfo{'dbmv'} " .
"meter:$loginfo{'meter'} " .
"duration:" . $duration . " secs " .
$loginfo{'service'}
;
LogIt(0,"$Green$msg");
$loginfo{'duration'} = $duration;
if (write_log(\%loginfo)) {
%scan_request = ('_cmd' => 'logoff');
tell_gui(2416);
}
if ($vfo{'_seq'} > 0) {
if ($loginfo{'init_time'}) {
$database{'freq'}[$vfo{'_seq'}]{'timestamp'} = $loginfo{'init_time'};
}
my $total_duration =  $database{'freq'}[$vfo{'_seq'}]{'duration'} + $duration;
if (looks_like_number($total_duration)) {$total_duration = sprintf("%10.1f",$total_duration);}
$database{'freq'}[$vfo{'_seq'}]{'duration'} = $total_duration;
$database{'freq'}[$vfo{'_seq'}]{'count'} =
$database{'freq'}[$vfo{'_seq'}]{'count'} + 1;
$database{'freq'}[$vfo{'_seq'}]{'signal'} = $loginfo{'signal'};
%scan_request = ('_cmd' => 'update', '_dbn' => 'freq', '_seq' => $vfo{'_seq'});
foreach my $key ('timestamp','duration','signal','count') {
if ($database{'freq'}[$vfo{'_seq'}]{$key}) {
$scan_request{$key} =  $database{'freq'}[$vfo{'_seq'}]{$key};
}
}
tell_gui(1665);
}
}
$vfo{'vdly'} = FALSE;
$vfo{'delay'} = 0;
$vfo{'vrsm'} = FALSE;
$vfo{'resume'} = 0;
%loginfo = ();
$duration = undef;
%scan_request = ();
return $retcode;
}
sub open_serial {
%scan_request = ('_cmd' => 'radio','connect' => 'connecting');
tell_gui(1981);
if ($portobj) {$portobj -> close;}
$radio_def{'active'} = FALSE;
$radio_def{'unresponsive'} = FALSE;
if (!$radio_def{'port'}) {
print Dumper(%radio_def);
LogIt(2173,"OPEN_SERIAL:No value for radio port!");
}
my $port = $radio_def{'port'};
if ($port ne '(none)') {
$portobj = Device::SerialPort->new($port) ;
if (!$portobj) {
LogIt(1,"OPEN_SERIAL:Cannot connect to port $port");
add_message("cannot connect to $port",1);
return FALSE;
}
else {
$portobj->user_msg("ON");
$portobj->databits(8);
$portobj->baudrate($radio_def{'baudrate'});
$portobj->parity($radio_def{'parity'});
$portobj->stopbits($radio_def{'stopbits'});
$portobj->handshake($radio_def{'handshake'});
$portobj->read_const_time(100);
$portobj->read_char_time(0);
$portobj->write_settings || undef $portobj;
}
}
else {
if ($radio_def{'protocol'} ne 'local') {
LogIt(1,"OPEN_SERIAL:Port of $port is not valid for this protocol");
add_message("Port $port is not valid for this protocol",1);
return FALSE;
}
}
$radio_def{'active'} = TRUE;
return TRUE;
}
sub radio_sync {
my $cmd = shift @_;
my $caller = shift @_;
if (!$radio_def{'active'} and ($cmd ne 'autobaud')) {return $CommErr;}
if (!defined $vfo{'channel'}) {
print Dumper(%vfo),"\n";
LogIt(2270,"RADIO_SYNC:VFO channel not set! Caller=$caller");
}
my $tries = 2;
my $protocol = '';
while ($tries) {
$protocol = $radio_def{'protocol'};
if (!$protocol) {
LogIt(1,"RADIO_SYNC l2373:Got undefined protocol. Retry after wait");
threads->yield;
sleep 1;
$tries--;
}
else {last;}
}
if (!$protocol) {
LogIt(1,"RADIO_SYNC l2382:Undefined protocol. Terminating RADIO_SYNC");
return $ParmErr;
}
delete $vfo{'_rdy'};
my %out = ();
my %in  = ();
my $ch = $vfo{'channel'};
my $freq = $vfo{'frequency'};
my  %radio_parms = (
'out'      => \%out,
'in'       => \%in,
'sysno'    => $sysno,
'portobj'  => $portobj,
'msg'      => \&add_message,
'def'      => \%radio_def,
'rsp'      => FALSE,
'rc'       => $GoodCode,
'progstate' => $progstate,
'database' => \%database,
'gui'      => \&add_shadow,
'cmd'      => $cmd,
'term'     => FALSE,
'unsolicited' => \@unsolicited,
'delay' => $usleep{'SIGNAL'},
);
if ($cmd eq 'setvfo') {
$in{'mode'} = $vfo{'mode'};
if (!$freq) {
if ($radio_def{'minfreq'}) {
LogIt(1,"RADIOSYNC l2184:Frequency is 0! Caller=$caller. Set to minfreq");
if (!$radio_def{'minfreq'}) {
print Dumper(%radio_def),"\n";
LogIt(2245,"Missing Minfreq");
}
$freq = $radio_def{'minfreq'};
}
else {
LogIt(1,"RADIOSYNC l 2188:No 'minfreq' defined in radio_def!");
$freq = 30000000;
}
}
my $notvalid = FALSE;
if ($freq > $radio_def{'maxfreq'}) {$notvalid = TRUE;}
elsif ($freq < $radio_def{'minfreq'}) {$notvalid = TRUE;}
elsif ($radio_def{'gap1_low'} and
($freq >= $radio_def{'gap1_low'}) and
($freq < $radio_def{'gap1_high'})) { $notvalid = TRUE;}
elsif ($radio_def{'gap2_low'} and
($freq >= $radio_def{'gap2_low'}) and
($freq < $radio_def{'gap2_high'})) { $notvalid = TRUE;}
if ($notvalid) {
LogIt(1,"bypassed setting $freq. Outside the range of the radio");
return $ParmErr;
}
$in{'frequency'} = $freq;
}
elsif (($cmd eq 'getvfo') or ($cmd eq 'selvfo')){
}
elsif ($cmd eq 'selmem')  {
$in{'channel'} = $ch;
$in{'sysno'} = $sysno;
}
elsif ($cmd eq 'setmem') {
set_start_stop(\%in);
if ($radio_def{'protocol'} eq 'uniden') {
}### dynamic process
else {
$sysno = 0;
if (scalar @{$database{'system'}} > 2) {### more than one system defined
}
my @sysnos = ();
$in{'sysno'} = 0;
if ($sysno) {
@sysnos = ($sysno);
$in{'sysno'} = \@sysnos;
}
$radio_parms{'sysno'} = $sysno;
foreach my $opt ('clear','skip','keep') {
if ($control{$opt}) {$in{$opt} = TRUE;}
else {$in{$opt} = FALSE;}
}
LogIt(0,"SCANNER l2291:SETMEM preprocess complete");
}### Non-Dynamic Radio process
}
elsif ($cmd eq 'vfo2mem') {
my %localdb = ();
add_a_record(\%localdb,'freq',\%vfo);
$sysno = $vfo{'sysno'};
$radio_parms{'sysno'} = $sysno;
$radio_parms{'database'} = \%localdb;
$in{'firstnum'} = $vfo{'channel'};
$in{'count'} = 1;
$radio_parms{'cmd'} = 'setmem';
}
elsif ($cmd eq 'getmem') {
set_start_stop(\%in);### Start/Stop Ranges
$in{'notrunk'} = TRUE;
$in{'nocomment'} = TRUE;
foreach my $opt ('clear','skip','keep') {
if ($control{$opt}) {$in{$opt} = TRUE;}
else {$in{$opt} = FALSE;}
}
if ($radio_def{'protocol'} eq 'uniden') {$in{'sysno'} = 0;}
else {$in{'sysno'} = $control{'sysno'};}
}
elsif ($cmd eq 'getsig') {
$out{'signal'} = 0;
$out{'rssi'} = 0;
$out{'meter'} = 0;
$out{'dbmv'} = -999;
}
elsif (($cmd eq 'optionset') or ($cmd eq 'setglob')) {
$cmd = 'setglob';
return $NotForModel;
}
elsif ($cmd eq 'getglob') {
}
elsif ($cmd eq 'init') {
}
elsif ($cmd eq 'scan') {
if (!$radio_def{'radioscan'}) {
add_message('Radio Does Not support radio scan mode!',1);
return $NotForModel;
}
}
elsif ($cmd eq 'manual') {
}
elsif ($cmd eq 'vfoinit'){
$radio_parms{'cmd'} = $cmd;
}
elsif ($cmd eq 'autobaud') {
$radio_parms{'cmd'} = $cmd;
}
else {
add_message("Warning! No Pre-Process defined for radio_sync cmd=$cmd",1);
LogIt(1,"RADIO_SYNC:No Pre-Process defined for cmd=$cmd");
return $NotForModel;
}
if (!defined $protocol) {
LogIt(2708,"RADIO_SYNC:Undefined protocol in Radio_Def");
}
$radio_parms{'portobj'} = $portobj;
my $routine = $radio_routine{$protocol};
my $rc = $GoodCode;
if ($routine) {$rc = &$routine($radio_parms{'cmd'},\%radio_parms);}
else {LogIt(2752,"RADIO_SYNC:Radio routine not set for protocol $protocol");}
if ($cmd eq 'autobaud') {return $rc;}
if ($radio_parms{'rsp'}) {
$radio_def{'unresponsive'} = TRUE;
my %req = ('_cmd' => 'radio','connect' => 'unresponsive');
wait_for_command(\%req,1774);
}
else {
if ($radio_def{'unresponsive'}) {
my %req = ('_cmd' => 'radio','connect' => 'connected');
wait_for_command(\%req,1781);
$radio_def{'unresponsive'} = FALSE;
}
}
if ($cmd eq 'init') {
if ($radio_parms{'rc'}) {
my $msg = "Could not connect to radio. May be powered off";
if ($radio_parms{'rc'} == 2) {
$msg = "Could not connect to radio. May be bad model spec ($radio_def{'model'})";
}
add_message($msg,1);
LogIt(1,"RADIO_SYNC:$msg");
if ($portobj) {$portobj->close;}
$portobj = '';
$radio_def{'active'} = FALSE;
my %req = ('_cmd' => 'radio','connect' => 'disconnected');
wait_for_command(\%req,2693);
set_manual_state();
return $CommErr;
}### got an error
else {
my $starttime = Time::HiRes::time();
radio_sync('getsig');
my $stoptime = Time::HiRes::time();
equate(\%out,\%vfo);
print "Line 2849:Modulation returned=>$vfo{'mode'}\n";
$vfo{'_sigtime'} = $stoptime-$starttime;
print "Signal time->$vfo{'_sigtime'}\n";
delete $vfo{'_rdy'};
dply_vfo(2344);
%scan_request = ('_cmd' => 'radio','connect' => 'connected');
tell_gui(2416);
LogIt(0,"Radio Init Connected to $radio_def{'name'}");
LogIt(0,"Radio's maximum channel number=>$radio_def{'maxchan'}");
}## Connection is OK
}#### Init
elsif ($cmd eq 'getsig') {
if (!$radio_parms{'rc'}) {
if (!defined $out{'signal'}) {
print Dumper(%out),"\n";
LogIt(2381,"Undefined 'signal' for $cmd");
}
$vfo{'signal'} = $out{'signal'};
$vfo{'tgid'} = '';
if ($vfo{'signal'}) {
foreach my $key ('sql','frequency','mode','channel','service','tgid','atten','tone','tone_type',
'_rcchan','_radiochan','igrp','rssi','dbmv','meter') {
if (defined $out{$key}) {$vfo{$key} = $out{$key};}
}
if (!$vfo{'mode'}) {
print Dumper(%out),"\n";
LogIt(1,"SCANNER l2984:No 'mode' in out");
$vfo{'mode'} = 'FMn';
}
}
}### no error
else {LogIt(1,"SCANNER l2879:GETSIG returned $radio_parms{'rc'} signal=$out{'signal'}");}
}### getsig post process
elsif ($cmd eq 'selmem') {
}
elsif ($cmd eq 'getmem') {
}
elsif ($cmd eq 'setmem') {
}
elsif ($cmd eq 'vfo2mem') {
}
elsif ($cmd eq 'getvfo')  {
if (!$radio_parms{'rc'}) {
foreach my $key ('frequency','mode','service','atten','preamp','channel') {### maybe others
if (defined $out{$key}) { $vfo{$key} = $out{$key};}
}
}
if (looks_like_number($vfo{'mode'})) {
LogIt(2023,"SCANNER l2923:Call for $cmd returned a numeric modulation for ".
"channel=$vfo{'channel'} freq=$vfo{'frequency'}");
}
}### VFO Getting
elsif ($cmd eq 'setvfo') {
}
elsif ($cmd eq 'getglob') {
}
elsif ($cmd eq 'vfoinit') {
}
elsif ($cmd eq 'manual') {
}
elsif ($cmd eq 'scan') {
}
else {
LogIt(1,"SCANNER_SYNC:No Post-Process defined for radio_sync cmd=$cmd");
}
if ($radio_parms{'rc'}) {
}
return ($radio_parms{'rc'});
}
sub set_start_stop {
my $in = shift @_;
my $firstch = 1;
my $count = 0;
if ($control{'start'}) {$firstch = $control{'start_value'};}
if ($control{'stop'}) {
my $lastch = $control{'stop_value'};
$count = abs($lastch - $firstch);
}
$in->{'firstnum'} = $firstch;
$in->{'count'} = $count;
return $GoodCode;
}
sub scanner_sync {
threads->yield;
while (defined  $gui_request{'_rdy'}) {
my $command = $gui_request{'_cmd'};
if (!$command) {
print Dumper(%gui_request),"\n";
LogIt(2889,"SCANNER_SYNC: Got a gui_request without a command!");
}
if ($command eq 'term') {
$vfo{'signal'} = 0;
$progstate = 'quit';
{### block lock
lock(%gui_request);
%gui_request = ();
}
return $StateChange;
}
elsif ($command eq 'sort') {
$response_pending = TRUE;
my $type = $gui_request{'type'};
my $field = 'frequency';
if ($type eq 'sortc') {$field = 'channel';}
{
lock(%gui_request);
%gui_request = ();
}
set_manual_state();
$database{'freq'}[0]{'index'} = 0;
$database{'freq'}[0]{'frequency'} = 0;
my @sorted =  sort
{
if ($a->{'index'} and $b->{'index'}) {
$a->{$field} <=> $b->{$field};
}
}
@{$database{'freq'}};
clear_database('freq');
%scan_request = ('_cmd' => 'clear', '_dbn' => 'freq');
tell_gui(2937);
foreach my $rec (@sorted) {
if ($rec->{'index'}) {
add_a_record(\%database,'freq',$rec,\&add_shadow);
}
}
$response_pending = FALSE;
return $StateChange;
}
elsif ($command eq 'clear') {
$response_pending = TRUE;
my $dbndx = $gui_request{'_dbn'};
if (!$dbndx) {LogIt(2977,"SCANNER_SYNC: No _DBN key in CLEAR request");}
{
lock(%gui_request);
%gui_request = ();
}
set_manual_state();
clear_database($dbndx);
if ($dbndx eq 'freq') {%lockout = ();}
%scan_request = ('_cmd' => 'clear', '_dbn' => $dbndx);
tell_gui(2937);
$response_pending = FALSE;
threads->yield;
return $StateChange;
}
elsif ($command eq 'statechange') {
if (!defined $gui_request{'state'}) {
print Dumper(%gui_request),"\n";
LogIt(3131,"SCANNER_SYNC: No progstate for state change!");
}
$vfo{'signal'} = 0;
dply_sig(2999);
$progstate = $gui_request{'state'};
{
lock(%gui_request);
%gui_request = ();
}
$response_pending = FALSE;
threads->yield;
return $StateChange;
}
elsif ($command eq 'newradio') {
$response_pending = TRUE;
my $status = 'disconnected';
%scan_request = ('_cmd' => 'radio', 'connect' => $status);
tell_gui(3875);
set_manual_state();
foreach my $datakey (keys %gui_request) {
my $value = $gui_request{$datakey};
if (substr($datakey,0,1) eq '_') {next;}
$radio_def{$datakey} = $value;
}
if ($portobj) {$portobj -> close;}
if ($radio_def{'protocol'} eq 'local') {
$radio_def{'active'} = TRUE;
$status = 'connected';
}
else {
$radio_def{'active'} = FALSE;
$status = 'disconnected';
}
{
lock(%gui_request);
%gui_request = ();
}
%scan_request = ('_cmd' => 'radio', 'connect' => $status);
tell_gui(3875);
$response_pending = FALSE;
return $StateChange;
}
elsif ($command eq 'connect') {
$response_pending = TRUE;
{
lock(%gui_request);
%gui_request = ();
}
if ( $radio_def{'active'}) {
if ($portobj) {$portobj -> close;}
$portobj = '';
$radio_def{'active'} = FALSE;
}
else {
if ($control{'autobaud'}) {
my $rc = radio_sync('autobaud',3299);
if ($rc) {
my $msg = "Could not determine port and/or baud rate. Radio may be powered off";
add_message($msg,1);
%scan_request = ('_cmd' => 'radio','connect' => 'disconnected');
tell_gui(3305);
$response_pending = FALSE;
return $CommErr;
}
%scan_request = ('_cmd' => 'baud', 'rate' => $radio_def{'baudrate'}, 'port' => $radio_def{'port'});
tell_gui(3366);
}
open_serial();
if ($radio_def{'active'}) {radio_sync('init',3126);}
}
set_manual_state();
%scan_request = ('_cmd' => 'radio','connect' => 'disconnected');
if ($radio_def{'active'}) {$scan_request{'connect'} = 'connected';}
tell_gui(3129);
$response_pending = FALSE;
return $StateChange;
}
elsif ($command eq 'sigkill') {
$vfo{'signal'} = 0;
dply_sig(3117);
{
lock(%gui_request);
%gui_request = ();
}
threads->yield;
$response_pending = FALSE;
return $SigKill;
}
elsif ($command eq 'control') {
my $retcode = $GoodCode;
$response_pending = TRUE;
my $ctl = $gui_request{'_ctl'};
my $value = $gui_request{'_value'};
if (!defined $value) {$value = '';}
if (!$ctl) {
print Dumper(%gui_request),"\n";
LogIt(3228,"SCANNER_SYNC: No '_ctl' for control command!");
}
if ($ctl =~ /up/i) {
$value = '+';
$vfo{'direction'} = 1;
}
elsif ($ctl =~ /down/i) {
$value = '-';
$vfo{'direction'} = -1;
}
if ($ctl =~ 'vchan') {  
my $channel = $vfo{'index'};
if (!$channel) {$channel = 1;}
my $max = MAXCHAN;
my $min = 1;
if ($control{'useradio'}) {
$channel = $vfo{'channel'};
if (!defined $channel) {$channel = $radio_def{'origin'};}
$max = $radio_def{'maxchan'};
$min = $radio_def{'origin'};
}
if ($value eq '+') {
$channel = $channel + 1;
if (!looks_like_number($max)) {
print Dumper(%radio_def),"\n";
LogIt(1,"MAX set to =>$max! radiodef=>$radio_def{'max'}");
}
if ($channel > $max) {$channel = $min;}
}
elsif ($value eq '-') {
$channel = $channel - 1;
if ($channel < $min) {$channel = $max;}
}
elsif ($value ne '') {
$channel = $value;
if (($channel > $max) or ($channel < $min)) {
{
lock(%gui_request);
%gui_request = ();
}
$response_pending = FALSE;
return $GoodCode;
}
}
else {
print Dumper(%gui_request),"\n";
LogIt(3134,"SCANNER SYNC:No value for control $ctl");
}
if ($vfo{'signal'}) {
$vfo{'signal'} = 0;
$retcode = $SigKill;
}
if ($progstate eq 'manual') {
if ($control{'useradio'}) {
$vfo{'channel'} = $channel;
if (!defined $channel) {
print Dumper(%radio_def),"\n";
LogIt(3334,"SCANNER_SYNC:Got an undefined channel! max=>$max, min=>$min");
}
radio_sync('selmem',3282);
}
else {
$vfo{'index'} = $channel;
if ($database{'freq'}[$channel]{'index'}) {
foreach my $key ('frequency','mode','atten') {
$vfo{$key} = $database{'freq'}[$channel]{$key};
}
radio_sync('setvfo',3217);
}
else {LogIt(1,"SCANNER l3283:Channel is empty.Cannot transfer");}
}
}### Manual state
elsif ($progstate =~ /scan/) {
LogIt(1,"Scanner L3275:Need operation for Channel   change for SCAN");
}### Scanning
elsif ($progstate eq 'search') {
LogIt(1,"SCANNER l3278: Need operation for Channel   change For SEARCH");
}### Searching
elsif ($progstate eq 'bank') {
LogIt(1,"SCANNER l3281: Need operation for Channel   change for BANK");
}### Bank search
else {
LogIt(1,"SCANNER l3285:Got change in frequency for state $progstate");
}
}### channel control
elsif ($ctl =~ 'vfreq') {
my $freq = $vfo{'frequency'};
if (!$freq) {$freq = 10;}
my $newfreq = $value;
LogIt(0,"SCANNER l3302 (vfreq):step=>$control{'step'} value=>$value freq=$freq");
if ($value eq '+') {
$newfreq = $freq + $control{'step'};
if ($newfreq > $radio_def{'maxfreq'}) {$newfreq = $radio_def{'minfreq'};}
}
elsif ($value eq '-') {
$newfreq = $freq - $control{'step'};
if ($newfreq < $radio_def{'minfreq'}) {$newfreq = $radio_def{'maxfreq'};}
}
elsif ($value ne '') {
$newfreq = $value;
if ( ($newfreq < $radio_def{'minfreq'}) or ($newfreq > $radio_def{'maxfreq'})) {
{
lock(%gui_request);
%gui_request = ();
}
$response_pending = FALSE;
return $GoodCode;
}
}
else {LogIt(3183,"SCANNER SYNC:No value for control 'FREQ'");}
if ($vfo{'signal'}) {
$vfo{'signal'} = 0;
$retcode = $SigKill;
}
if ($progstate eq 'manual') {
$vfo{'frequency'} = $newfreq;
LogIt(0,"Scanner4 l337:issuing RadioSync...");
radio_sync('setvfo',3210);
LogIt(0,"Scanner4 l339:RadioSync Completed...");
}### Manual state
elsif ($progstate =~ /scan/) {
LogIt(1,"Scanner L3268:Need operation for Frequency change for SCAN");
}### Scanning
elsif ($progstate eq 'search') {
LogIt(1,"SCANNER l3263: Need operation for Frequency change For SEARCH");
}### Searching
elsif ($progstate eq 'bank') {
LogIt(1,"SCANNER l3266: Need operation for Frequency change for BANK");
}### Bank search
else {
LogIt(1,"SCANNER l3252:Got change in frequency for state $progstate");
}
}
elsif ($ctl =~ 'vstep') {
LogIt(1,"SCANNER l3259:GUI did not deal with STEP value!");
}
elsif ($ctl =~ 'vmode') {
my $newmode = $value;
my $mode = $vfo{'mode'};
my $freq = $vfo{'frequency'};
if ($newmode ne $mode) {
if ($progstate eq 'manual') {
$vfo{'mode'} = $newmode;
LogIt(0,"Scanner4 l337:issuing RadioSync...");
radio_sync('setvfo',3210);
LogIt(0,"Scanner4 l3601:RadioSync Completed...");
}### Manual state
elsif ($progstate =~ /scan/) {
LogIt(1,"Scanner L3604:Need operation for Mode change for SCAN");
}### Scanning
elsif ($progstate eq 'search') {
LogIt(1,"SCANNER l3607: Need operation for Mode change For SEARCH");
}### Searching
elsif ($progstate eq 'bank') {
LogIt(1,"SCANNER l3610: Need operation for Mode change for BANK");
}### Bank search
else {
LogIt(1,"SCANNER l3614:Got change in Mode for state $progstate");
}
}### Modulation changed
}### Modulation Control
elsif ($ctl eq 'signal') {
if (!$value) {
if ($vfo{'signal'}) {
$vfo{'signal'} = 0;
$retcode = $SigKill;
}
}
else {
}
if ($radio_def{'protocol'} eq 'local') {
$local_vfo{'signal'} = $value;
if (!$local_vfo{'signal'}) {$local_vfo{'sql'} = FALSE;}
$retcode = 0;
}
}
else {
LogIt(1,"SCANNER l3257:Need process for control=>$ctl");
}
{
lock(%gui_request);
%gui_request = ();
}
$response_pending = FALSE;
return $retcode;
}
elsif ($command eq 'open') {
$response_pending = TRUE;
set_manual_state();
$progstate = 'open';
my $filespec = $gui_request{'filespec'};
my $replace = $gui_request{'replace'};
my $chsave = $vfo{'channel'};
if (!$filespec) {LogIt(2951,"SCANNER_SYNC:Missing 'filespec' in GUI request");}
{### release the GUI at this point
lock(%gui_request);
%gui_request = ();
}
threads->yield;
if (!-e $filespec) {add_message("Cannot locate file $filespec",1);}
else {
if ($replace) {
}
my %nextndx = ();
foreach my $rectype (@dblist) {
if (!$database{$rectype}) {$nextndx{$rectype} = 0;}
else {$nextndx{$rectype} = scalar @{$database{$rectype}};}
}
my %dummy = ();
my $channel = 0;
foreach my $dbndx (keys %database) {
foreach my $rec (@{$database{$dbndx}}) {
push @{$dummy{$dbndx}},$rec;
}
}
threads->yield;
my $rc = read_radioctl(\%dummy,$filespec);
if (!$rc or ($rc == 3)) {
%database = ();
%delete_count = ();
foreach my $dbndx (@dblist) {
$delete_count{$dbndx} = 0;
if ($progstate ne 'open') {last;}
foreach my $rec (@{$dummy{$dbndx}})  {
if ($progstate ne 'open') {last;}
if (!$rec ->{'index'}) {next;}
if ($dbndx eq 'freq') {
if ($rec->{'tgid_valid'}) {
next;
}
my $freq = $rec->{'frequency'};
if (!$freq) {next;}
if ($rec->{'channel'} =~ /\-/) {next;}  
if (!$rec->{'valid'}) {
if ($freq) {$lockout{$freq} = TRUE;}
}
else {
if ($freq and $lockout{$freq}) {$rec->{'valid'} = FALSE;}
}
}
if (($dbndx eq 'search')  or ($dbndx eq 'freq')){
if ($rec->{'mode'}) {
my $freq = $rec->{'frequency'};
if (lc($rec->{'mode'}) eq 'auto') {
if ($freq) {$rec->{'mode'} = AutoMode($freq);}
else {$rec->{'mode'} = 'FMn';}
}
if (!$rc_hash{lc(Strip($rec->{'mode'}))}) {$rec->{'mode'} = 'FMn';}
}
else {$rec->{'mode'} = 'FMn';}
}
my $newindex  = add_a_record(\%database,$dbndx,$rec,\&add_shadow);
if ($rec->{'sysno'})     {$vfo{'sysno'} = $rec->{'sysno'};}
if ($rec->{'groupno'})   {$vfo{'groupno'} = $rec->{'groupno'};}
}
dply_vfo(3393);
}### for all indexed databases
foreach my $rec (@{$dummy{'lookup'}}){
my $freq = Strip($rec->{'frequency'});
my $srv = Strip($rec->{'service'});
if ($freq) {$known{$freq + 0} = $srv;}
}
if ($progstate eq 'open') {
add_message("File $filespec read into database",0);
}
else {
add_message("read of $filespec was interrupted by user",1);
}
}### good code from READ_RADIOCTL
else {add_message("Error reading $filespec.",1);}
}### filespec located
LogIt(0,"SCANNER:file read process complete...");
set_manual_state();
$vfo{'channel'} = $chsave;
dply_vfo(3416);
$response_pending = FALSE;
return $StateChange;
}### Open command
elsif ($command eq 'save') {
$response_pending = TRUE;
my $filespec = $gui_request{'filespec'};
if (!$filespec) {LogIt(3338,"SCANNER_SYNC:Missing 'filespec' in GUI request");}
my @parms = ();
foreach my $key ('main','search','lookup') {
if ($key eq 'main') {
if (!$gui_request{'main'}) {
push @parms,'ex_system';
push @parms,'ex_group';
push @parms,'ex_freq';
}
}
else {if (!$gui_request{$key}) {push @parms,"ex_$key";}}
}
push @parms,'sort';
push @parms,'mhz';
push @parms,'log';
if (write_radioctl(\%database,$filespec,@parms)) {
}
{### don't release the GUI until all records have been saved.
lock(%gui_request);
%gui_request = ();
}
$response_pending = FALSE;
}### Save process
elsif ($command eq 'sync') {
my $db_no = $gui_request{'_dbn'};
if (!defined $db_no) {
print Dumper(%gui_request),"\n";
LogIt(3348,"SCANNER_SYNC:No DB_NO in gui_request!");
}
if ($db_no eq 'vfo') {
print Dumper(%gui_request),"\n";
LogIt(3532,"SCANNER_SYNC l3526:Called sync for VFO. Eliminate this call!");
}
my $seq =  $gui_request{'_seq'};
if (!defined $seq) {
print Dumper(%gui_request),"\n";
LogIt(3195,"GUI_REQ:No record number in request!");
}
$response_pending = TRUE;
my $retcode = $GoodCode;
my %shadowed = ();
my %change = ('_dbn' => $db_no, '_seq' => $seq, '_caller' => 'sync');
my %localkeys = %gui_request;
{### Flag the request as complete
lock(%gui_request);
%gui_request = ();
}
foreach my $datakey (keys %localkeys) {
if ($datakey =~ /^\_.*$/) {next;}  
my $value = $localkeys{$datakey};
if ($value) {
foreach my $toggle (keys %mutual_exclusive) {
my $exclude = $mutual_exclusive{$toggle};
if (($datakey eq $toggle) and $database{$db_no}[$seq]{$exclude}) {
$database{$db_no}[$seq]{$exclude} = FALSE;
$change{$exclude} = FALSE;
}
}
}### turning on something
if ($datakey eq 'valid') {
if (!$value) {
if (($progstate ne 'manual') and ($vfo{'signal'})) {
if (
(($db_no eq 'freq') and ($seq eq $vfo{'index'}))  or
(($db_no eq 'search') and ($seq eq $vfo{'bank'}))
) {
$vfo{'signal'} = 0;
dply_sig(3756);
$retcode = $SigKill;
}### active record needs to be turned off
}### Not 'manual' and signal
if ($db_no eq 'freq') {
my $freq = $database{$db_no}[$seq]{'frequency'};
if ($gui_request{'frequency'}) {$freq = $gui_request{'frequency'};}
$lockout{$freq} = TRUE;
}
}### Turning OFF the valid flag
else {
my $freq = $database{$db_no}[$seq]{'frequency'};
if ($gui_request{'frequency'}) {$freq = $gui_request{'frequency'};}
$lockout{$freq} = FALSE;
}
}### Valid flag process
elsif (($datakey eq 'frequency') and ($db_no eq 'freq')) {
if ($vfo{'signal'} and ($seq eq $vfo{'index'})) {
if ($progstate eq 'manual') {
LogIt(1,"SCANNER l3743: Need code for MANUAL state freq change");
}
else {
LogIt(1,"SCANNER l3743: Need code for $progstate state freq change");
}
}
my $freq = $database{$db_no}[$seq]{'frequency'};
if ($lockout{$freq}) {$lockout{$freq} = FALSE;}
my $valid = $database{$db_no}[$seq]{'valid'};
if (defined $gui_request{'valid'}) {$valid = $gui_request{'valid'};}
if ($valid) {
if ($lockout{$value}) {$lockout{$value} = FALSE;}
}
else {$lockout{$value} = TRUE;}
}
elsif ($datakey eq 'sysno') {
if (!$value) {$value = 0;}
if ($value > 0) {
if (!defined $database{'system'}[$value]{'index'}) {
my $errmsg = "System $value does not exist! Change request ignored";
add_message($errmsg,1);
next;
}
}
}### sysno check
elsif ($datakey eq 'groupno') {
if (!$value) {$value = 0;}
if ($value > 0) {
if (!defined $database{'group'}[$value]{'index'}) {
my $errmsg = "Group $value does not exist! Change request ignored";
add_message($errmsg,1);
next;
}
}
}### groupno check
elsif ($datakey eq 'dlyrsm') {
if (looks_like_number($value)) {
$value = int($value);
}
else {
my $errmsg = "DLYRSM $value is NOT a number! Change request ignored";
add_message($errmsg,1);
next;
}
}
$database{$db_no}[$seq]{$datakey} = $value;
$change{$datakey} = $value;
}
if (defined $scan_request{'service'}) {
if ($db_no eq 'group') {
foreach my $rcd (@{$database{'freq'}}) {
if (!$rcd->{'index'}) {next;}
if ($rcd->{'groupno'} == $seq) {
push @{$shadowed{'freq'}},$rcd->{'index'};
}
}
}### Group shadow
elsif ($db_no eq 'system') {
foreach my $db ('freq','group') {
foreach my $rcd (@{$database{$db}}) {
if (!$rcd->{'index'}) {next;}
if ($rcd->{'sysno'} == $seq) {
push @{$shadowed{$db}},$rcd->{'index'};
}
}### for every record in this database
}### freq/group
}### system shadow
}### SERVICE field was changed
add_shadow(\%change);
foreach my $db (keys %shadowed) {
@selected = @{$shadowed{$db}};
%scan_request = ('_dbn' => $db, '_cmd' => 'batch');
if ($db_no eq 'system') {
$scan_request{'systemname'} = $database{'system'}[$seq]{'service'};
}
elsif ($db_no eq 'group') {
$scan_request{'groupname'} = $database{'group'}[$seq]{'service'};
}
else {
LogIt(3868,"SCANNER SYNC:reply error for shadow. No process for database $db_no");
}
tell_gui(3862);
}
$response_pending = FALSE;
if ($retcode) {return $retcode;}
}### data sync command
elsif ($command eq 'create') {
$response_pending = TRUE;
my $dbndx = $gui_request{'_dbn'};
if (!defined $dbndx) {
print Dumper(%gui_request),"\n";
LogIt(3368,"SCANNER_SYNC:Create:No Database name in gui_request!");
}
{
lock(%gui_request);
%gui_request = ();
}
my $sysno = 0;
my $groupno = 0;
if ($database{'system'}[1]{'index'}) {$sysno = 1;}
if ($database{'group'}[1]{'index'}) {$groupno = 1;}
if (!$sysno and (($dbndx eq 'freq') or ($dbndx eq 'group'))) {
my %sysrec = ('service' => 'Default System','valid' => TRUE, 'systemtype' => 'cnv');
$sysno = add_a_record(\%database,'system',\%sysrec,\&add_shadow);
}
if (($dbndx eq 'freq') and (!$groupno)) {
my %grouprec = ('service' => 'Default Group','valid' => TRUE, 'sysno' => $sysno);
$groupno = add_a_record(\%database,'group',\%grouprec,\&add_shadow);
}
my %rec = ();
%scan_request = ('_cmd' => 'update','_dbn' => $dbndx);
foreach my $key (@{$structure{$dbndx}}) {
if ($key =~ /^\_.*$/) {next;}   
my $value = $clear{$key};
if ($key eq 'sysno') {$value = $sysno;}
if ($key eq 'groupno') {$value = $groupno;}
$scan_request{$key} = $value;
$rec{$key} = $value;
}
my $seq = add_a_record(\%database,$dbndx,\%rec,\&add_shadow);
$response_pending = FALSE;
}
elsif ($command eq 'batch') {
$response_pending = TRUE;
%scan_request = ();
my $retcode = $GoodCode;
my $dbndx = $gui_request{'_dbn'};
if (!defined $dbndx) {
print Dumper(%gui_request),"\n";
LogIt(3778,"SCANNER_SYNC_Batch:No Database name in BATCH gui_request!");
}
my $type = $gui_request{'_type'};
if (!defined $type) {
print Dumper(%gui_request),"\n";
LogIt(3778,"SCANNER_SYNC_Batch:No type in BATCH gui_request!");
}
my %localkeys = %gui_request;
{### Flag the request as complete
lock(%gui_request);
%gui_request = ();
}
if (!scalar @selected) {LogIt(1,"SCANNER_SYNC_Batch:No SELECTED records!");}
else {
if ($type eq 'edit') {
%scan_request = ('_cmd' => 'batch','_dbn' => $dbndx);
foreach my $datakey (keys %localkeys) {
if (substr($datakey,0,1) eq '_') {next;}
my $value =  $localkeys{$datakey};
foreach my $recno (@selected) {
if ($vfo{'signal'} and ($recno eq $vfo{'index'})) {
$vfo{'signal'} = 0;
dply_sig(4878);
$retcode = $SigKill;
}
if ($recno < 0) {next;}
$database{$dbndx}[$recno]{$datakey} = $value;
if (($datakey eq 'groupno') or ($datakey eq 'sysno')) {
shadow_sub($dbndx,$recno,\%scan_request);
}
else {
if ($vfo{'signal'} and ($dbndx eq 'freq') and ($recno eq $vfo{'index'})) {
if (($datakey eq 'frequency') or ($datakey eq 'valid')) {
$vfo{'signal'} = 0;
dply_sig(3756);
$retcode = $SigKill;
}
}
}
}### for all records
$scan_request{$datakey} = $value;
}### for All datakeys
}### EDIT
elsif ($type eq 'delete') {
my %affected = ();
foreach my $recno (@selected) {
if ($recno < 0) {next;}
$database{$dbndx}[$recno]{'index'} = 0;
$database{$dbndx}[$recno]{'valid'} = FALSE;
$delete_count{$dbndx}++;
$affected{$recno} = TRUE;
if ($vfo{'signal'} and ($dbndx eq 'freq') and ($recno eq $vfo{'index'})) {
$vfo{'signal'} = 0;
dply_sig(4143);
$retcode = $SigKill;
}
}### database delete records
%scan_request = ('_cmd' => 'delete','_dbn' => $dbndx);
tell_gui(3935);
if (($dbndx eq 'system') or ($dbndx eq 'group')) {
foreach my $changedb ('freq','group') {
@selected = ();
if ($dbndx eq $changedb) {next;}
my $xref = 'sysno';
if ($dbndx eq 'group') {$xref = 'groupno';
}
foreach my $rec (@{$database{$changedb}}) {
if (!$rec->{'index'}) {next;}
my $no = $rec->{$xref};
if (!$no) {next;}
if ($affected{$no}) {
$rec->{$xref} = 0;
push @selected,$rec->{'index'};
}
}
if (scalar @selected) {
%scan_request = ('_cmd' => 'batch','_dbn' => $changedb);
shadow_sub($changedb,$selected[0],\%scan_request);
tell_gui(3966);
}
}## GROUP & FREQ record check
}## GROUP or SYSTEM record deleted
}### delete
elsif ($type eq 'swap') {
}
elsif ($type eq 'xfer') {
}
else {LogIt(1,"SCANNER_SYNC_Batch:No processing for type=$type");}
}### records available
@selected = ();
if ($retcode) {return $retcode;}
}### Batch
elsif ($command eq 'renum') {
$response_pending = TRUE;
set_manual_state();
foreach my $rcd (@{$database{'freq'}}) {
my $index = $rcd->{'index'};
if (!$index) {next;}
$rcd->{'channel'} = $index;
%scan_request = ('_cmd' => 'update','_dbn' => 'freq',
'_seq' => $index, 'channel' => $index);
tell_gui(3358);
}
{### don't release the GUI until all records have been updated
lock(%gui_request);
%gui_request = ();
}
$response_pending = FALSE;
return $StateChange;
}
else  {
LogIt(1,"SCANNER_SYNC:No processing defined for command $command on scanner!");
print Dumper(%gui_request);
{### Flag the request as complete
lock(%gui_request);
%gui_request = ();
}
$response_pending = FALSE;
}
$response_pending = FALSE;
threads->yield;
usleep(20);
$command = '';
if (defined $gui_request{'_cmd'}) {$command = $gui_request{'_cmd'};}
}### waiting for a request
return $GoodCode;
}
sub find_bank {
my $dbndx = shift @_;
my $newbank = $vfo{'bank'};
my $bankrollover = 0;
my $bankvalid = FALSE;
while (!$bankvalid) {
$newbank++;
if ($newbank > $db_channel_max[$dbndx]) {
$newbank = 0;
$bankrollover++;
}
if ($bankrollover > 2) {
$vfo{'bank'} = 0;
$progstate = 'manual';
%scan_request = ('_cmd' => 'progstate', 'state' => $progstate);
tell_gui(3951);
return -1;
}
$bankvalid = $database[$dbndx][$newbank]{'valid'};
}
return $newbank
}
sub mem2vfo {
my $dbndx = shift @_;
my $seq = shift @_;
my $key_ref = shift @_;
if (!defined $database{$dbndx}[$seq]{'channel'}) {
LogIt(3899,"MEM2VFO:Database $dbndx undefined memory channel for index $seq");
}
foreach my $key (@{$structure{$dbndx}}) {
if ($key eq 'signal') {next;}
if ($key eq 'sql') {next;}
if ($key eq 'dlyrsm') {next;}
my $value = $database{$dbndx}[$seq]{$key};
if (!defined $value) {
LogIt(1,"MEM2VFO_l3898:Undefined  $dbndx value for key=>$key ch=>$seq.");
next;
}
$vfo{$key} = $value;
}
$vfo{'_seq'} = $seq;
$vfo{'index'} = $seq;
}
sub vfo2mem {
my $dbndx = shift @_;
my $seq = shift @_;
%scan_request = ('_dbn' => $dbndx, '_seq' => $seq, );
foreach my $key (@{$structure{$dbndx}}) {
my $value = $vfo{$key};
if (!defined $value) {$value = $clear{$key};}
if ($key eq 'dlyrsm') {$value = $control{'dlyrsm'};}
elsif ($key eq 'valid') {
if (($dbndx eq 'freq') and ($vfo{'frequency'} == 0)) {$value = FALSE;}
}
elsif ($key eq 'service') {
if (($dbndx eq 'freq') and $vfo{'tgid'} and (!$database{$dbndx}[$seq]{'service'})) {
$value = $vfo{'systemname'};
}
}
else {
}
$database{$dbndx}[$seq]{$key} = $value;
$scan_request{$key} = $value;
}
tell_gui(4811);
return 0;
}
sub squelch_level {
if (!$vfo{'signal'}) {return TRUE;}
my $cmpr = $control{'squelch'}/10;
if ($vfo{'signal'} < $cmpr) {return TRUE;}
else {return FALSE;}
}
sub tell_gui {
my $cmd = $scan_request{'_cmd'};
my $line    = shift @_;
if (!$line) {$line = '??';}
if (!$cmd) {
my ($pack,$file,$cline) = caller();
print Dumper(%scan_request),"\n";
LogIt(4127,"TELL_GUI:Dumb programmer forgot the command from line $line (caller=>$file:$cline)");
}
if ($progstate eq 'quit') {return;}
if ($cmd eq 'term')      {return;}
usleep(10);
$scan_request{'_rdy'} = TRUE;
my $i=0;
while ($scan_request{'_cmd'}) {
threads->yield;
usleep(30000);
threads->yield;
$i++;
}
%scan_request = ();
return 0;
}
sub add_shadow {
my $ref = shift @_;
my $dbn = $ref->{'_dbn'};
if (!$dbn) {LogIt(4782,"ADD_SHADOW:No _DBN spec");}
my @records = ();
my $cmd = 'update';
if ($ref->{'_seq'}) {@records = ($ref->{'_seq'});}
else {LogIt(4786,"ADD_SHADOW:No _SEQ or _LIST spec!");}
%scan_request = ('_cmd' => $cmd,'_dbn' => $dbn, '_seq'=> $records[0]);
foreach my $key (keys %{$ref}) {
if (substr($key,0,1) eq '_') {next;}
if (!defined $ref->{$key}) {
LogIt(1,"SCANNER l5019:Undefined value for key $key database=>$dbn");
next;
}
$scan_request{$key} = $ref->{$key};
}
if (($dbn eq 'freq') or ($dbn eq 'group')) {
foreach my $recno (@records) {
if (!$database{$dbn}[$recno]{'index'}) {
LogIt(4798,"ADD_SHADOW:Called update for a non-existant record!");
}
shadow_sub($dbn,$recno,\%scan_request);
}### for all records
}### Group or System
tell_gui(4985);
if ($dbn eq 'freq') {
if ($ref->{'_seq'}) { $vfo{'index'} = $ref->{'_seq'};}
if (defined $ref->{'channel'}) {$vfo{'channel'} = $ref->{'channel'};}
}
dply_vfo(4986);
}
sub shadow_sub {
my $dbn = shift @_;
if ($dbn eq 'SYSTEM') {return 0;}
my $recno = shift @_;
my $hash = shift @_;
foreach my $refdb ('system','group') {
if (($refdb eq 'group') and ($dbn ne 'freq')) {next;}
if (($refdb eq 'system') and ($dbn eq 'freq')) {next;}
my $keytype = 'sysno';
if ($refdb eq 'group') {$keytype = 'groupno';}
my $shadow = $refdb . 'name';
my $keyno = $database{$dbn}[$recno]{$keytype};
if ($keyno) {
my $keyname = '';
if ($database{$refdb}[$keyno]{'index'}) {
$keyname = $database{$refdb}[$keyno]{'service'};
}
else {$keyno = 0;}
$database{$dbn}[$recno]{$shadow} = $keyname;
$database{$dbn}[$recno]{$keytype} = $keyno;
$hash->{$keytype} = $keyno;
$hash->{$shadow} = $keyname;
}
else {
print "SCANNER l5197:Keyno for database $dbn record=$recno keytype=$keytype is not defined\n";
$keyno = 0;
}
}### for each database
return 0;
}### Shadow_sub
sub wait_for_sync {
if ($progstate eq 'quit') { return;}
if ($gui_request{'_cmd'} and ($gui_request{'_cmd'} eq 'term')) {return;}
my $line_no = shift @_;
if ($scan_request{'_rdy'}) {
}
if (! defined $scan_request{'_dbn'}) {
exit 4056;
}
if (($scan_request{'_dbn'} ne 'vfo') and (! defined $scan_request{'channel'}) ) {
exit 4061;
}
delete $scan_request{'sql'};
if (!$scan_request{'_cmd'}) {$scan_request{'_cmd'} = 'sync';}
usleep(10);
$scan_request{'_rdy'} = TRUE;
my $i=0;
while ($scan_request{'_cmd'}) {
threads->yield;
usleep(20000);
threads->yield;
$i++;
}
LogIt(0," Scanner Thread: GUI is finished");
%scan_request = ();
}
sub wait_for_command {
if ($progstate eq 'quit') { return;}
if ($gui_request{'_cmd'} and ($gui_request{'_cmd'} eq 'term')) {return;}
my $request = shift @_;
my $line_no = shift @_;
my $cmd = $request->{'_cmd'};
if (!$cmd) {
LogIt(4160,"WAIT_FOR_COMMAND:Missing command!");
}
LogIt(0,"Scanner Sending GUI a request for $request->{'_cmd'}");
my $i=0;
{
lock(%scan_request);
%scan_request = %{$request};
$scan_request{'_rdy'} = TRUE;
}
while ($scan_request{'_cmd'}) {
threads->yield;
usleep(20000);
threads->yield;
$i++;
}
LogIt(0,"Scanner received completion from last request after $i waits");
%scan_request = ();
return 0;
}
sub pop_up {
if ($progstate eq 'quit') {return;}
if ($gui_request{'_cmd'} and ($gui_request{'_cmd'} eq 'term')) {return;}
my $msg = shift @_;
{
lock (%scan_request);
%scan_request = ('_cmd' => 'pop-up','msg' => $msg);
$scan_request{'_rdy'} = TRUE;
}
while ($scan_request{'_cmd'}) {
threads->yield;
usleep(20000);
threads->yield;
print "SCANNER l5476:Waiting for response from GUI\n";
}
}
sub mem2vfo_mode { }
sub dply_vfo {
my $caller = shift @_;
foreach my $dbndx (@dblist) {
if (defined $database{$dbndx}) {
if (!$delete_count{$dbndx}) {$delete_count{$dbndx} = 0;}
$dbcounts{$dbndx} = (scalar @{$database{$dbndx}}) - $delete_count{$dbndx} - 1;
}
else {$dbcounts{$dbndx} = 0;}
}
if (!defined $vfo{'sysno'}) {
LogIt(1,"DPLY_VFO:vfo{sysno} is undefined from caller=>$caller");
$vfo{'sysno'} = 0;
}
%scan_request = ('_dbn' => 'vfo','_cmd' => 'vfodply');
tell_gui(399);
return 0;
}
sub dply_sig {
my $caller = shift @_;
%scan_request = ('_dbn' => 'vfo','_cmd' => 'sigdply');
tell_gui(5003);
return 0;
}
sub set_manual_state {
if ($progstate eq 'manual') {return;}
radio_sync('manual',4559);
$vfo{'signal'} = 0;
dply_sig(2925);
usleep(200000);
$progstate = 'manual';
%scan_request = ('_cmd' => 'statechange', 'state' => $progstate);
tell_gui(4396);
return 0;
}
sub in_scope_variables {
my %in_scope = %{peek_our(1)};
my $lexical  = peek_my(1);
while (my ($var, $ref) = each %$lexical) {
$in_scope{$var} = $ref;
}
return \%in_scope;
}
sub clear_database {
my $dbndx = shift @_;
if (!$dbndx) {LogIt(4758,"SCANNER Clear_database:Called with no dbndx!");}
$database{$dbndx} = ();
$delete_count{$dbndx} = 0;
push @{$database{$dbndx}},{%dummy_record};
$chan_active{$dbndx} = -1;
}
sub record_thread {
my $temp = "/tmp/temp.wav";
LogIt(0,"Started record thread..");
while (TRUE) {
while (!$start_recording and ($progstate ne 'quit') ) {usleep 100;}
if ($progstate eq 'quit') {threads->exit(0);}
my $filename = $record_file;
`parecord --file-format=wav --format=s32be $temp &`;
while ($start_recording) {usleep 100;}
`killall parecord`;
if (-e $filename) {
`sox  "$filename" $temp /tmp/newfile.wav`;
my $rtn = `mv /tmp/newfile.wav "$filename"`;
if ($rtn) {LogIt(1,"SCANNER l5000:'mv' returned $rtn");}
}
else {
my $rtn = `mv /tmp/temp.wav "$filename"`;
if ($rtn) {LogIt(1,"SCANNER l1855:'mv' returned $rtn");}
}
}### do forever
}
